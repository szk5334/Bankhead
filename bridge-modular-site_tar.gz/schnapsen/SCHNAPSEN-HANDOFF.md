# SCHNAPSEN — SESSION HANDOFF

A two-player Schnapsen web app: a real bot you can lose to, a coach that grades every decision, and a
heavily animated card table. Deployed on GitHub Pages (`szk5334.github.io/Bankhe`) as one of three games
(Bridge, Bankhead, Schnapsen) served by a shared `index.html` shell.

Working tree: `/home/claude/work/`. Deployable app: `schnapsen/`. The shell (`index.html`) lives at the
repo root and boots each game via `?module=<game>/adapter.js`.

---

## THE ONE THING TO REMEMBER

**The value in this engine lives strictly outside the exact-endgame solver's horizon.** Every attempt to
improve play or grading *inside* strict play measured zero, because the solver is already optimal there.
Every win — the belief bot, the counterfactual close, the whole grading system — came from the phase
*before* the solvable game begins. Check this first before building anything: if your idea operates inside
the phase the solver already solves, it will measure zero.

---

## PART 1 — THE BOT AND THE RPS INVESTIGATION (early sessions)

### The original question: can the bot roster be a rock-paper-scissors cycle?

**Answer: no. Two-player Schnapsen has no non-transitive bot roster.** Five independent designs — skill
(search depth), heuristic weights, risk objective, opponent modelling, race-aware closing — all produced
ladders, never cycles. The structural reason held every time: **both players solve the endgame exactly,
every deal ends there, and the open phase has no currency with which one strategy can *pay* to punish
another.** RPS needs a rock that is genuinely worse in the abstract and eats scissors anyway; Schnapsen
doesn't sell one.

Method note that matters for anyone revisiting this: **cyclic energy is a ratio and it lies.** When the
gradient (strength) is near zero and every edge sits inside its confidence interval, noise fills the
residual and the "cyclic fraction" runs to ~100%. Five coin-flips score ~100% cyclic. Always gate on
absolute edge size AND significance (`|edge| >= 0.15 gp`, `z >= 1.96`), never the fraction alone.

### GRETA — the flagship bot (shipped)

The strongest bot on the bench, and the first whose edge is not "searches harder." Two mechanisms, both
outside the solver:

1. **She counts what the opponent can still HOLD** (`engine/belief.js`): samples the unseen cards and
   computes `pRuff` (can he trump the ace I'm about to cash?) and `eHon` (how many aces/tens is he still
   sitting on?). Won't lead into a trump she believes is there; won't fear an ace he can't have. Measured
   **+0.139 strength** on the style bench where textbook scores −0.017.
2. **She closes by COMPARISON, not by a fixed bar** (Tompa's framework): asks "is closing *better than
   playing on*?" and computes both expectations via `closeCompare()`, rather than "is closing safe enough?"
   Measured **+0.030 gp/deal, 5/5 seeds, 14,000 paired deals, z=4.83**.

vs Resi (the previous best): **+0.175 gp/deal, 5/5 seeds** — an order of magnitude past the whole prior
skill ladder.

### From Tompa's book (*Winning Schnapsen*, Martin Tompa)

The **beginner guidelines are correct and worth nothing** (adjacency/take-the-higher, declare-marriage-now,
guard-the-ten): all implemented, all verified firing, all measured ~0. They're heuristic substitutes for a
calculation the solver already performs exactly. They ship anyway for the *explanations* they generate.
The **expert framework** (the counterfactual close) is where the money was.

### Bot bench harnesses (all in `tests/`, reusable)
- `bench.mjs` — persona round-robin, paired deals, Hodge decomposition
- `rr.mjs` / `hunt.mjs` / `hunt2.mjs` / `read.mjs` / `obj.mjs` — style/objective/belief searches
- `match.mjs` — Bummerl-level bench (only place a race objective exists)
- `ab.mjs` — A/B a style vs the shipped bot; `duel.mjs` — head-to-head persona ship gate
- `profile.mjs` — builds `engine/profiles.js` (style fingerprints; **stub the file before regenerating**,
  it is a bootstrap dependency of `belief.js`)
- `leak.mjs` — points the grader at bots with designed leaks (the grading calibration test)
- `styles.mjs` — the style/archetype tables
- A/B seeds: 2024, 3024, 4242, 5024, 6024. Five-seed bar for any bidding/judgment change.

---

## PART 2 — THE GRADING SYSTEM (the coach)

### `engine/grade.js` — pricing every decision

Grades each human decision in game points. The hard-won correct design, after two wrong versions:

- **v1** paid a bonus for any decision that couldn't be *proven* wrong. Bad players farmed the grader's
  uncertainty (most decisions are uncertain). Rejected.
- **v2** scored against a fixed "par" constant. The implicit baseline was *a random legal card*, i.e. a
  random player — and a bad human beats random, so terrible play scored positive. Rejected.
- **v3 (shipped): par is THE BOT.** Zero means "you played this decision as well as the machine opposite
  you would have." Above zero you outplayed it; below, it outplayed you. Free (the bot's move is already a
  candidate), calibrated, and gives the difficulty ladder for nothing (zero vs Poldi ≠ zero vs Greta).

Two statistical traps that had to be corrected and must not be reintroduced:
- **Optimizer's curse:** the max over noisy candidate estimates is biased upward, so a naive "best minus
  yours" charges everyone a loss including a perfect player. Fixed with **cross-fitting** (set A chooses
  the reference action, set B prices it) — used for the mistake *naming*.
- **Clamp bias:** clamping loss at zero re-introduces the same upward bias through the back door. The score
  uses the signed edge (`mine.ma − par.ma`), which has no maximum in it.

Calibration (from `tests/leak.mjs`): RANDOM play −185 pts/deal, the par bot ~0, Greta/Fritzl near 0,
xracer/xruffer negative. **Bad play now scores badly** — this was a real bug the user caught ("good grades
on terrible play") and it is fixed.

`gradeDecision` also emits `kind` (the *situation*: ACE_RISK / CLOSE_CALL / MARRIAGE / LEAD / FOLLOW) for
every decision — always, right or wrong — because a bounty needs a denominator (you clear a leak by facing
that situation cleanly, not by dodging it).

### `engine/points.js` — the three scoring layers (pure, tested)

- **Streak**: consecutive clean decisions build ×1.1 → ×2, reset by a *confident* mistake. Multiplies
  gains only — a streak must never make a blunder cost double.
- **Precision**: a bonus for finding the right move when it was HARD — `margin` (gap to the next-best move)
  thin AND `stakes` high. Both, or nothing.
- **Bounty**: your worst habit becomes a +250 target, cleared by playing that KIND of decision cleanly 8×
  (relapse costs a step). The hook for a future adaptive bot that baits your leak.

**One definition of "clean" everywhere** via `verdict(g)`: BEAT / PAR (both at-or-above par, not "bad") /
UNDER (cost you but unprovable — no accusation) / MISTAKE (cost you and named). This unified a real bug the
user caught where the summary said "5 of 6 clean" but the log showed all clean — the UI and the scorer had
two different definitions of the word.

### `tests/points.test.mjs` and `tests/score.test.mjs`
Assert the scoring rules against their stated intent (streaks build/break, fine calls pay, a bounty is
cleared by facing the situation not avoiding it, a bad player is caught out more than a good one).

---

## PART 3 — THE UI (this session's main work)

### Feedback lives in the LOG tab now (latest change)
The end-of-round feedback panel was **removed from the result screen** and moved to the LOG tab
(`PointsSummary` + `ReplayDeck` + `CoachLog` + deal `Log`, in a scrollable `.logscroll` block). The result
screen shows only the deal outcome plus a one-line play-points figure pointing to the LOG.

Critically, career/bounty **banking was split into a headless `useBanking` hook** (`ui/score.jsx`) that
runs regardless of what's displayed — so totals and bounty progress still update even though the panel
moved. `ui/score.jsx` exports: `PointsSummary, ReplayDeck, useBanking, PlayPointsHUD, CoachLog,
useDealGrades, loadCareer`. (`ScoreCard` is gone — do not re-add it.)

### Themes
Seven: casino, **neon** (new: black, monospace, straight lines, loud suit colours), blue, red, black,
cream, text. Registered in BOTH pickers in `App.jsx` and matched by the DOM test's theme regex
`/^[CNBRKWT]$/`. The text theme renders cards as plaintext tokens (suit glyph + rank char).

### Cards
- **Numbered deck** (default ON): prints each card's point value — J→2, Q→3, K→4; ten and ace unchanged.
  Driven by `setRankMode()` / `displayRank()` in `state/constants.js`. **Every place that prints a rank
  must use `displayRank(c.rank)`, never `c.rank`** — this bug hit four surfaces (Play button, trick-status
  line, chat commentary, swap button) and the DOM test now guards the Play button label.
- **Suit-gradient glyphs**: every index, centre letter and pip runs an animated gradient in its suit
  colour, with a per-card twinkle phase seeded from the card id (so the deck twinkles instead of pulsing
  as one object). `background-clip:text`, one composited layer per card.
- **The inlay** (darker panel behind the centre): geometry is a real constraint, not taste. Inset 11.5px
  clears the two-digit "10" index; pips are sized and placed so their EXTENT (not just centre) sits inside
  the inlay. `tests/card.test.mjs` asserts all of this — the regex targets `.br .brcard .inlay`
  specifically so the turn-up's smaller override doesn't fool it.
- The **turn-up** gets a proportional 7px inlay and shrunk glyphs (its card is only 30px wide).

### Animation / particles (all transform+opacity, no canvas, no rAF, React never in the loop)
- `ui/fx.jsx`: glyph **burst** on card select, **comet** from hand to trick on play (the card is held back
  ~170ms so it *arrives with* its trail), and a white/grey **jet** from the Close button into the stock
  (the deck flips to CLOSED only when the jet lands). `tests/fx.test.mjs` guards these.
- `ui/rain.jsx`: **trick rain** — when you win a trick, two layers fall from the divider line (your winning
  suit + all four suits) at different depths/speeds; the parallax is the depth effect. Falls from the top
  (positive delays, in SECONDS — a units bug once scheduled it 900s out). Only on a trick you win.
- **Fireworks** behind the result modal when you win the deal: randomised volleys (re-seeded, not a CSS
  loop — a loop reads as a screensaver within three cycles), colour families, random positions/delays.
- Everything is disabled under `prefers-reduced-motion`.

### Chat / talk dock (`ui/chat.jsx`)
Supabase Realtime transport already existed in `index.html`; the dock surfaces it on the game screen.
Online → chat with opponent; solo → deal commentary. The two feeds are merged **chronologically** (watch
both lists, append what's new in the order noticed — no timestamps to sort by).

### The running 66-score in the log (`ui/log.jsx`)
Every trick/meld line shows the live race to 66, including the fiddly rule that a marriage only counts once
its owner has taken a trick.

---

## PART 4 — LAYOUT (the long-running scroll bug)

**The result screen / play area sizing was the hardest bug of the session — fixed across ~6 attempts.**

Root causes, in the order they were (eventually) found:
1. Flex container as scroll parent — flex distributes height to children instead of overflowing.
2. `height:100%` on the scroll child — resolves against a flex-grown (non-definite) parent, so the box
   grows to fit content and never overflows.
3. **`100dvh` on the root + mobile Chrome's dynamic toolbar** — `dvh` resolves taller than the visible
   area, pushing the tab bar below the fold. This was the deepest cause.

The final, robust structure:
- Root `.br`: `position:fixed; inset:0` (pins to the *visible* viewport, immune to the toolbar).
- `html,body`: `height:100%; overflow:hidden; overscroll-behavior:none` (in `index.html`).
- `.stage`: **CSS grid** `grid-template-rows:auto 1fr auto` (status / screen / tabs). The `1fr` track is a
  DEFINITE box that clamps the middle, so the tab bar row is always on screen.
- `.gscreen`: `min-height:0; overflow:hidden` inside the `1fr` track.
- `.sc-result` and `.logscroll`: `flex:1 1 auto; min-height:0; overflow-y:auto` scrolling blocks.
- `.sctable` (play screen): `min-height:0; overflow-y:auto`; `.sc-mid` has a `min-height` floor scaled to
  card size so the trick cards/turn-up are never crushed when the coach HUD + chat dock consume space.

`tests/dom.test.mjs` has a **scroll guard** that asserts this structure (grid rows, no `display:flex` or
`height:100%` on the scroll container, `min-height:0` through the chain). It failed loudly on regressions.

**HONEST CAVEAT:** there is no real browser in the sandbox, so mobile scroll/layout could not be verified on
a device — only the CSS structure and non-crashing render. The result screen was deliberately made short
(feedback moved to the LOG) so the most important screen shouldn't need to scroll at all. If clipping ever
recurs, the next step is a runtime height-measurement failsafe.

---

## GATE SUITE (all green as of this handoff)

Run from `tests/` after `npm install jsdom @babel/standalone react react-dom`:
- `rules.test.mjs` — 27/27, the rules engine
- `card.test.mjs` — card/inlay/pip geometry (extents, not centres)
- `points.test.mjs` — streak / precision / bounty rules
- `score.test.mjs` — grader calibration (bad player caught more than good)
- `fx.test.mjs` — particles (right suit, staggered trail, never steal a tap)
- `guest.test.mjs` — redaction (bot plays on card backs; can't see your hand)
- `dom.test.mjs` — mounts the real app, plays a full Bummerl, checks themes + the scroll guard

**Build discipline:** `node_modules` is installed only to run tests; it is stripped before building the
tarball (`rm -rf schnapsen/node_modules schnapsen/package*.json`). Always verify the *extracted* tarball's
`css.js` parses — a stray backtick in a CSS comment once closed the template literal and would have shipped
a completely unstyled app. `ui/css.js` is a JS template-literal module: **no backticks in CSS comments,
and `\uXXXX` escapes are invalid — use the literal character.**

---

## KNOWN ISSUES / OPEN THREADS

- **Mobile layout unverified on-device** (no browser in sandbox) — see the caveat above.
- **Greta reads slightly under par in the grader** — because the grader's rollout policy runs with
  `close:false`, so it can't see the value of her closes. Cosmetic, but worth fixing (it makes the best bot
  look slightly sub-par).
- **The container was wiped twice mid-session.** The working tree lives only in the sandbox; the tarball in
  `/mnt/user-data/outputs/` is the sole backup. Keep each download until the next is confirmed.

## NEXT STEPS (highest value first)

1. **The adaptive bot** — the RPS wheel that doesn't exist between bots *does* exist between the bot and
   YOUR mistakes. `belief.js` + `profile.js` + the leak histogram are all in place. Point the profiler at
   the human's play history, feed it to belief-sampling, and have the bot bait your worst leak. Ship gate:
   point it at xracer (a bot with a known giant leak) and confirm it detects and beats him by more than
   Greta does.
2. **More flourish** (ranked): marriage-declaration shower → crossing-66 detonation → trump-exchange swap
   animation → last-trick slow-motion beat → bounty-progress pulse → trick-sweep to the winner's pile.
3. Fix Greta's under-par grader reading (rollout `close:true`).
4. Richer points sources already scoped: the exhausted-stock "endgame exam" (perfectly solvable, so a
   real "that was perfect" bonus), opponent multiplier, "outplayed the machine" bonus.

## STACK / INVARIANTS
- JS/JSX (React 18 UMD via shell), no build step — Babel-standalone transpiles in the browser.
- Cards: `{id, rank, suit}`, rank `"10"` not `"T"`, suits S/H/D/C, seats 0=S/1=W... (see engine).
- Grader parity, redaction (bot never sees your hand), and the geometry/scroll guards are hard gates.
- Tarball built from `/home/claude/work/` to preserve structure; shell at repo root, game in `schnapsen/`.
