/* THE TEST THAT WOULD HAVE CAUGHT IT.
 *
 * The other harness rendered the setup screen and mounted the app — and passed, happily, while the Deal
 * button led straight to a white screen. It never pressed anything. A render test that never clicks is
 * testing that your app can sit still.
 *
 * So this one mounts the real app in a real DOM and *uses* it: presses Deal, plays cards until the deal
 * scores, presses through a whole Bummerl, and opens every tab and the menu on the way. Any React error,
 * any window error, any console.error is a failure. And it asserts it ARRIVED somewhere — "no error" is
 * not the same as "it worked".
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { JSDOM } from "jsdom";
import * as Babel from "@babel/standalone";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const SRC  = path.join(ROOT, "..");

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>',
  { pretendToBeVisual: true, url: "https://example.org/" });
const { window } = dom;
globalThis.window = window;
globalThis.document = window.document;
Object.defineProperty(globalThis, "navigator", { value: window.navigator, configurable: true });
globalThis.HTMLElement = window.HTMLElement;
globalThis.Element = window.Element;
globalThis.Node = window.Node;
globalThis.getComputedStyle = window.getComputedStyle.bind(window);
globalThis.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 0);
globalThis.cancelAnimationFrame = clearTimeout;
window.ResizeObserver = globalThis.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
window.localStorage.setItem("bh_initials", "SZK");     // Deal is gated behind initials

const React = (await import("react")).default;
const RD = await import("react-dom");
const { createRoot } = await import("react-dom/client");
const { act } = await import("react-dom/test-utils");

/* ---- the shell's loader, verbatim ---- */
function jsxRuntime(R){
  const jsx=(t,props,key)=>{ props=props||{}; const cfg={}; for(const k in props) if(k!=="children") cfg[k]=props[k];
    if(key!==undefined) cfg.key=key; const ch=props.children;
    if(ch===undefined) return R.createElement(t,cfg);
    return Array.isArray(ch)?R.createElement(t,cfg,...ch):R.createElement(t,cfg,ch); };
  return { jsx, jsxs:jsx, jsxDEV:jsx, Fragment:R.Fragment };
}
const externalFor=(s)=> s==="react"?React : s==="react-dom"?RD
  : (s==="react/jsx-runtime"||s==="react/jsx-dev-runtime")?jsxRuntime(React) : undefined;
const RE_FROM=/^[ \t]*(?:import|export)\b[^\n]*?\bfrom[ \t]*["']([^"']+)["'][^\n]*$/mg;
const factories={},deps={},cacheM={},fetched={};
function fetchModule(abs){
  if(fetched[abs]) return; fetched[abs]=1;
  const orig=fs.readFileSync(abs,"utf8");
  factories[abs]=new Function("require","module","exports",
    Babel.transform(orig,{presets:[["react",{runtime:"classic"}]],plugins:["transform-modules-commonjs"],filename:path.basename(abs)}).code);
  deps[abs]=Object.create(null); RE_FROM.lastIndex=0; let m;
  while((m=RE_FROM.exec(orig))){ const sp=m[1];
    if(sp.startsWith(".")){ const d=path.resolve(path.dirname(abs),sp); deps[abs][sp]=d; fetchModule(d); }
    else if(externalFor(sp)===undefined) throw new Error("bare import with no external: "+sp); }
}
function requireAbs(abs){
  if(abs in cacheM) return cacheM[abs];
  const mod={exports:{}}; cacheM[abs]=mod.exports;
  factories[abs]((sp)=> sp.startsWith(".") ? requireAbs(deps[abs][sp]) : externalFor(sp), mod, mod.exports);
  return (cacheM[abs]=mod.exports);
}
fetchModule(path.join(SRC,"adapter.js")); requireAbs(path.join(SRC,"adapter.js"));
const GAME = window.GAME;

/* ---- nothing is swallowed ---- */
const errors=[];
console.error = (...a)=>{ const s=a.map(String).join(" "); if(!/not wrapped in act|ReactDOMTestUtils/.test(s)) errors.push(s); };
window.addEventListener("error", e=>errors.push("window.onerror: "+e.message));
const die = (where)=>{ console.log("\n*** "+where+" ***\n"+errors.slice(0,2).join("\n---\n").slice(0,2200)); process.exit(1); };
const fail = (m)=>{ console.log("FAIL: "+m); process.exit(1); };

const el = document.getElementById("root");
await act(async ()=>{ createRoot(el).render(React.createElement(GAME.App)); });

const btns  = ()=> [...el.querySelectorAll("button")];
const findB = (re)=> btns().find(b=>re.test((b.textContent||"").trim()));
const click = async (b)=>{ if(!b) return false; await act(async ()=>{ b.dispatchEvent(new window.MouseEvent("click",{bubbles:true})); }); return true; };
const tick  = async (ms=20)=>{ await act(async ()=>{ await new Promise(r=>setTimeout(r,ms)); }); };
const text  = ()=>{ const c=el.cloneNode(true); c.querySelectorAll("style").forEach(n=>n.remove()); return c.textContent.replace(/\s+/g," "); };

/* 1 — press Deal. */
const deal = findB(/^Deal$/);
if(!deal) fail("no Deal button on the setup screen");

/* SETUP SCROLL GUARD. The shell locks the root hard (height:100%; overflow:hidden) so the fixed play
   screen can pin to the viewport — which freezes the tall, normal-flow setup screen unless the document is
   handed back to normal. The app unlocks height AND overflow off the table and restores them at it. jsdom
   has no layout so we can't test reachability, but we assert the invariant that makes scrolling possible:
   on setup the document is a normal, unlocked page; once at the table it is hard-locked again. */
{
  const b = document.body, h = document.documentElement;
  const snap = ()=> `body{overflow:${b.style.overflow||"?"};height:${b.style.height||"?"}} html{overflow:${h.style.overflow||"?"};height:${h.style.height||"?"}}`;
  // A normal, scrollable page: overflow VISIBLE (auto on <html> self-defeats — it becomes a scroll
  // container that, at height:auto, never overflows) and height AUTO so the body grows past the viewport.
  if(b.style.overflow !== "visible" || h.style.overflow !== "visible")
    fail("setup overflow is not visible — the document will not scroll: "+snap());
  if(b.style.height !== "auto" || h.style.height !== "auto")
    fail("setup height is clamped — the body is pinned to the viewport and cannot scroll: "+snap());
  console.log("setup scroll guard: document is a normal scrollable page ("+snap()+"). ok");
}

await click(deal); await tick(60);
if(document.body.style.overflow !== "hidden" || document.body.style.height !== "100%")
  fail("the play table did not re-lock the document (body overflow="+JSON.stringify(document.body.style.overflow)+
       ", height="+JSON.stringify(document.body.style.height)+") — the fixed root needs a hard-locked body");
if(errors.length) die("CRASH ON DEAL");

/* 2 — did we actually ARRIVE at a table? */
if(!el.querySelector(".sctable")) fail("Deal did not produce a table (.sctable missing)");
const cards = el.querySelectorAll(".sc-hand .brcard").length;
if(cards !== 5) fail("expected 5 cards in hand after the deal, got " + cards);
console.log("Deal \u2192 table, 5 cards in hand. ok");

/* 2b — TAP, TAP. The hand is no longer a gesture: tap a card to select it, tap it again to play it.
 *      Every card is its own button now, so this is just two clicks. */
{
  // If the bot is non-dealer it leads, so wait until the table is actually waiting on us. The footer
  // hint ("Tap a card to pick it up") is gone, so the turn signal is now the hand itself: legal cards
  // become clickable (.brcard.clk) only when it is our move.
  for(let i=0;i<80 && !el.querySelector(".sc-fan .brcard.clk"); i++) await tick(25);
  if(!el.querySelector(".sc-fan .brcard.clk")) fail("the table never handed us the move");

  const playable = [...el.querySelectorAll(".sc-fan .brcard.clk")];
  if(!playable.length) fail("no playable card in the hand");
  const card  = playable[0];
  const named = (card.querySelector(".bc-t") || card).textContent.replace(/\s|\uFE0E/g, "");   // the plaintext token names the card unambiguously
  const handHas = ()=> [...el.querySelectorAll(".sc-fan .brcard")].some(c => (c.querySelector(".bc-t")||c).textContent.replace(/\s|\uFE0E/g,"") === named);

  await act(async ()=>{ card.dispatchEvent(new window.MouseEvent("click", { bubbles:true })); });   // select
  if(errors.length) die("CRASH SELECTING A CARD");
  if(!el.querySelector(".sc-fan .brcard.sel")) fail("tapping a card did not select it");
  if(!handHas()) fail("the selected card left the hand on the FIRST tap");

  // Don't count cards afterwards: the play, the bot's answer, the trick and BOTH DRAWS all land inside one
  // React flush, so the hand is back to five before you can look at it. Name the card; check it left.
  const again = [...el.querySelectorAll(".sc-fan .brcard")].find(c => (c.querySelector(".bc-t")||c).textContent.replace(/\s|\uFE0E/g,"") === named);
  await act(async ()=>{ again.dispatchEvent(new window.MouseEvent("click", { bubbles:true })); });  // play
  if(errors.length) die("CRASH PLAYING A CARD");
  if(handHas()) fail("tapped " + named + " twice but it is still in your hand");

  await tick(60);
  if(errors.length) die("CRASH RESOLVING THE TRICK");
  console.log("tap \u2192 select, tap again \u2192 " + named + " played and the trick resolved. ok");

  // and the hand must CENTRE, not justify: dwindling cards cling to the middle
  const fan = el.querySelector(".sc-fan");
  if(!fan) fail(".sc-fan did not render");
  if(fan.style.justifyContent && fan.style.justifyContent !== "center") fail("the hand is not centred");
}

/* 3 — open every tab and the menu. The Log tab had never been rendered by anything. */
if(!await click(findB(/^Log$/))) fail("no Log tab");
await tick(10); if(errors.length) die("CRASH OPENING THE LOG TAB");
if(!await click(findB(/^(Play|Result)$/))) fail("no Play tab");
await tick(10); if(errors.length) die("CRASH RETURNING TO THE PLAY TAB");
await click(el.querySelector(".gs-menu")); await tick(10);
if(errors.length) die("CRASH OPENING THE MENU");
if(!/Memory mode/.test(text())) fail("the menu did not open");
await click(findB(/^(Close|Resume|Back|Done)$/));
await tick(10);
console.log("Log tab, Play tab, menu: all open without throwing. ok");

/* 3b — EVERY THEME must render a LIVE TABLE, the new plaintext one included. Do this with cards on the
 *      table, not on the setup screen, or you are only testing that the colours parse. */
{
  await click(el.querySelector(".gs-menu")); await tick(10);
  const themeBtns = [...el.querySelectorAll("button")].filter(b => /^[CNBRKWT]$/.test((b.textContent||"").trim()));
  if(themeBtns.length !== 7) fail("expected 7 themes in the menu, found " + themeBtns.length);
  for(const b of themeBtns){
    await click(b); await tick(15);
    if(errors.length) die("CRASH SWITCHING TO THEME " + b.textContent.trim());
  }
  // land on the text theme and check a card is actually rendering as two characters.
  // Index by CONTENT, not by position — adding a theme should not silently retarget this click.
  await click(themeBtns.find(b => b.textContent.trim() === "T")); await tick(15);
  await click(findB(/^(Close|Resume|Back|Done)$/)); await tick(20);
  const root = el.querySelector(".br");
  if(!root || root.getAttribute("data-theme") !== "text") fail("the text theme did not stick");
  const tok = el.querySelector(".sc-fan .brcard .bc-t");
  if(!tok) fail("the text theme renders no plaintext card token");
  const face = tok.textContent.replace(/\s|\uFE0E/g, "");
  /* Two decks now: the faces (A K Q J T) and the numbered one (A 4 3 2 T), which prints each card's
     point value instead of its face. BOTH must stay exactly two characters wide, because that is the
     entire reason the text theme is set in a monospace font — the hand has to line up. */
  if(!/^[\u2660\u2665\u2666\u2663][AKQJT234]$/.test(face))
    fail("plaintext card reads '" + face + "', want a suit glyph then one of A K Q J T 2 3 4");
  if(face.length !== 2) fail("plaintext card '" + face + "' is not two columns wide — the hand will not align");
  console.log("all 7 themes render on a live table \u00b7 text theme card reads " + face + ". ok");
  if(errors.length) die("CRASH IN THE TEXT THEME");

  // and the rest of the Bummerl is now played out IN the text theme, so it is exercised for real
}


/* 4 — play it. Click legal cards and action buttons until the Bummerl is done. */
let plays=0, deals=1, guard=0;
while(guard++ < 5000){
  await tick(10);
  if(errors.length) die("CRASH DURING PLAY");
  if(/wins? the Bummerl/.test(text())) break;

  const next = findB(/^(Next deal|New Bummerl)$/);
  if(next){ if(/Next deal/.test(next.textContent)) deals++; await click(next); continue; }

  const doIt = findB(/^(Play\s|Declare|Close$|Swap)/);
  if(doIt){ await click(doIt); plays++; continue; }

  const card = el.querySelector(".sc-fan .brcard.clk");
  if(card){ await act(async ()=>{ card.dispatchEvent(new window.MouseEvent("click", { bubbles:true })); }); plays++; continue; }
  // nothing to press: it is the bot's move. Wait for it rather than giving up.
}
if(errors.length) die("CRASH DURING PLAY");
if(!/wins? the Bummerl/.test(text())) fail("never reached the end of a Bummerl in "+guard+" steps");
console.log("played "+plays+" actions across "+deals+" deals \u00b7 the Bummerl ended. ok");

/* 5 — the result screen, the score sheet, the high scores. */

/* SCROLL GUARD. The Next-deal button hid behind the tab bar three times, always the same cause: the
   scroll container .sc-result was ALSO a flex column, and a flex parent distributes height to its
   children instead of overflowing — so overflow-y:auto never engaged and the trailing button was
   compressed below the fold. jsdom has no layout so we cannot test reachability directly, but we CAN
   assert the structural invariant: the scroll container must be a block that scrolls, never a flex
   column. If someone reintroduces display:flex here, this fails before it reaches a phone. */
{
  const css = fs.readFileSync(fileURLToPath(new URL("../ui/css.js", import.meta.url)), "utf8");
  const grab = (sel)=>{ const m = css.match(new RegExp("\\.br \\." + sel + "\\{([^}]*)\\}")); return m ? m[1].replace(/\s+/g,"") : null; };

  // The layout guarantee is now a GRID on .stage: rows auto/1fr/auto. The 1fr middle track is a definite
  // box that clamps .gscreen, so the tab bar (the last auto row) is ALWAYS on screen and the scroll area
  // inside .gscreen overflows within its track instead of pushing the tabs off the bottom.
  const stage = grab("stage");
  if(!stage) fail("could not find the .stage rule");
  if(!/display:grid/.test(stage))
    fail(".stage is not a grid — the tab bar is only guaranteed visible when .stage is grid rows auto/1fr/auto");
  if(!/grid-template-rows:auto1frauto/.test(stage))
    fail(".stage grid-template-rows must be auto 1fr auto (status/screen/tabs); got: " + stage);

  const res = grab("sc-result");
  if(!res) fail("could not find the .sc-result rule");
  if(/display:flex/.test(res)) fail(".sc-result is a flex container again — it must be a scrolling block");
  if(!/overflow-y:auto/.test(res)) fail(".sc-result must scroll (overflow-y:auto)");
  if(/height:100%/.test(res)) fail(".sc-result sets height:100% — grows to fit content; let flex+min-height:0 size it");
  for(const sel of ["stage", "gscreen"])
    if(!/min-height:0/.test(grab(sel)||"")) fail("." + sel + " lost min-height:0 — the height chain breaks");
  console.log("scroll guard: .stage grid auto/1fr/auto, .sc-result scrolls, chain intact. ok");
}

const t = text();
for(const must of [[/game points to/,"the game-point award"], [/Cards:/,"the card count"],
                   [/Tricks:/,"the trick count"], [/High scores/,"the high-score table"]])
  if(!must[0].test(t)) fail("result screen is missing " + must[1]);
if(!/SZK/.test(t)) fail("the high-score table did not pick up the lobby initials");

console.log("\nALL GREEN \u2014 Deal works, the deal plays, the Bummerl ends, and the score sheet\nknows who you are. The app has now actually been used, not merely rendered.");
