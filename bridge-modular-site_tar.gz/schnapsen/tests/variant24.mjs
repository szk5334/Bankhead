import { ENG } from "../engine/core.js";
import { RULES, effPts, stockLeft, other } from "../engine/rules.js";
import { decide } from "../engine/bot.js";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
let pass=0, fail=0;
const ok  = (c,m)=> c ? (pass++) : (fail++, console.error("  FAIL:", m));

/* ---------- geometry: the deck the variant promises ---------- */
ENG.setVariant("24");
ok(ENG.getVariant()==="24", "variant flips to 24");
const deck = ENG.makeDeck();
ok(deck.length===24, `deck is 24 (got ${deck.length})`);
ok(ENG.handSize()===6, "hand size 6");
ok(ENG.exchangeRank()==="9", "the exchangeable trump is the 9");
const pts = deck.reduce((s,c)=>s+ENG.val(c),0);
ok(pts===120, `deck still worth 120 (got ${pts})`);
const nines = deck.filter(c=>c.rank==="9");
ok(nines.length===4, "four 9s in the pack");
ok(nines.every(c=>ENG.val(c)===0), "every 9 is worth 0 card points");
ok(nines.every(c=>ENG.power(c)===0), "the 9 is the lowest trick power");

/* the deal itself */
const d0 = RULES.newDeal(0, mulberry(7));
ok(d0.hands[0].length===6 && d0.hands[1].length===6, "both seats hold 6");
ok(stockLeft(d0)===12, `12-card stock at the deal (got ${stockLeft(d0)})`);
ok(!!d0.up, "a turn-up exists");
ok(d0.hands[0].length+d0.hands[1].length+d0.stock.length+1===24, "all 24 accounted for");

/* ---------- full self-play: invariants across many deals ---------- */
function runDeal(seed){
  const rnd = mulberry(seed);
  const d = RULES.newDeal(seed%2, rnd);
  let guard=0;
  while(d.phase==="play"){
    if(++guard>400) return { term:false, d };
    const p=d.turn;
    const dec=decide(d,p,{ brain:"fritzl", rnd, strictClaim:false });
    if(!dec) return { term:false, d };
    const a=dec.action;
    if(a.type==="PLAY"){
      const legal=RULES.legalCards(d,p);
      if(!legal.some(c=>c.id===a.cardId)) return { term:false, d, illegal:true };
      RULES.play(d,p,a.cardId,{});
    } else if(a.type==="MELD"){ RULES.meld(d,p,a.suit,{}); }
    else if(a.type==="EXCHANGE"){ RULES.exchange(d,p); }
    else if(a.type==="CLOSE"){ RULES.close(d,p); }
    else if(a.type==="CLAIM"){ RULES.claim(d,p); }
  }
  return { term:true, d };
}

let terminated=0, illegal=0, sawNineTrick=0, ptViolations=0, winners=[0,0];
const N=400;
for(let g=0; g<N; g++){
  const { term, d, illegal:il } = runDeal(3000+g);
  if(term) terminated++; if(il) illegal++;
  // card points taken can never exceed the 120 in the pack
  if((d.trickPts[0]+d.trickPts[1])>120) ptViolations++;
  if(d.result) winners[d.result.winner]++;
  // did a 9 ever actually get played into a trick? (sanity that low cards flow through)
  if((d.log||[]).some(e=>e.k==="trick" && (e.led?.rank==="9"||e.fol?.rank==="9"))) sawNineTrick++;
}
ok(terminated===N, `all ${N} deals terminated (got ${terminated})`);
ok(illegal===0, `no illegal bot actions (got ${illegal})`);
ok(ptViolations===0, "trick points never exceed 120 in any deal");
ok(sawNineTrick>0, `9s actually enter tricks (in ${sawNineTrick}/${N} deals)`);
ok(winners[0]>0 && winners[1]>0, `both seats win some deals (${winners[0]}/${winners[1]})`);

/* ---------- and classic is untouched by the round-trip ---------- */
ENG.setVariant("classic");
ok(ENG.makeDeck().length===20, "classic still deals 20");
ok(ENG.handSize()===5, "classic hand size back to 5");
ok(ENG.exchangeRank()==="J", "classic exchange is the trump Jack again");
const cd = RULES.newDeal(0, mulberry(1));
ok(stockLeft(cd)===10 && cd.hands[0].length===5, "classic 10-card stock, 5-card hands");

console.log(`\n${pass} passed, ${fail} failed  —  24-card variant`);
process.exit(fail?1:0);
