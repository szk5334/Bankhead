/* =======================================================================
   SCHNAPSEN CORE — 20 cards, French-suited.
   A(11) 10(10) K(4) Q(3) J(2).  Rank A > 10 > K > Q > J.  120 card points in the deck.
   ===================================================================== */

const ENG = (function(){
  const SUITS = ["S","H","D","C"];                 // display order

  /* ------------------------------------------------------------------ VARIANTS
   * Two decks share one engine. CLASSIC is Schnapsen's 20 (five ranks). The TWENTY-FOUR deck adds the
   * 9 as a new LOWEST card worth ZERO card points — so the pack is still 120 points and the race is
   * still to 66, the grader's whole calibration is untouched, and deduction survives (a 12-card stock).
   * The 9's only job is to be a true exit card: a trick you can duck without bleeding points.
   * The card you may swap for the turn-up is the LOWEST trump — the trump Jack in classic, the trump
   * Nine in the 24 deck (the Sixty-Six / Bezique "dix"). */
  const RANK_SETS = {
    classic: ["J","Q","K","10","A"],               // LOW -> HIGH (trick power)
    "24":    ["9","J","Q","K","10","A"],
  };
  const HAND_SIZE = { classic:5, "24":6 };          // cards dealt to each seat
  const LOW_TRUMP = { classic:"J", "24":"9" };       // the exchangeable trump
  let _variant = "classic";
  function setVariant(v){ _variant = RANK_SETS[v] ? v : "classic"; }
  function getVariant(){ return _variant; }
  function ranks(){ return RANK_SETS[_variant]; }
  function handSize(){ return HAND_SIZE[_variant]; }
  function exchangeRank(){ return LOW_TRUMP[_variant]; }

  const RANKVAL = { "9":0, J:1, Q:2, K:3, "10":4, A:5 };  // trick power (9 is the new floor)
  const CARDVAL = { "9":0, J:2, Q:3, K:4, "10":10, A:11 };// card points (the 9 carries none)
  const DECK_POINTS = 120;                          // 4 x (0+2+3+4+10+11) — true for BOTH decks
  const OUT = 66;                                   // the number you are racing to

  let _uid = 1;
  function makeDeck(){
    const d=[];
    for(const s of SUITS) for(const r of ranks()) d.push({ id:_uid++, rank:r, suit:s });
    return d;
  }
  function shuffle(a, rnd){
    a=a.slice(); const R = rnd || Math.random;
    for(let i=a.length-1;i>0;i--){ const j=(R()*(i+1))|0; const t=a[i]; a[i]=a[j]; a[j]=t; }
    return a;
  }
  const val   = (c)=> CARDVAL[c.rank];
  const power = (c)=> RANKVAL[c.rank];
  const key   = (c)=> c.rank+"."+c.suit;

  /* Does `b` (the follow) beat `a` (the lead)? */
  function follows(a, b, trump){
    if(b.suit===a.suit) return power(b) > power(a);
    return b.suit===trump;                         // a trump on a non-trump lead
  }
  /* Winner of a two-card trick. led = the leader's card, fol = the follower's. */
  function trickWinner(led, fol, trump, ledSeat, folSeat){
    return follows(led, fol, trump) ? folSeat : ledSeat;
  }

  /* ---------------- LEGAL PLAYS ----------------
   * While the stock is OPEN you may play anything at all — that freedom is the whole first half of
   * Schnapsen. The moment the stock is exhausted OR closed, three obligations bite, IN ORDER:
   *   1. follow suit,
   *   2. and if you can beat the led card in that suit, you must,
   *   3. if you are void in the led suit you must trump (any trump; there is only one card to beat).
   * Only when you can do none of those may you throw whatever you like.
   */
  function legalFollows(hand, led, trump, strict){
    if(!strict) return hand.slice();
    const suited = hand.filter(c=>c.suit===led.suit);
    if(suited.length){
      const higher = suited.filter(c=>power(c) > power(led));
      // heading the trick is only required among cards of the led suit
      if(led.suit===trump) return higher.length ? higher : suited;
      return higher.length ? higher : suited;
    }
    const trumps = hand.filter(c=>c.suit===trump);
    if(trumps.length) return trumps;
    return hand.slice();
  }
  /* Leading is free, EXCEPT immediately after declaring a marriage: you must lead one of its two cards. */
  function legalLeads(hand, meldSuit){
    if(!meldSuit) return hand.slice();
    return hand.filter(c=>c.suit===meldSuit && (c.rank==="K"||c.rank==="Q"));
  }

  /* Which suits in this hand form a marriage (K + Q of the same suit)? */
  function marriagesIn(hand){
    const out=[];
    for(const su of SUITS){
      const hasK=hand.some(c=>c.suit===su && c.rank==="K");
      const hasQ=hand.some(c=>c.suit===su && c.rank==="Q");
      if(hasK && hasQ) out.push(su);
    }
    return out;
  }
  const meldValue = (suit, trump)=> suit===trump ? 40 : 20;

  const sortDisplay = (hand, trump)=> hand.slice().sort((a,b)=>{
    const ta = a.suit===trump ? 1:0, tb = b.suit===trump ? 1:0;
    if(ta!==tb) return tb-ta;                                  // trumps first
    const sa=SUITS.indexOf(a.suit), sb=SUITS.indexOf(b.suit);
    if(sa!==sb) return sa-sb;
    return power(a)-power(b);                                  // low -> high inside a suit
  });

  const api = { SUITS, RANKVAL, CARDVAL, DECK_POINTS, OUT,
           makeDeck, shuffle, val, power, key, follows, trickWinner,
           legalFollows, legalLeads, marriagesIn, meldValue, sortDisplay,
           setVariant, getVariant, handSize, exchangeRank };
  /* RANKS is a LIVE view of the active variant, so `for(const r of ENG.RANKS)` — the bot's unseen-card
   * enumeration — tracks the deck in play with zero signature changes anywhere downstream. */
  Object.defineProperty(api, "RANKS", { get: ranks, enumerable:true });
  return api;
})();

export { ENG };
