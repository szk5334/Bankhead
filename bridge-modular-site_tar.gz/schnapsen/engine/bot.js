import { ENG } from "./core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "./rules.js";
import { solve } from "./solver.js";
import { beliefSample, readHand } from "./belief.js";

/* =======================================================================
   THE BOT — and, because it is the same code, the teaching hint.

   Schnapsen splits cleanly in half, and so does this file:

     OPEN STOCK   You may play any card at all, and you keep drawing. There is no tree worth searching
                  here — the draws are random and the hand you are optimising for does not exist yet.
                  So: heuristics, and honest ones. Keep your trumps. Do not lead a bare ten into an ace.
                  Trump their aces cheaply. Cash your side aces before they get trumped. Declare every
                  marriage the moment you can.

     STRICT PLAY  Closed or exhausted: no draws, at most five tricks, and the rules collapse the branching
                  to almost nothing. This is a solved game and it is solved exactly (solver.js). When the
                  stock has *exhausted*, the opponent's hand is deducible, so the answer is not an estimate
                  — it is the truth. When the stock was *closed*, five cards are still hidden, so we sample
                  the unseen cards many ways, solve each one exactly, and take the best average.

   The close decision uses the same machinery: sample, close, solve, count how often it comes home. A bot
   that closes on a feeling is a bot that hands you two game points; this one closes when the arithmetic says so.
   ===================================================================== */

/* ---------------- WHAT THIS SEAT ACTUALLY KNOWS ----------------
 *
 * This is the honesty boundary of the whole bot, and it is built from PUBLIC FACTS ONLY — never from the
 * real opponent hand or the real stock, which the bot is not allowed to look at and which, on a guest's
 * machine, are literally card backs anyway (adapter.js redacts them before they ever leave the host).
 *
 * So the unseen set is derived by subtraction: the whole 20-card pack, minus my hand, minus everything
 * that has been played, minus the face-up turn-up. What's left is exactly the opponent's hand plus the
 * face-down stock — which is precisely the ignorance a real player sits in.
 *
 * With one exception, and it is a lovely one: if the opponent took the turn-up (by swapping their trump
 * jack for it, or by drawing it as the last card of the stock), YOU WATCHED THEM DO IT. That card is not
 * a secret and the bot must not re-deal it into the stock when it samples. The log records both events,
 * publicly, so the sampler forces those cards back into their hand where they belong.
 */
const K = (c)=> c.rank + "." + c.suit;

function knowledge(d, p){
  const o = other(p);
  const played = new Set();
  for(const e of (d.log||[])) if(e.k==="trick"){ played.add(K(e.led)); played.add(K(e.fol)); }
  if(d.trick.length) played.add(K(d.trick[0].card));
  const mine = new Set(d.hands[p].map(K));
  const upK  = d.up ? K(d.up) : null;

  const unseen = [];
  let sid = -1;
  for(const su of ENG.SUITS) for(const r of ENG.RANKS){
    const k = r + "." + su;
    if(mine.has(k) || played.has(k) || k===upK) continue;
    unseen.push({ id: sid--, rank:r, suit:su });     // synthetic ids: only ever used inside a sample
  }
  const byKey = new Map(unseen.map(c=>[K(c), c]));

  const forced = [];
  for(const e of (d.log||[])){
    if((e.k==="exchange" || e.k==="tookup") && e.seat===o){
      const c = byKey.get(K(e.card));                // still unseen => still in their hand
      if(c && forced.indexOf(c)===-1) forced.push(c);
    }
  }
  return { unseen, forced, byKey };
}

/* One plausible world: deal the unseen cards into the opponent's hand and the stock. */
function sampleDeal(d, p, rnd){
  const o = other(p);
  const { unseen, forced } = knowledge(d, p);
  const fset = new Set(forced.map(c=>c.id));
  const rest = ENG.shuffle(unseen.filter(c=>!fset.has(c.id)), rnd);

  const oSize = d.hands[o].length;
  const take  = Math.max(0, oSize - forced.length);
  const oppHand = forced.slice(0, oSize).concat(rest.slice(0, take));
  const stock   = rest.slice(take);

  const hands = {}; hands[p] = d.hands[p].slice(); hands[o] = oppHand;
  return {
    ...d,
    hands, stock, trick: d.trick.slice(),
    trickPts: d.trickPts.slice(), meldPts: d.meldPts.slice(), tricksWon: d.tricksWon.slice(),
    meldedSuits: [d.meldedSuits[0].slice(), d.meldedSuits[1].slice()],
    closeSnap: d.closeSnap ? {...d.closeSnap} : null,
    lastTrick: d.lastTrick, reveals: (d.reveals||[]).slice(), log: (d.log||[]).slice(),
  };
}

/* ---------------- open-play heuristics ----------------
 * Every number below is a card-point-ish unit, so they can be added to a marriage's 20 or 40 and mean
 * something. The costs are the important half: what a card is worth LATER, which is why the trump ace
 * costs 24 to spend and a side jack costs nothing. */
/* THE STYLE VECTOR. Eight knobs, each of which is a sentence a bridge player would say.
 * STYLE0 is the identity: every multiplier 1, every offset 0, reproducing the constants this
 * file shipped with. A persona with no style declared plays EXACTLY as it did before. */
const STYLE0 = {
  trumpKeep: 1,   // reluctance to SPEND a trump on a trick        (cost 4 + power*4)
  trumpLead: 1,   // reluctance to LEAD a trump away               (penalty 14 + power*2)
  aceLead:   1,   // eagerness to cash a side ace while it lives   (bonus +10)
  tenFear:   1,   // fear of leading a bare ten into the ace       (penalty -14)
  aceHold:   1,   // reluctance to bury an ace/ten in a lost trick (cost 9 / 5)
  duck:      0,   // flat bias toward NOT winning a trick          (added when losing)
  meld:      1,   // weight on marriages: declaring, and not breaking one up
  barAdj:    0,   // shifts the close bar: negative = braver
  obj:  "linear", // WHAT THE BOT IS MAXIMISING — see OBJ below
  evBar:   0.6,   // the close must also clear this much expected UTILITY
  reads:  null,   // WHO IT THINKS IT IS PLAYING — a style name, or null for "a faceless stranger"
  ruffFear: 0,    // how much a believed trump in his hand stops me cashing my ace
  denyRuff: 0,    // how much a believed trump in his hand makes me lead trumps to kill it
  honFear:  0,    // how much his believed ACES stop me leading my tens into them
  adjWin:   0,    // TOMPA: among ADJACENT winners, take the trick with the HIGHER one
  meldNow:  0,    // TOMPA: show a marriage the moment you can — it is almost never wrong
  tenGuard: 0,    // TOMPA: keep a guard in the suit where you hold a ten and have not seen the ace
  evCompare:0,    // TOMPA: close iff E[gp | close] beats E[gp | play on] — the counterfactual, not a bar
  evMargin: 0,    // how much better closing must be before you do it
};

/* ---------------- THE OBJECTIVE ----------------
 * solver.js returns signed GAME POINTS: 1, 2, 3, and their negatives. That payoff is not linear —
 * the tiers are lumpy and they sit inside a race to 7 — so "how much do I want a 3 rather than a 1,
 * and what will I risk for it" is a real strategic axis, not a flavour.
 *
 * IT ONLY BITES UNDER UNCERTAINTY. In a perfect-information zero-sum game a monotone transform of the
 * payoff cannot change optimal play — minimax commutes with it. So the exhausted-stock solve, which is
 * exact, is objective-INVARIANT, and always will be. What the objective changes is every place we
 * AVERAGE over sampled worlds: the closed-stock play decision, and the close decision itself. That is
 * exactly where a human's risk preference lives too.
 */
const OBJ = {
  linear: (v)=> v,                                   // take the points at their real price
  safe:   (v)=> Math.sign(v),                        // P(win the deal). A 1 is as good as a 3; only the win counts
  tier:   (v)=> v * Math.abs(v),                     // convex: hunt the 2s and the 3s, pay risk to get them
  race:   (v, need)=> v >= 0 ? Math.min(v, need[0])  // points past the finish line are worthless...
                             : -Math.min(-v, need[1]),// ...and so are theirs
};
const objOf = (st, race)=>{
  const f = OBJ[st.obj] || OBJ.linear;
  const need = race ? [Math.max(1, 7-race[0]), Math.max(1, 7-race[1])] : [7,7];
  return (v)=> f(v, need);
};
const styleOf = (s)=> s ? { ...STYLE0, ...s } : STYLE0;

/* ---------------- TOMPA: adjacency ----------------
 * Two of my cards are ADJACENT when no card I have not seen ranks between them (A-10 always; 10-K always;
 * K-Q once the jack... etc — and cards BECOME adjacent as the ones between them get played).
 *
 * Why it matters, and why the bridge instinct is wrong here. Holding A and 10 of a suit, I can win the
 * trick with either. Bridge says win cheap: keep the ace. But whichever one I keep is the master of that
 * suit — nothing outstanding sits between them — so my residual power is IDENTICAL either way, and the
 * ace banks one more point than the ten. The point is free. Take it.
 *
 * Same for 10 and K: keep either, an outstanding ace beats it. So cash the TEN — six extra points now,
 * and the ten is a wasting asset that will fall to that ace eventually anyway.
 *
 * Implemented as a cost, not a special case: the true cost of spending a card is the cost of the LOWEST
 * card in its adjacency run, because that card simply inherits the role of the one I spent. */
function adjRunFloor(d, p, c){
  const mine = d.hands[p].filter(x=>x.suit===c.suit);
  if(mine.length < 2) return c;
  const { unseen } = knowledge(d, p);
  const gap = unseen.filter(x=>x.suit===c.suit).map(x=>ENG.power(x));
  let floor = c;
  for(;;){
    const next = mine.filter(x=>ENG.power(x) < ENG.power(floor))
                     .sort((a,b)=> ENG.power(b)-ENG.power(a))[0];
    if(!next) break;
    // adjacent only if nothing unseen sits strictly between them
    if(gap.some(g=> g > ENG.power(next) && g < ENG.power(floor))) break;
    floor = next;
  }
  return floor;
}
function effCost(d, p, c, st){
  if(!st.adjWin) return cardCost(c, d.trump, st);
  return cardCost(adjRunFloor(d, p, c), d.trump, st);
}

function cardCost(c, trump, st){
  st = st || STYLE0;
  if(c.suit===trump) return (4 + ENG.power(c) * 4) * st.trumpKeep;   // J 8 · Q 12 · K 16 · 10 20 · A 24
  if(c.rank==="A")  return 9 * st.aceHold;
  if(c.rank==="10") return 5 * st.aceHold;
  if(c.rank==="K")  return 1;
  return 0;
}
function leadScore(d, p, c, protectMarriage, st, ctx){
  st = st || STYLE0;
  const pRuff = ctx ? ctx.pRuff : 0;
  const eHon  = ctx ? ctx.eHon  : 1.5;      // 1.5 side honours is roughly what an unread stranger holds
  const hand = d.hands[p], trump = d.trump;
  let s = 0;
  if(protectMarriage && (c.rank==="K"||c.rank==="Q")
     && hand.some(x=>x.id!==c.id && x.suit===c.suit && (x.rank==="K"||x.rank==="Q"))
     && d.meldedSuits[p].indexOf(c.suit)===-1)
    s -= 30 * st.meld;                                  // do not break up a marriage you have not cashed
  if(c.suit===trump){
    /* a trump lead cannot be ruffed. against a man you believe is sitting on trumps waiting to eat your
       aces, leading one is not throwing away your endgame — it is taking away his. */
    s -= (14 + ENG.power(c) * 2) * st.trumpLead * (1 - st.denyRuff * pRuff);
  } else if(c.rank==="A"){
    s += 10 * st.aceLead * (1 - st.ruffFear * pRuff);   // he only beats it with a trump — so: has he got one?
  } else if(c.rank==="10"){
    /* a bare ten walks into the ace — but only if he still HAS the ace. Against a man you have read as
       having cashed everything, your tens are winners; against a hoarder they are gifts. */
    s += hand.some(x=>x.suit===c.suit && x.rank==="A") ? 2
       : -14 * st.tenFear * (1 + st.honFear * (eHon - 1.5));
  } else {
    s += 6 - ENG.val(c);                               // cheap probes: J, then Q, then K
  }
  return s;
}
function followScore(d, p, c, st){
  st = st || STYLE0;
  const led = d.trick[0].card, trump = d.trump;
  const win = ENG.follows(led, c, trump);
  const tv  = ENG.val(led) + ENG.val(c);
  let s = win ? (tv + 3) : -tv + st.duck;               // +3 for the lead and the first draw
  s -= win ? effCost(d, p, c, st) : cardCost(c, trump, st);
  /* TOMPA: an unprotected ten falls to the ace the moment you are forced to follow suit. If I hold a ten
   * and have not seen the ace, the small card beside it is not junk — it is the ten's bodyguard. */
  if(!win && st.tenGuard && c.suit!==trump){
    const suited = d.hands[p].filter(x=>x.suit===c.suit);
    const hasTen = suited.some(x=>x.rank==="10");
    if(hasTen && c.rank!=="10" && suited.length===2){
      const { unseen } = knowledge(d, p);
      const aceOut = unseen.some(x=>x.suit===c.suit && x.rank==="A");
      if(aceOut) s -= 5 * st.tenGuard * (c.rank==="K" ? 1.4 : 1);   // a king is the better bodyguard
    }
  }
  if(!win && c.rank==="10") s -= 6 * st.aceHold;        // never bury a ten under a trick you are losing
  if(!win && c.rank==="A")  s -= 10 * st.aceHold;
  return s;
}

/* ---------------- the close decision ----------------
 * Sample the hidden cards, close, solve, and see how often it comes home. A close that fails costs 2 or
 * 3 game points, so the bar is high and it is set by ARITHMETIC, not by how nice the trumps look. */
/* ---------------- TOMPA: the counterfactual ----------------
 * Tompa never asks "is closing good enough?" He asks "is closing BETTER THAN NOT CLOSING?" — and works
 * out both expectations. Two thirds of a game point from closing is a fine outcome when the alternative
 * is losing one; it is a poor one when the alternative is winning one.
 *
 * Our bot has never computed the right-hand side of that comparison. It measured E[gp | close] and then
 * held it up against a CONSTANT (a 0.85 win-rate bar). So it cannot tell a good close from a desperate
 * one: it is equally deaf to the close it should make from a hopeless position and the close it should
 * decline from a winning one.
 *
 * So: sample a world, and play it BOTH ways. Close it and solve it exactly. Or leave it open and roll it
 * out under the bot's own policy. Then compare. (The rollout policy cannot close again — otherwise this
 * recurses — so E[play on] is mildly pessimistic, and the bot's bias is toward the honest direction:
 * it will not talk itself into a close on the strength of a rollout that closed for it later.) */
const cloneDeal = (w)=> ({
  ...w,
  hands: { 0: w.hands[0].slice(), 1: w.hands[1].slice() },
  stock: w.stock.slice(), trick: w.trick.slice(),
  trickPts: w.trickPts.slice(), meldPts: w.meldPts.slice(), tricksWon: w.tricksWon.slice(),
  meldedSuits: [ w.meldedSuits[0].slice(), w.meldedSuits[1].slice() ],
  closeSnap: w.closeSnap ? {...w.closeSnap} : null,
  reveals: (w.reveals||[]).slice(), log: (w.log||[]).slice(),
});
const ROLLOUT = { samples: 4, solve: true, noise: 0, close: false, bar: 1.1 };   // never closes: no recursion
function rollout(w, me, rnd){
  let g = 0;
  while(w.phase === "play" && g++ < 60){
    const q = w.turn;
    const dec = decide(w, q, { brain:"fritzl", skill:ROLLOUT, style:{}, rnd });
    if(!dec) break;
    const a = dec.action;
    if(a.type==="PLAY")          RULES.play(w, q, a.cardId, {});
    else if(a.type==="MELD")     RULES.meld(w, q, a.suit, {});
    else if(a.type==="EXCHANGE") RULES.exchange(w, q);
    else if(a.type==="CLAIM")    RULES.claim(w, q);
    else break;
  }
  if(!w.result) return 0;
  return w.result.winner === me ? w.result.gp : -w.result.gp;
}
function closeCompare(d, p, samples, cap, rnd, U, who){
  let n=0, uClose=0, uPlay=0, wins=0;
  for(let i=0;i<samples;i++){
    const w = beliefSample(sampleDeal, who, d, p, rnd, 4);
    const a = cloneDeal(w);  RULES.close(a, p);
    const r = solve(a, p, cap);
    if(r===null) continue;
    const b = cloneDeal(w);
    const v = rollout(b, p, rnd);                       // the SAME world, played on instead
    n++; uClose += U(r.value); uPlay += U(v); if(r.value > 0) wins++;
  }
  if(!n) return null;
  return { evClose: uClose/n, evPlay: uPlay/n, wr: wins/n, n };
}

function closeStudy(d, p, samples, cap, rnd, U, who){
  U = U || ((v)=>v);
  let n=0, sum=0, usum=0, wins=0;
  for(let i=0;i<samples;i++){
    const sd = beliefSample(sampleDeal, who, d, p, rnd, 4);
    RULES.close(sd, p);
    const r = solve(sd, p, cap);
    if(r===null) continue;
    n++; sum += r.value; usum += U(r.value); if(r.value > 0) wins++;
  }
  if(!n) return null;
  return { ev: sum/n, uev: usum/n, wr: wins/n, n };
}

/* GRETA. The first bot on this bench whose edge is not "searches harder". She does two things none of
 * the others do, and both of them live OUTSIDE the endgame solver — which is the only place left where
 * there was anything to win:
 *
 *   1. She counts. Not the cards that have been played — they all do that — but what he can still HOLD:
 *      the chance he can ruff the ace she is about to cash, and how many aces and tens are still in his
 *      hand. She will not lead into a trump she believes is there, and she will not fear an ace he cannot
 *      have.  (+0.139 on the style bench, where textbook scores -0.017.)
 *
 *   2. She closes by COMPARISON, not by bar. Every other bot on this bench asks "is closing safe enough?"
 *      and checks the answer against a fixed number. Greta asks Tompa's question — "is closing BETTER than
 *      playing on?" — and works out both sides. She will close from a hopeless position that the others
 *      would nurse, and decline a close from a winning one that they would grab.
 *      (+0.030 gp/deal over resi's rule, positive on all five seeds, 14,000 paired deals.)
 *
 * Plus Tompa's small correct habits, which are worth almost nothing in points and a great deal in
 * explanations: take with the higher of two adjacent cards, show the marriage at once, guard the bare ten. */
const GRETA = {
  reads:"_base", ruffFear:0.9, denyRuff:0.7, honFear:0.9,   // count what he can still hold
  evCompare:1, evMargin:0.15,                                // close iff it beats playing on
  adjWin:1, meldNow:1, tenGuard:1,                           // the small correct habits
};
const SKILL = {
  poldi:  { close:false, samples:0,  solve:false, noise:0.45 },
  ignaz:  { close:true,  samples:12, solve:true,  noise:0.10, bar:0.92 },
  fritzl: { close:true,  samples:18, solve:true,  noise:0.04, bar:0.85 },
  vroni:  { close:true,  samples:20, solve:true,  noise:0.04, bar:0.68 },   // gambles on the close
  resi:   { close:true,  samples:28, solve:true,  noise:0,    bar:0.78 },
  greta:  { close:true,  samples:28, solve:true,  noise:0,    bar:0.78, style: GRETA },
};
const skillOf = (brain)=> SKILL[brain] || SKILL.fritzl;

const G = { S:"\u2660\uFE0E", H:"\u2665\uFE0E", D:"\u2666\uFE0E", C:"\u2663\uFE0E" };
const nameOf = (c)=> c.rank + G[c.suit];

/* ---------------- the decision ----------------
 * Returns { action, why } — the SAME object whether it is driving a bot or lighting up the human's hint.
 * One brain, one explanation; a hint that disagreed with how the bots actually play would be a lie.
 */
function decide(d, p, opts){
  opts = opts || {};
  const sk = opts.skill ? { ...skillOf(opts.brain || "fritzl"), ...opts.skill } : skillOf(opts.brain || "fritzl");
  const st = styleOf(opts.style || skillOf(opts.brain || "fritzl").style);
  const U  = objOf(st, opts.race);          // opts.race = [myGamePoints, theirGamePoints] in the Bummerl
  const rnd = opts.rnd || Math.random;
  /* the read: costs ten shuffles, and only when the bot actually has an opinion to act on */
  const ctx = (st.reads && (st.ruffFear || st.denyRuff || st.honFear) && !RULES.isStrict(d))
    ? readHand(sampleDeal, st.reads, d, p, rnd, 10) : null;
  const strict = isStrict(d);
  const onLead = d.trick.length===0;
  const me = effPts(d, p), them = effPts(d, other(p));

  /* --- STRICT CLAIMING: if the app is not counting for you, you must say it yourself --- */
  if(opts.strictClaim && RULES.canClaim(d,p) && me >= RULES.OUT)
    return { action:{type:"CLAIM", seat:p}, why:`You are on ${me}. Declare it — the deal is over.` };

  if(onLead){
    /* --- the trump jack for the turn-up: a free upgrade, and it is always right --- */
    if(RULES.canExchange(d, p))
      return { action:{type:"EXCHANGE", seat:p},
               why:`Swap your lowest trump for the turn-up ${nameOf(d.up)} — a better trump for your worst one, and it costs you nothing.` };

    /* --- close? --- */
    if(RULES.canClose(d, p) && sk.close){
      const trumps = d.hands[p].filter(c=>c.suit===d.trump).length;
      const worth = me >= 22 || trumps >= 3;                       // don't burn cycles on hopeless closes
      if(worth){
        if(st.evCompare){
          const cc = closeCompare(d, p, sk.samples, 40000, rnd, U, st.reads);
          if(cc && cc.evClose > cc.evPlay + st.evMargin){
            return { action:{type:"CLOSE", seat:p},
                     why:`Close. Closing here is worth ${cc.evClose.toFixed(2)} game points on average; playing on is worth ${cc.evPlay.toFixed(2)}. It is not that closing is safe — it is that it is BETTER than the alternative.` };
          }
        } else {
          const cs = closeStudy(d, p, sk.samples, 40000, rnd, U, st.reads);
          if(cs && cs.wr >= (sk.bar + st.barAdj) && cs.uev > st.evBar){
            return { action:{type:"CLOSE", seat:p},
                     why:`Close. From here you make 66 in ${Math.round(cs.wr*100)}% of the ways the hidden cards can lie — and closing now scores you against their ${them} points, not against whatever they scrape together later.` };
          }
        }
      }
    }

    /* --- the lead (marriages are candidates, not an afterthought) --- */
    const melds = RULES.meldOptions(d, p);
    const meldable = {}; for(const m of melds) meldable[m.suit] = m.value;

    if(strict && sk.solve){
      const r = solveHere(d, p, sk, rnd, U, st.reads);
      if(r){
        const c = r.card;
        if(meldable[c.suit] && (c.rank==="K"||c.rank==="Q") && !d.meldSuit)
          return { action:{type:"MELD", seat:p, suit:c.suit},
                   why:`Declare the ${meldable[c.suit]===40?"royal marriage":"marriage"} in ${G[c.suit]} — ${meldable[c.suit]} points, and you have to lead one of them anyway.` };
        return { action:{type:"PLAY", seat:p, cardId:c.id}, why: solveWhy(r, d, p) };
      }
    }

    // after a declaration you must lead the K or the Q — lead the KING, it wins more often
    if(d.meldSuit){
      const opts2 = ENG.legalLeads(d.hands[p], d.meldSuit);
      const k = opts2.find(c=>c.rank==="K") || opts2[0];
      return { action:{type:"PLAY", seat:p, cardId:k.id},
               why:`You declared ${G[d.meldSuit]} — lead the king. It is the half of the marriage that wins the trick.` };
    }

    /* TOMPA: show a marriage at the earliest opportunity. With five cards you will not keep it intact for
     * long, and a marriage you are still holding when the deal ends is worth exactly nothing. */
    if(st.meldNow && melds.length){
      const m = melds.slice().sort((a,b)=> b.value - a.value)[0];
      return { action:{type:"MELD", seat:p, suit:m.suit},
               why:`Declare the ${m.value===40?"royal marriage":"marriage"} in ${G[m.suit]} — ${m.value} points, banked now. A marriage you are still holding at the end is worth nothing.` };
    }

    let best=null, bestS=-Infinity, bestMeld=null;
    for(const c of d.hands[p]){
      const plain = leadScore(d, p, c, true, st, ctx) + noise(sk, rnd);
      if(plain > bestS){ bestS=plain; best=c; bestMeld=null; }
      if(meldable[c.suit] && (c.rank==="K"||c.rank==="Q")){
        const withMeld = leadScore(d, p, c, false, st, ctx) + meldable[c.suit] * 0.8 * st.meld + noise(sk, rnd);
        if(withMeld > bestS){ bestS=withMeld; best=c; bestMeld=c.suit; }
      }
    }
    if(bestMeld)
      return { action:{type:"MELD", seat:p, suit:bestMeld},
               why:`Declare the ${meldable[bestMeld]===40?"royal marriage":"marriage"} in ${G[bestMeld]} — ${meldable[bestMeld]} points for free. Declare them the moment you can; a marriage you are still holding at the end is worth nothing.` };
    return { action:{type:"PLAY", seat:p, cardId:best.id}, why: leadWhy(d, p, best) };
  }

  /* ---------------- following ---------------- */
  const legal = RULES.legalCards(d, p);
  if(!legal.length) return null;

  if(strict && sk.solve){
    const r = solveHere(d, p, sk, rnd, U, st.reads);
    if(r) return { action:{type:"PLAY", seat:p, cardId:r.card.id}, why: solveWhy(r, d, p) };
  }

  // taking the trick right now would take you out — do it, and do it with the cheapest card that works
  const led = d.trick[0].card;
  const winners = legal.filter(c=>ENG.follows(led, c, d.trump));
  if(winners.length){
    const gain = ENG.val(led);
    if(me + gain + minSelf(winners) >= RULES.OUT){
      const cheap = winners.slice().sort((a,b)=> cardCost(a,d.trump,st)-cardCost(b,d.trump,st) || ENG.power(a)-ENG.power(b))[0];
      if(me + gain + ENG.val(cheap) >= RULES.OUT)
        return { action:{type:"PLAY", seat:p, cardId:cheap.id},
                 why:`Take it with ${nameOf(cheap)}. That trick is worth ${gain + ENG.val(cheap)} and puts you on ${me + gain + ENG.val(cheap)} — over 66, and the deal is yours.` };
    }
  }

  let best=null, bestS=-Infinity;
  for(const c of legal){
    const sc = followScore(d, p, c, st) + noise(sk, rnd);
    if(sc > bestS){ bestS=sc; best=c; }
  }
  return { action:{type:"PLAY", seat:p, cardId:best.id}, why: followWhy(d, p, best) };
}
const minSelf = (cards)=> Math.min.apply(null, cards.map(c=>ENG.val(c)));
const noise = (sk, rnd)=> sk.noise ? (rnd()-0.5) * sk.noise * 30 : 0;

/* Exhausted stock => the opponent's hand is DEDUCIBLE, so one sample IS the truth and one solve is exact.
 * Closed stock => five cards are still hidden, so solve many worlds and take the best average. */
function solveHere(d, p, sk, rnd, U, who){
  U = U || ((v)=>v);
  const exact = !d.closed && stockLeft(d)===0;
  if(exact){
    const sd = sampleDeal(d, p, rnd);          // with nothing hidden this is deterministic
    const r = solve(sd, p, 200000);
    return r ? { ...r, exact:true } : null;
  }
  const N = Math.max(6, sk.samples||12);
  const tally = new Map();
  let any=false;
  for(let i=0;i<N;i++){
    const sd = beliefSample(sampleDeal, who, d, p, rnd, 4);   // worlds the READ says are plausible
    const r = solve(sd, p, 40000);
    if(!r) continue;
    any=true;
    for(const m of r.moves){
      const t = tally.get(m.card.id) || { card:m.card, sum:0, n:0 };
      t.sum += U(m.value); t.n++; tally.set(m.card.id, t);   // utility FIRST, then average — the whole point
    }
  }
  if(!any) return null;
  const moves = Array.from(tally.values())
    .map(t=>({ card:t.card, value: t.sum/t.n }))
    .sort((a,b)=> b.value - a.value);
  return { card: moves[0].card, value: moves[0].value, moves, exact:false };
}

/* ---------------- saying why ---------------- */
function solveWhy(r, d, p){
  const c = r.card;
  const v = r.value;
  const alt = r.moves && r.moves.length>1 ? r.moves[r.moves.length-1] : null;
  const verdict = v > 0 ? `wins the deal (${v > 0 ? "+"+Math.round(v*10)/10 : v} game points)`
                : v < 0 ? `loses it by the least (${Math.round(v*10)/10})`
                : "is level";
  if(r.exact){
    let s = `The stock is gone, so every card is accounted for — this is not a guess. ${nameOf(c)} ${verdict}.`;
    if(alt && alt.value < v) s += ` ${nameOf(alt.card)} would ${alt.value>0?"still win but for less":"hand them the deal"}.`;
    return s;
  }
  return `Playing it out against every way the hidden cards can lie, ${nameOf(c)} averages ${Math.round(v*100)/100} game points — the best of your options.`;
}
function leadWhy(d, p, c){
  const trump = d.trump;
  if(c.suit===trump) return `Lead the trump ${nameOf(c)} — you are drawing their trumps so nothing of yours gets ruffed later.`;
  if(c.rank==="A")  return `Lead ${nameOf(c)}. Only a trump beats an ace, and every trick you wait is a trick it might get trumped in. Cash it while the stock is still open.`;
  if(c.rank==="10") return `Lead ${nameOf(c)} — you hold the ace behind it, so the ten is safe.`;
  return `Lead ${nameOf(c)} — cheap. While the stock is open there is no obligation to follow suit, so a low lead costs you almost nothing and makes THEM spend something.`;
}
function followWhy(d, p, c){
  const led = d.trick[0].card;
  const win = ENG.follows(led, c, d.trump);
  const tv = ENG.val(led) + ENG.val(c);
  if(win && c.suit===d.trump && led.suit!==d.trump)
    return `Trump it with ${nameOf(c)}. Their ${nameOf(led)} is worth ${ENG.val(led)} — take it with the cheapest trump that does the job and you bank ${tv} for almost nothing.`;
  if(win) return `${nameOf(c)} takes it: ${tv} points, and you keep the lead (and draw first).`;
  if(ENG.val(c) <= 3) return `You cannot win this cheaply, so throw ${nameOf(c)} away. Duck it — give them the ${ENG.val(led)} and keep your ammunition.`;
  return `Nothing here wins without spending too much. ${nameOf(c)} is the cheapest thing you can bear to lose.`;
}

const BOT = { decide, sampleDeal, closeStudy, leadScore, followScore, cardCost, solveHere, SKILL, STYLE0, styleOf, OBJ };
export { BOT, decide, sampleDeal, closeStudy, STYLE0, styleOf };
export const __sample = sampleDeal;   // test hook: lets the guest test prove the endgame deduction is exact
