import { ENG } from "./core.js";

/* =======================================================================
   RULES — one deal of Schnapsen, as a state machine.

   The deal object (the part the engine owns):

     trump        "S"|"H"|"D"|"C"
     up           the face-up trump card (conceptually the LAST card of the stock), or null once drawn
     stock        the face-DOWN cards, stock[0] = next to draw.  total left = stock.length + (up?1:0)
     hands        {0:[card], 1:[card]}
     trick        [] | [{seat,card}]         (at most one entry — the lead — before it resolves)
     turn         seat to act
     lead         seat on lead for this trick
     closed       bool          — someone flipped the turn-up
     closedBy     seat|null
     closeSnap    {pts,tricks}  — the OPPONENT's state at the moment of closing (this is what they score by)
     meldSuit     suit|null     — you just declared; you must now lead its K or Q
     meldedSuits  [Set,Set]     — a marriage may only be declared once
     reveals      [{seat,id}]   — cards PUBLICLY known to be in a hand (the turn-up, however it was taken)
     trickPts     [n,n]         — points taken in tricks
     meldPts      [n,n]         — points declared (they only COUNT once you have won a trick)
     tricksWon    [n,n]
     phase        "play" | "scored"

   THE ONE NON-OBVIOUS RULE, and everything downstream depends on it:
   marriage points are worthless until you win a trick — so a player's real score is
   `effPts`, never `trickPts + meldPts`.
   ===================================================================== */

const OUT = ENG.OUT;
const other = (p)=> p^1;

/* A player's score AS IT COUNTS. Melds are provisional: 40 declared with no trick yet is 0. */
function effPts(d, p){ return d.trickPts[p] + (d.tricksWon[p] > 0 ? d.meldPts[p] : 0); }
/* The stock is "open" until it runs dry or someone closes it. Strict play begins the instant it isn't. */
function stockLeft(d){ return d.stock.length + (d.up ? 1 : 0); }
function isStrict(d){ return d.closed || stockLeft(d)===0; }

function newDeal(dealer, rnd){
  const h = ENG.handSize();                          // 5 (classic) or 6 (24-card)
  const deck = ENG.shuffle(ENG.makeDeck(), rnd);
  const hands = { 0:deck.slice(0,h), 1:deck.slice(h,2*h) };
  const up = deck[2*h];
  const stock = deck.slice(2*h+1);                    // classic 9 face-down, 24-card 11
  return {
    trump: up.suit, up, stock, hands,
    trick: [], turn: other(dealer), lead: other(dealer),   // forehand (non-dealer) leads
    closed:false, closedBy:null, closeSnap:null,
    meldSuit:null, meldedSuits:[[],[]],
    trickPts:[0,0], meldPts:[0,0], tricksWon:[0,0],
    lastTrick:null, dealer, phase:"play", result:null,
    reveals:[], log:[],
  };
}

/* ---------------- what may I do right now? ---------------- */
function canExchange(d, p){
  if(d.phase!=="play" || d.turn!==p || d.trick.length) return false;
  if(d.closed || !d.up || d.meldSuit) return false;
  return d.hands[p].some(c=>c.suit===d.trump && c.rank===ENG.exchangeRank());
}
function canClose(d, p){
  if(d.phase!=="play" || d.turn!==p || d.trick.length) return false;
  return !d.closed && !!d.up && !d.meldSuit;
}
function meldOptions(d, p){
  if(d.phase!=="play" || d.turn!==p || d.trick.length || d.meldSuit) return [];
  return ENG.marriagesIn(d.hands[p])
    .filter(su => d.meldedSuits[p].indexOf(su)===-1)
    .map(su => ({ suit:su, value: ENG.meldValue(su, d.trump) }));
}
function canClaim(d, p){
  return d.phase==="play" && d.turn===p && d.trick.length===0;
}
function legalCards(d, p){
  if(d.phase!=="play" || d.turn!==p) return [];
  if(d.trick.length===0) return ENG.legalLeads(d.hands[p], d.meldSuit);
  return ENG.legalFollows(d.hands[p], d.trick[0].card, d.trump, isStrict(d));
}

/* ---------------- the moves ---------------- */
function exchange(d, p){
  if(!canExchange(d,p)) return d;
  const j = d.hands[p].find(c=>c.suit===d.trump && c.rank===ENG.exchangeRank());
  const upc = d.up;
  d.hands[p] = d.hands[p].filter(c=>c.id!==j.id).concat([upc]);
  d.up = j;
  /* Your opponent WATCHED you take that card. It is not a secret, and a bot that re-deals it into the
   * face-down stock when it samples is fooling itself. Record every public acquisition of the turn-up. */
  d.reveals = d.reveals.concat([{ seat:p, id:upc.id }]);
  d.log = (d.log||[]).concat([{ k:"exchange", seat:p, card:upc, gave:j }]);
  return d;
}
function close(d, p){
  if(!canClose(d,p)) return d;
  const o = other(p);
  d.closed = true; d.closedBy = p;
  /* THE SNAPSHOT. A closer is scored against where the opponent stood WHEN THE STOCK WAS CLOSED, not
   * where they end up — so shutting someone out and then letting them scrape a trick back still pays 3.
   * It is also what they pay if the close fails. Take it here, once, and never recompute it. */
  d.closeSnap = { pts: effPts(d,o), tricks: d.tricksWon[o] };
  d.log = (d.log||[]).concat([{ k:"close", seat:p, oppPts:d.closeSnap.pts, oppTricks:d.closeSnap.tricks }]);
  return d;
}
function meld(d, p, suit, opts){
  if(!meldOptions(d,p).some(m=>m.suit===suit)) return d;
  const v = ENG.meldValue(suit, d.trump);
  d.meldPts[p] += v;
  d.meldedSuits[p] = d.meldedSuits[p].concat([suit]);
  d.meldSuit = suit;                       // you must now lead the K or the Q
  d.log = (d.log||[]).concat([{ k:"meld", seat:p, suit, value:v, counts:d.tricksWon[p]>0 }]);
  /* A marriage can take you out on the spot — and when it does the deal ends THERE, with the trick
   * never played. (Close the stock, lead the trump ace, declare 40, and you are home.) */
  if(!(opts && opts.strictClaim) && effPts(d,p) >= OUT) return finish(d, { reason:"claim", claimant:p });
  return d;
}

/* Play one card. Resolves the trick, draws, and ends the deal when it should.
 * `autoClaim` — the app counts for you, so reaching 66 ends the deal in your favour immediately.
 * With strict claiming ON you must press "Declare 66" yourself, exactly as at a real table. */
function play(d, p, cardId, opts){
  if(d.phase!=="play" || d.turn!==p) return d;
  const legal = legalCards(d, p);
  const c = legal.find(x=>x.id===cardId);
  if(!c) return d;
  const autoClaim = !(opts && opts.strictClaim);

  d.hands[p] = d.hands[p].filter(x=>x.id!==c.id);

  if(d.trick.length===0){                                   // ---- the lead ----
    d.trick = [{ seat:p, card:c }];
    d.meldSuit = null;
    d.turn = other(p);
    return d;
  }

  // ---- the follow: resolve ----
  const ledSeat = d.trick[0].seat, led = d.trick[0].card;
  const w = ENG.trickWinner(led, c, d.trump, ledSeat, p);
  const l = other(w);
  const pts = ENG.val(led) + ENG.val(c);
  d.trickPts[w] += pts;
  d.tricksWon[w] += 1;
  d.lastTrick = { trick:[d.trick[0], {seat:p, card:c}], winner:w, pts };
  d.log = (d.log||[]).concat([{ k:"trick", lead:ledSeat, led, fol:c, winner:w, pts }]);
  d.trick = [];
  d.turn = w; d.lead = w;

  // ---- the draw (winner first, loser second; the turn-up is always the very last card) ----
  if(!d.closed && stockLeft(d) > 0){
    for(const who of [w, l]){
      if(d.stock.length)      d.hands[who].push(d.stock.shift());
      else if(d.up){
        d.hands[who].push(d.up);
        d.reveals = d.reveals.concat([{ seat:who, id:d.up.id }]);
        d.log = d.log.concat([{ k:"tookup", seat:who, card:d.up }]);   // public: everyone saw who took the turn-up
        d.up = null;
      }
    }
  }

  if(autoClaim && effPts(d, w) >= OUT) return finish(d, { reason:"claim", claimant:w });
  if(d.hands[0].length===0 && d.hands[1].length===0)
    return finish(d, { reason: d.closed ? "closedOut" : "exhausted" });
  return d;
}

/* Declaring 66. Right → you win. Wrong → you have just handed the deal away.  */
function claim(d, p){
  if(!canClaim(d,p)) return d;
  return finish(d, { reason:"claim", claimant:p });
}

/* ---------------- HOW THE DEAL IS SCORED ----------------
 *
 * A deal ends one of three ways, and each pays differently:
 *
 *   claim      someone declared 66.  Right: 3 / 2 / 1 by how badly the loser is beaten.
 *                                    Wrong: the OPPONENT takes 2 (3 if they hold no tricks).
 *   exhausted  the stock ran out and nobody ever got to 66 — the last trick wins the deal, flat 1.
 *   closedOut  a closed deal ran to the end of the cards.  The closer needed 66 and either has it or hasn't.
 *
 * And the one rule everybody gets wrong: A CLOSER IS PAID BY THE SNAPSHOT. Both the reward for a
 * successful close and the penalty for a failed one read `closeSnap` — the opponent's position at the
 * moment the turn-up went face down — never their final position.
 */
function gpForWin(d, winner){
  const loser = other(winner);
  if(d.closed && d.closedBy===winner){                        // a successful close
    const s = d.closeSnap || { pts:effPts(d,loser), tricks:d.tricksWon[loser] };
    if(s.tricks===0) return 3;
    if(s.pts < 33)   return 2;
    return 1;
  }
  if(d.closed && d.closedBy===loser){                         // a FAILED close — the closer pays
    const s = d.closeSnap || { pts:0, tricks:d.tricksWon[winner] };
    return s.tricks===0 ? 3 : 2;                              // "you shut me out and STILL didn't make it"
  }
  const lp = effPts(d, loser);                                // an ordinary deal
  if(d.tricksWon[loser]===0) return 3;                        // schwarz — not a single trick
  if(lp < 33) return 2;                                       // schneider
  return 1;
}

function finish(d, how){
  let winner, gp, head, why;
  if(how.reason==="claim"){
    const p = how.claimant, o = other(p);
    if(effPts(d,p) >= OUT){
      winner = p; gp = gpForWin(d, p);
      head = "66 — declared and made";
      why  = `${effPts(d,p)} card points.`;
    } else {
      winner = o;
      gp = (d.closed && d.closedBy===p)
        ? gpForWin(d, o)
        : (d.tricksWon[o]===0 ? 3 : 2);
      head = "A false claim";
      why  = `Declared 66 holding only ${effPts(d,p)}.`;
    }
  } else if(how.reason==="closedOut"){
    const p = d.closedBy, o = other(p);
    if(effPts(d,p) >= OUT){ winner = p; gp = gpForWin(d, p); head = "The close came home"; why = `${effPts(d,p)} card points.`; }
    else { winner = o; gp = gpForWin(d, o); head = "The close failed"; why = `Closed, then finished on ${effPts(d,p)}.`; }
  } else {                                                     // exhausted, nobody ever reached 66
    winner = d.lastTrick ? d.lastTrick.winner : 0;
    gp = 1;
    head = "Neither side reached 66";
    why  = "The last trick takes the deal.";
  }
  d.phase = "scored";
  d.result = {
    winner, gp, head, why, reason: how.reason,
    pts: [effPts(d,0), effPts(d,1)],
    tricks: [d.tricksWon[0], d.tricksWon[1]],
    closedBy: d.closedBy, closeSnap: d.closeSnap,
    schwarz: d.tricksWon[other(winner)]===0,
  };
  return d;
}

const RULES = { newDeal, effPts, stockLeft, isStrict, other, OUT,
                canExchange, canClose, canClaim, meldOptions, legalCards,
                exchange, close, meld, play, claim, gpForWin, finish };

export { RULES, effPts, stockLeft, isStrict, other };
