import React from "react";
import { PROFILES, ALL_BRAINS } from "../state/personas.js";
import { HighScores } from "./table.jsx";

function Seg({val, opts, onPick}){
  return (
    <div className="toggle">
      {opts.map(o=>(
        <button key={String(o.v)} className={val===o.v?"on":""} onClick={()=>onPick(o.v)}>{o.l}</button>
      ))}
    </div>
  );
}

function Setup({s, dispatch, initials, setInitials, scores, onStart, onShowRules, campaign, onResume, onDiscard}){
  const ready = (initials||"").length >= 1;
  return (
    <div className="setwrap">
      {campaign && (
        <div className="setcard resume">
          <div className="lbl2">Bummerl in progress</div>
          <div style={{fontSize:11.5,color:"var(--ink)"}}>
            {campaign.gp[0]}–{campaign.gp[1]} to {campaign.target} against {(PROFILES[campaign.brains[1]]||{}).name || "an opponent"}.
          </div>
          <div style={{display:"flex", gap:7}}>
            <button className="btn gold" onClick={onResume}>Resume</button>
            <button className="btn ghost" onClick={onDiscard}>Discard</button>
          </div>
        </div>
      )}

      <div className="setcard">
        <div className="lbl2">Your initials</div>
        <input className="sc-ini" value={initials} maxLength={3} placeholder="ABC"
          onChange={(e)=>setInitials(e.target.value)}/>
        <div className="hint" style={{textAlign:"left",fontSize:10}}>
          High scores are kept against these — the same three letters the lobby asks for.
        </div>
      </div>

      <div className="setcard">
        <div className="lbl2">Your opponent</div>
        <div className="sc-opps">
          {ALL_BRAINS.map(k=>{
            const p = PROFILES[k];
            return (
              <button key={k} className={"sc-oppr"+(s.brains[1]===k?" on":"")} style={{"--accent":p.color}}
                onClick={()=>dispatch({type:"SET_BRAIN", seat:1, key:k})}>
                <span className="g">{p.glyph}</span>
                <span className="n">{p.name}</span>
                <span className="b">{p.blurb}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div className="setcard">
        <div className="menu-row">
          <span className="lbl2">Play to</span>
          <Seg val={s.target} opts={[{v:7,l:"7"},{v:11,l:"11"}]} onPick={(v)=>dispatch({type:"SET_TARGET", target:v})}/>
        </div>
        <div className="menu-row">
          <span className="lbl2">Deck</span>
          <Seg val={s.variant||"classic"}
               opts={[{v:"classic",l:"20"},{v:"24",l:"24"}]}
               onPick={(v)=>dispatch({type:"SET_VARIANT", variant:v})}/>
        </div>
        <div className="hint" style={{textAlign:"left",fontSize:10,lineHeight:1.5}}>
          {(s.variant||"classic")==="24"
            ? "Twenty-four cards: the 9s join as the lowest rank, worth zero — a true exit card to duck a trick without bleeding points. Deal is six each, twelve-card stock; still a race to 66, and the trump NINE swaps for the turn-up."
            : "Classic Schnapsen: twenty cards, five each, ten-card stock. Every card carries points and the trump Jack swaps for the turn-up."}
        </div>
        <div className="menu-row">
          <span className="lbl2">Strict claiming</span>
          <button className={"btn ghost"+(s.strictClaim?" on":"")} onClick={()=>dispatch({type:"SET_STRICT", on:!s.strictClaim})}>
            {s.strictClaim ? "On ✓" : "Off"}
          </button>
        </div>
        <div className="hint" style={{textAlign:"left",fontSize:10,lineHeight:1.5}}>
          {s.strictClaim
            ? "You must press Declare 66 yourself. Get it wrong and you hand them the deal; forget it entirely and the last trick decides. This is how it is played in Vienna."
            : "The app counts for you and the deal ends the moment you cross 66. Turn this on when you want to keep the count in your own head."}
        </div>
      </div>

      <button className="startbtn" disabled={!ready} onClick={onStart}>
        {ready ? "Deal" : "Enter your initials"}
      </button>
      <div className="bar">
        <button className="btn ghost" onClick={onShowRules}>Rules</button>
      </div>

      <div className="setcard">
        <div className="lbl2">High scores · this device</div>
        <HighScores table={scores} meIni={initials}/>
      </div>
    </div>
  );
}

/* The rules, written so that someone who has never seen the game can sit down and play it — and so that
   someone who HAS can check the two rules everybody argues about (the close, and the marriage). */
function RulesScreen({onClose}){
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheetmodal" onClick={(e)=>e.stopPropagation()}>
        <div className="smhead"><b className="dl-title">SCHNAPSEN</b><button className="dl-x" onClick={onClose}>×</button></div>
        <div className="smbody">
          <div className="rsec">
            <div className="rsh">The deck</div>
            <div className="rsl">Twenty cards: <b>A 10 K Q J</b> in each suit. They rank <b>A · 10 · K · Q · J</b> — note the ten sits above the king.</div>
            <div className="rsl">Card points: <b>Ace 11 · Ten 10 · King 4 · Queen 3 · Jack 2</b>. That is 120 in the pack, and you are racing to <b>66</b>.</div>
          </div>
          <div className="rsec">
            <div className="rsh">The deal</div>
            <div className="rsl">Five cards each. The next card goes face up — its suit is trumps — and the last nine sit face down on top of it. That pile is the <b>stock</b>, and the turn-up is the last card anyone will draw from it.</div>
            <div className="rsl">The non-dealer leads.</div>
          </div>
          <div className="rsec">
            <div className="rsh">While the stock is open</div>
            <div className="rsl"><b>You may play any card you like.</b> There is no obligation to follow suit. This is the half of Schnapsen that surprises everyone.</div>
            <div className="rsl">Highest card of the led suit takes the trick — unless it is trumped. The winner takes both cards, draws the top of the stock, the loser draws the next, and the winner leads again.</div>
          </div>
          <div className="rsec">
            <div className="rsh">Marriages</div>
            <div className="rsl">Hold the <b>K and Q of a suit</b> and you may declare it <b>when you are on lead</b>: <b>20</b> points, or <b>40</b> in trumps. You must then lead one of the two.</div>
            <div className="rsl">The catch: <b>a marriage is worth nothing until you win a trick.</b> Declare 40, never take a trick, and you scored nothing at all.</div>
          </div>
          <div className="rsec">
            <div className="rsh">The trump jack</div>
            <div className="rsl">On lead, while the stock is open, you may swap the <b>jack of trumps</b> for the face-up turn-up. Almost always worth doing — you trade your worst trump for a better one.</div>
          </div>
          <div className="rsec">
            <div className="rsh">Closing the stock</div>
            <div className="rsl">On lead, you may <b>close</b>: turn the turn-up face down. No more drawing, and from that moment the strict rules bite — <b>follow suit, beat the led card if you can, and trump if you are void</b>.</div>
            <div className="rsl">If you close and make 66, you score by <b>where your opponent stood at the moment you closed</b> — not where they end up. If you close and miss, <b>they</b> take 2 game points (3 if they had no tricks when you shut it).</div>
          </div>
          <div className="rsec">
            <div className="rsh">Winning the deal</div>
            <div className="rsl">First to <b>66 card points</b> takes the deal, and scores:</div>
            <div className="rsl">· <b>3</b> game points if the loser took <b>no tricks at all</b></div>
            <div className="rsl">· <b>2</b> if the loser is under 33</div>
            <div className="rsl">· <b>1</b> if the loser is on 33 or more</div>
            <div className="rsl">If the stock runs out and nobody ever reached 66, the <b>winner of the last trick takes the deal</b> for 1 game point.</div>
          </div>
          <div className="rsec">
            <div className="rsh">The Bummerl</div>
            <div className="rsl">First to <b>7 game points</b> wins. Austrians count <i>down</i> from seven, which is what the number in the corner is doing.</div>
            <div className="rsl">Win 7–0 and your opponent is <b>Schneider</b> — the only thing in this game worth bragging about.</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export { Setup, RulesScreen, Seg };
