//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { AUC } from "../engine/auction.js";
import { BID } from "../engine/bidding.js";
import { ENG } from "../engine/core.js";
import { SEAT_ABBR, SEAT_NAME, SUIT_GLYPH, callLabel, nextSeat, partnerOf, sideOf } from "../state/constants.js";
import { who } from "../state/personas.js";
import { getGlossary } from "../state/teachingMode.js";
import { Card } from "./cards.jsx";
import { linkifyGlossary, suitColorClass } from "./glossary.jsx";
import { BidVerdict } from "./table.jsx";
import { C } from "./theme.js";
//#endregion gen


/* =======================================================================
   APP
   ===================================================================== */
/* ======================================================================
   HELP DRAWER — a live, linkified, colourful explanation of the whole game.
   ====================================================================== */
const DW_SUIT={S:"spades",H:"hearts",D:"diamonds",C:"clubs",NT:"notrump"};
const dwMajor=(s)=>s==="H"||s==="S", dwMinor=(s)=>s==="C"||s==="D";
const DW_RANK={C:0,D:1,H:2,S:3};
const DW_TERMS=["opening bid","overcall","takeout double","penalty double","negative double","Stayman",
  "Jacoby transfer","transfer","weak two","preempt","reverse","limit raise","single raise","Blackwood","Gerber",
  "Michaels","unusual notrump","Cappelletti","Jordan","fourth suit forcing","balanced","stopper","support","fit",
  "forcing","game-forcing","slam","redouble"];
const dwTag=(t)=>DW_TERMS.filter(x=>t.toLowerCase().includes(x.toLowerCase()));
const dwD=(meaning,o={})=>({meaning,points:o.points||null,lengths:o.lengths||null,artificial:!!o.artificial,forcing:!!o.forcing,inferred:!!o.inferred,terms:dwTag(meaning)});
function dwOpeningOf(ctx){ return ctx.openerSeat>=0 ? (ctx.by[ctx.openerSeat]||[]).find(c=>c.k==="B")||null : null; }
function describeCall(priorCalls, dealer, seat, call){
  let ctx; try{ ctx=BID.context(priorCalls,dealer,seat); }catch(_){ return dwD(callLabel(call)+"."); }
  const S=call.strain, L=call.level;
  const nobody=ctx.openerSeat===-1;
  const partnerOpen=ctx.partnerBids && ctx.partnerBids.find(c=>c.k==="B");
  const opening=dwOpeningOf(ctx);
  if(call.k==="P"){
    // a pass has no agreed meaning — these are honest inferences, not known facts.
    // (the point bounds are kept only to inform the partner snapshot, never shown as
    //  a number for an opponent.)
    if(nobody) return dwD("No opening bid \u2014 suggests fewer than opening values.",{points:[0,11],inferred:true});
    if(ctx.openerSeat===ctx.partner) return dwD("Doesn't respond \u2014 suggests too few points to look for game.",{points:[0,5],inferred:true});
    if(ctx.openerSeat===seat) return dwD("Nothing more to add.");
    return dwD("No suit or values worth competing here.",{inferred:true});
  }
  if(call.k==="D"){
    const lb=ctx.info.lastBid;
    if(opening && opening.strain==="NT") return dwD("A balanced 15+ hand \u2014 equal to their notrump (Cappelletti double).",{points:[15,40]});
    if(ctx.partnerOpened && ctx.rhoBids && ctx.rhoBids.some(c=>c.k==="B")) return dwD("Negative double \u2014 shows the unbid major(s) with values.",{forcing:true,points:[6,40]});
    if(!ctx.partnerOpened && lb && lb.level<=2 && lb.strain!=="NT") return dwD("Takeout double \u2014 opening values, short in "+DW_SUIT[lb.strain]+", and support for the unbid suits.",{points:[12,40]});
    return dwD("Penalty double \u2014 expects to defeat this contract.");
  }
  if(call.k==="R"){ return ctx.partnerOpened ? dwD("Redouble \u2014 10+ points; this hand belongs to our side.",{points:[10,40]}) : dwD("Redouble \u2014 confident of making the doubled contract."); }
  if(nobody){
    if(S==="NT") return L===1?dwD("Opening bid: balanced, 15\u201317.",{points:[15,17]}):L===2?dwD("Opening bid: balanced, 20\u201321.",{points:[20,21]}):dwD("Opening bid: balanced, 25\u201327.",{points:[25,27]});
    if(L===2&&S==="C") return dwD("Opening bid: 22+ points \u2014 artificial and game-forcing.",{points:[22,40],artificial:true,forcing:true});
    if(L===2) return dwD("Weak two: a six-card "+DW_SUIT[S]+" suit, 5\u201311 points.",{points:[5,11],lengths:{[S]:6}});
    if(L>=3) return dwD("Preempt: a "+(L+4)+"-card "+DW_SUIT[S]+" suit, weak.",{points:[0,10],lengths:{[S]:L+4}});
    if(dwMajor(S)) return dwD("Opening bid: five or more "+DW_SUIT[S]+", about 12\u201321 points.",{points:[12,21],lengths:{[S]:5}});
    return dwD("Opening bid: "+(S==="D"?"four or more diamonds (sometimes three)":"three or more clubs")+", 12\u201321 points.",{points:[12,21],lengths:{[S]:3}});
  }
  if(ctx.openerSeat===seat){
    const myOpen=(ctx.by[seat]||[]).find(c=>c.k==="B");
    if(myOpen && S!=="NT" && S!==myOpen.strain && L===2 && DW_RANK[S]>DW_RANK[myOpen.strain]) return dwD("A reverse \u2014 a higher new suit showing extra values (about 17+), forcing.",{points:[17,40],forcing:true,lengths:{[S]:4}});
    if(S==="NT") return L===1?dwD("Rebid: balanced 12\u201314.",{points:[12,14]}):L===2?dwD("Rebid: balanced 18\u201319.",{points:[18,19]}):dwD("Rebid: balanced, extra strength.");
    if(myOpen && S===myOpen.strain) return dwD("Rebids "+DW_SUIT[S]+" \u2014 usually a six-card suit.",{lengths:{[S]:6}});
    if(S!=="NT") return dwD("A second suit in "+DW_SUIT[S]+" \u2014 13\u201318 points.",{points:[13,18],lengths:{[S]:4}});
  }
  if(ctx.openerSeat===ctx.partner){
    const ourSuits=new Set([...(ctx.myBids||[]),...(ctx.partnerBids||[])].filter(c=>c.k==="B"&&c.strain!=="NT").map(c=>c.strain));
    if(S!=="NT" && L>=2 && ourSuits.size===3 && !ourSuits.has(S)) return dwD("Fourth suit forcing \u2014 artificial and game-forcing, asking opener for more (often a stopper for notrump).",{artificial:true,forcing:true});
    if(partnerOpen && partnerOpen.strain==="NT" && partnerOpen.level===1){
      if(S==="C"&&L===2) return dwD("Stayman \u2014 asks whether opener holds a four-card major (usually 8+).",{artificial:true,points:[8,40]});
      if((S==="D"||S==="H")&&L===2) return dwD("Jacoby transfer \u2014 shows five or more "+DW_SUIT[S==="D"?"H":"S"]+".",{artificial:true,lengths:{[S==="D"?"H":"S"]:5}});
      if(S==="S"&&L===2) return dwD("A weak hand with a long minor \u2014 a puppet to 3\u2663 (pass or correct to 3\u2666).",{artificial:true,points:[0,7]});
      if(S==="NT"&&L===2) return dwD("Invitational \u2014 a balanced 8\u20139.",{points:[8,9]});
      if(S==="NT"&&L===3) return dwD("To play game \u2014 a balanced 10\u201315.",{points:[10,15]});
      if(S==="C"&&L===4) return dwD("Gerber \u2014 asks for aces.",{artificial:true});
    }
    if(S==="NT"&&L===4) return dwD("Blackwood \u2014 asks how many aces partner holds.",{artificial:true});
    if(partnerOpen && partnerOpen.strain===S && S!=="NT"){
      if(L===partnerOpen.level+1) return dwD("Single raise \u2014 "+(dwMajor(S)?"three or more":"four or more")+" "+DW_SUIT[S]+", 6\u201310 points.",{points:[6,10],lengths:{[S]:dwMajor(S)?3:4}});
      if(L===partnerOpen.level+2) return dwD("Limit raise \u2014 10\u201311 points with "+(dwMajor(S)?"three or more":"five or more")+" "+DW_SUIT[S]+".",{points:[10,11],lengths:{[S]:dwMajor(S)?3:5}});
      return dwD("Raise to game in "+DW_SUIT[S]+" \u2014 a fit with shape, usually under 10 high-card points.",{lengths:{[S]:dwMajor(S)?4:5}});
    }
    if(S==="NT"&&L===2 && partnerOpen && dwMajor(partnerOpen.strain)) return dwD("Jacoby 2NT \u2014 a game-forcing raise asking opener to show a shortage.",{artificial:true,forcing:true,points:[13,40],lengths:{[partnerOpen.strain]:4}});
    if(S==="NT") return L===1?dwD("6\u20139 points, no fit and no suit to show at the one level.",{points:[6,9]}):L===2?dwD("Invitational \u2014 balanced 13\u201315 with stoppers.",{points:[13,15]}):dwD("To play \u2014 balanced 16\u201318 with stoppers.",{points:[16,18]});
    if(L===1) return dwD("A new suit: four or more "+DW_SUIT[S]+", 6+ points, forcing.",{forcing:true,points:[6,40],lengths:{[S]:4}});
    if(L===2) return dwD("A new suit at the two level: five or more "+DW_SUIT[S]+" (or four+ if a minor), 10+ points, forcing.",{forcing:true,points:[10,40],lengths:{[S]:dwMinor(S)?4:5}});
    return dwD("A new suit in "+DW_SUIT[S]+", forcing.",{forcing:true});
  }
  if(opening){
    if(opening.strain!=="NT" && S===opening.strain && L===2) return dwMinor(opening.strain)?dwD("Michaels cuebid \u2014 five or more in each major.",{lengths:{H:5,S:5}}):dwD("Michaels cuebid \u2014 the other major (5+) and a five-card minor.",{lengths:{[opening.strain==="H"?"S":"H"]:5}});
    if(S==="NT" && L===2 && opening.strain!=="NT"){ const low=["C","D","H","S"].filter(x=>x!==opening.strain).slice(0,2); return dwD("Unusual notrump \u2014 five or more in "+DW_SUIT[low[0]]+" and "+DW_SUIT[low[1]]+".",{lengths:{[low[0]]:5,[low[1]]:5}}); }
    if(opening.strain==="NT"){
      if(S==="D"&&L===2) return dwD("Cappelletti \u2014 five or more in each major.",{lengths:{H:5,S:5}});
      if(S==="H"&&L===2) return dwD("Cappelletti \u2014 hearts and an unspecified minor (5-5).",{lengths:{H:5}});
      if(S==="S"&&L===2) return dwD("Cappelletti \u2014 spades and an unspecified minor (5-5).",{lengths:{S:5}});
      if(S==="NT"&&L===2) return dwD("Cappelletti \u2014 five or more in each minor.",{lengths:{C:5,D:5}});
      if(S==="C"&&L===2) return dwD("Cappelletti \u2014 a one-suited hand (relay 2\u2666 to find the suit).",{artificial:true});
    }
    if(S==="NT"&&L===1) return dwD("Notrump overcall \u2014 15\u201318, balanced, with their suit stopped.",{points:[15,18]});
    const jump=ctx.info.lastBid && AUC.bidVal(call)>AUC.bidVal(ctx.info.lastBid)+5;
    if(jump && S!=="NT") return dwD("Weak jump overcall \u2014 a good "+(L>=3?"seven":"six")+"-card "+DW_SUIT[S]+" suit, preemptive.",{points:[5,10],lengths:{[S]:L>=3?7:6}});
    if(S!=="NT") return dwD("Overcall: a good five-card "+DW_SUIT[S]+" suit, roughly 8\u201316, suggesting the lead.",{points:[8,16],lengths:{[S]:5}});
  }
  return dwD(callLabel(call)+".");
}
function partnerProfile(calls, dealer, seat){
  const partner=(seat+2)%4;
  const prof={pointsMin:0,pointsMax:40,lengths:{},notes:[],acted:false};
  for(let i=0;i<calls.length;i++){ if(calls[i].by!==partner) continue;
    const d=describeCall(calls.slice(0,i),dealer,partner,calls[i]);
    if(calls[i].k!=="P") prof.acted=true;
    if(d.points){ prof.pointsMin=Math.max(prof.pointsMin,d.points[0]); prof.pointsMax=Math.min(prof.pointsMax,d.points[1]); }
    if(d.lengths) for(const su in d.lengths) prof.lengths[su]=Math.max(prof.lengths[su]||0,d.lengths[su]);
  }
  if(prof.pointsMin>prof.pointsMax) prof.pointsMin=Math.max(0,prof.pointsMax-3);
  return prof;
}
const PLAY_TAG = {
  F_ATT_HI:"attitude signal (encouraging)", F_ATT_LO:"attitude signal (discouraging)",
  F_CNT_HI:"count signal (even)", F_CNT_LO:"count signal (odd)",
  F_COVER:"cover an honour", F_HOLDUP:"hold-up", F_DUCK_HOLDUP:"defensive hold-up", F_HOLDUP_WIN:"win to strand", F_3RD_HIGH:"third hand high", F_FINESSE_WIN:"finesse",
  DECL_UNBLOCK:"unblock",   F_SPLIT:"split honours",   F_WIN_CHEAP:"wins cheaply", F_DUCK_PARTNER:"low \u2014 partner is winning", F_2ND_LOW:"second hand low",
  F_CANT:"low", DECL_DRAW:"drawing trumps", DECL_CASH:"cashing a winner", DECL_FINESSE:"finesse",
  DECL_RUFF:"setting up a ruff", DECL_RUFF_FIRST:"ruff before drawing", DECL_CROSS:"crossing to finesse",
  DECL_ESTABLISH:"establishing a suit", RUFF:"ruff", DISCARD:"discard",
  LEAD_SEQ:"top of a sequence", LEAD_4TH:"fourth best", LEAD_ACE:"ace lead", LEAD_LOW:"low lead", D_CONTINUE:"reading partner — continue their suit", D_RETURN:"return partner's suit", D_ROLLOUT:"rollout-chosen switch", ONLY:"forced",
};
function drawerCardRead(before, card, seat, ledSuit, trump, why){
  const nm=card.rank+SUIT_GLYPH[card.suit];
  const tag = why && PLAY_TAG[why.code] ? " \u2014 "+PLAY_TAG[why.code] : "";
  if(before.length===0) return {who:seat, text:"leads "+nm+tag, win:true, kind:"lead"};
  const cards=[...before.map(t=>({rank:t.card.rank,suit:t.card.suit,player:t.seat})),{rank:card.rank,suit:card.suit,player:seat}];
  const rr=ENG.resolveTrick(cards, ledSuit, trump); const win=rr.winner===seat;
  if(card.suit===ledSuit) return {who:seat, text:"follows with "+nm+(win?" \u2014 winning":"")+tag, win, kind:"follow"};
  if(trump!=="NT" && card.suit===trump) return {who:seat, text:"ruffs with "+nm+(win?" \u2014 winning":"")+tag, win, kind:"ruff"};
  return {who:seat, text:"discards "+nm+tag, win:false, kind:"discard"};
}
function MiniCard({card, win}){
  if(!card) return <div className="mcard empty"/>;
  return <div className={"mcard "+suitColorClass(card.suit)+(win?" win":"")}><span className="mr">{card.rank}</span><span className="ms">{SUIT_GLYPH[card.suit]}</span></div>;
}
function MiniTrick({t, focus}){
  const bottom=focus, top=partnerOf(focus), left=nextSeat(focus), right=(focus+3)%4;
  const cardBy=(seat)=>{ const x=t.trick.find(tc=>tc.seat===seat); return x?x.card:null; };
  const cell=(seat,pos)=>(
    <div className={"mt-slot "+pos} key={pos}>
      <MiniCard card={cardBy(seat)} win={t.winner===seat}/>
      <span className={"mt-seat"+(t.winner===seat?" win":"")}>{SEAT_ABBR[seat]}</span>
    </div>
  );
  return (
    <div className="minitrick">
      {cell(top,"top")}{cell(left,"left")}
      <div className="mt-num num">#{t.num}</div>
      {cell(right,"right")}{cell(bottom,"bottom")}
    </div>
  );
}
/* One grade block, rendered inline BENEATH the trick it grades so all the pedagogy for a decision
 * sits with that decision (A5). Pure display: reads the grade object produced by the worker. */
function GradeNote({g, link}){
  if(!g) return null;
  const gl=(k)=>{ if(!k) return ""; const i=k.lastIndexOf("."); return k.slice(0,i)+(SUIT_GLYPH[k.slice(i+1)]||k.slice(i+1)); };
  const role=g.role==="defender"?"Defence":"Declarer";
  const actLabel=g.mid_trick?"play":"lead";     // grades now surface for mid-trick follows, not just leads
  const playedVerb=g.mid_trick?"Played":"Led";
  const L=g.lens||null;
  const pts=L?L.points:g.points;
  const CLASS_META={ right:{label:"right",color:"#3aa657"}, unlucky:{label:"unlucky",color:"#3a86c7"},
                     lucky:{label:"lucky",color:"#c79a2e"}, wrong:{label:"wrong",color:"#c0503f"} };
  const cls=L?CLASS_META[L.classification]:null;
  const accent=cls?cls.color:(pts>=95?"#3aa657":(pts>=70?"#c79a2e":"#c0503f"));
  // Phase B: a defender graded on a CONFIDENT follow-technique is judged by convention, not percentage — so
  // frame the classification in convention terms (and drop the "lenient" caveat below).
  const techConfident = !!(L && ((L.technique && !L.technique.soft) || L.signal) && L.confidence==="high" && g.role==="defender");
  const classLine=(L&&L.classification==="unlucky")
      ? (techConfident ? "Correct defensive technique \u2014 the layout just didn't reward it."
                       : "Right play by the odds \u2014 this layout was against you.")
      : (L&&L.classification==="lucky")
        ? (techConfident ? "This worked, but it's against standard defensive technique."
           : g.role==="defender" ? "This worked \u2014 though it wasn't the percentage play." : "This worked, but it was against the odds.")
        : null;
  const runners=(g.ranked||[]).slice(0,4);
  const pct=(x)=>Math.round((x||0)*100);
  return (
    <div className="dl-grade" style={{margin:"5px 0 1px",padding:"6px 9px",borderRadius:8,background:"rgba(127,127,127,0.08)",borderLeft:"3px solid "+accent}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",fontSize:11,opacity:0.85}}>
        <span>{role} {actLabel}
          {cls?<span style={{marginLeft:6,padding:"1px 6px",borderRadius:10,background:cls.color+"22",color:cls.color,fontSize:10,fontWeight:700}}>{cls.label}</span>:null}
          {g.best_tag?<span style={{marginLeft:6,padding:"1px 6px",borderRadius:10,background:"rgba(127,127,127,0.20)",fontSize:10}}>{g.best_tag}</span>:null}</span><b style={{color:accent}}>{pts}/100</b>
      </div>
      <div style={{fontSize:12,marginTop:3,lineHeight:1.45}}>
        {(() => {
          // For a confident defender technique OR signal grade, "sound" vs "best" follows convention/signal
          // correctness, not the SD equiv set.
          const tc = techConfident ? L.technique : null;
          const sg = techConfident ? L.signal : null;
          const isSound = tc ? (tc.consistent===true || tc.consistent==="near")
                        : sg ? (sg.consistent===true || sg.consistent==="near")
                        : g.played_in_equiv;
          const bestShow = tc ? ((tc.expected&&tc.expected[0])||g.best)
                         : sg ? (sg.correctKey||g.best)
                         : (g.best_named||g.best);
          return isSound
            ? <span>{playedVerb} {gl(g.played)} — <b>sound</b>.</span>
            : <span>{playedVerb} {gl(g.played)}; best {gl(bestShow)}.</span>;
        })()}
        {classLine ? <div style={{opacity:0.8,marginTop:2}}>{classLine}</div> : null}
        {g.best_why ? <div style={{opacity:0.78,marginTop:2}}>{link(g.best_why)}</div> : null}
        {g.payoff==="make"
          ? <div style={{opacity:0.6,marginTop:2}}>Declarer {pct(g.played_ev)}% to make{g.played_in_equiv?null:<> · best {pct(g.best_ev)}% · cost {pct(g.gap)}%</>}</div>
          : (!g.played_in_equiv && g.gap!=null)
            ? <div style={{opacity:0.6,marginTop:2}}>Cost \u2248 {g.payoff==="imp" ? g.gap.toFixed(1)+" IMPs" : g.gap.toFixed(2)+" tricks"} vs best</div>
            : null}
        {runners.length>1 ? <div style={{opacity:0.6,marginTop:2}}>Equal options: {runners.map(gl).join("  ")}</div> : null}
        {g.role==="defender" && L && !techConfident && (L.classification==="lucky"||L.classification==="wrong")
          ? <div style={{opacity:0.5,marginTop:2,fontStyle:"italic"}}>defensive scoring is lenient \u2014 single-dummy is a weak judge of defence</div>
          : (g.needs_clairvoyance ? <div style={{opacity:0.55,marginTop:2,fontStyle:"italic"}}>double-dummy best needs clairvoyance</div> : null)}
      </div>
    </div>
  );
}

function HelpDrawer({s, focus, open, onToggle, onTapTerm, sug, gradeStatus, embedded}){
  const gloss=getGlossary();
  const link=(text)=>linkifyGlossary(text, gloss, onTapTerm);
  const sideCls=(seat)=> sideOf(seat)===sideOf(focus) ? "us" : "them";
  const rows=[];
  const calls=s.calls||[];
  if(calls.length){
    rows.push(<div key="bh" className="dl-head">The auction</div>);
    for(let i=0;i<calls.length;i++){
      const c=calls[i]; const d=describeCall(calls.slice(0,i), s.dealer, c.by, c);
      const suit=c.k==="B"?c.strain:null;
      rows.push(
        <div key={"c"+i} className={"dl-call "+sideCls(c.by)+(d.inferred?" inf":"")}>
          <span className="dl-seat">{SEAT_ABBR[c.by]}</span>
          <span className={"dl-bid"+(suit&&(suit==="H"||suit==="D")?" red":"")}>{callLabel(c)}</span>
          <span className="dl-txt">{link(d.meaning)}{d.inferred?<span className="tagpill infer">inferred</span>:null}{d.artificial?<span className="tagpill conv">artificial</span>:null}{d.forcing?<span className="tagpill force">forcing</span>:null}</span>
        </div>
      );
    }
    const prof=partnerProfile(calls, s.dealer, focus);
    if(prof.acted){
      const lenTxt=Object.keys(prof.lengths).length?Object.entries(prof.lengths).sort((a,b)=>DW_RANK[b[0]]-DW_RANK[a[0]]).map(([su,n])=>n+"+ "+SUIT_GLYPH[su]).join("   "):"\u2014";
      rows.push(
        <div key="psnap" className="dl-snap">
          <div className="dl-snap-h">What we know about partner</div>
          <div className="dl-snap-row"><span>points</span><b className="num">{prof.pointsMin}–{prof.pointsMax}</b></div>
          <div className="dl-snap-row"><span>length</span><b>{lenTxt}</b></div>
        </div>
      );
    }
  }
  const th=s.trickHistory||[];
  if(th.length || (s.trick&&s.trick.length)){
    rows.push(<div key="ph" className="dl-head">The play</div>);
    { const gs=gradeStatus||{};
      const wk = gs.worker===false ? "unavailable" : gs.worker ? "on" : "starting\u2026";
      const be = gs.backend==="wasm" ? "full DDS" : gs.backend==="js" ? "endgame-only (CDN blocked)" : null;
      const errTxt = gs.ddsError || gs.lastError;
      rows.push(
        <div key="gstatus" style={{margin:"2px 0 6px",padding:"5px 8px",borderRadius:8,background:"rgba(127,127,127,0.06)",fontSize:11,opacity:0.75,lineHeight:1.4}}>
          Grader: {wk}{be?" \u00b7 "+be:""} \u00b7 {gs.graded||0} graded{gs.skipped?", "+gs.skipped+" skipped":""}{gs.errored?", "+gs.errored+" err":""}
          {errTxt?<div style={{marginTop:2,opacity:0.7,wordBreak:"break-word"}}>{String(errTxt).slice(0,140)}</div>:null}
        </div>
      );
    }
    /* THE AUCTION, GRADED. Until now the review opened straight onto trick one — the bidding, which is half
       the game and the half most students actually lose on, left no trace at all. Every call the student made
       is replayed here with its verdict, in the SAME BidVerdict card the trainer showed at the table, so the
       lesson after the hand is the same lesson they were given before the bid.
       Only the student's calls are shown. Judgment calls appear too, marked as such: "we are not marking this
       wrong" is itself a thing worth teaching, and it is two-thirds of all calls. */
    {
      const mine=(s.calls||[]).filter(c=>c.grade && s.brains && s.brains[c.by]==="human");
      if(mine.length){
        const marked=mine.filter(c=>c.grade.points<100).length;
        rows.push(
          <div key="auction-grade" className="dl-trick">
            <div className="dl-trick-body">
              <div className="dl-trick-sum" style={{marginBottom:4}}>
                The auction — your {mine.length} call{mine.length===1?"":"s"}
                {marked ? `, ${marked} marked` : ", nothing to flag"}.
              </div>
              {mine.map((c,i)=>(<BidVerdict key={i} g={c.grade}/>))}
            </div>
          </div>
        );
      }
    }
    for(const t of th){
      let before=[]; const lines=[];
      for(const tc of t.trick){ const r=drawerCardRead(before,tc.card,tc.seat,t.ledSuit,t.trump,tc.why); lines.push(r); before=[...before,tc]; }
      // Grades are keyed per CARD: `${rubber}.${deal}.${trickIdx}.${posInTrick}` (reducer buildGradePos).
      // For a played trick, trickIdx === t.num-1 and posInTrick === j (t.trick is in play order), so the
      // per-card grade for line j is grades[`${rubber}.${deal}.${t.num-1}.${j}`]. Render it inline beneath
      // that card so each decision's pedagogy sits with the card it grades (undefined => GradeNote renders
      // nothing, so only graded plays — declarer plays and post-dummy defender plays — show a note).
      const gradeKey=(j)=>`${s.rubberNo||1}.${s.dealNo||1}.${t.num-1}.${j}`;
      rows.push(
        <div key={"t"+t.num} className="dl-trick">
          <MiniTrick t={t} focus={focus}/>
          <div className="dl-trick-body">
            {lines.map((r,j)=>(
              <React.Fragment key={j}>
                <div className={"dl-play "+sideCls(r.who)+(r.win?" win":"")}><span className="dl-seat sm">{SEAT_ABBR[r.who]}</span>{link(r.text)}</div>
                <GradeNote g={(s.grades||{})[gradeKey(j)]} link={link}/>
              </React.Fragment>
            ))}
            <div className="dl-trick-sum">{SEAT_NAME[t.winner]} wins trick {t.num}.</div>
          </div>
        </div>
      );
    }
    if(s.trick && s.trick.length){
      let before=[]; const lines=[];
      const ledSuit=s.ledSuit||(s.trick[0]&&s.trick[0].card.suit);
      for(const tc of s.trick){ const r=drawerCardRead(before,tc.card,tc.seat,ledSuit,s.trump,tc.why); lines.push(r); before=[...before,tc]; }
      rows.push(
        <div key="curtrick" className="dl-trick live">
          <div className="dl-trick-body">
            <div className="dl-live-h">In progress</div>
            {lines.map((r,j)=><div key={j} className={"dl-play "+sideCls(r.who)+(r.win?" win":"")}><span className="dl-seat sm">{SEAT_ABBR[r.who]}</span>{link(r.text)}</div>)}
          </div>
        </div>
      );
    }
  }
  if(sug && sug.text){
    rows.push(
      <div key="hint" className="dl-hint">
        <div className="dl-hint-h">Your turn{sug.label?" \u2014 "+sug.label:""}</div>
        <div className="dl-hint-b">{link(sug.text)}</div>
      </div>
    );
  }
  /* Card-play grades now render inline beneath each graded card (see GradeNote in the play loop above). */
  if(!rows.length) rows.push(<div key="empty" className="dl-empty">The running commentary appears here as the deal unfolds — every call and card, what it shows, and what we can deduce about partner's hand.</div>);
  // Embedded mode: render as a full-width screen (its own tab) rather than the slide-in drawer. The play
  // annotations use the whole width; only this inner region scrolls (the app shell around it does not).
  if(embedded){
    return <div className="talkwrap"><div className="dl-scroll dl-full">{rows}</div></div>;
  }
  return (
    <>
      <button className={"dl-tab"+(open?" open":"")} onClick={()=>onToggle(!open)} aria-label="Table talk">{open?"\u203a":"\u2039"}<span className="dl-tab-l">TABLE&nbsp;TALK</span></button>
      <aside className={"help-drawer"+(open?" open":"")}>
        <div className="dl-top"><span className="dl-title">TABLE&nbsp;TALK</span><button className="dl-x" onClick={()=>onToggle(false)}>×</button></div>
        <div className="dl-scroll">{rows}</div>
      </aside>
    </>
  );
}



//#region gen (auto — removed when bundled to a single bridge.jsx)
export { DW_RANK, DW_SUIT, DW_TERMS, GradeNote, HelpDrawer, MiniCard, MiniTrick, PLAY_TAG, describeCall, drawerCardRead, dwD, dwMajor, dwMinor, dwOpeningOf, dwTag, partnerProfile };
//#endregion gen
