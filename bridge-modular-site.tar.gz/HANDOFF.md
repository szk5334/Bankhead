# HANDOFF — Bridge (modular Card Table deploy, **two-tarball split**)

Read this first when picking the project up cold in a new chat. The project ships and is edited as a
**module tree**, and now deploys as **two tarballs** (site + WASM engine) that a glob-everything GitHub
Actions workflow unpacks onto GitHub Pages. This supersedes every earlier single-tarball / CDN-WASM
handoff.

---

## 0. TL;DR — the model (what changed most recently)

- **Deploy is now TWO tarballs committed side-by-side at the repo root:**
  - **`bridge-modular-site.tar.gz`** — the app you iterate on:
    ```
    index.html      Card Table shell (shell-r9) — modular loader
    bridge/         the ES-module source, deployed AS-IS (source of truth)
    HANDOFF.md      this file
    ```
  - **`bridge-dds-engine.tar.gz`** — one big, rarely-changing file:
    ```
    bridge/grader/dds_engine.inline.js   the bridge-dds WASM engine (base64-embedded, ~524 KB)
    ```
  They overlay into the same `bridge/` tree at deploy time. The engine lives in its own tarball so the
  524 KB blob isn't re-shipped every time you touch game/grader logic.
- **Why split:** the grader worker used to try `import('https://esm.sh/bridge-dds')`, which GitHub Pages
  blocks → every hand >7 cards/hand was skipped. The engine is now **inlined** (WASM base64, no network),
  but kept in a **separate** tarball so the site bundle stays small. See §9.
- **No build step for the site.** Edit files under `bridge/`, re-pack the tarball, commit.
- **Deploy** = commit the tarball(s) → `.github/workflows/deploy-pages.yml` unpacks **every** `*.tar.gz`
  and publishes. Repo → Settings → Pages → Source = **"GitHub Actions"** (one-time). Adding a third
  tarball later (new game, asset pack) needs **no workflow change** — it's globbed in.
- Live routes on the deployed shell:
  - **Modular (primary):** `…/?module=bridge/adapter.js`
  - **Monolith (legacy fallback):** `…/?game=bridge.jsx` — still works, optional, may drift.
- The launcher (`…/` with no query) lists games; BRIDGE shows a "▸ dev build · load from modules" link
  pointing at the modular route.

**Related packages (separate tarballs, not part of the site):**
- **`bridge-grader-core_tar.gz`** — the parity-verified grader engine + the build scripts that GENERATE
  `workerSrc.js` and `dds_engine.inline.js`. Touch this only when changing grader logic or bumping
  bridge-dds. Has its own HANDOFF.
- **`DEPLOY.md`** — the deploy cheat-sheet (upload model + update-one-piece recipes).

---

## 1. Dev loop in a chat

1. User uploads `bridge-modular-site.tar.gz` (and, if the grader/engine is in play,
   `bridge-dds-engine.tar.gz` and/or `bridge-grader-core_tar.gz`).
2. Unpack the site:
   ```bash
   mkdir -p /home/claude/work/site
   tar xzf /mnt/user-data/uploads/bridge-modular-site.tar.gz -C /home/claude/work/site
   # -> site/index.html, site/bridge/…, site/HANDOFF.md
   ```
   If you need the engine present locally (e.g. to test the assembled worker), also unpack the engine
   tarball on top so `site/bridge/grader/dds_engine.inline.js` exists.
3. Edit modules under `site/bridge/`. Use normal ES `import`/`export` between modules — the loader
   resolves the whole graph (it does NOT strip imports like the monolith path does).
4. **Validate before shipping** (see §4).
5. Re-pack and hand back:
   ```bash
   tar czf bridge-modular-site.tar.gz -C site .          # site (excludes the engine if you kept it separate)
   # present bridge-modular-site.tar.gz
   ```
   Only re-pack `bridge-dds-engine.tar.gz` when the engine file itself changes (a bridge-dds bump).

---

## 2. How the shell loads the modules (loader mechanics)

`index.html` has two independent routes:

- **`?game=<file>` (monolith):** fetch one file, strip the React import, drop every other `import`,
  rewrite `export default function App`, Babel-transform, mount `window.GAME.App`. Used by `bankhead.jsx`
  and the legacy `bridge.jsx`.
- **`?module=<entry>` (modular):** load an ES-module graph directly. For each module it `fetch().text()`s
  the source, transpiles **ESM → CommonJS** with Babel-standalone (JSX via the classic runtime), wraps it
  as a factory, and links everything with a tiny runtime `require()` registry that **registers a module
  BEFORE running its factory** — so import cycles resolve the way Node/webpack do. Because it fetches text
  and transpiles in-browser, GitHub Pages' MIME type for `.js`/`.jsx` is irrelevant.

**Bare imports** resolve through `externalFor()` in `index.html`:
- `react`, `react-dom`, `react-dom/client`, `react/jsx-runtime` → the page's CDN **UMD globals** (one
  React instance shared with the shell — do not load a second React).
- anything else → fetched from **esm.sh** as a best-effort fallback.
- To add a real CDN dependency: add a `<script>` in `<head>` **and** a `case` in `externalFor` (search
  "EXTERNALS" in index.html).

**Entry** is `bridge/adapter.js`. Importing it runs its side effect that registers
`window.GAME = { id, title, App, redactFor, publicView, actionTypes, … }`; the shell then mounts
`window.GAME.App`.

**The grader Worker is NOT loaded through this route.** It's a self-contained **Blob module worker**
built inside `App.jsx` (see §9) — the `?module=` loader / `externalFor` never touch it. That's why the
worker has to carry (or fetch) its own DDS engine rather than sharing the shell's dependency resolution.

---

## 3. Graph facts — corrections to the old monolith handoff

- **There IS an import cycle:** `state/constants.js` ↔ `engine/auction.js` (constants imports `AUC` from
  auction; auction imports `callLabel` from constants). The monolith build hid this because concatenation
  flattens all modules into one scope. The modular loader handles it via register-before-run. **Do not
  assume "no cycles."**
- **`adapter.js` imports `App`** via `import App from "./App.jsx";` inside its `//#region gen` block. The
  monolith build strips gen regions, so `build-bridge.mjs` output is byte-unchanged and the monolith still
  works.
- Every relative import carries an explicit `.js`/`.jsx` extension.
- The only bare specifiers in the source are `react` and `react-dom/client`.
- JSX lives only in `.jsx` files (keep the convention even though the loader Babels every module).
- `index.jsx` is a **dev-only** entry (self-mounts via `createRoot`). The shell never loads it; the
  modular entry is `adapter.js`.

---

## 4. Validation (do this before shipping any change)

**Site compile/link/mount** — two headless harnesses in the working area (not shipped; regenerate if
absent — logic mirrors §2). Need `@babel/standalone@7` in the working dir.
- **`harness.mjs`** — Node port of the loader: fetch → Babel(ESM→CJS) → cycle-safe require → asserts
  `window.GAME` registers with `App` (id `bridge`, plus `redactFor`/`publicView`).
- **`vmcheck.mjs`** — runs the **real** `index.html` inline scripts in a VM through `?module=` and asserts
  the app mounts (`document.title` → "BRIDGE"). Run: `SITE=/home/claude/work/site node vmcheck.mjs`.
  (Realm gotchas: give the VM its own native `Function`; define `navigator` via `Object.defineProperty`.)

**Grader worker (split deploy)** — validate BOTH paths the way `App.jsx` assembles them, driving the real
worker text through a fake `self` (no browser). The grader-core package ships this as
`test_worker_inline.mjs` / a split harness; the shape is:
- **Assembled** (`dds_engine.inline.js` + "\n" + `GRADER_WORKER_SRC`) → worker announces `backend:"wasm"`,
  full hands (8–13 cards) grade (not skipped), endgame bit-exact vs the pure-JS reference.
- **Degraded** (worker source alone, engine missing) → `backend:"js"`, `ddsError:"dds-engine-not-loaded"`,
  full hands **skipped** cleanly (no crash), endgame still grades.

**Workflow** — simulate the overlay before trusting a deploy: copy a fake repo (stale `index.html` + a
second game) + both tarballs into `_site`, run the yml's bash steps, assert `bridge/grader/
dds_engine.inline.js` lands, `index.html` is the tarball's, other games survive, `HANDOFF.md`/`*.tar.gz`
are stripped.

The one check **no headless test covers**: a real browser. Open `?module=bridge/adapter.js`, play a hand,
confirm Table Talk grades appear **and the status reads `wasm`** (not "endgame-only"). This is the top
open item (§10).

---

## 5. Deploy (GitHub Pages via Actions) — glob-everything workflow

`.github/workflows/deploy-pages.yml` (shipped in this handoff set):
- One-time: add the workflow; set Pages Source = "GitHub Actions".
- Each update: commit the changed tarball(s) and push. The workflow:
  1. copies the repo into `_site`, **excluding** `.git`, `.github`, `*.tar.gz`, `_site`;
  2. **unpacks every `*.tar.gz`** (sorted, last-wins overlay) on top — so site + engine merge into one
     `bridge/` tree;
  3. strips internal files from the published set (`HANDOFF.md`, `MODULE_MAP.md`, `*.tar.gz`);
  4. adds `.nojekyll`;
  5. sanity-checks: fails if `index.html` is missing; **warns** if `workerSrc.js` is published without
     `dds_engine.inline.js` (→ grader would silently run endgame-only — you forgot the engine tarball).
- `ARCHIVE_DIR` (default `.`) can point at a subfolder if you keep tarballs elsewhere.
- Change `branches: [main]` if your default branch differs.
- The tarball's `index.html` overwrites the repo's every deploy — **keep the tarball's copy current; don't
  hand-edit `index.html` in the repo separately**, or the tarball wins.

Note: uploading a `.tar.gz` to plain deploy-from-branch Pages does **not** work — Pages serves files
as-is and never unpacks. The Actions workflow is what makes it real.

---

## 6. Invariants (don't break)

- Card shape `{id, rank, suit}`; rank `"10"` not `"T"`; suits `S H D C`; seats `0=S 1=W 2=N 3=E`.
- `adapter.js` must register `window.GAME` with `App`, `redactFor`, `publicView`, `actionTypes`.
- `data/teaching.js` sets `window.BRIDGE_TEACHING` as a load-time side effect (App also imports it).
- `ui/online.js` binds to shell globals (`window.GameBar` / `LobbyScreens` / `useGameNet`), defined by the
  shell's net layer before any game loads.
- Keep new code OUT of `//#region gen … //#endregion gen` blocks (auto-generated wiring; the monolith
  build strips them).
- **Grader is a pure, guarded side-effect** — it only attaches annotations; it must never touch card
  legality or turn order. Keep the `try{…}catch` guards.
- **Engine path contract:** `App.jsx` fetches `window.BRIDGE_DDS_ENGINE_URL || "bridge/grader/
  dds_engine.inline.js"`. If you move/rename the engine file, update both the fetch default and the
  engine tarball layout.

---

## 7. Monolith fallback (optional)

`?game=bridge.jsx` still works. Regenerate the single file with `build-bridge.mjs` (in `bridge-dev`) —
strips gen regions, concatenates in dependency order. Under the modular model this is optional and the
committed `bridge.jsx` may lag `bridge/`. NOTE: the monolith path predates the split-worker/engine wiring;
if you care about the monolith grading full hands, it needs the same engine-prepend treatment (untested).

---

## 8. File map

```
bridge/
  adapter.js        ENTRY — registers window.GAME (imports App)
  App.jsx           default App component; BUILDS the grader Blob worker (fetches + prepends the engine)
  engine/           core → auction → scoring → bidding → play   (IIFE namespaces ENG/AUC/SCO/BID/PLY)
  state/            constants, personas, reducer, teachingMode   (constants ↔ auction: the cycle)
  ui/               theme, css, storage, online, cards, table, setup, glossary, helpDrawer,
                    errorBoundary, learn
  data/             curriculum, teaching   (teaching sets window.BRIDGE_TEACHING)
  drills/           declplay, generator
  grader/
    workerSrc.js    grader Worker source as a string (GRADER_WORKER_SRC) — SPLIT form: engine NOT inlined
    dds_engine.inline.js   ← arrives from bridge-dds-engine.tar.gz at deploy time (NOT in the site tarball)
  index.jsx         DEV-ONLY entry (self-mounts; not used by the shell)
```
Per-module exports / provenance: `MODULE_MAP.md` in the `bridge-dev` package.

---

## 9. Grader internals + WASM split (current state)

**Provenance.** The grader engine is the separate `bridge-grader-core` package; the in-app pieces are
generated, not hand-edited:
```
  sampler/dds/grader/evalcards/tiebreak  →  build_grd_inline.js  →  grader.worker.js (SPLIT: no engine)
                                                                     → paste as GRADER_WORKER_SRC in
                                                                       bridge/grader/workerSrc.js
  bridge-dds dist (WASM base64)          →  build_dds_inline.js   →  dds_engine.inline.js  (engine tarball)
```

**Runtime wiring (in `App.jsx`).** A Blob **module** worker is built once:
1. fetch `bridge/grader/dds_engine.inline.js` (override: `window.BRIDGE_DDS_ENGINE_URL`);
2. `src = engineText + "\n" + GRADER_WORKER_SRC` (engine PREPENDED so `__DDS_ENGINE` is in worker scope);
3. `new Worker(URL.createObjectURL(new Blob([src],{type:"text/javascript"})), {type:"module"})`.
The worker's `ensureDds()` guards `typeof __DDS_ENGINE === 'undefined'` → if the engine text wasn't
prepended (fetch failed / not deployed) it degrades to the inlined pure-JS endgame solver. The worker
posts a `{ready, backend, ddsError}` handshake, then per-message `{id, grade, backend}`.

**[FIXED] CDN-blocked WASM** (the old main task). Was `import('https://esm.sh/bridge-dds@1.4.0')` — blocked
on Pages, so all hands >7 cards/hand were skipped. bridge-dds v1.4.0's Emscripten build **base64-embeds**
the WASM inside `dist/lib/dds.js` (no sidecar `.wasm`, no fetch on the happy path), so the whole engine is
pure JS. It's now inlined into `dds_engine.inline.js` (`const __DDS_ENGINE = {loadDds,Dds,…}`), shipped in
its own tarball, and prepended at worker-build time. **No network.** Proven in Node with bridge-dds
*removed* from `node_modules`: full hands grade, `backend=wasm`, endgame still bit-exact vs pure-JS.

**[FIXED] Pure-JS endgame crash in-browser.** `solveNode` referenced Node-only `global.__DDS_NOTT`; fixed
to `globalThis` in both `workerSrc.js` and upstream `bridge-grader-core/dds.js` (so a regen won't
reintroduce it).

**Status line decoder (Table Talk header):** `graded` = cards scored; `skipped` =
`no-wasm-hand-too-large` (engine absent → pure-JS regime, only ≤7 cards/hand); `err` = worker threw.
Backend `wasm` = engine loaded; `js` = degraded (check `ddsError`).

---

## 10. TO-DO (in priority order — start here)

1. **Browser smoke test (THE open item).** Deploy both tarballs, load a hand, confirm Table Talk grades
   appear and status = `wasm`. This is the only unrun path. If it says endgame-only: either the engine
   tarball didn't land (the workflow prints a warning), or a Blob **module** worker can't instantiate the
   embedded WASM under the page CSP (would need `wasm-unsafe-eval`; a different fix than the CDN one). If
   it's CSP, options are: add a `Content-Security-Policy` `<meta>`/header allowing wasm-eval, or serve the
   engine as a real module the worker `import()`s by absolute URL instead of prepending text.
2. **Defence-specific tiebreak principles.** `tiebreak.js` currently reuses lead principles for defenders
   with defensive *wording*. Genuine defender rules (signal honestly, don't block partner, keep
   count/parity) would improve defence teaching. Note: SD-best defensive teaching needs a signalling model
   before it's trustworthy (belief-sampler investment is shelved).
3. **Defender OPENING lead.** Skipped today (dummy not down → 3 hidden hands, outside the 2-hidden
   sampler). To grade it, add a 3-hand belief split to `sampler.js` (or condition on the auction only).
4. **Teaching-layer hooks.** `best_why`/`best_tag`/`ranked`/`needs_clairvoyance` are ready to power the
   SD-vs-DD divergence quiz and per-card scoring in the teaching UI/state (`bridge/ui`, `bridge/state`).
   Expert-validation remains the trust gate before shipping graded quizzes.
5. **Payoff/N knobs.** Grading uses `payoff:"make"`, `N:16` (set in `maybeEnqueueGrade`, in
   `state/reducer.js`). `imp`/`tricks` payoffs and higher `N` are one-line changes.
6. **Monolith parity (only if you still use `?game=bridge.jsx`).** Give the monolith the same
   engine-prepend wiring, or accept that the monolith grades endgame-only.

**Already done (don't redo):** CDN→inline WASM (§9); mid-trick follow grading (solveFollow, both
backends, parity-proven); declarer + defender perspectives; A5 named tiebreaks (22/22); the two-tarball
split + glob workflow; both worker paths Node-validated.

---

## 11. Quick start for the next session

```bash
# unpack site (+ engine if testing the grader)
mkdir -p /home/claude/work/site && tar xzf /mnt/user-data/uploads/bridge-modular-site.tar.gz -C /home/claude/work/site
tar xzf /mnt/user-data/uploads/bridge-dds-engine.tar.gz -C /home/claude/work/site   # optional, for worker tests

# grader engine work? unpack the core and re-run its gates:
#   cd bridge-grader-core && bash setup_wasm.sh && bash run_parity.sh frozen && bash verify_inline.sh
#   node build_dds_inline.js   # regen dds_engine.inline.js  (needs bridge-dds installed)
#   node build_grd_inline.js   # regen SPLIT grader.worker.js -> paste into bridge/grader/workerSrc.js
```
Then pick from §10 (start with the browser smoke test). The grader is the yardstick — trust it only while
its parity + split-worker suites are green.
