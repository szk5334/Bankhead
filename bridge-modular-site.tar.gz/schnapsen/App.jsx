import React, { useReducer, useEffect, useRef } from "react";
import { ENG } from "./engine/core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "./engine/rules.js";
import { SETUP, reducer, botAction } from "./state/reducer.js";
import { who, seatPersona, PROFILES } from "./state/personas.js";
import { SUIT_GLYPH, suitColorClass, setRankMode, displayRank } from "./state/constants.js";
import { THEME_CSS } from "./ui/css.js";
import { UIErrorBoundary } from "./ui/errorBoundary.jsx";
import { Hand } from "./ui/hand.jsx";
import { StatusBar, TabBar, OppStrip, YouStrip, StockZone, TrickZone, ActionBar, ScoreSheet, HighScores, G } from "./ui/table.jsx";
import { Log } from "./ui/log.jsx";
import { TalkDock } from "./ui/chat.jsx";
import { ScoreCard, PlayPointsHUD, CoachLog, useDealGrades } from "./ui/score.jsx";
import { FxLayer, fxBurst, fxFly, fxStream } from "./ui/fx.jsx";
import { AmbientRain, TrickRain, Fireworks } from "./ui/rain.jsx";
import { Setup, RulesScreen, Seg } from "./ui/setup.jsx";
import { OnlineBar, OnlineScreens, SpectatorView, useGameNet } from "./ui/online.js";
import { loadTheme, saveTheme, loadInitials, saveInitials, loadSettings, saveSettings, loadCampaign, saveCampaign, loadScores, recordBummerl } from "./ui/storage.js";

export default function App(){
  const [s, dispatch] = useReducer(reducer, SETUP);
  const [theme, setTheme] = React.useState(()=>loadTheme());
  const [set, setSet] = React.useState(()=>loadSettings());
  const [initials, setInits] = React.useState(()=>loadInitials());
  const [scores, setScores] = React.useState(()=>loadScores());
  const [campaign, setCampaign] = React.useState(()=>loadCampaign());
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [showRules, setShowRules] = React.useState(false);
  const [tab, setTab] = React.useState("game");
  const [sel, setSel] = React.useState(null);

  useEffect(()=>{ saveTheme(theme); }, [theme]);
  useEffect(()=>{ saveSettings(set); }, [set]);
  const setInitials = (v)=>{ const c=(v||"").toUpperCase().replace(/[^A-Z]/g,"").slice(0,3); setInits(c); saveInitials(c); };

  const timer = useRef(null);
  const netRef = useRef(null);
  const recordedRef = useRef(null);

  /* ---------------- multiplayer ----------------
   * Identical contract to bridge: a GUEST never runs the rules, it just SENDS its action to the host and
   * renders whatever snapshot comes back. The host is the only machine that owns the deal. That is what
   * makes cheating structurally impossible rather than merely discouraged — a guest's client has never
   * been told what is in the other hand or the stock (see adapter.js/redactFor).
   */
  /* every decision the human makes, with the position as it stood when they made it. The grader
     re-derives the opponent's hand by sampling — it never peeks at the snapshot's other seat — so
     capturing full state here is safe and is what lets us price the move afterwards. */
  const [moves, setMoves] = React.useState([]);
  const sRef = React.useRef(null);
  sRef.current = s;

  /* a new deal wipes the capture. This MUST sit with the other top-level hooks: App returns early for
     the spectator and lobby screens, and a hook below those returns is a hook that sometimes does not
     run — which is exactly the "rendered more hooks than during the previous render" crash. */
  React.useEffect(()=>{
    if(s.mode==="play" && s.phase==="play" && !(s.trick||[]).length && !(s.log||[]).length)
      setMoves(cur => cur.length ? [] : cur);
  }, [s.mode, s.phase, (s.trick||[]).length, (s.log||[]).length]);

  /* set before any child renders this pass, so every card in the tree agrees on what a King is called */
  setRankMode(set.numerals ? "values" : "faces");

  const dealKey = s.roundEndedAt || 0;
  /* The result screen's feedback is permanent. The LIVE feedback is the toggle — so `finish` forces the
     grader to catch up the moment the deal is scored, whether the coach was switched on or not. */
  const grades = useDealGrades(moves, !!set.coach, s.phase==="scored");

  const apply = React.useCallback((action)=>{
    const st = sRef.current;
    if(st && st.mode==="play" && st.phase==="play" && action.seat!=null && st.brains[action.seat]==="human")
      setMoves(cur => cur.concat([{ snap: st, seat: action.seat, action }]));
    if(netRef.current && netRef.current.role==="guest"){ netRef.current.send(action); return; }
    dispatch(action);
  }, []);

  const net = useGameNet({
    onAction: (a)=>dispatch(a),                                     // host: a guest's action, already seat-checked
    onResume: (state)=>dispatch({type:"__SYNC__", state}),
    onGoSolo: ()=>dispatch({type:"TO_SETUP"}),
    onSeatChange: (seat, brain, name)=>dispatch({type:"SET_BRAIN_LIVE", seat, brain:(brain==="human"?"human":"fritzl"), name:(name!=null?name:"")}),
  });
  netRef.current = net;
  const online = net.role !== "off";
  const focus = online ? Math.max(0, net.seat) : 0;

  /* Closing the stock is the biggest single decision in the game and it happened with no ceremony at
     all — one frame the deck was open, the next it said CLOSED. Now you throw the switch: a jet of white
     runs from the button into the deck, and the deck flips when the jet arrives. */
  const closeStock = React.useCallback((ev)=>{
    const btn = ev && ev.currentTarget;
    const deck = document.querySelector(".br .sc-stock");
    const beat = (btn && deck) ? fxStream(btn, deck) : 0;
    setTimeout(()=> apply({type:"CLOSE", seat:focus}), beat);
  }, [focus, apply]);   // eslint-disable-line


  useEffect(()=>{ if(net.role==="host" && s.mode==="play") net.broadcastState(s, net.names, s.target); },
    [s, net.names, net.role]);                                       // eslint-disable-line
  useEffect(()=>{ if(net.role==="guest" && net.snap) dispatch({type:"__SYNC__", state: net.snap}); },
    [net.snapV]);                                                    // eslint-disable-line

  /* The host starts the game the shell's lobby set up: whoever is seated is human, anyone missing is a bot. */
  const startOnline = React.useCallback((tgt)=>{
    const brains = [0,1].map(i => (net.roster||[]).some(r=>r.seat===i) ? "human" : "fritzl");
    const names  = [0,1].map(i => (net.names && net.names[i]) || "");
    dispatch({type:"START", brains, names, target: tgt || 7, dealer:0});
  }, [net.roster, net.names]);                                       // eslint-disable-line

  /* ---------------- the bots ----------------
   * They also cover a seat whose human has dropped, so a disconnect never freezes the table. */
  useEffect(()=>{
    if(netRef.current && netRef.current.role==="guest") return;
    if(s.mode!=="play" || s.phase!=="play") return;
    const seat = s.turn;
    const down = net.role==="host" && net.isSeatDown && net.isSeatDown(seat);
    if(s.brains[seat]==="human" && !down) return;
    const bs = (s.brains[seat]==="human") ? {...s, brains: s.brains.map((b,i)=> i===seat ? "fritzl" : b)} : s;
    /* THE BEAT. When a trick has just resolved, both cards are sitting face-up on the table and the
       player is trying to add 11 and 4 and keep a running count. Snatching them away in 620ms makes
       that impossible, and counting to 66 is not an optional part of this game — it IS the game. So the
       bot waits a full second longer before it leads to the next trick. It costs nothing and it is the
       difference between a game you can follow and a game that happens at you. */
    const justResolved = !(s.trick||[]).length && !!s.lastTrick;
    const delay = down ? 2000 : (justResolved ? 1600 : 620);
    timer.current = setTimeout(()=>{
      const d = botAction(bs, seat);
      if(d && d.action) dispatch(d.action);
    }, delay);
    return ()=>clearTimeout(timer.current);
  }, [s, net.role]);                                                 // eslint-disable-line

  useEffect(()=>{ setSel(null); }, [s.turn, s.phase, (s.trick||[]).length]);

  /* ---------------- persistence ----------------
   * The in-progress Bummerl is saved after every deal (solo only — an online Bummerl belongs to the host's
   * room, not to this device), and a finished one is banked into the high scores exactly once.
   */
  useEffect(()=>{
    if(!(s.mode==="play" && s.phase==="scored" && s.roundEndedAt)) return;
    if(recordedRef.current === s.roundEndedAt) return;
    recordedRef.current = s.roundEndedAt;

    if(s.bummerlDone){
      /* BOTH SEATS GO IN THE BOOK. Online, every device that watched the Bummerl end banks both players'
       * results, so the board fills with everyone you have ever sat across from. A bot has no initials
       * and recordBummerl drops it on the floor. */
      const entries = [0,1].map(i=>{
        const ini = (i===focus && !online) ? initials
                  : (s.brains[i]==="human" ? ((s.names && s.names[i]) || (i===focus ? initials : "")) : "");
        const won = s.bummerlWinner===i;
        const deals = (s.sheet||[]).length;
        return { ini, won,
          gpFor: s.gp[i], gpAgainst: s.gp[other(i)],
          deals, dealsWon: (s.sheet||[]).filter(r=>r.winner===i).length,
          schneider: won && s.gp[other(i)]===0 };
      });
      setScores(recordBummerl(entries));
      if(!online){ saveCampaign(null); setCampaign(null); }
    } else if(!online){
      const snap = { brains:[...s.brains], names:[...s.names], target:s.target, gp:[...s.gp],
                     bummerlNo:s.bummerlNo, dealNo:s.dealNo, sheet:[...(s.sheet||[])],
                     dealer:s.dealer, strictClaim:!!s.strictClaim, ts:Date.now() };
      saveCampaign(snap); setCampaign(snap);
    }
  }, [s.phase, s.roundEndedAt]);                                     // eslint-disable-line


  /* ---------------- chrome (the same furniture on every screen) ---------------- */
  const chrome = (
    <>
      {menuOpen && (
        <div className="overlay" onClick={()=>setMenuOpen(false)}>
          <div className="sheetmodal" onClick={(e)=>e.stopPropagation()}>
            <div className="smhead"><b className="dl-title">MENU</b><button className="dl-x" onClick={()=>setMenuOpen(false)}>×</button></div>
            <div className="smbody">
              <div className="menu-row"><span className="lbl2">Theme</span>
                <div className="toggle">
                  {[["casino","C"],["neon","N"],["blue","B"],["red","R"],["black","K"],["cream","W"],["text","T"]].map(([t,l])=>(
                    <button key={t} className={theme===t?"on":""} onClick={()=>setTheme(t)}>{l}</button>
                  ))}
                </div>
              </div>
              <div className="menu-row"><span className="lbl2">Numbered deck</span>
                <button className={"btn ghost"+(set.numerals?" on":"")} onClick={()=>setSet(v=>({...v, numerals:!v.numerals}))}>{set.numerals?"On ✓":"Off"}</button></div>
              <div className="hint" style={{fontSize:10,textAlign:"left"}}>
                Prints each card's point value on its face — the jack becomes a 2, the queen a 3, the king a 4.
                Same deck, same rules, same marriages. You just don't have to remember what a queen is worth.
              </div>
              <div className="menu-row"><span className="lbl2">Live coach</span>
                <button className={"btn ghost"+(set.coach?" on":"")} onClick={()=>setSet(v=>({...v, coach:!v.coach}))}>{set.coach?"On ✓":"Off"}</button></div>
              <div className="hint" style={{fontSize:10,textAlign:"left"}}>
                Grades every decision you make as you make it, in the log and on the table. Switch it off and
                you still get the full review after the deal — that part never goes away.
              </div>
              <div className="menu-row"><span className="lbl2">Memory mode</span>
                <button className={"btn ghost"+(set.memory?" on":"")} onClick={()=>setSet(v=>({...v, memory:!v.memory}))}>{set.memory?"On ✓":"Off"}</button></div>
              <div className="hint" style={{fontSize:10,textAlign:"left"}}>
                Memory mode hides your opponent's running score. You have to count it yourself — which is what a Schnapsen player is doing the whole time.
              </div>
              {s.mode==="play" && <ScoreSheet s={s}/>}
              <div className="menu-acts">
                <button className="btn ghost" onClick={()=>{setMenuOpen(false); setShowRules(true);}}>Rules</button>
                <button className="btn ghost" onClick={()=>{setMenuOpen(false); dispatch({type:"TO_SETUP"});}}>Setup</button>
              </div>
            </div>
          </div>
        </div>
      )}
      {showRules && <RulesScreen onClose={()=>setShowRules(false)}/>}
    </>
  );

  /* ---------------- lobby / spectator ---------------- */
  if(net.role==="spectate")
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><SpectatorView net={net}/></div>;
  if(net.role==="lobby" || (online && s.mode!=="play"))
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><OnlineScreens net={net} onStart={startOnline}/></div>;

  /* ---------------- setup ---------------- */
  if(s.mode==="setup"){
    return (
      <div className="br" data-theme={theme} style={{minHeight:"100vh", background:"var(--bg)", padding:14}}>
        <style>{THEME_CSS}</style>
        <OnlineBar net={net}/>
        <div className="app">
          <header>
            <div className="wordmark">SCHNAPSEN</div>
            <div className="toggle">
              {[["casino","Casino"],["neon","Neon"],["blue","Blue"],["red","Red"],["black","Black"],["cream","Cream"],["text","Text"]].map(([t,l])=>(
                <button key={t} className={theme===t?"on":""} onClick={()=>setTheme(t)}>{l}</button>
              ))}
            </div>
          </header>
          <div className="hint">
            Austria's national card game. Twenty cards, two players, and a race to 66 — <b>with no obligation to follow suit</b> until somebody shuts the stock.
          </div>
          <UIErrorBoundary>
            <Setup s={s} dispatch={dispatch} initials={initials} setInitials={setInitials} scores={scores}
              onStart={()=>dispatch({type:"START", brains:s.brains, names:[initials,""], target:s.target, dealer:0})}
              onShowRules={()=>setShowRules(true)}
              campaign={campaign}
              onResume={()=>{ recordedRef.current=null; dispatch({type:"RESUME", ...campaign, names:[initials,""]}); }}
              onDiscard={()=>{ saveCampaign(null); setCampaign(null); }}/>
          </UIErrorBoundary>
        </div>
        {chrome}
      </div>
    );
  }

  /* ---------------- the table ---------------- */
  /* Is the table waiting on YOU? Everything the hand can do is downstream of this one line. */
  const myTurn = s.mode==="play" && s.phase==="play" && s.turn===focus && s.brains[focus]==="human";

  const sv = { ...s, memory: set.memory };
  const me = effPts(s, focus);
  const canAct = myTurn;
  const legal = canAct ? new Set(RULES.legalCards(s, focus).map(c=>c.id)) : null;

  /* Tap once to select, tap the same card again to play it. Two taps, no gesture to learn. */
  const onPick  = (c, el)=>{ if(!canAct) return;
    if(sel===c.id){
      /* Fire the comet, THEN hold the card back until its middle reaches the table. The card used to be
         in the trick before its own particles had left your hand, which made the trail look like an
         afterthought rather than the card's own flight. */
      const beat = fxFly(el, c.suit) || 0;
      setSel(null);
      setTimeout(()=> apply({type:"PLAY", seat:focus, cardId:c.id}), beat);
    }
    else { fxBurst(el, c.suit); setSel(c.id); } };
  const playSel = ()=>{ if(sel==null || !canAct) return; const id=sel;
    const card = (s.hands[focus]||[]).find(c=>c.id===id);
    const el = document.querySelector(".br .sc-fan .brcard.sel");
    const beat = (card && el) ? (fxFly(el, card.suit) || 0) : 0;
    setSel(null);
    setTimeout(()=> apply({type:"PLAY", seat:focus, cardId:id}), beat); };
  const selCard = sel!=null ? (s.hands[focus]||[]).find(c=>c.id===sel) : null;

  const turnText = s.phase==="scored" ? ""
    : canAct
      ? (s.trick.length ? "Your turn — follow" : s.meldSuit ? `Declared ${SUIT_GLYPH[s.meldSuit]} — lead the king or the queen` : "Your lead")
      : `${who(s, s.turn)} is thinking…`;


  /* You took the trick: rain the suit of the card that WON it — not the card you played, the card that
     took it, which is the same thing when you win and is the point of the whole flourish. It falls until
     you play your next card, which is exactly the window in which the trick is still yours to enjoy. */
  const lt = s.lastTrick;
  const winSuit = (lt && lt.winner===focus && !(s.trick||[]).length)
    ? ((lt.trick.find(x=>x.seat===lt.winner)||{}).card||{}).suit || null : null;
  const winSeed = (s.log||[]).length;

  const trickMsg = s.trick.length
    ? (s.trick[0].seat===focus ? "you led — waiting" : <><b>{who(s, other(focus))}</b> led {displayRank(s.trick[0].card.rank)}{G(s.trick[0].card.suit)}</>)
    : s.lastTrick
      ? <>last trick: <b>{who(s, s.lastTrick.winner)}</b> took {s.lastTrick.pts}</>
      : "first lead";


  const r = s.result;
  const iWon = r && r.winner===focus;
  const needMore = s.target>0 ? s.target - s.gp[focus] : null;

  return (
    <div className="br" data-theme={theme} style={{position:"fixed", inset:0, background:"var(--bg)", display:"flex", flexDirection:"column"}}>
      <FxLayer/>
      <style>{THEME_CSS}</style>
      <OnlineBar net={net}/>
      <div className="stage">
        <StatusBar s={s} focus={focus} onMenu={()=>setMenuOpen(true)} turnText={turnText}/>

        <div className="gscreen">
          <AmbientRain on={!!winSuit} seed={winSeed}/>
          <TrickRain suit={winSuit} seed={winSeed}/>
          <UIErrorBoundary>
          {tab==="log" ? (
            <>
              <CoachLog moves={moves} grades={grades} on={!!set.coach}/>
              <Log s={sv} focus={focus}/>
            </>
          ) : s.phase==="scored" && r ? (
            <div className="sc-result">
              <Fireworks on={iWon}/>
              <div className="result">
                <div className={"rhead "+(iWon?"won":"lost")}>{iWon ? r.head : r.head}</div>
                <div className="rgp num">+{r.gp}<small>game points to {who(s, r.winner)}</small></div>
                <div className="rdetail">
                  {r.why}<br/>
                  Cards: <b className="num">{r.pts[focus]}</b> – <b className="num">{r.pts[other(focus)]}</b> ·
                  {" "}Tricks: <b className="num">{r.tricks[focus]}</b> – <b className="num">{r.tricks[other(focus)]}</b>
                  {r.closedBy!=null && <><br/>{who(s, r.closedBy)} closed the stock with {who(s, other(r.closedBy))} on {r.closeSnap ? r.closeSnap.pts : 0} and {r.closeSnap ? r.closeSnap.tricks : 0} {r.closeSnap && r.closeSnap.tricks===1 ? "trick" : "tricks"}.</>}
                  {r.schwarz && <><br/><b style={{color:"var(--yellow)"}}>Schwarz — {who(s, other(r.winner))} did not take a single trick.</b></>}
                </div>
                {/* Its own boundary. A crash in the grader took out the entire result screen once — the player lost
                    the actual outcome of the deal to a bug in an ornament. The scoreboard is the thing that
                    matters; the coach is the thing that is allowed to fail. */}
                <UIErrorBoundary>
                  <ScoreCard moves={moves} grades={grades} dealKey={dealKey}/>
                </UIErrorBoundary>
                {s.bummerlDone
                  ? <div className="rbig">{who(s, s.bummerlWinner)} {s.bummerlWinner===focus?"win":"wins"} the Bummerl {s.gp[s.bummerlWinner]}–{s.gp[other(s.bummerlWinner)]}{s.schneiderBummerl ? " · SCHNEIDER" : ""}</div>
                  : <div className="rdetail" style={{marginTop:8}}>{needMore} more game {needMore===1?"point":"points"} and the Bummerl is yours.</div>}
              </div>
              <ScoreSheet s={s}/>
              {s.bummerlDone && <div className="setcard"><div className="lbl2">High scores · this device</div><HighScores table={scores} meIni={online ? (net.names[focus]||net.myInitials) : initials} limit={5}/></div>}
              <div className="bar">
                {(!online || net.role==="host")
                  ? (s.bummerlDone
                      ? <button className="btn primary" onClick={()=>apply({type:"NEW_BUMMERL"})}>New Bummerl</button>
                      : <button className="btn primary" onClick={()=>apply({type:"NEXT_DEAL"})}>Next deal</button>)
                  : <div className="hint">waiting for the host…</div>}
                <button className="btn ghost" onClick={()=>setMenuOpen(true)}>Menu</button>
              </div>
            </div>
          ) : (
            <div className="sctable">
              <PlayPointsHUD grades={grades} moves={moves} on={!!set.coach}/>
              <OppStrip s={sv} seat={other(focus)} focus={focus} hidden={set.memory}/>
              <div className="sc-mid">
                <StockZone s={s}/>
                <TrickZone s={s} focus={focus} message={trickMsg}/>
              </div>
              <YouStrip s={s} seat={focus}/>
              <ActionBar s={s} seat={focus} dispatch={apply} canAct={canAct} onClose={closeStock}/>
              <div className="sc-hand">
                <div className="sc-handl">
                  Your hand
                  {canAct && <em>tap to select · tap again to play</em>}
                  {s.meldSuit && <em style={{color:"var(--purple)"}}>must lead K or Q of {SUIT_GLYPH[s.meldSuit]}</em>}
                </div>
                <Hand hand={s.hands[focus]} trump={s.trump} legalIds={legal} active={canAct}
                  selId={sel} onPick={onPick} showVal/>
              </div>
              <TalkDock s={s} net={net} online={!!online} focus={focus}/>
              <div className="sc-foot">
                {selCard
                  ? <button className="sc-play" onClick={playSel}>
                      Play&nbsp;{displayRank(selCard.rank)}<span className={suitColorClass(selCard.suit)}>{SUIT_GLYPH[selCard.suit]}</span>&nbsp;▶
                    </button>
                  : <div className="hint">{canAct
                      ? <>Tap a card to pick it up.</>
                      : turnText}</div>}
              </div>
            </div>
          )}
          </UIErrorBoundary>
        </div>

        <TabBar tab={tab} onTab={setTab} phase={s.phase} yourTurn={myTurn}/>
      </div>
      {chrome}
    </div>
  );
}
