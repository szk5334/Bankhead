import React, { useReducer, useEffect, useRef } from "react";
import { ENG } from "./engine/core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "./engine/rules.js";
import { SETUP, reducer, botAction } from "./state/reducer.js";
import { who, seatPersona, PROFILES } from "./state/personas.js";
import { SUIT_GLYPH, suitColorClass } from "./state/constants.js";
import { THEME_CSS } from "./ui/css.js";
import { UIErrorBoundary } from "./ui/errorBoundary.jsx";
import { Hand } from "./ui/hand.jsx";
import { StatusBar, TabBar, OppStrip, YouStrip, StockZone, TrickZone, ActionBar, ScoreSheet, HighScores, G } from "./ui/table.jsx";
import { Log } from "./ui/log.jsx";
import { Setup, RulesScreen, Seg } from "./ui/setup.jsx";
import { OnlineBar, OnlineScreens, SpectatorView, useGameNet } from "./ui/online.js";
import { loadTheme, saveTheme, loadInitials, saveInitials, loadSettings, saveSettings, loadCampaign, saveCampaign, loadScores, recordBummerl } from "./ui/storage.js";

export default function App(){
  const [s, dispatch] = useReducer(reducer, SETUP);
  const [theme, setTheme] = React.useState(()=>loadTheme());
  const [set, setSet] = React.useState(()=>loadSettings());
  const [initials, setInits] = React.useState(()=>loadInitials());
  const [scores, setScores] = React.useState(()=>loadScores());
  const [campaign, setCampaign] = React.useState(()=>loadCampaign());
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [showRules, setShowRules] = React.useState(false);
  const [tab, setTab] = React.useState("game");
  const [sel, setSel] = React.useState(null);

  useEffect(()=>{ saveTheme(theme); }, [theme]);
  useEffect(()=>{ saveSettings(set); }, [set]);
  const setInitials = (v)=>{ const c=(v||"").toUpperCase().replace(/[^A-Z]/g,"").slice(0,3); setInits(c); saveInitials(c); };

  const timer = useRef(null);
  const netRef = useRef(null);
  const recordedRef = useRef(null);

  /* ---------------- multiplayer ----------------
   * Identical contract to bridge: a GUEST never runs the rules, it just SENDS its action to the host and
   * renders whatever snapshot comes back. The host is the only machine that owns the deal. That is what
   * makes cheating structurally impossible rather than merely discouraged — a guest's client has never
   * been told what is in the other hand or the stock (see adapter.js/redactFor).
   */
  const apply = React.useCallback((action)=>{
    if(netRef.current && netRef.current.role==="guest"){ netRef.current.send(action); return; }
    dispatch(action);
  }, []);

  const net = useGameNet({
    onAction: (a)=>dispatch(a),                                     // host: a guest's action, already seat-checked
    onResume: (state)=>dispatch({type:"__SYNC__", state}),
    onGoSolo: ()=>dispatch({type:"TO_SETUP"}),
    onSeatChange: (seat, brain, name)=>dispatch({type:"SET_BRAIN_LIVE", seat, brain:(brain==="human"?"human":"fritzl"), name:(name!=null?name:"")}),
  });
  netRef.current = net;
  const online = net.role !== "off";
  const focus = online ? Math.max(0, net.seat) : 0;

  useEffect(()=>{ if(net.role==="host" && s.mode==="play") net.broadcastState(s, net.names, s.target); },
    [s, net.names, net.role]);                                       // eslint-disable-line
  useEffect(()=>{ if(net.role==="guest" && net.snap) dispatch({type:"__SYNC__", state: net.snap}); },
    [net.snapV]);                                                    // eslint-disable-line

  /* The host starts the game the shell's lobby set up: whoever is seated is human, anyone missing is a bot. */
  const startOnline = React.useCallback((tgt)=>{
    const brains = [0,1].map(i => (net.roster||[]).some(r=>r.seat===i) ? "human" : "fritzl");
    const names  = [0,1].map(i => (net.names && net.names[i]) || "");
    dispatch({type:"START", brains, names, target: tgt || 7, dealer:0});
  }, [net.roster, net.names]);                                       // eslint-disable-line

  /* ---------------- the bots ----------------
   * They also cover a seat whose human has dropped, so a disconnect never freezes the table. */
  useEffect(()=>{
    if(netRef.current && netRef.current.role==="guest") return;
    if(s.mode!=="play" || s.phase!=="play") return;
    const seat = s.turn;
    const down = net.role==="host" && net.isSeatDown && net.isSeatDown(seat);
    if(s.brains[seat]==="human" && !down) return;
    const bs = (s.brains[seat]==="human") ? {...s, brains: s.brains.map((b,i)=> i===seat ? "fritzl" : b)} : s;
    const delay = down ? 2000 : 620;
    timer.current = setTimeout(()=>{
      const d = botAction(bs, seat);
      if(d && d.action) dispatch(d.action);
    }, delay);
    return ()=>clearTimeout(timer.current);
  }, [s, net.role]);                                                 // eslint-disable-line

  useEffect(()=>{ setSel(null); }, [s.turn, s.phase, (s.trick||[]).length]);

  /* ---------------- persistence ----------------
   * The in-progress Bummerl is saved after every deal (solo only — an online Bummerl belongs to the host's
   * room, not to this device), and a finished one is banked into the high scores exactly once.
   */
  useEffect(()=>{
    if(!(s.mode==="play" && s.phase==="scored" && s.roundEndedAt)) return;
    if(recordedRef.current === s.roundEndedAt) return;
    recordedRef.current = s.roundEndedAt;

    if(s.bummerlDone){
      /* BOTH SEATS GO IN THE BOOK. Online, every device that watched the Bummerl end banks both players'
       * results, so the board fills with everyone you have ever sat across from. A bot has no initials
       * and recordBummerl drops it on the floor. */
      const entries = [0,1].map(i=>{
        const ini = (i===focus && !online) ? initials
                  : (s.brains[i]==="human" ? ((s.names && s.names[i]) || (i===focus ? initials : "")) : "");
        const won = s.bummerlWinner===i;
        const deals = (s.sheet||[]).length;
        return { ini, won,
          gpFor: s.gp[i], gpAgainst: s.gp[other(i)],
          deals, dealsWon: (s.sheet||[]).filter(r=>r.winner===i).length,
          schneider: won && s.gp[other(i)]===0 };
      });
      setScores(recordBummerl(entries));
      if(!online){ saveCampaign(null); setCampaign(null); }
    } else if(!online){
      const snap = { brains:[...s.brains], names:[...s.names], target:s.target, gp:[...s.gp],
                     bummerlNo:s.bummerlNo, dealNo:s.dealNo, sheet:[...(s.sheet||[])],
                     dealer:s.dealer, strictClaim:!!s.strictClaim, ts:Date.now() };
      saveCampaign(snap); setCampaign(snap);
    }
  }, [s.phase, s.roundEndedAt]);                                     // eslint-disable-line


  /* ---------------- chrome (the same furniture on every screen) ---------------- */
  const chrome = (
    <>
      {menuOpen && (
        <div className="overlay" onClick={()=>setMenuOpen(false)}>
          <div className="sheetmodal" onClick={(e)=>e.stopPropagation()}>
            <div className="smhead"><b className="dl-title">MENU</b><button className="dl-x" onClick={()=>setMenuOpen(false)}>×</button></div>
            <div className="smbody">
              <div className="menu-row"><span className="lbl2">Theme</span>
                <div className="toggle">
                  {[["casino","C"],["blue","B"],["red","R"],["black","K"],["cream","W"],["text","T"]].map(([t,l])=>(
                    <button key={t} className={theme===t?"on":""} onClick={()=>setTheme(t)}>{l}</button>
                  ))}
                </div>
              </div>
              <div className="menu-row"><span className="lbl2">Memory mode</span>
                <button className={"btn ghost"+(set.memory?" on":"")} onClick={()=>setSet(v=>({...v, memory:!v.memory}))}>{set.memory?"On ✓":"Off"}</button></div>
              <div className="hint" style={{fontSize:10,textAlign:"left"}}>
                Memory mode hides your opponent's running score. You have to count it yourself — which is what a Schnapsen player is doing the whole time.
              </div>
              {s.mode==="play" && <ScoreSheet s={s}/>}
              <div className="menu-acts">
                <button className="btn ghost" onClick={()=>{setMenuOpen(false); setShowRules(true);}}>Rules</button>
                <button className="btn ghost" onClick={()=>{setMenuOpen(false); dispatch({type:"TO_SETUP"});}}>Setup</button>
              </div>
            </div>
          </div>
        </div>
      )}
      {showRules && <RulesScreen onClose={()=>setShowRules(false)}/>}
    </>
  );

  /* ---------------- lobby / spectator ---------------- */
  if(net.role==="spectate")
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><SpectatorView net={net}/></div>;
  if(net.role==="lobby" || (online && s.mode!=="play"))
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><OnlineScreens net={net} onStart={startOnline}/></div>;

  /* ---------------- setup ---------------- */
  if(s.mode==="setup"){
    return (
      <div className="br" data-theme={theme} style={{minHeight:"100vh", background:"var(--bg)", padding:14}}>
        <style>{THEME_CSS}</style>
        <OnlineBar net={net}/>
        <div className="app">
          <header>
            <div className="wordmark">SCHNAPSEN</div>
            <div className="toggle">
              {[["casino","Casino"],["blue","Blue"],["red","Red"],["black","Black"],["cream","Cream"],["text","Text"]].map(([t,l])=>(
                <button key={t} className={theme===t?"on":""} onClick={()=>setTheme(t)}>{l}</button>
              ))}
            </div>
          </header>
          <div className="hint">
            Austria's national card game. Twenty cards, two players, and a race to 66 — <b>with no obligation to follow suit</b> until somebody shuts the stock.
          </div>
          <UIErrorBoundary>
            <Setup s={s} dispatch={dispatch} initials={initials} setInitials={setInitials} scores={scores}
              onStart={()=>dispatch({type:"START", brains:s.brains, names:[initials,""], target:s.target, dealer:0})}
              onShowRules={()=>setShowRules(true)}
              campaign={campaign}
              onResume={()=>{ recordedRef.current=null; dispatch({type:"RESUME", ...campaign, names:[initials,""]}); }}
              onDiscard={()=>{ saveCampaign(null); setCampaign(null); }}/>
          </UIErrorBoundary>
        </div>
        {chrome}
      </div>
    );
  }

  /* ---------------- the table ---------------- */
  /* Is the table waiting on YOU? Everything the hand can do is downstream of this one line. */
  const myTurn = s.mode==="play" && s.phase==="play" && s.turn===focus && s.brains[focus]==="human";

  const sv = { ...s, memory: set.memory };
  const me = effPts(s, focus);
  const canAct = myTurn;
  const legal = canAct ? new Set(RULES.legalCards(s, focus).map(c=>c.id)) : null;

  /* Tap once to select, tap the same card again to play it. Two taps, no gesture to learn. */
  const onPick  = (c)=>{ if(!canAct) return;
    if(sel===c.id){ setSel(null); apply({type:"PLAY", seat:focus, cardId:c.id}); }
    else setSel(c.id); };
  const playSel = ()=>{ if(sel==null || !canAct) return; const id=sel; setSel(null); apply({type:"PLAY", seat:focus, cardId:id}); };
  const selCard = sel!=null ? (s.hands[focus]||[]).find(c=>c.id===sel) : null;

  const turnText = s.phase==="scored" ? ""
    : canAct
      ? (s.trick.length ? "Your turn — follow" : s.meldSuit ? `Declared ${SUIT_GLYPH[s.meldSuit]} — lead the king or the queen` : "Your lead")
      : `${who(s, s.turn)} is thinking…`;

  const trickMsg = s.trick.length
    ? (s.trick[0].seat===focus ? "you led — waiting" : <><b>{who(s, other(focus))}</b> led {s.trick[0].card.rank}{G(s.trick[0].card.suit)}</>)
    : s.lastTrick
      ? <>last trick: <b>{who(s, s.lastTrick.winner)}</b> took {s.lastTrick.pts}</>
      : "first lead";


  const r = s.result;
  const iWon = r && r.winner===focus;
  const needMore = s.target>0 ? s.target - s.gp[focus] : null;

  return (
    <div className="br" data-theme={theme} style={{height:"100dvh", background:"var(--bg)", display:"flex", flexDirection:"column"}}>
      <style>{THEME_CSS}</style>
      <OnlineBar net={net}/>
      <div className="stage">
        <StatusBar s={s} focus={focus} onMenu={()=>setMenuOpen(true)} turnText={turnText}/>

        <div className="gscreen">
          <UIErrorBoundary>
          {tab==="log" ? (
            <Log s={sv} focus={focus}/>
          ) : s.phase==="scored" && r ? (
            <div className="sc-result">
              <div className="result">
                <div className={"rhead "+(iWon?"won":"lost")}>{iWon ? r.head : r.head}</div>
                <div className="rgp num">+{r.gp}<small>game points to {who(s, r.winner)}</small></div>
                <div className="rdetail">
                  {r.why}<br/>
                  Cards: <b className="num">{r.pts[focus]}</b> – <b className="num">{r.pts[other(focus)]}</b> ·
                  {" "}Tricks: <b className="num">{r.tricks[focus]}</b> – <b className="num">{r.tricks[other(focus)]}</b>
                  {r.closedBy!=null && <><br/>{who(s, r.closedBy)} closed the stock with {who(s, other(r.closedBy))} on {r.closeSnap ? r.closeSnap.pts : 0} and {r.closeSnap ? r.closeSnap.tricks : 0} {r.closeSnap && r.closeSnap.tricks===1 ? "trick" : "tricks"}.</>}
                  {r.schwarz && <><br/><b style={{color:"var(--yellow)"}}>Schwarz — {who(s, other(r.winner))} did not take a single trick.</b></>}
                </div>
                {s.bummerlDone
                  ? <div className="rbig">{who(s, s.bummerlWinner)} {s.bummerlWinner===focus?"win":"wins"} the Bummerl {s.gp[s.bummerlWinner]}–{s.gp[other(s.bummerlWinner)]}{s.schneiderBummerl ? " · SCHNEIDER" : ""}</div>
                  : <div className="rdetail" style={{marginTop:8}}>{needMore} more game {needMore===1?"point":"points"} and the Bummerl is yours.</div>}
              </div>
              <ScoreSheet s={s}/>
              {s.bummerlDone && <div className="setcard"><div className="lbl2">High scores · this device</div><HighScores table={scores} meIni={online ? (net.names[focus]||net.myInitials) : initials} limit={5}/></div>}
              <div className="bar">
                {(!online || net.role==="host")
                  ? (s.bummerlDone
                      ? <button className="btn primary" onClick={()=>apply({type:"NEW_BUMMERL"})}>New Bummerl</button>
                      : <button className="btn primary" onClick={()=>apply({type:"NEXT_DEAL"})}>Next deal</button>)
                  : <div className="hint">waiting for the host…</div>}
                <button className="btn ghost" onClick={()=>setMenuOpen(true)}>Menu</button>
              </div>
            </div>
          ) : (
            <div className="sctable">
              <OppStrip s={sv} seat={other(focus)} focus={focus} hidden={set.memory}/>
              <div className="sc-mid">
                <StockZone s={s}/>
                <TrickZone s={s} focus={focus} message={trickMsg}/>
              </div>
              <YouStrip s={s} seat={focus}/>
              <ActionBar s={s} seat={focus} dispatch={apply} canAct={canAct}/>
              <div className="sc-hand">
                <div className="sc-handl">
                  Your hand
                  {canAct && <em>tap to select · tap again to play</em>}
                  {s.meldSuit && <em style={{color:"var(--purple)"}}>must lead K or Q of {SUIT_GLYPH[s.meldSuit]}</em>}
                </div>
                <Hand hand={s.hands[focus]} trump={s.trump} legalIds={legal} active={canAct}
                  selId={sel} onPick={onPick} showVal/>
              </div>
              <div className="sc-foot">
                {selCard
                  ? <button className="sc-play" onClick={playSel}>
                      Play&nbsp;{selCard.rank}<span className={suitColorClass(selCard.suit)}>{SUIT_GLYPH[selCard.suit]}</span>&nbsp;▶
                    </button>
                  : <div className="hint">{canAct
                      ? <>Tap a card to pick it up.</>
                      : turnText}</div>}
              </div>
            </div>
          )}
          </UIErrorBoundary>
        </div>

        <TabBar tab={tab} onTab={setTab} phase={s.phase} yourTurn={myTurn}/>
      </div>
      {chrome}
    </div>
  );
}
