import { ENG } from "./core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "./rules.js";
import { solve } from "./solver.js";

/* =======================================================================
   THE BOT — and, because it is the same code, the teaching hint.

   Schnapsen splits cleanly in half, and so does this file:

     OPEN STOCK   You may play any card at all, and you keep drawing. There is no tree worth searching
                  here — the draws are random and the hand you are optimising for does not exist yet.
                  So: heuristics, and honest ones. Keep your trumps. Do not lead a bare ten into an ace.
                  Trump their aces cheaply. Cash your side aces before they get trumped. Declare every
                  marriage the moment you can.

     STRICT PLAY  Closed or exhausted: no draws, at most five tricks, and the rules collapse the branching
                  to almost nothing. This is a solved game and it is solved exactly (solver.js). When the
                  stock has *exhausted*, the opponent's hand is deducible, so the answer is not an estimate
                  — it is the truth. When the stock was *closed*, five cards are still hidden, so we sample
                  the unseen cards many ways, solve each one exactly, and take the best average.

   The close decision uses the same machinery: sample, close, solve, count how often it comes home. A bot
   that closes on a feeling is a bot that hands you two game points; this one closes when the arithmetic says so.
   ===================================================================== */

/* ---------------- WHAT THIS SEAT ACTUALLY KNOWS ----------------
 *
 * This is the honesty boundary of the whole bot, and it is built from PUBLIC FACTS ONLY — never from the
 * real opponent hand or the real stock, which the bot is not allowed to look at and which, on a guest's
 * machine, are literally card backs anyway (adapter.js redacts them before they ever leave the host).
 *
 * So the unseen set is derived by subtraction: the whole 20-card pack, minus my hand, minus everything
 * that has been played, minus the face-up turn-up. What's left is exactly the opponent's hand plus the
 * face-down stock — which is precisely the ignorance a real player sits in.
 *
 * With one exception, and it is a lovely one: if the opponent took the turn-up (by swapping their trump
 * jack for it, or by drawing it as the last card of the stock), YOU WATCHED THEM DO IT. That card is not
 * a secret and the bot must not re-deal it into the stock when it samples. The log records both events,
 * publicly, so the sampler forces those cards back into their hand where they belong.
 */
const K = (c)=> c.rank + "." + c.suit;

function knowledge(d, p){
  const o = other(p);
  const played = new Set();
  for(const e of (d.log||[])) if(e.k==="trick"){ played.add(K(e.led)); played.add(K(e.fol)); }
  if(d.trick.length) played.add(K(d.trick[0].card));
  const mine = new Set(d.hands[p].map(K));
  const upK  = d.up ? K(d.up) : null;

  const unseen = [];
  let sid = -1;
  for(const su of ENG.SUITS) for(const r of ENG.RANKS){
    const k = r + "." + su;
    if(mine.has(k) || played.has(k) || k===upK) continue;
    unseen.push({ id: sid--, rank:r, suit:su });     // synthetic ids: only ever used inside a sample
  }
  const byKey = new Map(unseen.map(c=>[K(c), c]));

  const forced = [];
  for(const e of (d.log||[])){
    if((e.k==="exchange" || e.k==="tookup") && e.seat===o){
      const c = byKey.get(K(e.card));                // still unseen => still in their hand
      if(c && forced.indexOf(c)===-1) forced.push(c);
    }
  }
  return { unseen, forced, byKey };
}

/* One plausible world: deal the unseen cards into the opponent's hand and the stock. */
function sampleDeal(d, p, rnd){
  const o = other(p);
  const { unseen, forced } = knowledge(d, p);
  const fset = new Set(forced.map(c=>c.id));
  const rest = ENG.shuffle(unseen.filter(c=>!fset.has(c.id)), rnd);

  const oSize = d.hands[o].length;
  const take  = Math.max(0, oSize - forced.length);
  const oppHand = forced.slice(0, oSize).concat(rest.slice(0, take));
  const stock   = rest.slice(take);

  const hands = {}; hands[p] = d.hands[p].slice(); hands[o] = oppHand;
  return {
    ...d,
    hands, stock, trick: d.trick.slice(),
    trickPts: d.trickPts.slice(), meldPts: d.meldPts.slice(), tricksWon: d.tricksWon.slice(),
    meldedSuits: [d.meldedSuits[0].slice(), d.meldedSuits[1].slice()],
    closeSnap: d.closeSnap ? {...d.closeSnap} : null,
    lastTrick: d.lastTrick, reveals: (d.reveals||[]).slice(), log: (d.log||[]).slice(),
  };
}

/* ---------------- open-play heuristics ----------------
 * Every number below is a card-point-ish unit, so they can be added to a marriage's 20 or 40 and mean
 * something. The costs are the important half: what a card is worth LATER, which is why the trump ace
 * costs 24 to spend and a side jack costs nothing. */
function cardCost(c, trump){
  if(c.suit===trump) return 4 + ENG.power(c) * 4;      // J 8 · Q 12 · K 16 · 10 20 · A 24
  if(c.rank==="A")  return 9;
  if(c.rank==="10") return 5;
  if(c.rank==="K")  return 1;
  return 0;
}
function leadScore(d, p, c, protectMarriage){
  const hand = d.hands[p], trump = d.trump;
  let s = 0;
  if(protectMarriage && (c.rank==="K"||c.rank==="Q")
     && hand.some(x=>x.id!==c.id && x.suit===c.suit && (x.rank==="K"||x.rank==="Q"))
     && d.meldedSuits[p].indexOf(c.suit)===-1)
    s -= 30;                                            // do not break up a marriage you have not cashed
  if(c.suit===trump){
    s -= 14 + ENG.power(c) * 2;                         // your trumps ARE the endgame — do not lead them away
  } else if(c.rank==="A"){
    s += 10;                                            // only a trump beats it, and it will be trumped later if you wait
  } else if(c.rank==="10"){
    s += hand.some(x=>x.suit===c.suit && x.rank==="A") ? 2 : -14;   // a bare ten walks straight into the ace
  } else {
    s += 6 - ENG.val(c);                               // cheap probes: J, then Q, then K
  }
  return s;
}
function followScore(d, p, c){
  const led = d.trick[0].card, trump = d.trump;
  const win = ENG.follows(led, c, trump);
  const tv  = ENG.val(led) + ENG.val(c);
  let s = win ? (tv + 3) : -tv;                          // +3 for the lead and the first draw
  s -= cardCost(c, trump);
  if(!win && c.rank==="10") s -= 6;                      // never bury a ten under a trick you are losing
  if(!win && c.rank==="A")  s -= 10;
  return s;
}

/* ---------------- the close decision ----------------
 * Sample the hidden cards, close, solve, and see how often it comes home. A close that fails costs 2 or
 * 3 game points, so the bar is high and it is set by ARITHMETIC, not by how nice the trumps look. */
function closeStudy(d, p, samples, cap, rnd){
  let n=0, sum=0, wins=0;
  for(let i=0;i<samples;i++){
    const sd = sampleDeal(d, p, rnd);
    RULES.close(sd, p);
    const r = solve(sd, p, cap);
    if(r===null) continue;
    n++; sum += r.value; if(r.value > 0) wins++;
  }
  if(!n) return null;
  return { ev: sum/n, wr: wins/n, n };
}

const SKILL = {
  poldi:  { close:false, samples:0,  solve:false, noise:0.45 },
  ignaz:  { close:true,  samples:12, solve:true,  noise:0.10, bar:0.92 },
  fritzl: { close:true,  samples:18, solve:true,  noise:0.04, bar:0.85 },
  vroni:  { close:true,  samples:20, solve:true,  noise:0.04, bar:0.68 },   // gambles on the close
  resi:   { close:true,  samples:28, solve:true,  noise:0,    bar:0.78 },
};
const skillOf = (brain)=> SKILL[brain] || SKILL.fritzl;

const G = { S:"\u2660\uFE0E", H:"\u2665\uFE0E", D:"\u2666\uFE0E", C:"\u2663\uFE0E" };
const nameOf = (c)=> c.rank + G[c.suit];

/* ---------------- the decision ----------------
 * Returns { action, why } — the SAME object whether it is driving a bot or lighting up the human's hint.
 * One brain, one explanation; a hint that disagreed with how the bots actually play would be a lie.
 */
function decide(d, p, opts){
  opts = opts || {};
  const sk = skillOf(opts.brain || "fritzl");
  const rnd = opts.rnd || Math.random;
  const strict = isStrict(d);
  const onLead = d.trick.length===0;
  const me = effPts(d, p), them = effPts(d, other(p));

  /* --- STRICT CLAIMING: if the app is not counting for you, you must say it yourself --- */
  if(opts.strictClaim && RULES.canClaim(d,p) && me >= RULES.OUT)
    return { action:{type:"CLAIM", seat:p}, why:`You are on ${me}. Declare it — the deal is over.` };

  if(onLead){
    /* --- the trump jack for the turn-up: a free upgrade, and it is always right --- */
    if(RULES.canExchange(d, p))
      return { action:{type:"EXCHANGE", seat:p},
               why:`Swap the trump ${G[d.trump]}J for the turn-up ${nameOf(d.up)} — a better trump for your worst one, and it costs you nothing.` };

    /* --- close? --- */
    if(RULES.canClose(d, p) && sk.close){
      const trumps = d.hands[p].filter(c=>c.suit===d.trump).length;
      const worth = me >= 22 || trumps >= 3;                       // don't burn cycles on hopeless closes
      if(worth){
        const st = closeStudy(d, p, sk.samples, 40000, rnd);
        if(st && st.wr >= sk.bar && st.ev > 0.6){
          return { action:{type:"CLOSE", seat:p},
                   why:`Close. From here you make 66 in ${Math.round(st.wr*100)}% of the ways the hidden cards can lie — and closing now scores you against their ${them} points, not against whatever they scrape together later.` };
        }
      }
    }

    /* --- the lead (marriages are candidates, not an afterthought) --- */
    const melds = RULES.meldOptions(d, p);
    const meldable = {}; for(const m of melds) meldable[m.suit] = m.value;

    if(strict && sk.solve){
      const r = solveHere(d, p, sk, rnd);
      if(r){
        const c = r.card;
        if(meldable[c.suit] && (c.rank==="K"||c.rank==="Q") && !d.meldSuit)
          return { action:{type:"MELD", seat:p, suit:c.suit},
                   why:`Declare the ${meldable[c.suit]===40?"royal marriage":"marriage"} in ${G[c.suit]} — ${meldable[c.suit]} points, and you have to lead one of them anyway.` };
        return { action:{type:"PLAY", seat:p, cardId:c.id}, why: solveWhy(r, d, p) };
      }
    }

    // after a declaration you must lead the K or the Q — lead the KING, it wins more often
    if(d.meldSuit){
      const opts2 = ENG.legalLeads(d.hands[p], d.meldSuit);
      const k = opts2.find(c=>c.rank==="K") || opts2[0];
      return { action:{type:"PLAY", seat:p, cardId:k.id},
               why:`You declared ${G[d.meldSuit]} — lead the king. It is the half of the marriage that wins the trick.` };
    }

    let best=null, bestS=-Infinity, bestMeld=null;
    for(const c of d.hands[p]){
      const plain = leadScore(d, p, c, true) + noise(sk, rnd);
      if(plain > bestS){ bestS=plain; best=c; bestMeld=null; }
      if(meldable[c.suit] && (c.rank==="K"||c.rank==="Q")){
        const withMeld = leadScore(d, p, c, false) + meldable[c.suit] * 0.8 + noise(sk, rnd);
        if(withMeld > bestS){ bestS=withMeld; best=c; bestMeld=c.suit; }
      }
    }
    if(bestMeld)
      return { action:{type:"MELD", seat:p, suit:bestMeld},
               why:`Declare the ${meldable[bestMeld]===40?"royal marriage":"marriage"} in ${G[bestMeld]} — ${meldable[bestMeld]} points for free. Declare them the moment you can; a marriage you are still holding at the end is worth nothing.` };
    return { action:{type:"PLAY", seat:p, cardId:best.id}, why: leadWhy(d, p, best) };
  }

  /* ---------------- following ---------------- */
  const legal = RULES.legalCards(d, p);
  if(!legal.length) return null;

  if(strict && sk.solve){
    const r = solveHere(d, p, sk, rnd);
    if(r) return { action:{type:"PLAY", seat:p, cardId:r.card.id}, why: solveWhy(r, d, p) };
  }

  // taking the trick right now would take you out — do it, and do it with the cheapest card that works
  const led = d.trick[0].card;
  const winners = legal.filter(c=>ENG.follows(led, c, d.trump));
  if(winners.length){
    const gain = ENG.val(led);
    if(me + gain + minSelf(winners) >= RULES.OUT){
      const cheap = winners.slice().sort((a,b)=> cardCost(a,d.trump)-cardCost(b,d.trump) || ENG.power(a)-ENG.power(b))[0];
      if(me + gain + ENG.val(cheap) >= RULES.OUT)
        return { action:{type:"PLAY", seat:p, cardId:cheap.id},
                 why:`Take it with ${nameOf(cheap)}. That trick is worth ${gain + ENG.val(cheap)} and puts you on ${me + gain + ENG.val(cheap)} — over 66, and the deal is yours.` };
    }
  }

  let best=null, bestS=-Infinity;
  for(const c of legal){
    const sc = followScore(d, p, c) + noise(sk, rnd);
    if(sc > bestS){ bestS=sc; best=c; }
  }
  return { action:{type:"PLAY", seat:p, cardId:best.id}, why: followWhy(d, p, best) };
}
const minSelf = (cards)=> Math.min.apply(null, cards.map(c=>ENG.val(c)));
const noise = (sk, rnd)=> sk.noise ? (rnd()-0.5) * sk.noise * 30 : 0;

/* Exhausted stock => the opponent's hand is DEDUCIBLE, so one sample IS the truth and one solve is exact.
 * Closed stock => five cards are still hidden, so solve many worlds and take the best average. */
function solveHere(d, p, sk, rnd){
  const exact = !d.closed && stockLeft(d)===0;
  if(exact){
    const sd = sampleDeal(d, p, rnd);          // with nothing hidden this is deterministic
    const r = solve(sd, p, 200000);
    return r ? { ...r, exact:true } : null;
  }
  const N = Math.max(6, sk.samples||12);
  const tally = new Map();
  let any=false;
  for(let i=0;i<N;i++){
    const sd = sampleDeal(d, p, rnd);
    const r = solve(sd, p, 40000);
    if(!r) continue;
    any=true;
    for(const m of r.moves){
      const t = tally.get(m.card.id) || { card:m.card, sum:0, n:0 };
      t.sum += m.value; t.n++; tally.set(m.card.id, t);
    }
  }
  if(!any) return null;
  const moves = Array.from(tally.values())
    .map(t=>({ card:t.card, value: t.sum/t.n }))
    .sort((a,b)=> b.value - a.value);
  return { card: moves[0].card, value: moves[0].value, moves, exact:false };
}

/* ---------------- saying why ---------------- */
function solveWhy(r, d, p){
  const c = r.card;
  const v = r.value;
  const alt = r.moves && r.moves.length>1 ? r.moves[r.moves.length-1] : null;
  const verdict = v > 0 ? `wins the deal (${v > 0 ? "+"+Math.round(v*10)/10 : v} game points)`
                : v < 0 ? `loses it by the least (${Math.round(v*10)/10})`
                : "is level";
  if(r.exact){
    let s = `The stock is gone, so every card is accounted for — this is not a guess. ${nameOf(c)} ${verdict}.`;
    if(alt && alt.value < v) s += ` ${nameOf(alt.card)} would ${alt.value>0?"still win but for less":"hand them the deal"}.`;
    return s;
  }
  return `Playing it out against every way the hidden cards can lie, ${nameOf(c)} averages ${Math.round(v*100)/100} game points — the best of your options.`;
}
function leadWhy(d, p, c){
  const trump = d.trump;
  if(c.suit===trump) return `Lead the trump ${nameOf(c)} — you are drawing their trumps so nothing of yours gets ruffed later.`;
  if(c.rank==="A")  return `Lead ${nameOf(c)}. Only a trump beats an ace, and every trick you wait is a trick it might get trumped in. Cash it while the stock is still open.`;
  if(c.rank==="10") return `Lead ${nameOf(c)} — you hold the ace behind it, so the ten is safe.`;
  return `Lead ${nameOf(c)} — cheap. While the stock is open there is no obligation to follow suit, so a low lead costs you almost nothing and makes THEM spend something.`;
}
function followWhy(d, p, c){
  const led = d.trick[0].card;
  const win = ENG.follows(led, c, d.trump);
  const tv = ENG.val(led) + ENG.val(c);
  if(win && c.suit===d.trump && led.suit!==d.trump)
    return `Trump it with ${nameOf(c)}. Their ${nameOf(led)} is worth ${ENG.val(led)} — take it with the cheapest trump that does the job and you bank ${tv} for almost nothing.`;
  if(win) return `${nameOf(c)} takes it: ${tv} points, and you keep the lead (and draw first).`;
  if(ENG.val(c) <= 3) return `You cannot win this cheaply, so throw ${nameOf(c)} away. Duck it — give them the ${ENG.val(led)} and keep your ammunition.`;
  return `Nothing here wins without spending too much. ${nameOf(c)} is the cheapest thing you can bear to lose.`;
}

const BOT = { decide, sampleDeal, closeStudy, leadScore, followScore, cardCost, solveHere, SKILL };
export { BOT, decide, sampleDeal, closeStudy };
export const __sample = sampleDeal;   // test hook: lets the guest test prove the endgame deduction is exact
