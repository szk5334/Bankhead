/* =======================================================================
   SCHNAPSEN CORE — 20 cards, French-suited.
   A(11) 10(10) K(4) Q(3) J(2).  Rank A > 10 > K > Q > J.  120 card points in the deck.
   ===================================================================== */

const ENG = (function(){
  const SUITS = ["S","H","D","C"];                 // display order
  const RANKS = ["J","Q","K","10","A"];            // LOW -> HIGH (trick power)
  const RANKVAL = { J:1, Q:2, K:3, "10":4, A:5 };  // trick power
  const CARDVAL = { J:2, Q:3, K:4, "10":10, A:11 };// card points
  const DECK_POINTS = 120;
  const OUT = 66;                                  // the number you are racing to

  let _uid = 1;
  function makeDeck(){
    const d=[];
    for(const s of SUITS) for(const r of RANKS) d.push({ id:_uid++, rank:r, suit:s });
    return d;
  }
  function shuffle(a, rnd){
    a=a.slice(); const R = rnd || Math.random;
    for(let i=a.length-1;i>0;i--){ const j=(R()*(i+1))|0; const t=a[i]; a[i]=a[j]; a[j]=t; }
    return a;
  }
  const val   = (c)=> CARDVAL[c.rank];
  const power = (c)=> RANKVAL[c.rank];
  const key   = (c)=> c.rank+"."+c.suit;

  /* Does `b` (the follow) beat `a` (the lead)? */
  function follows(a, b, trump){
    if(b.suit===a.suit) return power(b) > power(a);
    return b.suit===trump;                         // a trump on a non-trump lead
  }
  /* Winner of a two-card trick. led = the leader's card, fol = the follower's. */
  function trickWinner(led, fol, trump, ledSeat, folSeat){
    return follows(led, fol, trump) ? folSeat : ledSeat;
  }

  /* ---------------- LEGAL PLAYS ----------------
   * While the stock is OPEN you may play anything at all — that freedom is the whole first half of
   * Schnapsen. The moment the stock is exhausted OR closed, three obligations bite, IN ORDER:
   *   1. follow suit,
   *   2. and if you can beat the led card in that suit, you must,
   *   3. if you are void in the led suit you must trump (any trump; there is only one card to beat).
   * Only when you can do none of those may you throw whatever you like.
   */
  function legalFollows(hand, led, trump, strict){
    if(!strict) return hand.slice();
    const suited = hand.filter(c=>c.suit===led.suit);
    if(suited.length){
      const higher = suited.filter(c=>power(c) > power(led));
      // heading the trick is only required among cards of the led suit
      if(led.suit===trump) return higher.length ? higher : suited;
      return higher.length ? higher : suited;
    }
    const trumps = hand.filter(c=>c.suit===trump);
    if(trumps.length) return trumps;
    return hand.slice();
  }
  /* Leading is free, EXCEPT immediately after declaring a marriage: you must lead one of its two cards. */
  function legalLeads(hand, meldSuit){
    if(!meldSuit) return hand.slice();
    return hand.filter(c=>c.suit===meldSuit && (c.rank==="K"||c.rank==="Q"));
  }

  /* Which suits in this hand form a marriage (K + Q of the same suit)? */
  function marriagesIn(hand){
    const out=[];
    for(const su of SUITS){
      const hasK=hand.some(c=>c.suit===su && c.rank==="K");
      const hasQ=hand.some(c=>c.suit===su && c.rank==="Q");
      if(hasK && hasQ) out.push(su);
    }
    return out;
  }
  const meldValue = (suit, trump)=> suit===trump ? 40 : 20;

  const sortDisplay = (hand, trump)=> hand.slice().sort((a,b)=>{
    const ta = a.suit===trump ? 1:0, tb = b.suit===trump ? 1:0;
    if(ta!==tb) return tb-ta;                                  // trumps first
    const sa=SUITS.indexOf(a.suit), sb=SUITS.indexOf(b.suit);
    if(sa!==sb) return sa-sb;
    return power(a)-power(b);                                  // low -> high inside a suit
  });

  return { SUITS, RANKS, RANKVAL, CARDVAL, DECK_POINTS, OUT,
           makeDeck, shuffle, val, power, key, follows, trickWinner,
           legalFollows, legalLeads, marriagesIn, meldValue, sortDisplay };
})();

export { ENG };
