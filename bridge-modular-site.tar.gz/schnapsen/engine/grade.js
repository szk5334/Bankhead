import { ENG } from "./core.js";
import { RULES, effPts, isStrict, other } from "./rules.js";
import { decide, sampleDeal } from "./bot.js";
import { beliefSample } from "./belief.js";

/* =======================================================================
   THE GRADER — what did that card actually cost you?

   Not "was that the move the bot would have played" (that grades you against a bot's taste). The
   question is what it COST, in game points, against the best thing available. So: take every legal
   action, and for each one, play the deal out from there many times over the hands he might be
   holding. The difference between the best action's average and yours is the price of your move.

   Two disciplines carried over from the bench, and both matter more here than they did there:

   • COMMON RANDOM NUMBERS. Every candidate action is evaluated over the SAME sampled worlds. Without
     that, you are mostly measuring which action got luckier deals, and a grader that does that will
     accuse you of blunders you did not commit.

   • PRECISION OVER RECALL. A teacher who falsely accuses is worse than one who stays quiet. So a
     mistake is only ever called when the loss clears BOTH a floor (it has to matter) and its own
     confidence interval (we have to actually know). Everything else is scored silently as fine. The
     bot would rather miss a real error than invent one.

   • CROSS-FIT, and this one is not optional. The obvious grader — score every candidate over the same
     worlds, take the best, subtract yours — is BROKEN. `best` is the maximum of a handful of noisy
     estimates, and the maximum of noise is biased upward. So the "best" action is partly just the
     luckiest one, and EVERY player shows a loss, including a perfect one. Measured: it charged Greta
     0.20 game points per decision, which would be 1.6 a deal, which is nonsense.
     So we split the worlds in two. Set A CHOOSES the best action. Set B PRICES it. The selection noise
     and the evaluation noise are then independent, and a player who found the best card is charged
     nothing. This is the same correction that collapsed the phantom opening-lead gap in the bridge work.
   ===================================================================== */

const REF = { samples: 6, solve: true, noise: 0, close: false, bar: 1.1 };  // the yardstick: never closes, no recursion

const cloneDeal = (w)=> ({
  ...w,
  hands: { 0: w.hands[0].slice(), 1: w.hands[1].slice() },
  stock: w.stock.slice(), trick: w.trick.slice(),
  trickPts: w.trickPts.slice(), meldPts: w.meldPts.slice(), tricksWon: w.tricksWon.slice(),
  meldedSuits: [ w.meldedSuits[0].slice(), w.meldedSuits[1].slice() ],
  closeSnap: w.closeSnap ? {...w.closeSnap} : null,
  reveals: (w.reveals||[]).slice(), log: (w.log||[]).slice(),
});

function apply(w, seat, a){
  if(a.type==="PLAY")          RULES.play(w, seat, a.cardId, {});
  else if(a.type==="MELD")     RULES.meld(w, seat, a.suit, {});
  else if(a.type==="EXCHANGE") RULES.exchange(w, seat);
  else if(a.type==="CLOSE")    RULES.close(w, seat);
  else if(a.type==="CLAIM")    RULES.claim(w, seat);
}

function rollout(w, me, rnd){
  let g = 0;
  while(w.phase==="play" && g++ < 60){
    const q = w.turn;
    const dec = decide(w, q, { brain:"fritzl", skill:REF, style:{}, rnd });
    if(!dec) break;
    apply(w, q, dec.action);
  }
  return w.result ? (w.result.winner===me ? w.result.gp : -w.result.gp) : 0;
}

/* everything the player could legally have done here */
function candidates(d, p){
  const out = [];
  if(d.trick.length===0){
    if(RULES.canExchange(d, p)) out.push({ type:"EXCHANGE", seat:p });
    if(RULES.canClose(d, p))    out.push({ type:"CLOSE", seat:p });
    for(const m of RULES.meldOptions(d, p)) out.push({ type:"MELD", seat:p, suit:m.suit });
  }
  for(const c of RULES.legalCards(d, p)) out.push({ type:"PLAY", seat:p, cardId:c.id });
  return out;
}
const sameAction = (a, b)=>
  a.type===b.type && (a.cardId||null)===(b.cardId||null) && (a.suit||null)===(b.suit||null);

/* ---- naming the SITUATION. Distinct from naming the mistake, and the distinction is the whole reason
   bounties can exist. `tag` says what you got wrong. `kind` says what KIND of decision it was — and it is
   computed for every decision, right or wrong, because you cannot make progress against "you cash aces
   into ruffs" by counting your failures. You clear it by counting the times you were offered the
   temptation and DIDN'T take it. A leak needs a denominator. ---- */
function kindOf(d, p, ruffed){
  if(d.trick.length===0){
    if(RULES.canClose(d, p))                 return "CLOSE_CALL";
    if(RULES.meldOptions(d, p).length)       return "MARRIAGE";
    const rich = d.hands[p].some(c=> c.suit!==d.trump && (c.rank==="A" || c.rank==="10"));
    if(rich && ruffed > 0.4)                 return "ACE_RISK";
    return "LEAD";
  }
  return "FOLLOW";
}
const KIND_OF_TAG = {
  ACE_INTO_RUFF:"ACE_RISK",
  MISSED_CLOSE:"CLOSE_CALL", BAD_CLOSE:"CLOSE_CALL",
  SAT_ON_A_MARRIAGE:"MARRIAGE", BROKE_A_MARRIAGE:"MARRIAGE",
  LED_TRUMP_EARLY:"LEAD", WRONG_LEAD:"LEAD",
  DUCKED_A_WINNER:"FOLLOW", BURIED_AN_HONOUR:"FOLLOW",
  DUMPED_THE_GUARD:"FOLLOW", TOOK_A_TRICK_YOU_SHOULD_DUCK:"FOLLOW",
};

/* ---- naming the mistake. The number tells you it was wrong; the name tells you WHY. ---- */
function tagOf(d, p, chosen, best, ruffed){
  const onLead = d.trick.length===0;
  const hand = d.hands[p], trump = d.trump;
  const card = chosen.type==="PLAY" ? hand.find(c=>c.id===chosen.cardId) : null;

  if(chosen.type!=="CLOSE" && best.type==="CLOSE") return "MISSED_CLOSE";
  if(chosen.type==="CLOSE" && best.type!=="CLOSE") return "BAD_CLOSE";
  if(chosen.type!=="MELD"  && best.type==="MELD")  return "SAT_ON_A_MARRIAGE";
  if(!card) return "GENERIC";

  if(onLead){
    if(card.suit!==trump && (card.rank==="A"||card.rank==="10") && ruffed > 0.5) return "ACE_INTO_RUFF";
    if(card.suit===trump && !isStrict(d)) return "LED_TRUMP_EARLY";
    if((card.rank==="K"||card.rank==="Q")
       && hand.some(x=>x.id!==card.id && x.suit===card.suit && (x.rank==="K"||x.rank==="Q"))
       && d.meldedSuits[p].indexOf(card.suit)===-1) return "BROKE_A_MARRIAGE";
    return "WRONG_LEAD";
  }
  const led = d.trick[0].card;
  const iWin = ENG.follows(led, card, trump);
  const bestCard = best.type==="PLAY" ? hand.find(c=>c.id===best.cardId) : null;
  if(!iWin && bestCard && ENG.follows(led, bestCard, trump)) return "DUCKED_A_WINNER";
  if(!iWin && (card.rank==="A"||card.rank==="10")) return "BURIED_AN_HONOUR";
  if(!iWin && card.suit!==trump){
    const suited = hand.filter(x=>x.suit===card.suit);
    if(suited.some(x=>x.rank==="10") && card.rank!=="10" && suited.length===2) return "DUMPED_THE_GUARD";
  }
  if(iWin && bestCard && !ENG.follows(led, bestCard, trump)) return "TOOK_A_TRICK_YOU_SHOULD_DUCK";
  return "GENERIC";
}

/* ---- THE POINTS. Rewritten, because the first version paid you for noise.
 *
 * It scored a THREE-WAY CLASSIFICATION: clean (+6..+50), unsure (0), wrong (-10..-50). And "clean" was
 * `evLoss <= 0.03`, where evLoss was the CLAMPED loss — max(0, rawLoss). So every move whose noisy loss
 * happened to land below zero, which is roughly half of all non-best moves by chance alone, was paid up
 * to fifty points for it. Meanwhile "wrong" required `confident`, which with eight sampled worlds almost
 * never fired, so mistakes scored zero. Rewards on noise, punishments never: free money, and a player
 * could blunder a whole deal away and finish on +106.
 *
 * The replacement is continuous and has no classifier in it at all. You are scored on the UNCLAMPED loss
 * — which is allowed to be negative, meaning you beat the reference — measured against PAR.
 *
 * PAR is the honest part. The reference is a one-ply lookahead that searches every legal move over
 * sampled worlds; nobody plays that well, and scoring against perfection would leave every human deeply
 * negative forever. So par is what a competent player actually gives up per decision. Beat par and you
 * gain; fall short and you lose. Noise now cuts BOTH ways and averages out across a deal instead of
 * being harvested.
 *
 * Note what is no longer coupled: the POINTS are continuous and always applied, but a mistake is still
 * only NAMED when the grader is confident. Scoring what we measured and accusing only what we can prove
 * are different jobs, and the old function conflated them. ---- */
/* ---- WHERE ZERO IS. This is the whole question, and I have now had it wrong twice.
 *
 * v1 paid a bonus for every decision that could not be PROVEN wrong. That pays you for the grader's
 * uncertainty, and most decisions are uncertain, so bad players farmed it.
 *
 * v2 (par) scored `PAR - loss` against a fixed constant. Better — continuous, symmetric — but the zero
 * was still arbitrary, and `loss` was measured against a NOISY 1-ply pick. Beat that noisy pick by luck
 * and you were paid. Worse, the implicit baseline of "an average legal card" is a RANDOM player, and a
 * bad human is still better than random. So terrible play scored positive, because it was being asked
 * the wrong question: not "did you play well" but "did you beat a coin".
 *
 * v3: par is not a number. Par is THE BOT. Zero means "you played this decision as well as the machine
 * sitting opposite you would have played it". Above zero you outplayed it; below zero it outplayed you.
 * That is a calibrated, meaningful, and honest zero — and it costs nothing, because the bot's move is
 * already one of the candidates we were evaluating anyway.
 *
 * It also gives the difficulty ladder for free: zero against Poldi is not the same achievement as zero
 * against Greta, and the score says so. ---- */
const PTS_PER_GP = 100;
const CAP_GP = 3.0;                     // capped in GAME POINTS — 3 is the most a single deal can swing

function points(edgeGp, stakes){
  /* Clamp the LOSS, symmetrically, in game points. The previous version clamped the SCORE at +-60, which
   * sounds equivalent and is not: loss is right-skewed, so a rawLoss of 0.55 already hit the floor and
   * every disaster beyond it — a whole game point, two game points — cost exactly the same as a mediocre
   * card. A bad player's catastrophes were free. Capping the loss instead treats both tails alike, and
   * a blunder that really does cost a game point really does cost you a hundred. */
  const edge = Math.max(-CAP_GP, Math.min(CAP_GP, edgeGp));   // positive = you beat the bot's own move
  /* A decision that did not matter is worth almost nothing, whichever card you chose. stakes is in game
   * points and averages about 1.5, so normalise by that scale rather than by 1. */
  const weight = 0.15 + 0.85 * Math.min(1, stakes / 2.0);
  return Math.round(PTS_PER_GP * edge * weight);
}

/* ---- grade ONE decision ---- */
function gradeDecision(d, p, chosen, rnd, opts){
  opts = opts || {};
  const K = opts.worlds || 12;                            // per HALF — we draw 2K and split them
  const cands = candidates(d, p);
  if(cands.length < 2) return null;                       // no choice was made, so nothing to grade

  /* the same worlds for every candidate — CRN. otherwise we grade the shuffle, not the player. */
  const worlds = [];
  for(let i=0;i<2*K;i++) worlds.push(beliefSample(sampleDeal, opts.reads || "_base", d, p, rnd, 3));
  const A = worlds.slice(0, K), B = worlds.slice(K);      // A chooses. B prices. Never the same world.

  let ruffed = 0;
  for(const w of worlds) if(w.hands[other(p)].some(c=>c.suit===d.trump)) ruffed++;
  ruffed /= worlds.length;

  const run = (a, set)=> set.map(w => {
    const x = cloneDeal(w);
    apply(x, p, a);
    if(a.type==="MELD" || a.type==="EXCHANGE"){           // these do not end your turn — you still lead
      const dec = decide(x, p, { brain:"fritzl", skill:REF, style:{}, rnd });
      if(dec) apply(x, p, dec.action);
    }
    return rollout(x, p, rnd);
  });
  const mean = (v)=> v.reduce((a,b)=>a+b,0) / v.length;

  const evs = cands.map(a => { const va = run(a, A); return { a, va, ma: mean(va) }; });

  /* PAR. Ask the bot what IT would have played here — from your seat, with your cards, knowing only what
   * you know. Its move is already in `cands`, so scoring against it is free. This is the zero. */
  let par = null;
  try {
    const rd = decide(d, p, { brain: opts.par || "fritzl", rnd });
    if(rd && rd.action) par = evs.find(e => sameAction(e.a, rd.action)) || null;
  } catch(_){ par = null; }
  if(!par) par = evs.reduce((x,y)=> ({ ma: x.ma + y.ma/evs.length }), { ma:0 });   // fallback: the average card
  const ranked = evs.slice().sort((x,y)=> y.ma - x.ma);
  const pick = ranked[0];                                 // CHOSEN on A
  /* margin: how FINE the call was — the gap to the next-best move. Not the same thing as `stakes`,
     which is how much was riding on it. A decision can matter enormously and still be obvious (high
     stakes, wide margin); the ones worth real points are the ones that matter AND are close. */
  const margin = ranked.length > 1 ? (ranked[0].ma - ranked[1].ma) : 0;
  const mine = evs.find(e => sameAction(e.a, chosen));
  if(!mine) return null;

  /* priced on B — and if the player already found the pick, the loss is exactly zero by construction */
  /* rawLoss may be NEGATIVE — that means you beat the reference action, and the accounting must be
   * allowed to say so. Clamping it at zero would re-introduce, through the back door, exactly the
   * upward bias the cross-fit just removed: half the time the noisy A-pick is worse than your card,
   * and if those cases score 0 instead of a negative, every player on earth shows a loss.
   * So: rawLoss for the books. evLoss (clamped) only for what we SAY to the player. */
  const sameAsPick = sameAction(pick.a, chosen);
  const pickB = sameAsPick ? null : run(pick.a, B);
  const mineB = sameAsPick ? null : run(chosen, B);
  const rawLoss = sameAsPick ? 0 : (mean(pickB) - mean(mineB));
  const evLoss  = Math.max(0, rawLoss);

  const stakes = Math.max(0, ranked[0].ma - ranked[ranked.length-1].ma);

  let confident = false;
  if(!sameAsPick){
    const diffs = pickB.map((v,i)=> v - mineB[i]);        // paired on B
    const dm = mean(diffs);
    const dv = diffs.reduce((a,b)=>a+(b-dm)*(b-dm),0) / Math.max(1, diffs.length-1);
    const se = Math.sqrt(dv / diffs.length);
    confident = evLoss > 0.12 && evLoss > 1.96 * se;
  }

  /* the score: your move against the BOT's move, on the same worlds. Paired, unbiased, no maximum
   * anywhere in it — so none of the optimizer's curse that forced the cross-fit in the first place.
   * (The cross-fit survives, but only for NAMING the mistake, which does involve a maximum.) */
  const edge = mine.ma - par.ma;

  const tag = (evLoss > 0.03 && confident) ? tagOf(d, p, chosen, pick.a, ruffed) : "OK";
  return {
    evLoss, rawLoss, stakes, margin, confident, edge,
    pts: points(edge, stakes),
    tag,
    kind: kindOf(d, p, ruffed),                           // the situation — always, right or wrong
    best: pick.a, n: 2*K,
  };
}

export { gradeDecision, candidates, points, KIND_OF_TAG };
