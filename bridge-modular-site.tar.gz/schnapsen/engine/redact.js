import { effPts, stockLeft, other } from "./rules.js";
import { SUIT_GLYPH } from "../state/constants.js";
import { who } from "../state/personas.js";

/* =======================================================================
   REDACTION — what one seat is allowed to know about the table.
   This lives in the ENGINE, not in the adapter, for one reason: it is the
   rule that everything else trusts, so it has to be testable on its own.
   ===================================================================== */

/* THE PRIVACY BOUNDARY, AND IT IS THE ONLY ONE THAT MATTERS.
 *
 * The host broadcasts one snapshot per seat, and this is the function that builds it. Anything left in
 * here is on the guest's machine, in their devtools, forever. So: their hand becomes card BACKS, the stock
 * becomes card backs, and the guest is told nothing it could not have worked out at the table.
 *
 * What DOES stay is everything a real Schnapsen player is entitled to: the turn-up (both players saw it,
 * even after it is closed), the running counts, the log — every line of which is public — and hand sizes.
 * Redaction is not "hide as much as possible"; it is "hide exactly what a table would hide".
 */
function redactFor(state, seat){
  if(!state || !state.hands) return state;
  const back = (n, tag)=>{ const a=[]; for(let i=0;i<n;i++) a.push({ id:-(tag*100+i+1), rank:"?", suit:"?", back:true }); return a; };
  const opp = other(seat);
  const hands = {};
  hands[seat] = state.hands[seat];
  hands[opp]  = back((state.hands[opp]||[]).length, 1);
  return {
    ...state,
    hands,
    stock: back((state.stock||[]).length, 2),   // face-down means face-down, on every machine
  };
}

/* The spectator's view + the shell's high-score feed. `score` is game points, so the shell's own
   "top scores" list and its discovery advert both read the Bummerl correctly with no special-casing. */
function publicView(s){
  if(!s || !s.hands) return { status:"", seats:[], pileTop:null, pileCount:0, stockCount:0, log:[] };
  const seats = [0,1].map(i=>({
    name: who(s, i),
    handCount: (s.hands[i]||[]).length,
    score: s.gp ? s.gp[i] : 0,
    turn: i===s.turn && s.phase!=="scored",
    note: `${effPts(s, i)} pts · ${s.tricksWon[i]} tricks`,
  }));
  const top = s.trick && s.trick.length ? s.trick[s.trick.length-1].card
            : (s.lastTrick ? s.lastTrick.trick[s.lastTrick.trick.length-1].card : null);
  const status = s.phase==="scored"
    ? (s.result ? s.result.head : "deal over")
    : `${who(s, s.turn)} to play · ${SUIT_GLYPH[s.trump]||""} trumps${s.closed ? " · closed" : ""}`;
  const log = (s.log||[]).slice(-14).reverse().map(e=>{
    if(e.k==="trick")    return `${who(s,e.winner)} took ${e.led.rank}${SUIT_GLYPH[e.led.suit]} / ${e.fol.rank}${SUIT_GLYPH[e.fol.suit]} (${e.pts})`;
    if(e.k==="meld")     return `${who(s,e.seat)} declared ${e.value} in ${SUIT_GLYPH[e.suit]}`;
    if(e.k==="close")    return `${who(s,e.seat)} closed the stock`;
    if(e.k==="exchange") return `${who(s,e.seat)} swapped the trump jack`;
    if(e.k==="tookup")   return `${who(s,e.seat)} drew the turn-up`;
    return "";
  }).filter(Boolean);
  return {
    status, seats,
    pileTop: top ? (top.rank + SUIT_GLYPH[top.suit]) : null,
    pileCount: s.trick ? s.trick.length : 0,
    stockCount: stockLeft(s),
    log,
  };
}

export { redactFor, publicView };
