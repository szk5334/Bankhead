import { KIND_OF_TAG } from "./grade.js";

/* =======================================================================
   POINTS — the three layers that sit on top of a raw grade. Pure functions, no view, so they can be
   tested against their own rules rather than eyeballed in a screenshot.
   ===================================================================== */

/* =============== SCORING: three layers on top of the raw grade =========================
 *
 *  STREAK      consecutive clean decisions build a multiplier, ×1.1 per link to a ceiling of ×2, and a
 *              CONFIDENT mistake resets it to nothing. It rewards the thing that actually wins Schnapsen,
 *              which is not brilliance — it is not blundering. Note it multiplies gains only: a streak
 *              cannot make a blunder cost more, or the game would be punishing you twice for one card.
 *
 *  PRECISION   a bonus for finding the right move when it was HARD to see. `margin` is the gap between
 *              the best move and the next best; when that gap is thin and you still found it, that is a
 *              read, not a reflex. Fine calls pay; obvious ones do not.
 *
 *  BOUNTY      your worst habit, turned into a target. Cleared not by avoiding the situation but by
 *              meeting it and playing it clean — which is why the grader had to learn to name the KIND
 *              of every decision, not just the wrong ones.
 */
const MULT_CAP = 2.0;
function scoreDeal(grades){
  let streak = 0;
  return grades.map(g=>{
    if(!g) return null;
    const clean = g.tag === "OK";
    const mult  = clean ? Math.min(MULT_CAP, 1 + 0.1*streak) : 1;
    /* precision: matters AND close. Both, or neither. */
    const fine  = clean && !g.forced && g.margin !== undefined
                  && g.margin < 0.20 && g.stakes > 0.30;
    const bonus = fine ? Math.round(15 + 35 * Math.min(1, g.stakes)) : 0;
    const base  = g.pts;
    const pts   = base >= 0 ? Math.round(base * mult) + bonus : base;
    streak = clean ? streak + 1 : 0;
    return { ...g, base, mult, bonus, fine, pts, streak };
  });
}

const BOUNTY_NEED  = 8;
const BOUNTY_REWARD = 250;
const KIND_NAME = { ACE_RISK:"ace-cash", CLOSE_CALL:"close", MARRIAGE:"marriage", LEAD:"lead", FOLLOW:"follow" };

/* Set a bounty on your worst habit once it has happened enough times to be a habit and not an accident.
 * You clear it by playing that KIND of decision clean, eight times — not by dodging it. */
function updateBounty(career, graded){
  const c = { ...career, tags:{...career.tags}, bounty: career.bounty ? {...career.bounty} : null };
  let cleared = false;

  if(c.bounty){
    for(const g of graded){
      if(!g || g.kind !== c.bounty.kind) continue;
      if(g.tag === "OK") c.bounty.done += 1;
      else               c.bounty.done = Math.max(0, c.bounty.done - 1);   // a relapse costs you ground
    }
    if(c.bounty.done >= c.bounty.need){
      c.total += BOUNTY_REWARD;
      c.cleared = (c.cleared || []).concat([c.bounty.tag]);
      c.tags[c.bounty.tag] = 0;                       // the habit is spent; it must earn its way back
      c.bounty = null;
      cleared = true;
    }
  }
  if(!c.bounty){
    const worst = Object.entries(c.tags)
      .filter(([t,n])=> n >= 3 && KIND_OF_TAG[t])
      .sort((a,b)=> b[1]-a[1])[0];
    if(worst) c.bounty = { tag: worst[0], kind: KIND_OF_TAG[worst[0]], need: BOUNTY_NEED, done: 0 };
  }
  return { career: c, cleared };
}


export { scoreDeal, updateBounty, BOUNTY_NEED, BOUNTY_REWARD, KIND_NAME, MULT_CAP };
