import { PROFILES } from "./profiles.js";

/* =======================================================================
   BELIEF — reading the other player.

   Every bot in this file until now sampled the unseen cards UNIFORMLY. That means each of them was
   playing against a faceless opponent: a player with no habits, no tells, and nothing to exploit. Bots
   like that can be better or worse than one another. They can never be OPPOSED to one another — which is
   why the bench came out a ladder no matter how we tuned it.

   This is the fix. A reader carries a hypothesis about who it is sitting across from — "he is a Ruffer" —
   and reweights the worlds it samples accordingly. If he is a Ruffer he has been sitting on his aces all
   deal, so worlds in which he still holds two of them are LIKELY and worlds in which he holds none are
   nearly impossible. The reader then plays against that belief: it does not cash into his trumps, and it
   does not fear an ace he cannot have.

   The whole point is that the edge is CONDITIONAL. A reader is strong exactly insofar as its hypothesis
   is true, and it is a fool exactly insofar as it is false. That is the machinery of rock-paper-scissors:
   not a better player, but a player who is right about a specific opponent and wrong about another.
   ===================================================================== */

const isHon = (c, trump)=> c.suit !== trump && (c.rank==="A" || c.rank==="10");
const gauss = (x, m, sd)=> Math.exp(-((x-m)*(x-m)) / (2*sd*sd));

/* How plausible is this world, if the opponent really is `who`? */
export function worldWeight(who, oppHand, trump, tricks){
  const prof = PROFILES[who], base = PROFILES._base;
  if(!prof || !base) return 1;
  const i = Math.min(5, tricks);
  const b = prof[i], z = base[i];
  let nT=0, nH=0;
  for(const c of oppHand){ if(c.suit===trump) nT++; else if(isHon(c, trump)) nH++; }
  /* LIKELIHOOD RATIO, not fit. "Does this world look like HIM" — not "does this world look possible",
     which nearly every world does. The denominator is a uniformly-dealt stranger, so the common part of
     every profile cancels and only the direction that actually separates the styles survives.
     Clamped, not floored: the reader is allowed to be confidently wrong. That capacity IS the wheel. */
  const r = (gauss(nT, b.trump[0], b.trump[1]) / Math.max(1e-6, gauss(nT, z.trump[0], z.trump[1])))
          * (gauss(nH, b.hon[0],   b.hon[1])   / Math.max(1e-6, gauss(nH, z.hon[0],   z.hon[1])));
  return Math.min(40, Math.max(0.02, r));
}

/* Importance sampling: draw M worlds uniformly, keep one in proportion to how well it fits the read. */
export function beliefSample(sampleFn, who, d, p, rnd, M){
  if(!who || !PROFILES[who]) return sampleFn(d, p, rnd);
  const tricks = d.tricksWon[0] + d.tricksWon[1];
  const o = p ^ 1;
  const cand = [], w = [];
  let sum = 0;
  for(let i=0;i<M;i++){
    const s = sampleFn(d, p, rnd);
    const x = worldWeight(who, s.hands[o], d.trump, tricks);
    cand.push(s); w.push(x); sum += x;
  }
  let r = rnd() * sum;
  for(let i=0;i<cand.length;i++){ r -= w[i]; if(r <= 0) return cand[i]; }
  return cand[cand.length-1];
}

/* P(he can ruff my side-suit lead) under the read. This is the single most valuable thing a Schnapsen
 * player knows about the person opposite: whether the ace in his hand is safe to cash. */
export function readHand(sampleFn, who, d, p, rnd, K=10){
  const o = p ^ 1;
  const tricks = d.tricksWon[0] + d.tricksWon[1];
  let num=0, hon=0, den=0;
  for(let i=0;i<K;i++){
    const s = sampleFn(d, p, rnd);
    const w = who ? worldWeight(who, s.hands[o], d.trump, tricks) : 1;
    if(s.hands[o].some(c=>c.suit===d.trump)) num += w;
    hon += w * s.hands[o].filter(c=>isHon(c, d.trump)).length;
    den += w;
  }
  /* pRuff: can he beat my side-suit ace?   eHon: how many aces and tens is he still sitting on?
   * The second is the bigger tell — a Racer has spent his, a Ruffer is hoarding them. */
  return den > 0 ? { pRuff: num/den, eHon: hon/den } : { pRuff: 0.5, eHon: 1.5 };
}

export const BELIEF = { worldWeight, beliefSample, readHand, PROFILES };
