# SCHNAPSEN — handoff

Austrian 2-player trick-and-draw, French deck, 20 cards. Race to 66 in a deal; race to 7 game points
(a **Bummerl**) in a match. Ships as an ES-module graph, no build step, loaded by the shell via
`?module=schnapsen/adapter.js`.

## What changed outside this folder

`index.html` went **shell-r9 → shell-r10**. Eight hunks, all backward-compatible — bridge and BANKHEAD
behave exactly as before. Three of them are generic improvements that any future game gets for free:

| hunk | why |
|---|---|
| `GAMES` gets a SCHNAPSEN entry | registry |
| seat loops `k <= 3` → `k < gameMax()` | **a 2-player game could otherwise seat a third player.** Bridge/BANKHEAD have `maxPlayers: 4`, so nothing moves for them |
| host table-size `i <= 4` → `i <= gameMax()` | same reason, host side |
| new `gameTargets()`, lobby Seg reads it | the "play to" segment was hardcoded to BANKHEAD's 100/200/free. Now it reads `GAME.targets`; a game that declares none gets the old list verbatim |
| legacy link guarded on `g.entry && g.file` | Schnapsen has no monolith, so don't render a dead link to one |

## Layout

```
engine/   core.js    deck, rank order, trick resolution, legality
          rules.js   the deal state machine — the rulebook, and the only place rules live
          solver.js  exact alpha-beta endgame solver, returns signed game points
          bot.js     decide() — ONE function that drives both the bots and your hint
          redact.js  what a seat is allowed to know. Lives in engine/, not adapter/, on purpose
state/    reducer.js Bummerl-of-deals; every mutation goes through here
ui/       …          bridge's chrome, lifted (5 themes, four-colour pip deck, fan-hand gesture)
adapter.js           window.GAME. ~30 lines. It is supposed to be boring
```

## It is a playing app, not a teaching app

There is no hint, no "Why" box, no suggested-card highlight, no teaching toggle. The **Log** tab is the
public record of the deal — what was played, who took it, who declared, who took the turn-up — and it
does not advise you. **Memory mode** (menu) hides the opponent's running total so you have to count it
yourself, which is what a Schnapsen player is doing the whole time anyway. The rules reference on the
setup screen is a reference, not a tutor; say the word and it goes too.

## The two things worth knowing

**1. The bot cannot see your cards, structurally.** `engine/bot.js → knowledge()` builds the unseen set by
*subtraction*: the whole 20-card pack, minus my hand, minus everything played, minus the turn-up. It never
reads `hands[opponent]`. This matters most in **solo play**, where the bot is handed a state object that
does contain your hand — it simply never looks. `guest.test.mjs` proves it by making the bot play from a
state where your cards have been replaced with card backs: it plays exactly as well, because it never
had them.

The one exception is the good one: if the opponent **took the turn-up** — swapped their trump jack for it,
or drew it as the last card — you *watched them do it*. The log records both events publicly, so the
sampler forces that card back into their hand instead of re-dealing it into the stock. The bot remembers
what it saw.

Consequence: when the stock is exhausted, the unseen set *is* the opponent's hand, exactly. The sampler
returns one world, the solver solves it, and the endgame is played perfectly. `guest.test.mjs` verifies
that reconstruction against the truth (126 endgame positions last run).

**2. Closing is arithmetic, not vibes.** `closeStudy()` samples worlds, closes in each, solves, and
averages the signed game points. The bots close when the number says to. That's why `fritzl` beats `poldi`
78% — the ladder is real, not cosmetic.

## Verification

```
node rules.test.mjs   27/27 — incl. all three strict obligations, marriage-worthless-until-a-trick,
                      close snapshot + payout, failed close, the 3/2/1 tiers, false claim
node guest.test.mjs   the bot, the legal-move filter, and the endgame deduction all run on card
                      backs — proof the bot cannot cheat in solo play
node harness.mjs      loads the module graph THROUGH THE SHELL'S OWN Babel/CJS loader and renders.
                      If it's green here it's green on Pages
node selfplay.mjs     400 deals, 0 invariant failures (cards conserved, points ≤ 120, hands legal)
node skill.mjs        the persona ladder, seats swapped
```

All five run from `schnapsen/tests/` (`npm i react react-dom @babel/standalone` first — `harness.mjs`
needs them to render).

`harness.mjs` earns its keep: the shell's loader scans imports with a **line-anchored regex**, so a
multi-line `import { … } from "…"` is invisible to it and white-screens the phone. Keep every
`import … from` on one physical line.

## Open threads

- No tutor. If you ever want one back, `engine/bot.js` still returns a `why` string with every decision —
  the explanations were never deleted, just unwired from the UI.
- No monolith build. If you want `?game=schnapsen.jsx`, concatenate and add a `file:` key — the launcher
  will pick the legacy link up on its own.
- `state/personas.js` has five opponents (poldi / ignaz / fritzl / vroni / resi). Skill is a
  `{samples, cap}` budget on the solver, so a sixth is a table row, not code.
- The shell's own top-scores list reads `publicView().seats[].score`, which is game points — so it
  records the Bummerl correctly with no special-casing. The richer initials-keyed table in
  `ui/storage.js` sits alongside it and shares the lobby's `bh_initials` key.
