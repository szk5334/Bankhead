import { ENG } from "../engine/core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { who } from "./personas.js";

/* =======================================================================
   STATE — a BUMMERL (a race to 7 game points), played one deal at a time.

   The deal itself lives in engine/rules.js and is spread flat into this state, so `s` IS a deal plus the
   match wrapped around it. That is deliberate: the shell's redactFor/publicView only ever have to reason
   about one object, and the engine can be tested with no React anywhere near it.
   ===================================================================== */

const SETUP = {
  mode:"setup", n:2,
  brains:["human","fritzl"], names:["",""],
  target:7, gp:[0,0], bummerlNo:1, dealNo:1, dealer:0,
  bummerlDone:false, bummerlWinner:null, sheet:[],
  strictClaim:false,
};

function freshDeal(prev, dealer){
  const d = RULES.newDeal(dealer);
  return {
    ...prev, ...d,
    mode:"play",
    dealNo: prev.dealNo || 1,
    roundEndedAt: null,
    banner: `Deal ${prev.dealNo||1}. ${who(prev, other(dealer))} leads. ${d.trump} is trumps.`,
  };
}
function freshBummerl(prev, brains, names, target, dealer){
  const base = {
    ...SETUP,
    mode:"play", n:2,
    brains:[...brains], names:(names||["",""]).slice(0,2),
    target: target || 7,
    gp:[0,0], bummerlNo:(prev && prev.bummerlNo ? prev.bummerlNo+1 : 1), dealNo:1,
    bummerlDone:false, bummerlWinner:null, sheet:[],
    strictClaim: !!(prev && prev.strictClaim),
  };
  return freshDeal(base, dealer!=null?dealer:0);
}

/* The engine mutates a deal in place, so hand it a copy — React needs a NEW object to re-render, and a
 * host that mutated its own state in place would broadcast a snapshot it had already moved past. */
function clone(s){
  return {
    ...s,
    hands: { 0:(s.hands[0]||[]).slice(), 1:(s.hands[1]||[]).slice() },
    stock: (s.stock||[]).slice(),
    trick: (s.trick||[]).slice(),
    trickPts: s.trickPts.slice(), meldPts: s.meldPts.slice(), tricksWon: s.tricksWon.slice(),
    meldedSuits: [s.meldedSuits[0].slice(), s.meldedSuits[1].slice()],
    gp: s.gp.slice(), sheet: (s.sheet||[]).slice(),
    reveals: (s.reveals||[]).slice(), log: (s.log||[]).slice(),
    closeSnap: s.closeSnap ? {...s.closeSnap} : null,
  };
}

/* When a deal ends, bank it: game points, the score sheet, and whether the Bummerl is over. */
function settle(s){
  if(s.phase!=="scored" || s.roundEndedAt) return s;
  const r = s.result;
  const gp = s.gp.slice();
  gp[r.winner] += r.gp;
  const done = s.target > 0 && gp[r.winner] >= s.target;
  return {
    ...s, gp,
    roundEndedAt: Date.now(),
    sheet: (s.sheet||[]).concat([{
      dealNo: s.dealNo, winner:r.winner, gp:r.gp, reason:r.reason,
      pts:[r.pts[0], r.pts[1]], closedBy:r.closedBy, trump:s.trump,
    }]),
    bummerlDone: done,
    bummerlWinner: done ? r.winner : null,
    /* SCHNEIDERBUMMERL — they never got a single game point off you. In the coffee house that is worth
     * double, and it is the only thing in this game worth bragging about. */
    schneiderBummerl: done && gp[other(r.winner)]===0,
  };
}

function reducer(state, a){
  if(a.type==="__SYNC__") return a.state;

  switch(a.type){
    case "SET_BRAIN":  { const brains=[...state.brains]; brains[a.seat]=a.key; return {...state, brains}; }
    case "SET_NAME":   { const names=[...(state.names||["",""])]; names[a.seat]=a.name||""; return {...state, names}; }
    case "SET_TARGET": return {...state, target:a.target};
    case "SET_STRICT": return {...state, strictClaim:!!a.on};

    case "START":
      return freshBummerl(null, a.brains||state.brains, a.names||state.names, a.target||state.target, a.dealer||0);

    case "RESUME":
      return { ...freshBummerl(null, a.brains, a.names, a.target, a.dealer||0),
               gp:(a.gp||[0,0]).slice(), bummerlNo:a.bummerlNo||1, dealNo:a.dealNo||1,
               sheet:(a.sheet||[]).slice(), strictClaim:!!a.strictClaim };

    case "TO_SETUP":
      return {...SETUP, brains:[...state.brains], names:[...(state.names||["",""])],
              target:state.target||7, strictClaim:!!state.strictClaim};

    case "SET_BRAIN_LIVE": {   // the shell seats or unseats a human mid-game
      const brains = state.brains.map((b,i)=> i===a.seat ? a.brain : b);
      const names  = (state.names||["",""]).slice();
      if(a.seat < names.length) names[a.seat] = a.name!=null ? a.name : "";
      return {...state, brains, names};
    }

    case "NEXT_DEAL": {
      if(state.phase!=="scored" || state.bummerlDone) return state;
      const nd = { ...state, dealNo:(state.dealNo||1)+1 };
      return freshDeal(nd, other(state.dealer));         // the deal alternates
    }
    case "NEW_BUMMERL":
      return freshBummerl(state, state.brains, state.names, state.target, other(state.dealer||0));

    case "PLAY": {
      if(state.mode!=="play" || state.phase!=="play") return state;
      const s = clone(state);
      RULES.play(s, a.seat, a.cardId, { strictClaim: s.strictClaim });
      return settle(s);
    }
    case "MELD": {
      if(state.mode!=="play" || state.phase!=="play") return state;
      const s = clone(state);
      RULES.meld(s, a.seat, a.suit, { strictClaim: s.strictClaim });
      return settle(s);
    }
    case "EXCHANGE": {
      if(state.mode!=="play" || state.phase!=="play") return state;
      const s = clone(state); RULES.exchange(s, a.seat); return s;
    }
    case "CLOSE": {
      if(state.mode!=="play" || state.phase!=="play") return state;
      const s = clone(state); RULES.close(s, a.seat); return s;
    }
    case "CLAIM": {
      if(state.mode!=="play" || state.phase!=="play") return state;
      const s = clone(state); RULES.claim(s, a.seat); return settle(s);
    }
    default: return state;
  }
}

/* The bot's move. */
function botAction(s, seat){
  try{ return decide(s, seat, { brain: s.brains[seat], strictClaim: s.strictClaim }); }
  catch(_){
    const legal = RULES.legalCards(s, seat);          // never freeze the table: play *something* legal
    return legal.length ? { action:{ type:"PLAY", seat, cardId: legal[0].id }, why:"" } : null;
  }
}

export { SETUP, reducer, freshDeal, freshBummerl, botAction, settle, clone };
