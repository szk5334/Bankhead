/* =======================================================================
   THE BENCH. They all play the same rules; what differs is how hard they
   count and how brave they are about closing the stock.
   ===================================================================== */
const PROFILES = {
  poldi:  { name:"Poldi",  glyph:"\u263B", color:"var(--cyan)",
            blurb:"Still learning. Never closes the stock, and will hand you a trick out of politeness." },
  ignaz:  { name:"Ignaz",  glyph:"\u2666", color:"var(--di)",
            blurb:"Cautious to a fault. Counts everything but closes almost never \u2014 you will have to out-point him." },
  fritzl: { name:"Fritzl", glyph:"\u2660", color:"var(--sp)",
            blurb:"Textbook. Keeps his trumps, declares every marriage, and closes when the arithmetic says so." },
  vroni:  { name:"Vroni",  glyph:"\u2665", color:"var(--he)",
            blurb:"A gambler. Closes on two-thirds odds and dares you to punish her for it." },
  resi:   { name:"Resi",   glyph:"\u2663", color:"var(--cl)",
            blurb:"Remembers every card and solves the endgame exactly. She will not miss. Good luck." },
  greta:  { name:"Greta",  glyph:"\u2605", color:"var(--purple)",
            blurb:"Counts what you can still be holding, and closes only when closing beats playing on. She is not guessing." },
};
const ALL_BRAINS = ["poldi","ignaz","fritzl","vroni","resi","greta"];
const HUMAN = { glyph:"\u263B", color:"var(--cyan)" };

function seatPersona(s, i){
  if(s.brains[i]==="human") return { name:(s.names&&s.names[i])||(i===0?"You":"Opponent"), glyph:HUMAN.glyph, color:HUMAN.color, human:true };
  return PROFILES[s.brains[i]] || PROFILES.fritzl;
}
function who(s, i){
  const nm = s.names && s.names[i];
  if(s.brains[i]==="human") return nm || (i===0 ? "You" : "Opponent");
  return (PROFILES[s.brains[i]] || PROFILES.fritzl).name;
}
export { PROFILES, ALL_BRAINS, HUMAN, seatPersona, who };
