import { ENG } from "../engine/core.js";

/* =======================================================================
   DISPLAY CONSTANTS — two seats, and that is the whole table.
   ===================================================================== */
const SUIT_GLYPH = { S:"\u2660\uFE0E", H:"\u2665\uFE0E", D:"\u2666\uFE0E", C:"\u2663\uFE0E" };
const SUIT_NAME  = { S:"spades", H:"hearts", D:"diamonds", C:"clubs" };
const SEAT_NAME  = ["You","Them"];
const other      = (seat)=> seat^1;
const cardName   = (c)=> (!c || c.back) ? "?" : (c.rank + SUIT_GLYPH[c.suit]);
const suitColorClass = (su)=> su==="S"?"gsp":su==="H"?"ghe":su==="D"?"gdi":su==="C"?"gcl":"";
const sortHandDisplay = (hand, trump)=> ENG.sortDisplay(hand||[], trump);

export { SUIT_GLYPH, SUIT_NAME, SEAT_NAME, other, cardName, suitColorClass, sortHandDisplay };
