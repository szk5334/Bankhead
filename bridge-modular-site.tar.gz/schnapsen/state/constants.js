import { ENG } from "../engine/core.js";

/* =======================================================================
   DISPLAY CONSTANTS — two seats, and that is the whole table.
   ===================================================================== */
const SUIT_GLYPH = { S:"\u2660\uFE0E", H:"\u2665\uFE0E", D:"\u2666\uFE0E", C:"\u2663\uFE0E" };
const SUIT_NAME  = { S:"spades", H:"hearts", D:"diamonds", C:"clubs" };
const SEAT_NAME  = ["You","Them"];
const other      = (seat)=> seat^1;
/* Schnapsen's five ranks are worth 2, 3, 4, 10 and 11. The faces carry no information the numbers do
 * not — so you can simply PRINT the value on the card and let a beginner add up the table instead of
 * memorising a rank order. The J becomes a 2, the Q a 3, the K a 4; the ten and the ace are already
 * their own values. Nothing about the rules changes: a "4" still beats a "3", a marriage is still the
 * 4 and the 3 of a suit. It is a relabelling of the deck, not a variant of the game. */
let RANK_MODE = "faces";                                  // "faces" | "values"
const setRankMode = (m)=>{ RANK_MODE = (m==="values") ? "values" : "faces"; };
const VALUE_RANK = { J:"2", Q:"3", K:"4" };               // the ten and the ace already read as themselves
const displayRank = (r)=> (RANK_MODE==="values" && VALUE_RANK[r]) ? VALUE_RANK[r] : r;
const isNumbered = ()=> RANK_MODE === "values";
const cardName   = (c)=> (!c || c.back) ? "?" : (displayRank(c.rank) + SUIT_GLYPH[c.suit]);
const suitColorClass = (su)=> su==="S"?"gsp":su==="H"?"ghe":su==="D"?"gdi":su==="C"?"gcl":"";
const sortHandDisplay = (hand, trump)=> ENG.sortDisplay(hand||[], trump);

export { SUIT_GLYPH, SUIT_NAME, SEAT_NAME, other, cardName, suitColorClass, sortHandDisplay, setRankMode, displayRank, isNumbered };
