/* Runs the game THROUGH THE SHELL'S ACTUAL LOADER: the same Babel transform, the same cycle-safe
 * CommonJS registry, the same externalFor() for react. If it renders here it renders on GitHub Pages,
 * and if it throws here it would have thrown as a white screen on a phone. */
import fs from "node:fs";
import path from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";
import React from "react";
import { renderToString } from "react-dom/server";
import * as Babel from "@babel/standalone";

const ROOT = path.dirname(fileURLToPath(import.meta.url));

// ---- a minimal DOM so React + our components don't explode ----
const store = new Map();
globalThis.window = globalThis;
globalThis.localStorage = {
  getItem:(k)=>store.has(k)?store.get(k):null,
  setItem:(k,v)=>store.set(k,String(v)),
  removeItem:(k)=>store.delete(k),
};
globalThis.getComputedStyle = ()=>({ getPropertyValue:()=>"1.15" });
globalThis.ResizeObserver = class { observe(){} disconnect(){} };

function jsxRuntime(R){
  const jsx=(t,props,key)=>{ props=props||{}; const cfg={}; for(const k in props) if(k!=="children") cfg[k]=props[k];
    if(key!==undefined) cfg.key=key; const ch=props.children;
    if(ch===undefined) return R.createElement(t,cfg);
    return Array.isArray(ch)?R.createElement(t,cfg,...ch):R.createElement(t,cfg,ch); };
  return { jsx, jsxs:jsx, jsxDEV:jsx, Fragment:R.Fragment };
}
const externalFor = (spec)=>{
  if(spec==="react") return React;
  if(spec==="react-dom"||spec==="react-dom/client") return { createRoot:()=>({render(){}}) };
  if(spec==="react/jsx-runtime"||spec==="react/jsx-dev-runtime") return jsxRuntime(React);
  return undefined;
};

const RE_FROM = /^[ \t]*(?:import|export)\b[^\n]*?\bfrom[ \t]*["']([^"']+)["'][^\n]*$/mg;
const RE_BARE = /^[ \t]*import[ \t]+["']([^"']+)["'][^\n]*$/mg;
function collectSpecs(code){
  const out={}; let m;
  RE_FROM.lastIndex=0; while((m=RE_FROM.exec(code))) out[m[1]]=1;
  RE_BARE.lastIndex=0; while((m=RE_BARE.exec(code))) out[m[1]]=1;
  return Object.keys(out);
}

const factories={}, deps={}, cacheM={}, fetched={};
function fetchModule(abs){
  if(fetched[abs]) return;
  fetched[abs]=1;
  const orig = fs.readFileSync(abs, "utf8");
  const code = Babel.transform(orig, {
    presets:[["react",{runtime:"classic"}]],
    plugins:["transform-modules-commonjs"],
    filename: path.basename(abs), sourceMaps:false,
  }).code;
  factories[abs] = new Function("require","module","exports", code);
  deps[abs] = Object.create(null);
  for(const spec of collectSpecs(orig)){
    if(spec.startsWith(".")){
      const dep = path.resolve(path.dirname(abs), spec);
      deps[abs][spec]=dep;
      fetchModule(dep);
    } else if(externalFor(spec)===undefined){
      throw new Error(`bare import '${spec}' has no external and there is no CDN here — add a case in index.html's externalFor()`);
    }
  }
}
function requireAbs(abs){
  if(abs in cacheM) return cacheM[abs];
  const module={exports:{}};
  cacheM[abs]=module.exports;                    // register BEFORE running -> cycle-safe, exactly like the shell
  const localRequire=(spec)=>{
    if(!spec.startsWith(".")){ const e=externalFor(spec); if(e!==undefined) return e; throw new Error("unresolved "+spec); }
    const dep=deps[abs] && deps[abs][spec];
    if(!dep) throw new Error("unresolved require "+spec+" in "+abs);
    return requireAbs(dep);
  };
  factories[abs](localRequire, module, module.exports);
  cacheM[abs]=module.exports;
  return module.exports;
}

// ---- load exactly the way the shell does: entry = adapter.js ----
const entry = path.join(ROOT, "../adapter.js");
fetchModule(entry);
requireAbs(entry);

const GAME = globalThis.window.GAME;
console.log("window.GAME:", { id:GAME.id, title:GAME.title, min:GAME.minPlayers, max:GAME.maxPlayers,
                              actions:GAME.actionTypes, targets:GAME.targets });
if(!GAME.App) throw new Error("adapter did not register an App");
console.log("modules loaded:", Object.keys(factories).length);

// ---- render the setup screen ----
let html = renderToString(React.createElement(GAME.App));
console.log("setup renders:", html.length, "chars ·", /SCHNAPSEN/.test(html) ? "wordmark ok" : "NO WORDMARK");

// ---- drive a whole deal through the reducer and render EVERY position ----
const R = requireAbs(path.join(ROOT, "../state/reducer.js"));
const RU = requireAbs(path.join(ROOT, "../engine/rules.js"));
const { reducer, SETUP, botAction } = R;

let s = reducer(SETUP, { type:"START", brains:["human","resi"], names:["SZK",""], target:7, dealer:0 });
let steps=0, rendered=0;
const dealsSeen = [];
while(steps++ < 900){
  if(s.phase==="scored"){
    dealsSeen.push({ deal:s.dealNo, winner:s.result.winner, gp:s.result.gp, reason:s.result.reason, gpNow:[...s.gp] });
    if(s.bummerlDone) break;
    s = reducer(s, { type:"NEXT_DEAL" });
    continue;
  }
  const d = botAction(s, s.turn);           // drive BOTH seats with the bot, incl. the "human" seat 0
  if(!d || !d.action) throw new Error("no action at step " + steps);
  s = reducer(s, d.action);
}
console.log("bummerl done:", s.bummerlDone, "winner:", s.bummerlWinner, "gp:", s.gp, "deals:", dealsSeen.length);

// ---- render a live table + a result screen. The reducer state has to survive the real components. ----
let s2 = reducer(SETUP, { type:"START", brains:["human","fritzl"], names:["SZK",""], target:7, dealer:1 });
for(let i=0;i<600;i++){
  html = renderToString(React.createElement(GAME.App));   // App owns its own state; this just checks it mounts
  break;
}
console.log("table mounts:", html.length > 0);

// ---- redaction: the single most important thing to get right ----
let s3 = reducer(SETUP, { type:"START", brains:["human","human"], names:["AAA","BBB"], target:7, dealer:0 });
for(let i=0;i<6;i++){ const d=botAction(s3, s3.turn); if(!d) break; s3 = reducer(s3, d.action); if(s3.phase!=="play") break; }
const red = GAME.redactFor(s3, 1);
const leaks = [];
for(const c of red.hands[0]) if(!c.back) leaks.push("seat0 card " + c.rank + c.suit);
for(const c of red.stock)    if(!c.back) leaks.push("stock card " + c.rank + c.suit);
const ids = red.hands[0].concat(red.stock).map(c=>c.id);
if(new Set(ids).size !== ids.length) leaks.push("duplicate React keys among the card backs");
if(red.hands[1].some(c=>c.back)) leaks.push("seat1 cannot see its OWN hand");
if(red.hands[0].length !== s3.hands[0].length) leaks.push("hand size changed");
if(!red.up && s3.up) leaks.push("the turn-up was hidden — both players saw it");
console.log("redaction leaks:", leaks.length ? leaks : "none  · seat 1 sees " + red.hands[1].length + " of its own, " +
            red.hands[0].length + " backs opposite, " + red.stock.length + " in the stock");

const pv = GAME.publicView(s3);
console.log("publicView:", JSON.stringify({ status:pv.status, seats:pv.seats, stock:pv.stockCount, log:pv.log.slice(0,2) }));

if(leaks.length) process.exit(1);
console.log("\nALL GREEN");
