/* THE TEST THAT THE OLD SCORER FAILED.
   Point the grader at players of known, very different quality and demand that the points ORDER them
   and that a bad player finishes NEGATIVE. The previous scorer paid +106 for a deal full of blunders
   because it rewarded "we didn't catch you" — this asserts that cannot happen again. */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { gradeDecision } from "../engine/grade.js";
import { scoreDeal } from "../engine/points.js";
import { STYLES, SCOUT } from "./styles.mjs";

function mul(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }

const N = +(process.argv[2] || 16);
const GRETA = { reads:"_base", ruffFear:0.9, denyRuff:0.7, honFear:0.9,
                evCompare:1, evMargin:0.15, adjWin:1, meldNow:1, tenGuard:1 };
const SUBJ = {
  greta:   { style:GRETA,          skill:SCOUT },
  textbook:{ style:{},             skill:SCOUT },
  xruffer: { style:STYLES.xruffer, skill:SCOUT },
  poldi:   { style:{},             skill:{ samples:0, solve:false, noise:0.45, close:false, bar:2 } },
};

const out = {};
for(const [name, sub] of Object.entries(SUBJ)){
  let total=0, deals=0, clean=0, n=0;
  for(let s=0;s<N;s++){
    const d = RULES.newDeal(0, mul(55000 + s*17));
    const r = mul(s ^ 0x1a2b);
    const raw = [];
    let g=0;
    while(d.phase==="play" && g++<400){
      const p = d.turn;
      const dec = decide(d, p, { brain:"fritzl", skill: p===0 ? sub.skill : SCOUT,
                                 style: p===0 ? sub.style : {}, rnd:r });
      if(!dec) break;
      if(p===0){
        const gr = gradeDecision(d, 0, dec.action, r, { worlds: 8 });
        if(gr) raw.push(gr);
      }
      const a = dec.action;
      if(a.type==="PLAY")RULES.play(d,p,a.cardId,{}); else if(a.type==="MELD")RULES.meld(d,p,a.suit,{});
      else if(a.type==="EXCHANGE")RULES.exchange(d,p); else if(a.type==="CLOSE")RULES.close(d,p);
      else if(a.type==="CLAIM")RULES.claim(d,p); else break;
    }
    const sc = scoreDeal(raw);
    total += sc.reduce((a,x)=>a+x.pts,0);
    clean += sc.filter(x=>x.clean).length; n += sc.length;
    deals++;
  }
  out[name] = { perDeal: total/deals, cleanPct: 100*clean/n };
  console.log(`  ${name.padEnd(9)} ${(total/deals>=0?"+":"")}${(total/deals).toFixed(1).padStart(7)} pts/deal   ${(100*clean/n).toFixed(0).padStart(3)}% clean`);
}

let fail = 0;
const ok = (n,c,d)=>{ console.log((c?"\n  ok   ":"\n  FAIL ")+n+(d?"  ("+d+")":"")); if(!c) fail++; };
ok("the best player scores above the rest",
   out.greta.perDeal > out.textbook.perDeal && out.greta.perDeal > out.poldi.perDeal && out.greta.perDeal > out.xruffer.perDeal,
   `greta ${out.greta.perDeal.toFixed(0)} vs textbook ${out.textbook.perDeal.toFixed(0)}, poldi ${out.poldi.perDeal.toFixed(0)}, xruffer ${out.xruffer.perDeal.toFixed(0)}`);
ok("a genuinely bad player scores NEGATIVE", out.poldi.perDeal < 0,
   `poldi ${out.poldi.perDeal.toFixed(1)}`);
ok("a good player scores positive", out.greta.perDeal > 0, `greta ${out.greta.perDeal.toFixed(1)}`);
ok("a bad player is caught out more often than a good one",
   out.poldi.cleanPct < out.greta.cleanPct,
   `poldi ${out.poldi.cleanPct.toFixed(0)}% clean vs greta ${out.greta.cleanPct.toFixed(0)}%`);
ok("the gap between best and worst is decisive",
   out.greta.perDeal - out.poldi.perDeal > 40,
   `${(out.greta.perDeal - out.poldi.perDeal).toFixed(0)} points a deal`);
process.exit(fail?1:0);
