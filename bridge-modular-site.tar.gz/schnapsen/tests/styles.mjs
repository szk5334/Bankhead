/* Candidate styles. All eight play at the SAME skill (same samples, zero noise, same base close
 * bar) — so anything the bench finds between them is STYLE, not strength. If they differed in
 * search depth we would just be re-measuring the ladder with new names.
 *
 * Every knob is a sentence:
 *   trumpKeep  low = spends trumps freely (ruffs)      high = hoards them
 *   trumpLead  low = happily leads trumps              high = never leads them away
 *   aceLead    high = cashes side aces early           negative = refuses to cash
 *   tenFear    high = will not lead a bare ten         low = leads it anyway
 *   aceHold    high = will not bury an ace/ten         low = throws them under a lost trick
 *   duck       positive = would rather lose the trick cheaply than win it
 *   meld       high = plays for the 20s and 40s
 *   barAdj     negative = closes braver than its skill says
 */
export const STYLES = {
  /* the reference: exactly the bot that ships today */
  textbook:  {},

  /* cashes its winners while they are alive and races to 66 */
  racer:     { aceLead: 2.0, aceHold: 0.5, tenFear: 0.6, trumpKeep: 1.2, duck: -3, barAdj: +0.06 },

  /* hoards trumps, never cashes, ducks cheap, and eats your aces */
  ruffer:    { aceLead: -0.4, trumpKeep: 0.45, trumpLead: 1.7, duck: +6, aceHold: 1.8, barAdj: +0.10 },

  /* the tier-exploiter: closes far braver than the arithmetic strictly wants */
  closer:    { barAdj: -0.25, trumpKeep: 1.3, aceHold: 1.2, duck: +1 },

  /* plays for the 20s and the 40s; needs one trick and nothing else */
  wedding:   { meld: 2.2, trumpLead: 1.4, aceLead: 0.6, aceHold: 1.4, duck: +2 },

  /* gives nothing away, ever. keeps its own points low as a side effect */
  miser:     { duck: +9, aceHold: 1.9, aceLead: 0.2, tenFear: 1.7, trumpKeep: 1.4 },

  /* leads trumps to strip — the vertex I argued on paper CANNOT work, kept in to be falsified */
  stripper:  { trumpLead: 0.3, trumpKeep: 0.8, aceLead: 1.6, barAdj: -0.08 },

  /* EXTREME prey. The moderate archetypes barely leave a fingerprint — a reader can only exploit a tell
   * that exists. These two are caricatures on purpose: one cashes everything the instant he can, the
   * other would rather die than spend an ace. Their hands look nothing alike by trick four. */
  xracer:    { aceLead: 3.0, aceHold: 0.15, tenFear: 0.15, duck: -6, trumpKeep: 1.1 },
  xruffer:   { aceLead: -2.0, aceHold: 2.6, tenFear: 2.0, duck: +8, trumpKeep: 0.40, trumpLead: 1.8 },

  /* plays the transition: dump cheap tricks, be on lead when the stock runs dry */
  clock:     { duck: +5, trumpKeep: 1.7, trumpLead: 1.8, aceHold: 1.5, aceLead: 0.3, barAdj: +0.12 },
};

/* one skill for everybody. samples kept low for the search; finalists get re-run at full strength. */
export const SCOUT = { samples: 8, solve: true, noise: 0, close: true, bar: 0.85 };

/* Objective-space vertices. The heuristics are IDENTICAL to textbook — the only thing that differs is
 * what the bot is maximising when it averages over worlds it cannot see. Note we do not hand-tune their
 * bravery: a convex objective (tier) clears evBar more easily and so closes more; a sign objective (safe)
 * clears it less easily and so closes less. The risk appetite is a CONSEQUENCE of the objective, not a
 * second knob bolted on beside it. */
export const OBJS = {
  textbook: {},
  safe:     { obj:"safe" },                 // only the win counts; a 1 is as good as a 3
  tier:     { obj:"tier" },                 // hunt the 2s and 3s, pay risk to get them
  racer:    STYLES.racer,
  ruffer:   STYLES.ruffer,
  closer:   STYLES.closer,
  stripper: STYLES.stripper,
  wedding:  STYLES.wedding,
};

/* THE READERS. Identical heuristics to textbook — the ONLY difference is who they think they are
 * playing. Each carries a fixed hypothesis and acts on it: it will not cash into trumps it believes are
 * there, it will lead trumps to kill ruffs it believes are coming, and it will lead its tens into a man
 * it believes has already spent his aces. Its edge is exactly as true as its hypothesis. */
const READ = { ruffFear: 0.9, denyRuff: 0.7, honFear: 0.8 };
export const READERS = {
  racer:      STYLES.racer,
  ruffer:     STYLES.ruffer,
  stripper:   STYLES.stripper,
  textbook:   {},
  vsRacer:    { ...READ, reads:"racer"    },
  vsRuffer:   { ...READ, reads:"ruffer"   },
  vsStripper: { ...READ, reads:"stripper" },
};

/* THE DECISIVE EXPERIMENT.
 *   xracer / xruffer  — the prey, with fingerprints that now genuinely differ
 *   counter           — the CONTROL. Has every belief term (ruffFear, honFear, denyRuff) but reads "_base",
 *                       whose likelihood ratio is identically 1. So it card-counts and does not read.
 *                       Anything a reader achieves ABOVE this bot is the value of the read itself.
 *   vsXRacer/vsXRuffer— readers committed to one hypothesis.
 * Prediction: vsXRuffer beats xruffer by more than counter does, and LOSES that edge against xracer. */
const READ2 = { ruffFear: 0.9, denyRuff: 0.7, honFear: 0.9 };
export const HUNTERS = {
  xracer:    STYLES.xracer,
  xruffer:   STYLES.xruffer,
  textbook:  {},
  counter:   { ...READ2, reads:"_base"   },
  vsXRacer:  { ...READ2, reads:"xracer"  },
  vsXRuffer: { ...READ2, reads:"xruffer" },
};
