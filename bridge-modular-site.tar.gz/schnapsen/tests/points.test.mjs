/* The scoring rules, asserted against their own stated intent. */
import { scoreDeal, updateBounty, BOUNTY_NEED, BOUNTY_REWARD, MULT_CAP } from "../engine/points.js";

let fail = 0;
const ok = (n, c, d)=>{ console.log((c?"  ok   ":"  FAIL ")+n+(d?"  ("+d+")":"")); if(!c) fail++; };
const G = (o)=> ({ pts:20, tag:"OK", kind:"LEAD", stakes:0.1, margin:0.9, evLoss:0, ...o });

/* --- streak --- */
let g = scoreDeal([G(),G(),G(),G(),G(),G()]);
ok("a clean run builds a multiplier", g[5].mult > g[1].mult, `×${g[1].mult.toFixed(1)} -> ×${g[5].mult.toFixed(1)}`);
ok("the multiplier is capped", scoreDeal(Array(30).fill(G())).slice(-1)[0].mult === MULT_CAP, `×${MULT_CAP}`);

g = scoreDeal([G(),G(),G(),G(),G({pts:-30, tag:"ACE_INTO_RUFF"}),G()]);
ok("a confident mistake resets the streak", g[5].mult === 1, `×${g[5].mult}`);
ok("the streak never magnifies a LOSS", g[4].pts === -30,
   "a blunder after four clean cards must not cost double");

/* --- precision --- */
const obvious = scoreDeal([G({ stakes:0.9, margin:0.9 })])[0];
const fine    = scoreDeal([G({ stakes:0.9, margin:0.05 })])[0];
ok("an obvious right move earns no precision bonus", obvious.bonus === 0);
ok("a fine right move does", fine.bonus > 0, `+${fine.bonus}`);
const finePointless = scoreDeal([G({ stakes:0.02, margin:0.01 })])[0];
ok("a close call that did not MATTER earns nothing", finePointless.bonus === 0,
   "close + trivial is not a read, it is a coin-flip nobody cared about");

/* --- bounty --- */
let career = { total:0, deals:0, best:0, tags:{ ACE_INTO_RUFF:4 }, bounty:null };
let r = updateBounty(career, []);
ok("a repeated habit gets a bounty put on it", r.career.bounty && r.career.bounty.tag==="ACE_INTO_RUFF");
ok("the bounty targets the KIND, not the mistake", r.career.bounty.kind === "ACE_RISK");

career = r.career;
r = updateBounty(career, [G({kind:"ACE_RISK", tag:"OK"}), G({kind:"LEAD", tag:"OK"})]);
ok("a clean decision of that kind is progress", r.career.bounty.done === 1);
ok("a clean decision of another kind is not", r.career.bounty.done === 1);

r = updateBounty(r.career, [G({kind:"ACE_RISK", tag:"ACE_INTO_RUFF", pts:-40})]);
ok("a relapse costs you ground", r.career.bounty.done === 0);

let c2 = r.career;
for(let i=0;i<BOUNTY_NEED;i++) c2 = updateBounty(c2, [G({kind:"ACE_RISK", tag:"OK"})]).career;
ok("clearing it pays out", c2.total === BOUNTY_REWARD, `+${c2.total}`);
ok("and the habit is wiped, not merely ticked", (c2.tags.ACE_INTO_RUFF||0) === 0);
ok("you cannot clear a bounty by AVOIDING the situation",
   updateBounty({total:0,deals:0,best:0,tags:{ACE_INTO_RUFF:4},bounty:{tag:"ACE_INTO_RUFF",kind:"ACE_RISK",need:8,done:0}},
                [G({kind:"FOLLOW"}),G({kind:"FOLLOW"}),G({kind:"LEAD"})]).career.bounty.done === 0);

console.log(fail ? `\n${fail} FAILED` : "\nall green — streaks build and break, fine calls pay, and a leak is cleared by facing it.");
process.exit(fail?1:0);
