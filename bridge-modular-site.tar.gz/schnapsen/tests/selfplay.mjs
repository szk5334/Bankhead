import { ENG } from "../engine/core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "../engine/rules.js";
import { decide } from "../engine/bot.js";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }

const ARG = Object.fromEntries(process.argv.slice(2).map(x=>{const [k,v]=x.split("=");return [k.replace(/^--/,""),v??"1"];}));
const N = +(ARG.n || 300);
const B0 = ARG.b0 || "fritzl", B1 = ARG.b1 || "fritzl";
const STRICT = ARG.strict === "1";

let fails = 0, deals = 0;
const gpTally = {1:0,2:0,3:0};
const reasons = {}; const wins = [0,0]; let closes=0, closeFails=0, melds=0, exchanges=0;
const seatWins = [0,0];

function chk(cond, msg, d){ if(!cond){ fails++; if(fails<6) console.error("FAIL:", msg, JSON.stringify({trump:d.trump, tp:d.trickPts, mp:d.meldPts, tw:d.tricksWon, closed:d.closed, res:d.result})); } }

const t0 = Date.now();
for(let g=0; g<N; g++){
  const rnd = mulberry(1000+g);
  const d = RULES.newDeal(g % 2, rnd);
  const opts = { strictClaim: STRICT };
  let guard = 0;
  const startCards = ENG.makeDeck().length; // just to touch it

  while(d.phase === "play"){
    if(++guard > 400){ chk(false, "no termination", d); break; }
    const p = d.turn;
    const dec = decide(d, p, { brain: p===0?B0:B1, rnd, strictClaim: STRICT });
    chk(!!dec, "bot produced no action", d);
    if(!dec) break;
    const a = dec.action;

    // ---- every action the bot proposes must be legal by the rules module ----
    if(a.type==="PLAY"){
      const legal = RULES.legalCards(d, p);
      chk(legal.some(c=>c.id===a.cardId), "illegal card", d);
      RULES.play(d, p, a.cardId, opts);
    } else if(a.type==="MELD"){
      chk(RULES.meldOptions(d,p).some(m=>m.suit===a.suit), "illegal meld", d);
      melds++; RULES.meld(d, p, a.suit, opts);
    } else if(a.type==="EXCHANGE"){
      chk(RULES.canExchange(d,p), "illegal exchange", d);
      exchanges++; RULES.exchange(d, p);
    } else if(a.type==="CLOSE"){
      chk(RULES.canClose(d,p), "illegal close", d);
      closes++; RULES.close(d, p);
    } else if(a.type==="CLAIM"){
      chk(RULES.canClaim(d,p), "illegal claim", d);
      RULES.claim(d, p);
    }

    // ---- invariants that must hold at EVERY step ----
    const inPlay = d.hands[0].length + d.hands[1].length + d.trick.length + d.stock.length + (d.up?1:0);
    const played = (d.log||[]).filter(e=>e.k==="trick").length * 2;
    chk(inPlay + played === 20, "cards conserved (" + inPlay + "+" + played + ")", d);
    chk(d.trickPts[0] + d.trickPts[1] <= 120, "trick points <= 120", d);
    if(!d.closed && stockLeft(d) > 0 && d.trick.length===0 && d.phase==="play")
      chk(d.hands[0].length === d.hands[1].length, "hands equal between tricks", d);
    chk(d.hands[0].length <= 5 && d.hands[1].length <= 5, "hand size <= 5", d);
  }

  deals++;
  const r = d.result;
  chk(!!r, "deal produced no result", d);
  if(!r) continue;
  chk(r.gp>=1 && r.gp<=3, "gp in 1..3", d);
  chk(d.trickPts[0] + d.trickPts[1] === 120 || r.reason==="claim" || r.reason==="closedOut", "all 120 dealt out on exhaustion", d);
  gpTally[r.gp]++; reasons[r.reason]=(reasons[r.reason]||0)+1; seatWins[r.winner]++;
  if(d.closed){ if(r.winner !== d.closedBy) closeFails++; }
}
const ms = Date.now()-t0;

console.log(`deals=${deals}  fails=${fails}  ${ms}ms  (${(ms/deals).toFixed(1)} ms/deal)`);
console.log(`winner by seat: fore/deal alternating -> ${seatWins}`);
console.log(`game points:`, gpTally);
console.log(`endings:`, reasons);
console.log(`closes=${closes} (failed ${closeFails})  melds=${melds}  exchanges=${exchanges}`);
process.exit(fails ? 1 : 0);
