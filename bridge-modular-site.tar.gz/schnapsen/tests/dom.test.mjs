/* THE TEST THAT WOULD HAVE CAUGHT IT.
 *
 * The other harness rendered the setup screen and mounted the app — and passed, happily, while the Deal
 * button led straight to a white screen. It never pressed anything. A render test that never clicks is
 * testing that your app can sit still.
 *
 * So this one mounts the real app in a real DOM and *uses* it: presses Deal, plays cards until the deal
 * scores, presses through a whole Bummerl, and opens every tab and the menu on the way. Any React error,
 * any window error, any console.error is a failure. And it asserts it ARRIVED somewhere — "no error" is
 * not the same as "it worked".
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { JSDOM } from "jsdom";
import * as Babel from "@babel/standalone";

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const SRC  = path.join(ROOT, "..");

const dom = new JSDOM('<!doctype html><html><body><div id="root"></div></body></html>',
  { pretendToBeVisual: true, url: "https://example.org/" });
const { window } = dom;
globalThis.window = window;
globalThis.document = window.document;
Object.defineProperty(globalThis, "navigator", { value: window.navigator, configurable: true });
globalThis.HTMLElement = window.HTMLElement;
globalThis.Element = window.Element;
globalThis.Node = window.Node;
globalThis.getComputedStyle = window.getComputedStyle.bind(window);
globalThis.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 0);
globalThis.cancelAnimationFrame = clearTimeout;
window.ResizeObserver = globalThis.ResizeObserver = class { observe(){} unobserve(){} disconnect(){} };
globalThis.IS_REACT_ACT_ENVIRONMENT = true;
window.localStorage.setItem("bh_initials", "SZK");     // Deal is gated behind initials

const React = (await import("react")).default;
const RD = await import("react-dom");
const { createRoot } = await import("react-dom/client");
const { act } = await import("react-dom/test-utils");

/* ---- the shell's loader, verbatim ---- */
function jsxRuntime(R){
  const jsx=(t,props,key)=>{ props=props||{}; const cfg={}; for(const k in props) if(k!=="children") cfg[k]=props[k];
    if(key!==undefined) cfg.key=key; const ch=props.children;
    if(ch===undefined) return R.createElement(t,cfg);
    return Array.isArray(ch)?R.createElement(t,cfg,...ch):R.createElement(t,cfg,ch); };
  return { jsx, jsxs:jsx, jsxDEV:jsx, Fragment:R.Fragment };
}
const externalFor=(s)=> s==="react"?React : s==="react-dom"?RD
  : (s==="react/jsx-runtime"||s==="react/jsx-dev-runtime")?jsxRuntime(React) : undefined;
const RE_FROM=/^[ \t]*(?:import|export)\b[^\n]*?\bfrom[ \t]*["']([^"']+)["'][^\n]*$/mg;
const factories={},deps={},cacheM={},fetched={};
function fetchModule(abs){
  if(fetched[abs]) return; fetched[abs]=1;
  const orig=fs.readFileSync(abs,"utf8");
  factories[abs]=new Function("require","module","exports",
    Babel.transform(orig,{presets:[["react",{runtime:"classic"}]],plugins:["transform-modules-commonjs"],filename:path.basename(abs)}).code);
  deps[abs]=Object.create(null); RE_FROM.lastIndex=0; let m;
  while((m=RE_FROM.exec(orig))){ const sp=m[1];
    if(sp.startsWith(".")){ const d=path.resolve(path.dirname(abs),sp); deps[abs][sp]=d; fetchModule(d); }
    else if(externalFor(sp)===undefined) throw new Error("bare import with no external: "+sp); }
}
function requireAbs(abs){
  if(abs in cacheM) return cacheM[abs];
  const mod={exports:{}}; cacheM[abs]=mod.exports;
  factories[abs]((sp)=> sp.startsWith(".") ? requireAbs(deps[abs][sp]) : externalFor(sp), mod, mod.exports);
  return (cacheM[abs]=mod.exports);
}
fetchModule(path.join(SRC,"adapter.js")); requireAbs(path.join(SRC,"adapter.js"));
const GAME = window.GAME;

/* ---- nothing is swallowed ---- */
const errors=[];
console.error = (...a)=>{ const s=a.map(String).join(" "); if(!/not wrapped in act|ReactDOMTestUtils/.test(s)) errors.push(s); };
window.addEventListener("error", e=>errors.push("window.onerror: "+e.message));
const die = (where)=>{ console.log("\n*** "+where+" ***\n"+errors.slice(0,2).join("\n---\n").slice(0,2200)); process.exit(1); };
const fail = (m)=>{ console.log("FAIL: "+m); process.exit(1); };

const el = document.getElementById("root");
await act(async ()=>{ createRoot(el).render(React.createElement(GAME.App)); });

const btns  = ()=> [...el.querySelectorAll("button")];
const findB = (re)=> btns().find(b=>re.test((b.textContent||"").trim()));
const click = async (b)=>{ if(!b) return false; await act(async ()=>{ b.dispatchEvent(new window.MouseEvent("click",{bubbles:true})); }); return true; };
const tick  = async (ms=20)=>{ await act(async ()=>{ await new Promise(r=>setTimeout(r,ms)); }); };
const text  = ()=>{ const c=el.cloneNode(true); c.querySelectorAll("style").forEach(n=>n.remove()); return c.textContent.replace(/\s+/g," "); };

/* 1 — press Deal. */
const deal = findB(/^Deal$/);
if(!deal) fail("no Deal button on the setup screen");
await click(deal); await tick(60);
if(errors.length) die("CRASH ON DEAL");

/* 2 — did we actually ARRIVE at a table? */
if(!el.querySelector(".sctable")) fail("Deal did not produce a table (.sctable missing)");
const cards = el.querySelectorAll(".sc-hand .brcard").length;
if(cards !== 5) fail("expected 5 cards in hand after the deal, got " + cards);
console.log("Deal \u2192 table, 5 cards in hand. ok");

/* 2b — the FLICK. It is the primary way you play a card, and nothing had ever tested it: mousedown on the
 *      fan to focus the nearest legal card, then release well above the start point. A card should leave
 *      your hand and land on the table. */
{
  // If the bot is non-dealer it leads, so wait until the table is actually waiting on us.
  for(let i=0;i<80 && !/Slide along your hand/.test(text()); i++) await tick(25);
  if(!/Slide along your hand/.test(text())) fail("the table never handed us the move");
  const fan = [...el.querySelectorAll(".sc-hand div")].find(d => d.style && d.style.touchAction === "pan-y");
  if(!fan) fail("the fan hand did not render");

  // Don't count cards: the flick plays, the bot answers, the trick is taken and BOTH PLAYERS DRAW, all
  // inside one React flush — so the hand is back to five before you can look at it, and a naive count
  // says nothing happened. Name the card instead, and check that specific card left your hand.
  await act(async ()=>{ fan.dispatchEvent(new window.MouseEvent("mousedown", { bubbles:true, clientX:160, clientY:400 })); });
  const named = (text().match(/Play\s+(\S+)\s*\u25b6/) || [])[1];
  if(!named) fail("mousedown on the fan did not focus a card");
  const handHas = ()=> [...el.querySelectorAll(".sc-hand .brcard")].some(c => c.textContent.replace(/\s+/g,"").includes(named.replace(/\s+/g,"")));
  if(!handHas()) fail("the focused card " + named + " is not in the hand");

  await act(async ()=>{ fan.dispatchEvent(new window.MouseEvent("mouseup", { bubbles:true, clientX:160, clientY:300 })); }); // flick up
  if(errors.length) die("CRASH ON THE FLICK");
  if(handHas()) fail("flicked " + named + " but it is still in your hand");
  await tick(60);
  if(errors.length) die("CRASH RESOLVING THE TRICK");
  console.log("flick up \u2192 " + named + " left the hand and the trick resolved. ok");
}

/* 3 — open every tab and the menu. The Log tab had never been rendered by anything. */
if(!await click(findB(/^Log$/))) fail("no Log tab");
await tick(10); if(errors.length) die("CRASH OPENING THE LOG TAB");
if(!await click(findB(/^(Play|Result)$/))) fail("no Play tab");
await tick(10); if(errors.length) die("CRASH RETURNING TO THE PLAY TAB");
await click(el.querySelector(".gs-menu")); await tick(10);
if(errors.length) die("CRASH OPENING THE MENU");
if(!/Memory mode/.test(text())) fail("the menu did not open");
await click(findB(/^(Close|Resume|Back|Done)$/));
await tick(10);
console.log("Log tab, Play tab, menu: all open without throwing. ok");

/* 4 — play it. Click legal cards and action buttons until the Bummerl is done. */
let plays=0, deals=1, guard=0;
while(guard++ < 5000){
  await tick(10);
  if(errors.length) die("CRASH DURING PLAY");
  if(/wins? the Bummerl/.test(text())) break;

  const next = findB(/^(Next deal|New Bummerl)$/);
  if(next){ if(/Next deal/.test(next.textContent)) deals++; await click(next); continue; }

  const doIt = findB(/^(Play\s|Declare|Close$|Swap)/);
  if(doIt){ await click(doIt); plays++; continue; }

  // The hand is a scrub-and-flick gesture, not a set of click targets — so drive it as a gesture.
  // mousedown anywhere along the fan focuses the nearest LEGAL card; then the foot shows "Play X".
  const fan = [...el.querySelectorAll(".sc-hand div")].find(d => d.style && d.style.touchAction === "pan-y");
  if(fan){
    const mouse = (type, y)=> new window.MouseEvent(type, { bubbles:true, clientX: 40 + (guard*37)%240, clientY: y });
    await act(async ()=>{ fan.dispatchEvent(mouse("mousedown", 400)); });
    await act(async ()=>{ fan.dispatchEvent(mouse("mouseup",   400)); });   // a tap: focus, don't flick
    continue;
  }
  break;
}
if(errors.length) die("CRASH DURING PLAY");
if(!/wins? the Bummerl/.test(text())) fail("never reached the end of a Bummerl in "+guard+" steps");
console.log("played "+plays+" actions across "+deals+" deals \u00b7 the Bummerl ended. ok");

/* 5 — the result screen, the score sheet, the high scores. */
const t = text();
for(const must of [[/game points to/,"the game-point award"], [/Cards:/,"the card count"],
                   [/Tricks:/,"the trick count"], [/High scores/,"the high-score table"]])
  if(!must[0].test(t)) fail("result screen is missing " + must[1]);
if(!/SZK/.test(t)) fail("the high-score table did not pick up the lobby initials");

console.log("\nALL GREEN \u2014 Deal works, the deal plays, the Bummerl ends, and the score sheet\nknows who you are. The app has now actually been used, not merely rendered.");
