/* =======================================================================
   MATCH — the Bummerl. The only resolution where the race objective exists at all.

   A deal is worth 1, 2 or 3 game points, and the match is a race to 7. That makes the payoff NONLINEAR
   in a way the deal-level bench is structurally blind to:

     • at 6-6, a 3 is worth exactly what a 1 is worth — both win the match. Risk is pure downside.
     • at 0-6, a 1-point loss ends you as surely as a 3-point loss. Risk is FREE. Take every gamble.

   So "how much should I gamble" is a function of the scoreboard, and a bot that knows the scoreboard is
   doing something a bot that maximises game points per deal literally cannot do. This is also the last
   objective that provably cannot collapse into the win-rate bar — the clamp is not monotone in wr.

   Paired: every pairing plays the same sequence of deals, and each bot plays each match from both seats.

   node match.mjs [bummerls] [seed]
   ===================================================================== */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { SCOUT } from "./styles.mjs";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const hash = (a,b)=> ((a*0x9E3779B1) ^ (b*0x85EBCA77) ^ ((a+b)*0xC2B2AE3D)) >>> 0;

/* the contestants. barAdj is IDENTICAL across all of them, so the close bar is not the variable —
 * the only thing that differs is what each bot thinks a game point is worth once it is on the board. */
const B = { barAdj: -0.15 };
const STYLES = {
  linear: { ...B },                    // control: a game point is a game point
  race:   { ...B, obj:"race"  },       // points past the finish line are worthless — and so are his
  tier:   { ...B, obj:"tier"  },       // always hunt the 2s and 3s
  safe:   { ...B, obj:"safe"  },       // only the win counts
};

function playDeal(s0, s1, dealSeed, dealer, gp){
  const d = RULES.newDeal(dealer, mulberry(dealSeed));
  const brnd = mulberry(dealSeed ^ 0x5bf03635);
  let g=0;
  while(d.phase==="play" && g++<400){
    const p=d.turn;
    const race = p===0 ? [gp[0], gp[1]] : [gp[1], gp[0]];    // the scoreboard, from the mover's side
    const dec = decide(d, p, { brain:"fritzl", skill:SCOUT, style: p===0?s0:s1, rnd:brnd, race });
    if(!dec) break;
    const a=dec.action;
    if(a.type==="PLAY")          RULES.play(d,p,a.cardId,{});
    else if(a.type==="MELD")     RULES.meld(d,p,a.suit,{});
    else if(a.type==="EXCHANGE") RULES.exchange(d,p);
    else if(a.type==="CLOSE")    RULES.close(d,p);
    else if(a.type==="CLAIM")    RULES.claim(d,p);
    else break;
  }
  return d.result ? (d.result.winner===0 ? d.result.gp : -d.result.gp) : null;
}

function bummerl(s0, s1, matchSeed){
  const gp=[0,0]; let dealer=0, k=0;
  while(gp[0]<7 && gp[1]<7 && k<40){
    const v = playDeal(s0, s1, hash(matchSeed, k), dealer, gp);
    if(v===null) break;
    if(v>0) gp[0]+=v; else gp[1]+=-v;
    dealer^=1; k++;
  }
  return gp[0]>=7 ? 0 : 1;
}

const M    = +(process.argv[2] || 150);
const SEED = +(process.argv[3] || 2024);
const names = Object.keys(STYLES);
const n = names.length;
const W = Array.from({length:n},()=>new Array(n).fill(0));
const SE= Array.from({length:n},()=>new Array(n).fill(0));

const t0=Date.now();
for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){
  let w=0, tot=0;
  for(let m=0;m<M;m++){
    const ms = hash(hash(SEED, i*29+j), m);
    if(bummerl(STYLES[names[i]], STYLES[names[j]], ms)===0) w++;   // i at seat 0
    if(bummerl(STYLES[names[j]], STYLES[names[i]], ms)===1) w++;   // seats swapped, SAME deals
    tot += 2;
  }
  const wr = w/tot;
  W[i][j] = wr-0.5; W[j][i] = 0.5-wr;
  SE[i][j]=SE[j][i]= Math.sqrt(wr*(1-wr)/tot);
  process.stderr.write(`  ${names[i]}/${names[j]}: ${(100*wr).toFixed(1)}% (${tot} bummerls)\n`);
}
const secs=((Date.now()-t0)/1000).toFixed(0);

const s = names.map((_,i)=> W[i].reduce((a,b)=>a+b,0)/n);
let tot=0, cyc=0;
for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){ const r=W[i][j]-(s[i]-s[j]); tot+=W[i][j]**2; cyc+=r*r; }

const pad=(x,w)=>String(x).padStart(w);
console.log(`\nMATCH-LEVEL (Bummerl win% - 50%; ${M} bummerls x2 seats per pairing; seed ${SEED}; ${secs}s)\n`);
console.log("         " + names.map(x=>pad(x,9)).join("") + "   rating");
for(let i=0;i<n;i++)
  console.log(names[i].padEnd(9) + names.map((_,j)=> i===j?pad("--",9):pad((W[i][j]>=0?"+":"")+(100*W[i][j]).toFixed(1),9)).join("")
    + "   " + (s[i]>=0?"+":"") + (100*s[i]).toFixed(1));
console.log(`\nHODGE:  strength ${(100*(1-cyc/tot)).toFixed(1)}%   |   CYCLE ${(100*cyc/tot).toFixed(1)}%`);
console.log(`typical 95% CI on an edge: +/-${(100*1.96*SE[0][1]).toFixed(1)} points\n`);
let found=0;
for(let i=0;i<n;i++) for(let j=0;j<n;j++) for(let k=0;k<n;k++){
  if(i>=j||i>=k||j===k) continue;
  for(const [a,b,c] of [[i,j,k],[i,k,j]]) if(W[a][b]>0&&W[b][c]>0&&W[c][a]>0){
    const z=Math.min(W[a][b]/SE[a][b], W[b][c]/SE[b][c], W[c][a]/SE[c][a]);
    found++;
    console.log(`  ${z>=1.96?"SIG   ":"cycle?"} ${names[a]} > ${names[b]} > ${names[c]} > ${names[a]}   weakest edge z=${z.toFixed(2)}`);
  }
}
if(!found) console.log("  no 3-cycles.");
