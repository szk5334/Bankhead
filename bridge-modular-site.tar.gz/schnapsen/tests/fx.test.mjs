/* Does selecting a card actually emit glyphs, and are they the RIGHT suit? */
import { JSDOM } from "jsdom";
import * as babel from "@babel/standalone";
import { readFileSync } from "fs";
import path from "path";

const dom = new JSDOM("<!doctype html><html><body><div id=r></div></body></html>", { pretendToBeVisual:true });
global.window = dom.window; global.document = dom.window.document;
Object.defineProperty(globalThis, "navigator", { value: dom.window.navigator, configurable: true });
global.HTMLElement = dom.window.HTMLElement;
global.IS_REACT_ACT_ENVIRONMENT = true;
dom.window.matchMedia = dom.window.matchMedia || (()=>({ matches:false, addListener(){}, removeListener(){} }));

const React = (await import("react")).default;
const { createRoot } = await import("react-dom/client");

/* transpile fx.jsx the same way the app shell does */
const src = readFileSync(path.resolve("../ui/fx.jsx"), "utf8");
const out = babel.transform(src, { presets:[["react",{runtime:"classic"}]], sourceType:"module" }).code;
const mod = out
  .replace(/import React from "react";/, "")
  .replace(/import \{ SUIT_GLYPH, suitColorClass \} from "..\/state\/constants.js";/, "")
  .replace(/export \{[^}]*\};/, "return { FxLayer, fxBurst, fxFly };");
const SUIT_GLYPH = { S:"\u2660\uFE0E", H:"\u2665\uFE0E", D:"\u2666\uFE0E", C:"\u2663\uFE0E" };
const suitColorClass = (su)=> su==="S"?"gsp":su==="H"?"ghe":su==="D"?"gdi":su==="C"?"gcl":"";
const { FxLayer, fxBurst, fxFly } = new Function("React","SUIT_GLYPH","suitColorClass", mod)(React, SUIT_GLYPH, suitColorClass);

const { act } = await import("react");
const root = createRoot(document.getElementById("r"));
await act(async ()=>{ root.render(React.createElement(FxLayer)); });

let fail = 0;
const ok = (name, cond)=>{ console.log((cond?"  ok   ":"  FAIL ") + name); if(!cond) fail++; };

ok("layer is empty until something happens", document.querySelectorAll(".fx-p").length === 0);

/* a fake card element with a real-looking rect */
const card = document.createElement("div");
card.getBoundingClientRect = ()=>({ left:40, top:300, width:48, height:66, right:88, bottom:366, x:40, y:300 });
document.body.appendChild(card);

await act(async ()=>{ fxBurst(card, "H"); });
const burst = document.querySelectorAll(".fx-burst");
ok("selecting a card bursts glyphs", burst.length === 12);
ok("the glyphs are the card's suit", Array.from(burst).every(e=>e.textContent === SUIT_GLYPH.H));
ok("the glyphs carry the suit colour class", Array.from(burst).every(e=>e.classList.contains("ghe")));
ok("the layer cannot eat a tap", document.querySelector(".fx").getAttribute("aria-hidden") === "true");

/* fly needs a .sc-trick to aim at — with none present it must no-op, not throw */
await act(async ()=>{ fxFly(card, "S"); });
ok("no trick zone on screen: fly is a safe no-op", document.querySelectorAll(".fx-fly").length === 0);

const wrap = document.createElement("div"); wrap.className = "br";
const trick = document.createElement("div"); trick.className = "sc-trick";
trick.getBoundingClientRect = ()=>({ left:150, top:120, width:90, height:70, right:240, bottom:190, x:150, y:120 });
wrap.appendChild(trick); document.body.appendChild(wrap);

await act(async ()=>{ fxFly(card, "S"); });
ok("playing a card runs a comet to the trick", document.querySelectorAll(".fx-fly").length === 14);
ok("the comet is staggered (that is what makes it a trail)",
   new Set(Array.from(document.querySelectorAll(".fx-fly")).map(e=>e.style.animationDelay)).size > 8);
ok("the comet lands with a burst", document.querySelectorAll(".fx-burst").length >= 6);

console.log(fail ? `\n${fail} FAILED` : "\nall green — the glyphs burst, they are the right suit, they travel, and they never steal a tap.");
process.exit(fail ? 1 : 0);
