import { ENG } from "../engine/core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "../engine/rules.js";
import { solve } from "../engine/solver.js";

let pass=0, fail=0;
const t=(name, fn)=>{ try{ fn(); pass++; console.log("  ok  " + name); } catch(e){ fail++; console.log("FAIL  " + name + "\n      " + e.message); } };
const eq=(a,b,m)=>{ if(JSON.stringify(a)!==JSON.stringify(b)) throw new Error((m||"")+" expected "+JSON.stringify(b)+" got "+JSON.stringify(a)); };
const ok=(c,m)=>{ if(!c) throw new Error(m||"expected true"); };

/* build a deal by hand so the scenarios are exact */
let uid=1000;
const C=(r,s)=>({ id:uid++, rank:r, suit:s });
function rig({trump="S", up, stock=[], h0=[], h1=[], turn=0}={}){
  return {
    trump, up: (up===undefined ? C("J",trump) : up), stock, hands:{0:h0,1:h1},
    trick:[], turn, lead:turn, closed:false, closedBy:null, closeSnap:null,
    meldSuit:null, meldedSuits:[[],[]], trickPts:[0,0], meldPts:[0,0], tricksWon:[0,0],
    lastTrick:null, dealer:1, phase:"play", result:null, reveals:[], log:[],
  };
}

console.log("\n— the deck —");
t("20 cards, 120 card points", ()=>{
  const d = ENG.makeDeck();
  eq(d.length, 20);
  eq(d.reduce((a,c)=>a+ENG.val(c),0), 120);
});
t("rank order is A > 10 > K > Q > J", ()=>{
  const p = ["A","10","K","Q","J"].map(r=>ENG.power({rank:r}));
  eq(p, [5,4,3,2,1]);
});

console.log("\n— trick resolution —");
t("higher card of the led suit wins", ()=>{
  eq(ENG.trickWinner(C("K","H"), C("10","H"), "S", 0, 1), 1);
  eq(ENG.trickWinner(C("10","H"), C("K","H"), "S", 0, 1), 0);
});
t("a trump beats any non-trump", ()=>{
  eq(ENG.trickWinner(C("A","H"), C("J","S"), "S", 0, 1), 1);
});
t("an off-suit non-trump never wins", ()=>{
  eq(ENG.trickWinner(C("J","H"), C("A","D"), "S", 0, 1), 0);
});

console.log("\n— obligations —");
t("while the stock is OPEN you may play literally anything", ()=>{
  const hand=[C("A","D"),C("J","C")];
  eq(ENG.legalFollows(hand, C("K","H"), "S", false).length, 2);
});
t("strict: must follow suit", ()=>{
  const hand=[C("Q","H"),C("A","D"),C("J","S")];
  const l=ENG.legalFollows(hand, C("K","H"), "S", true);
  eq(l.map(c=>c.rank+c.suit), ["QH"]);
});
t("strict: must HEAD the trick when you can", ()=>{
  const hand=[C("Q","H"),C("A","H"),C("J","H")];
  const l=ENG.legalFollows(hand, C("K","H"), "S", true);
  eq(l.map(c=>c.rank), ["A"]);            // only the ace beats the king
});
t("strict: void in the led suit -> must trump", ()=>{
  const hand=[C("A","D"),C("J","S")];
  const l=ENG.legalFollows(hand, C("K","H"), "S", true);
  eq(l.map(c=>c.rank+c.suit), ["JS"]);
});
t("strict: void and trumpless -> anything goes", ()=>{
  const hand=[C("A","D"),C("J","C")];
  eq(ENG.legalFollows(hand, C("K","H"), "S", true).length, 2);
});

console.log("\n— marriages —");
t("a marriage is worthless until you win a trick", ()=>{
  const d = rig({ trump:"S", h0:[C("K","H"),C("Q","H"),C("J","C")], h1:[C("A","H"),C("A","D"),C("A","C")], stock:[C("J","D"),C("Q","D"),C("K","D")] });
  RULES.meld(d, 0, "H", {strictClaim:true});
  eq(d.meldPts[0], 20);
  eq(effPts(d, 0), 0, "no trick yet, so the 20 does not count:");
  RULES.play(d, 0, d.hands[0].find(c=>c.rank==="K").id, {strictClaim:true});  // K♥
  RULES.play(d, 1, d.hands[1].find(c=>c.rank==="A"&&c.suit==="H").id, {strictClaim:true}); // A♥ takes it
  eq(d.tricksWon[0], 0);
  eq(effPts(d, 0), 0, "beaten, still no trick:");
});
t("...but it counts the moment a trick comes later", ()=>{
  const d = rig({ trump:"S", turn:0,
    h0:[C("K","H"),C("Q","H"),C("A","C")], h1:[C("A","H"),C("J","C"),C("J","D")], stock:[] , up:null});
  d.meldedSuits=[[],[]];
  RULES.meld(d, 0, "H", {strictClaim:true});
  RULES.play(d, 0, d.hands[0].find(c=>c.rank==="K").id, {strictClaim:true});
  RULES.play(d, 1, d.hands[1].find(c=>c.suit==="H").id, {strictClaim:true});   // seat 1 takes it
  eq(effPts(d,0), 0);
  // seat 1 leads a jack, seat 0's ace takes it -> the 20 lights up
  RULES.play(d, 1, d.hands[1].find(c=>c.suit==="C").id, {strictClaim:true});
  RULES.play(d, 0, d.hands[0].find(c=>c.suit==="C").id, {strictClaim:true});
  eq(d.tricksWon[0], 1);
  eq(effPts(d,0), 20 + 13, "20 for the marriage + A(11)+J(2):");
});
t("declaring forces you to lead the king or the queen of that suit", ()=>{
  const d = rig({ trump:"S", h0:[C("K","H"),C("Q","H"),C("A","C")], h1:[C("A","H"),C("J","C"),C("J","D")] });
  RULES.meld(d, 0, "H", {strictClaim:true});
  eq(RULES.legalCards(d,0).map(c=>c.rank+c.suit).sort(), ["KH","QH"]);
});
t("a marriage may only be declared once", ()=>{
  const d = rig({ trump:"S", h0:[C("K","H"),C("Q","H")], h1:[C("J","C"),C("J","D")] });
  RULES.meld(d, 0, "H", {strictClaim:true});
  d.meldSuit=null;                                    // pretend the trick came round again
  eq(RULES.meldOptions(d,0).length, 0);
});
t("a trump marriage is 40", ()=>{
  eq(ENG.meldValue("S","S"), 40);
  eq(ENG.meldValue("H","S"), 20);
});

console.log("\n— the trump jack —");
t("swap the trump jack for the turn-up", ()=>{
  const d = rig({ trump:"S", up:C("A","S"), stock:[C("J","D"),C("Q","D")], h0:[C("J","S"),C("K","H")], h1:[C("J","C"),C("Q","C")] });
  ok(RULES.canExchange(d,0));
  RULES.exchange(d,0);
  eq(d.up.rank, "J");
  eq(d.hands[0].some(c=>c.rank==="A"&&c.suit==="S"), true);
  eq(d.reveals.length, 1, "the opponent watched you take it — it is public:");
});
t("no swap once the stock is closed", ()=>{
  const d = rig({ trump:"S", up:C("A","S"), stock:[C("J","D")], h0:[C("J","S")], h1:[C("Q","C")] });
  RULES.close(d,0);
  eq(RULES.canExchange(d,0), false);
});

console.log("\n— closing —");
t("closing snapshots the OPPONENT's position, and pays by it", ()=>{
  const d = rig({ trump:"S", up:C("A","S"), stock:[C("J","D"),C("Q","D")], h0:[C("A","H")], h1:[C("K","C")] });
  d.trickPts=[40, 20]; d.tricksWon=[2,1];
  RULES.close(d, 0);
  eq(d.closeSnap, { pts:20, tricks:1 });
  // seat 1 then rallies to 40 — irrelevant, the snapshot is what pays
  d.trickPts[1]=40; d.trickPts[0]=70;
  eq(RULES.gpForWin(d, 0), 2, "opponent was under 33 at the close -> 2 game points:");
});
t("close + shut them out entirely = 3", ()=>{
  const d = rig({ trump:"S", up:C("A","S"), stock:[C("J","D")], h0:[C("A","H")], h1:[C("K","C")] });
  d.trickPts=[50,0]; d.tricksWon=[3,0];
  RULES.close(d,0);
  eq(RULES.gpForWin(d,0), 3);
});
t("a FAILED close pays the opponent 2 — or 3 if they had no tricks when you closed", ()=>{
  const a = rig({ trump:"S", up:C("A","S"), stock:[C("J","D")], h0:[C("A","H")], h1:[C("K","C")] });
  a.trickPts=[50,0]; a.tricksWon=[3,0];
  RULES.close(a,0);
  eq(RULES.gpForWin(a, 1), 3, "shut out at the close, and the closer still missed:");

  const b = rig({ trump:"S", up:C("A","S"), stock:[C("J","D")], h0:[C("A","H")], h1:[C("K","C")] });
  b.trickPts=[30,20]; b.tricksWon=[2,2];
  RULES.close(b,0);
  eq(RULES.gpForWin(b, 1), 2);
});

console.log("\n— the finish —");
t("a right claim pays 3 / 2 / 1 by how badly the loser is beaten", ()=>{
  const mk=(lp, lt)=>{ const d=rig({trump:"S", h0:[C("A","H")], h1:[C("K","C")]}); d.trickPts=[70,lp]; d.tricksWon=[4,lt]; return d; };
  eq(RULES.gpForWin(mk(0,0), 0), 3, "schwarz:");
  eq(RULES.gpForWin(mk(20,1), 0), 2, "schneider:");
  eq(RULES.gpForWin(mk(40,2), 0), 1);
});
t("a FALSE claim hands the deal to the opponent", ()=>{
  const d = rig({ trump:"S", h0:[C("A","H")], h1:[C("K","C")] });
  d.trickPts=[50,10]; d.tricksWon=[3,1];
  RULES.claim(d, 0);
  eq(d.result.winner, 1);
  eq(d.result.gp, 2);
  eq(d.result.reason, "claim");
});
t("false claim by someone holding no tricks = 3 to the opponent", ()=>{
  const d = rig({ trump:"S", turn:1, h0:[C("A","H")], h1:[C("K","C")] });
  d.trickPts=[0,50]; d.tricksWon=[0,3];
  RULES.claim(d, 1);   // seat 1 claims on 50 — wrong. seat 0 has no tricks.
  eq(d.result.winner, 0);
  eq(d.result.gp, 3);
});
t("nobody reaches 66 -> the LAST TRICK takes the whole deal, flat 1", ()=>{
  const d = rig({ trump:"S", turn:0, up:null, stock:[],
    h0:[C("J","H")], h1:[C("Q","H")] });
  d.trickPts=[60,55];
  RULES.play(d, 0, d.hands[0][0].id, {strictClaim:true});
  RULES.play(d, 1, d.hands[1][0].id, {strictClaim:true});   // Q beats J -> seat 1 takes the last trick
  eq(d.result.reason, "exhausted");
  eq(d.result.winner, 1);
  eq(d.result.gp, 1);
  ok(d.result.pts[0] < 66 && d.result.pts[1] < 66);
});

console.log("\n— the Pagat line: close, cash the trump ace, declare 40, go out —");
t("A K Q of trumps: close, lead the ace, declare 40, win", ()=>{
  // seat 0 on lead with A K Q of trumps + two rags. The opponent cannot hold more than one trump.
  const d = rig({ trump:"S", turn:0, up:C("J","S"),
    h0:[C("A","S"),C("K","S"),C("Q","S"),C("J","H"),C("J","D")],
    h1:[C("A","H"),C("A","D"),C("A","C"),C("10","H"),C("10","D")],
    stock:[C("10","C"),C("K","H"),C("K","D"),C("K","C"),C("Q","H"),C("Q","D"),C("Q","C"),C("J","C"),C("10","S")] });
  RULES.close(d, 0);
  const r = solve(d, 0, 400000);
  ok(r.value > 0, "the solver should find this is a win, got " + (r && r.value));
  eq(r.card.suit, "S", "and it should start with a trump:");
});

console.log("\n— the solver —");
t("finds the forced win when the stock is exhausted", ()=>{
  // seat 0 holds all remaining trumps: every trick is theirs.
  const d = rig({ trump:"S", turn:0, up:null, stock:[],
    h0:[C("A","S"),C("K","S")], h1:[C("A","H"),C("A","D")] });
  d.trickPts=[40,20]; d.tricksWon=[3,2];
  const r = solve(d, 0, 100000);
  ok(r.value > 0, "value " + r.value);
});
t("knows when it is beaten and loses by the least", ()=>{
  const d = rig({ trump:"S", turn:0, up:null, stock:[],
    h0:[C("J","H"),C("J","D")], h1:[C("A","S"),C("K","S")] });
  d.trickPts=[10,50]; d.tricksWon=[1,4];
  const r = solve(d, 0, 100000);
  ok(r.value < 0, "value " + r.value);
});

console.log(`\n${pass} passed, ${fail} failed\n`);
process.exit(fail?1:0);
