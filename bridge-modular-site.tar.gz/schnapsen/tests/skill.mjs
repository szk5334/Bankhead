import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
function mul(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
function bummerl(A,B,seed){ // play to 7 game points; returns 0 if A wins
  const rnd=mul(seed); const gp=[0,0]; let dealer=0, guard=0;
  while(gp[0]<7 && gp[1]<7 && guard++<40){
    const d=RULES.newDeal(dealer,rnd); let g=0;
    while(d.phase==="play" && g++<300){
      const p=d.turn; const dec=decide(d,p,{brain:p===0?A:B,rnd}); if(!dec)break;
      const a=dec.action;
      if(a.type==="PLAY") RULES.play(d,p,a.cardId,{});
      else if(a.type==="MELD") RULES.meld(d,p,a.suit,{});
      else if(a.type==="EXCHANGE") RULES.exchange(d,p);
      else if(a.type==="CLOSE") RULES.close(d,p);
      else if(a.type==="CLAIM") RULES.claim(d,p);
    }
    if(!d.result) break;
    gp[d.result.winner]+=d.result.gp; dealer^=1;
  }
  return gp[0]>=7?0:1;
}
const pairs=[["resi","poldi"],["fritzl","poldi"],["resi","ignaz"],["vroni","fritzl"],["resi","fritzl"]];
const N=+(process.argv[2]||60);
for(const [A,B] of pairs){
  let a=0;
  for(let i=0;i<N;i++){ if(bummerl(A,B,900+i*7)===0) a++; }   // A always seat 0
  let a2=0;
  for(let i=0;i<N;i++){ if(bummerl(B,A,900+i*7)===1) a2++; }  // and again with seats swapped
  const w=a+a2, tot=2*N;
  console.log(`${A.padEnd(7)} vs ${B.padEnd(7)}  ${String(w).padStart(3)}/${tot} bummerls  ${(100*w/tot).toFixed(0)}%`);
}
