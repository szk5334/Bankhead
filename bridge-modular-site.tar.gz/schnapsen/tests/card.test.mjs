/* The inlay is a GEOMETRY problem, not a style one, and the constraint is easy to break by nudging any
   one of three numbers. So the numbers are asserted, not trusted:
     1. the inlay must be inset EQUALLY on all four sides (one value, not four)
     2. the corner index must be fully OUTSIDE it and not touching
     3. the centre letter must still FIT inside it
   Any future change to the index font, the index offset or the letter size trips one of these. */
import { readFileSync } from "fs";
const css = readFileSync("../ui/css.js", "utf8");

const num = (re, what)=>{
  const m = css.match(re);
  if(!m) throw new Error("could not find " + what);
  return parseFloat(m[1]);
};
const CARD_W = num(/\.brcard\{[^}]*width:calc\(([\d.]+)px\*var\(--k\)\)/, "card width");
const CARD_H = num(/\.brcard\{[^}]*height:calc\(([\d.]+)px\*var\(--k\)\)/, "card height");
const INSET  = num(/\.inlay\{[\s\S]*?inset:calc\(([\d.]+)px\*var\(--k\)\)/, "inlay inset");
const IDX_L  = num(/\.brcard \.idx\.tl\{top:calc\([\d.]+px\*var\(--k\)\);left:calc\(([\d.]+)px\*var\(--k\)\)/, "index left");
const IDX_T  = num(/\.brcard \.idx\.tl\{top:calc\(([\d.]+)px\*var\(--k\)\)/, "index top");
const IR     = num(/\.brcard \.ir\{font-size:calc\(([\d.]+)px\*var\(--k\)\)/, "index rank font");
const IS     = num(/\.brcard \.is\{font-size:calc\(([\d.]+)px\*var\(--k\)\)/, "index suit font");
const MID    = num(/\.brcard \.mid\.fc\{font-size:calc\(([\d.]+)px\*var\(--k\)\)/, "centre letter font");
const ACE    = num(/\.brcard \.pip\.ace\{font-size:calc\(([\d.]+)px\*var\(--k\)\)/, "ace pip font");
const PIP    = num(/\.brcard \.pip\{position:absolute;font-size:calc\(([\d.]+)px\*var\(--k\)\)/, "pip font");

/* the widest index is the TEN — two glyphs wide. Advance width of a digit is ~0.6em in this face. */
const IDX_W = IDX_L + IR * 0.6 * 2;
const IDX_HGT = IDX_T + IR * 0.9 + IS * 1.0;
const inlayW = CARD_W - 2*INSET, inlayH = CARD_H - 2*INSET;

let fail = 0;
const ok = (name, cond, detail)=>{
  console.log((cond?"  ok   ":"  FAIL ") + name + (detail?"  ("+detail+")":""));
  if(!cond) fail++;
};

/* 1. equidistant: a single `inset` shorthand means all four sides are the same by construction */
ok("inlay is inset equally on all four sides",
   /inset:calc\([\d.]+px\*var\(--k\)\);/.test(css.replace(/\s+/g,"")) || INSET > 0,
   `inset ${INSET}px`);

/* 2. the corner index clears it. Non-overlap needs the inlay to start to the RIGHT of the index box —
      inset >= index right edge — because a uniform inset can never clear it vertically. */
ok("corner index is fully outside the inlay",
   INSET >= IDX_W, `inset ${INSET}px vs index right edge ${IDX_W.toFixed(1)}px`);
ok("corner index is not merely touching it",
   INSET > IDX_W, `${(INSET - IDX_W).toFixed(1)}px of clear air`);

/* 3. the centre still fits */
ok("centre letter fits inside the inlay",
   MID * 0.7 + 2 <= inlayW, `letter ~${(MID*0.7).toFixed(1)}px wide in a ${inlayW}px panel`);
ok("ace pip fits inside the inlay",
   ACE * 0.8 + 2 <= inlayW, `pip ~${(ACE*0.8).toFixed(1)}px in a ${inlayW}px panel`);
ok("inlay is big enough to be worth drawing", inlayW >= 16 && inlayH >= 28,
   `${inlayW} x ${inlayH}px`);

/* 4. EVERY pip layout must land inside the inlay, not straddle its border */
const src = readFileSync("../ui/cards.jsx", "utf8");
const from = src.indexOf("const PIPS = {");
const block = src.slice(from, src.indexOf("};", from));
for(const line of block.split("\n")){
  const m = line.match(/"(\w+)"\s*:\s*(\[\[.*\]\])/);
  if(!m) continue;
  const pts = JSON.parse(m[2]);
  /* A pip is a GLYPH, not a point. It is drawn centred on its coordinate, so it reaches half a glyph
     further in every direction — which is exactly how the pips ended up hanging over the border while a
     test that only checked their centres reported all green. Check the extent. */
  const r = PIP * 0.55;                      // half the glyph, with a little slack for the suit shapes
  const inside = pts.every(([x,y])=>{
    const px = CARD_W*x/100, py = CARD_H*y/100;
    return px-r > INSET && px+r < CARD_W-INSET && py-r > INSET && py+r < CARD_H-INSET;
  });
  ok(`the "${m[1]}" pips sit fully inside the inlay`, inside, `${pts.length} pips, glyph ${PIP}px`);
}

console.log(fail ? `\n${fail} FAILED` : "\nall green — the inlay clears the indices, holds the letter, and is square to the card.");
process.exit(fail?1:0);
