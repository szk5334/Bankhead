/* =======================================================================
   RR — round-robin over STYLE vectors at a single fixed skill.

   Same measurement discipline as bench.mjs: paired deals, common random numbers, both seats,
   two independent RNG streams. Then Hodge, then a search over every 5-subset for the one with
   the most cyclic energy — the pentagon, if there is one.

   node rr.mjs [N] [seed]        N = paired deals per pairing
   ===================================================================== */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { READERS as STYLES, SCOUT } from "./styles.mjs";
import { writeFileSync } from "fs";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const hash = (a,b)=> ((a*0x9E3779B1) ^ (b*0x85EBCA77) ^ ((a+b)*0xC2B2AE3D)) >>> 0;

function playDeal(s0, s1, dealSeed, dealer){
  const d = RULES.newDeal(dealer, mulberry(dealSeed));
  const brnd = mulberry(dealSeed ^ 0x5bf03635);
  let guard = 0;
  while(d.phase === "play" && guard++ < 400){
    const p = d.turn;
    const dec = decide(d, p, { brain:"fritzl", skill:SCOUT, style: p===0 ? s0 : s1, rnd: brnd });
    if(!dec) break;
    const a = dec.action;
    if(a.type==="PLAY")          RULES.play(d, p, a.cardId, {});
    else if(a.type==="MELD")     RULES.meld(d, p, a.suit, {});
    else if(a.type==="EXCHANGE") RULES.exchange(d, p);
    else if(a.type==="CLOSE")    RULES.close(d, p);
    else if(a.type==="CLAIM")    RULES.claim(d, p);
    else break;
  }
  return d.result ? (d.result.winner===0 ? d.result.gp : -d.result.gp) : null;
}

function duel(sA, sB, N, seed){
  const diffs=[];
  for(let i=0;i<N;i++){
    const ds = hash(seed, i);
    const g1 = playDeal(sA, sB, ds, 0);
    const g2 = playDeal(sB, sA, ds, 0);
    if(g1===null||g2===null) continue;
    diffs.push((g1 - g2)/2);
  }
  const n=diffs.length, m=diffs.reduce((a,b)=>a+b,0)/n;
  const v=diffs.reduce((a,b)=>a+(b-m)*(b-m),0)/(n-1);
  return { mean:m, se:Math.sqrt(v/n) };
}

function hodge(M, idx){
  const k = idx.length;
  const s = idx.map(i => idx.reduce((a,j)=> a + M[i][j], 0) / k);
  let tot=0, cyc=0;
  for(let a=0;a<k;a++) for(let b=a+1;b<k;b++){
    const g = s[a]-s[b], r = M[idx[a]][idx[b]] - g;
    tot += M[idx[a]][idx[b]]**2; cyc += r*r;
  }
  return { s, cycFrac: tot>0 ? cyc/tot : 0 };
}

const N    = +(process.argv[2] || 150);
const SEED = +(process.argv[3] || 2024);
const names = Object.keys(STYLES);
const n = names.length;
const M  = Array.from({length:n},()=>new Array(n).fill(0));
const SE = Array.from({length:n},()=>new Array(n).fill(0));

const t0=Date.now();
for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){
  const r = duel(STYLES[names[i]], STYLES[names[j]], N, hash(SEED, i*17+j));
  M[i][j]= r.mean; M[j][i]= -r.mean;
  SE[i][j]=r.se;   SE[j][i]= r.se;
  process.stderr.write(`  ${names[i]}/${names[j]} ${r.mean>=0?"+":""}${r.mean.toFixed(2)}\n`);
}
const secs=((Date.now()-t0)/1000).toFixed(0);
writeFileSync(`rr-${SEED}-${N}.json`, JSON.stringify({names, M, SE, N, SEED}));

const pad=(x,w)=>String(x).padStart(w);
const H = hodge(M, names.map((_,i)=>i));
console.log(`\nSTYLE ROUND-ROBIN  (mean signed gp; N=${N} paired deals; scout skill; seed ${SEED}; ${secs}s)\n`);
console.log("           " + names.map(x=>pad(x.slice(0,8),9)).join("") + "   strength");
for(let i=0;i<n;i++)
  console.log(names[i].padEnd(11) + names.map((_,j)=> i===j?pad("--",9):pad((M[i][j]>=0?"+":"")+M[i][j].toFixed(2),9)).join("")
    + "   " + (H.s[i]>=0?"+":"") + H.s[i].toFixed(3));
console.log(`\nWHOLE FIELD:  strength ${(100*(1-H.cycFrac)).toFixed(1)}%   |   CYCLE ${(100*H.cycFrac).toFixed(1)}%`);

/* 3-cycles, significance-weighted */
const tri=[];
for(let i=0;i<n;i++) for(let j=0;j<n;j++) for(let k=0;k<n;k++){
  if(i>=j||j===k||i>=k) continue;
  for(const [a,b,c] of [[i,j,k],[i,k,j]]){
    if(M[a][b]>0 && M[b][c]>0 && M[c][a]>0){
      const z = Math.min(M[a][b]/SE[a][b], M[b][c]/SE[b][c], M[c][a]/SE[c][a]);
      tri.push({ t:[a,b,c], z });
    }
  }
}
tri.sort((x,y)=>y.z-x.z);
console.log(`\n3-CYCLES: ${tri.length} found`);
for(const t of tri.slice(0,8))
  console.log(`  ${t.z>=1.96?"SIG ":"    "} ${names[t.t[0]]} > ${names[t.t[1]]} > ${names[t.t[2]]} > ${names[t.t[0]]}   weakest edge z=${t.z.toFixed(2)}`);

/* every 5-subset, ranked by cyclic energy */
const subs=[];
const pick=(start, cur)=>{
  if(cur.length===5){
    const h = hodge(M, cur);
    const spread = Math.max(...cur.map((_,a)=>h.s[a])) - Math.min(...cur.map((_,a)=>h.s[a]));
    // regular pentagon = every vertex beats exactly 2 of the other 4
    const wins = cur.map(i => cur.filter(j=> j!==i && M[i][j]>0).length);
    const regular = wins.every(w=>w===2);
    subs.push({ cur:cur.slice(), cyc:h.cycFrac, spread, regular,
                condW: wins.some(w=>w===4), condL: wins.some(w=>w===0) });
    return;
  }
  for(let i=start;i<n;i++){ cur.push(i); pick(i+1, cur); cur.pop(); }
};
pick(0, []);
subs.sort((a,b)=> b.cyc - a.cyc);
console.log(`\nBEST 5-SUBSETS BY CYCLIC ENERGY (${subs.length} examined)\n`);
for(const s of subs.slice(0,6)){
  const tag = s.regular ? "REGULAR PENTAGON" : (!s.condW && !s.condL) ? "no Condorcet w/l " : "                 ";
  console.log(`  cyc ${(100*s.cyc).toFixed(1).padStart(5)}%  spread ${s.spread.toFixed(2)}  ${tag}  ${s.cur.map(i=>names[i]).join(" ")}`);
}
