/* =======================================================================
   HUNT — the search. Surviving archetypes + random style vectors, full round-robin,
   then every 5-subset ranked by cyclic energy.

   node hunt.mjs [N] [seed] [nRandom]
   ===================================================================== */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { STYLES, SCOUT } from "./styles.mjs";
import { writeFileSync } from "fs";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const hash = (a,b)=> ((a*0x9E3779B1) ^ (b*0x85EBCA77) ^ ((a+b)*0xC2B2AE3D)) >>> 0;

const N     = +(process.argv[2] || 70);
const SEED  = +(process.argv[3] || 2024);
const NRAND = +(process.argv[4] || 10);

/* the six archetypes that are not degenerate — clock and miser were simply weak */
const KEEP = ["textbook","racer","ruffer","closer","wedding","stripper"];
const pool = {};
for(const k of KEEP) pool[k] = STYLES[k];

/* random style vectors over ranges that keep every knob inside "a thing a player could believe" */
const R = mulberry(SEED ^ 0xBEEF);
const U = (lo,hi)=> lo + R()*(hi-lo);
for(let i=0;i<NRAND;i++){
  pool["r"+i] = {
    trumpKeep: +U(0.4, 1.9).toFixed(2),
    trumpLead: +U(0.2, 1.9).toFixed(2),
    aceLead:   +U(-0.6, 2.3).toFixed(2),
    tenFear:   +U(0.2, 2.0).toFixed(2),
    aceHold:   +U(0.3, 2.0).toFixed(2),
    duck:      +U(-5, 10).toFixed(1),
    meld:      +U(0.3, 2.3).toFixed(2),
    barAdj:    +U(-0.28, 0.14).toFixed(3),
  };
}

function playDeal(s0, s1, dealSeed, dealer){
  const d = RULES.newDeal(dealer, mulberry(dealSeed));
  const brnd = mulberry(dealSeed ^ 0x5bf03635);
  let g=0;
  while(d.phase==="play" && g++<400){
    const p=d.turn;
    const dec = decide(d, p, { brain:"fritzl", skill:SCOUT, style: p===0 ? s0 : s1, rnd: brnd });
    if(!dec) break;
    const a=dec.action;
    if(a.type==="PLAY")          RULES.play(d,p,a.cardId,{});
    else if(a.type==="MELD")     RULES.meld(d,p,a.suit,{});
    else if(a.type==="EXCHANGE") RULES.exchange(d,p);
    else if(a.type==="CLOSE")    RULES.close(d,p);
    else if(a.type==="CLAIM")    RULES.claim(d,p);
    else break;
  }
  return d.result ? (d.result.winner===0 ? d.result.gp : -d.result.gp) : null;
}
function duel(sA, sB, N, seed){
  const diffs=[];
  for(let i=0;i<N;i++){
    const ds=hash(seed,i);
    const g1=playDeal(sA,sB,ds,0), g2=playDeal(sB,sA,ds,0);
    if(g1===null||g2===null) continue;
    diffs.push((g1-g2)/2);
  }
  const n=diffs.length, m=diffs.reduce((a,b)=>a+b,0)/n;
  const v=diffs.reduce((a,b)=>a+(b-m)*(b-m),0)/(n-1);
  return { mean:m, se:Math.sqrt(v/n) };
}
function hodge(M, idx){
  const k=idx.length;
  const s=idx.map(i=> idx.reduce((a,j)=>a+M[i][j],0)/k);
  let tot=0, cyc=0;
  for(let a=0;a<k;a++) for(let b=a+1;b<k;b++){
    const r = M[idx[a]][idx[b]] - (s[a]-s[b]);
    tot += M[idx[a]][idx[b]]**2; cyc += r*r;
  }
  return { s, cycFrac: tot>0?cyc/tot:0 };
}

const names = Object.keys(pool);
const n = names.length;
const M  = Array.from({length:n},()=>new Array(n).fill(0));
const SE = Array.from({length:n},()=>new Array(n).fill(0));
const t0=Date.now();
for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){
  const r = duel(pool[names[i]], pool[names[j]], N, hash(SEED, i*31+j));
  M[i][j]=r.mean; M[j][i]=-r.mean; SE[i][j]=SE[j][i]=r.se;
}
const secs=((Date.now()-t0)/1000).toFixed(0);
writeFileSync(`hunt-${SEED}.json`, JSON.stringify({names, pool, M, SE, N, SEED}, null, 1));

const H = hodge(M, names.map((_,i)=>i));
const pad=(x,w)=>String(x).padStart(w);
console.log(`\nHUNT  ${n} styles, N=${N} paired deals/pairing, seed ${SEED}, ${secs}s`);
console.log(`WHOLE FIELD:  strength ${(100*(1-H.cycFrac)).toFixed(1)}%  |  CYCLE ${(100*H.cycFrac).toFixed(1)}%\n`);
console.log("strength: " + names.map((x,i)=>`${x} ${H.s[i]>=0?"+":""}${H.s[i].toFixed(2)}`).join("  "));

/* 5-subsets: regular pentagon = every vertex beats exactly two others */
const subs=[];
const pick=(start,cur)=>{
  if(cur.length===5){
    const h=hodge(M,cur);
    const wins=cur.map(i=>cur.filter(j=>j!==i && M[i][j]>0).length);
    const regular = wins.every(w=>w===2);
    const spread = Math.max(...h.s)-Math.min(...h.s);
    const minEdge = Math.min(...cur.flatMap(i=>cur.filter(j=>j!==i).map(j=>Math.abs(M[i][j]))));
    const minZ = Math.min(...cur.flatMap(i=>cur.filter(j=>j>i).map(j=>Math.abs(M[i][j])/SE[i][j])));
    subs.push({cur:cur.slice(), cyc:h.cycFrac, regular, spread, minEdge, minZ});
    return;
  }
  for(let i=start;i<n;i++){ cur.push(i); pick(i+1,cur); cur.pop(); }
};
pick(0,[]);

const regs = subs.filter(s=>s.regular).sort((a,b)=> b.minZ - a.minZ);
console.log(`\nREGULAR PENTAGONS (every bot beats exactly 2, loses to exactly 2): ${regs.length} of ${subs.length} subsets`);
for(const s of regs.slice(0,8))
  console.log(`  cyc ${(100*s.cyc).toFixed(0).padStart(3)}%  weakest-edge z=${s.minZ.toFixed(2)}  |edge|>=${s.minEdge.toFixed(2)}  spread ${s.spread.toFixed(2)}  ::  ${s.cur.map(i=>names[i]).join(" ")}`);

subs.sort((a,b)=>b.cyc-a.cyc);
console.log(`\nHIGHEST CYCLIC ENERGY, any shape:`);
for(const s of subs.slice(0,5))
  console.log(`  cyc ${(100*s.cyc).toFixed(0).padStart(3)}%  ${s.regular?"REGULAR":"       "}  z>=${s.minZ.toFixed(2)}  ::  ${s.cur.map(i=>names[i]).join(" ")}`);

console.log(`\nrandom styles:`);
for(const k of names) if(k[0]==="r" && /^r\d/.test(k)) console.log(`  ${k}: ${JSON.stringify(pool[k])}`);
