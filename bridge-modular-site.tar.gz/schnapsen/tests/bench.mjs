/* =======================================================================
   BENCH — the payoff matrix, and how much of it Elo cannot explain.

   Two resolutions, because they are different games:

     DEAL   mean signed game points per deal. Paired: every pairing sees the SAME deals,
            and each bot plays each deal from BOTH seats. Deal luck cancels exactly.
     MATCH  Bummerl win rate (race to 7). A nonlinear transform of the deal distribution —
            two bots level on gp/deal can still have a decisive edge here.

   Then the only number that matters:

     HODGE  M is skew-symmetric. Least-squares fit M[i][j] ~= s_i - s_j is the GRADIENT part:
            a pure strength rating, and precisely what Elo can see. What's left over is the
            CYCLIC part. On a complete graph the harmonic term vanishes, so
                ||M||^2 = ||grad||^2 + ||curl||^2
            and cyc% = ||curl||^2 / ||M||^2 is the fraction of the tournament that is
            rock-paper-scissors rather than ladder. A pure ladder scores 0%.

   CRITICAL — two independent RNG streams. The deal rng is seeded per deal, so the cards are
   a function of the deal seed ALONE. If the bots drew from the same stream, a bot that samples
   more worlds would deal itself different cards, and every comparison would be measuring the
   shuffle instead of the play.
   ===================================================================== */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { ALL_BRAINS } from "../state/personas.js";

function mulberry(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const hash = (a,b)=> ((a*0x9E3779B1) ^ (b*0x85EBCA77) ^ ((a+b)*0xC2B2AE3D)) >>> 0;

/* Play ONE deal. seat0/seat1 are brain names. Returns signed gp from seat 0's view. */
function playDeal(seat0, seat1, dealSeed, dealer){
  const d    = RULES.newDeal(dealer, mulberry(dealSeed));      // cards: a function of dealSeed only
  const brnd = mulberry(dealSeed ^ 0x5bf03635);                // bots: a separate stream
  let guard = 0;
  while(d.phase === "play" && guard++ < 400){
    const p = d.turn;
    const dec = decide(d, p, { brain: p===0 ? seat0 : seat1, rnd: brnd });
    if(!dec) break;
    const a = dec.action;
    if(a.type==="PLAY")          RULES.play(d, p, a.cardId, {});
    else if(a.type==="MELD")     RULES.meld(d, p, a.suit, {});
    else if(a.type==="EXCHANGE") RULES.exchange(d, p);
    else if(a.type==="CLOSE")    RULES.close(d, p);
    else if(a.type==="CLAIM")    RULES.claim(d, p);
    else break;
  }
  if(!d.result) return null;
  return d.result.winner === 0 ? d.result.gp : -d.result.gp;
}

/* A vs B over N paired deals. Each deal is played twice, seats swapped, same cards.
 * Returns mean signed gp/deal for A, and the paired standard error. */
function dealDuel(A, B, N, seed){
  const diffs = [];
  for(let i=0;i<N;i++){
    const ds = hash(seed, i);
    const g1 = playDeal(A, B, ds, 0);      // A holds seat 0's cards
    const g2 = playDeal(B, A, ds, 0);      // B holds them; A now holds seat 1's
    if(g1===null || g2===null) continue;
    diffs.push((g1 + -g2) / 2);            // A's gp in both orientations, averaged
  }
  const n = diffs.length;
  const m = diffs.reduce((a,b)=>a+b,0) / n;
  const v = diffs.reduce((a,b)=>a+(b-m)*(b-m),0) / (n-1);
  return { mean:m, se: Math.sqrt(v/n), n };
}

/* One Bummerl to 7. Deal seeds come from the match seed, so every pairing plays the
 * same sequence of deals. Returns 0 if seat0's brain won. */
function bummerl(seat0, seat1, matchSeed){
  const gp=[0,0]; let dealer=0, k=0;
  while(gp[0]<7 && gp[1]<7 && k<60){
    const g = playDeal(seat0, seat1, hash(matchSeed, k), dealer);
    if(g===null) break;
    if(g > 0) gp[0] += g; else gp[1] += -g;
    dealer ^= 1; k++;
  }
  return gp[0] >= 7 ? 0 : 1;
}
function matchDuel(A, B, M, seed){
  let w=0, n=0;
  for(let i=0;i<M;i++){
    const ms = hash(seed ^ 0x1234, i);
    if(bummerl(A, B, ms)===0) w++;          // A at seat 0
    if(bummerl(B, A, ms)===1) w++;          // seats swapped, same deals
    n += 2;
  }
  return { wr: w/n, n };
}

/* ---------------- Hodge: strength vs cycle ---------------- */
function hodge(M){
  const n = M.length;
  const s = M.map(row => row.reduce((a,b)=>a+b,0) / n);        // least-squares rating
  let tot=0, cyc=0;
  for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){
    const g = s[i] - s[j];
    const r = M[i][j] - g;
    tot += M[i][j]*M[i][j];
    cyc += r*r;
  }
  return { s, cycFrac: tot > 0 ? cyc/tot : 0, tot, cyc };
}

/* ---------------- run ---------------- */
const N     = +(process.argv[2] || 300);      // paired deals per pairing
const MB    = +(process.argv[3] || 0);        // bummerls per pairing (0 = skip)
const SEED  = +(process.argv[4] || 2024);
const names = ALL_BRAINS;
const n = names.length;

const M = Array.from({length:n}, ()=> new Array(n).fill(0));
const SE = Array.from({length:n}, ()=> new Array(n).fill(0));
const t0 = Date.now();
for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){
  const r = dealDuel(names[i], names[j], N, hash(SEED, i*17+j));
  M[i][j] =  r.mean; M[j][i] = -r.mean;
  SE[i][j] = r.se;   SE[j][i] = r.se;
  process.stderr.write(`  ${names[i]} vs ${names[j]}: ${r.mean>=0?"+":""}${r.mean.toFixed(3)} +/- ${(1.96*r.se).toFixed(3)}  (${r.n} paired deals)\n`);
}
const secs = ((Date.now()-t0)/1000).toFixed(1);

const H = hodge(M);
console.log(`\nDEAL-LEVEL PAYOFF  (mean signed game points, row vs column; N=${N} paired deals, seed ${SEED}, ${secs}s)\n`);
const pad = (x,w)=> String(x).padStart(w);
console.log("          " + names.map(x=>pad(x,8)).join("") + "   strength");
for(let i=0;i<n;i++){
  const row = names.map((_,j)=> i===j ? pad("--",8) : pad((M[i][j]>=0?"+":"")+M[i][j].toFixed(2), 8)).join("");
  console.log(names[i].padEnd(10) + row + "   " + (H.s[i]>=0?"+":"") + H.s[i].toFixed(3));
}
console.log(`\nHODGE:  strength (gradient) ${(100*(1-H.cycFrac)).toFixed(1)}%   |   CYCLE (curl) ${(100*H.cycFrac).toFixed(1)}%`);

/* every 3-cycle, and whether any of them is real */
let cycles = 0, sig = 0;
for(let i=0;i<n;i++) for(let j=0;j<n;j++) for(let k=0;k<n;k++){
  if(i===j||j===k||i===k) continue;
  if(i>j || i>k) continue;                                   // canonical: i is the smallest
  if(M[i][j]>0 && M[j][k]>0 && M[k][i]>0){
    cycles++;
    const worst = Math.min(M[i][j]/(1.96*SE[i][j]), M[j][k]/(1.96*SE[j][k]), M[k][i]/(1.96*SE[k][i]));
    const ok = worst >= 1;
    if(ok) sig++;
    console.log(`  ${ok?"CYCLE  ":"cycle? "} ${names[i]} > ${names[j]} > ${names[k]} > ${names[i]}   weakest edge ${(worst).toFixed(2)}x its 95% CI`);
  }
}
if(!cycles) console.log("  no 3-cycles at all — this is a total order.");
else console.log(`  ${cycles} raw 3-cycle(s), ${sig} with every edge outside its 95% CI`);

/* Condorcet */
const beatsAll = names.filter((_,i)=> names.every((_,j)=> i===j || M[i][j] > 0));
const losesAll = names.filter((_,i)=> names.every((_,j)=> i===j || M[i][j] < 0));
console.log(`  Condorcet winner: ${beatsAll.length?beatsAll.join(","):"none"}   Condorcet loser: ${losesAll.length?losesAll.join(","):"none"}`);

if(MB){
  const MM = Array.from({length:n}, ()=> new Array(n).fill(0));
  for(let i=0;i<n;i++) for(let j=i+1;j<n;j++){
    const r = matchDuel(names[i], names[j], MB, hash(SEED, i*31+j));
    MM[i][j] = r.wr - 0.5; MM[j][i] = 0.5 - r.wr;
  }
  const HM = hodge(MM);
  console.log(`\nMATCH-LEVEL (Bummerl win rate - 50%, ${MB} bummerls x2 seats per pairing)\n`);
  console.log("          " + names.map(x=>pad(x,8)).join(""));
  for(let i=0;i<n;i++)
    console.log(names[i].padEnd(10) + names.map((_,j)=> i===j ? pad("--",8) : pad((100*MM[i][j]>=0?"+":"")+(100*MM[i][j]).toFixed(0)+"%", 8)).join(""));
  console.log(`\nHODGE:  strength ${(100*(1-HM.cycFrac)).toFixed(1)}%   |   CYCLE ${(100*HM.cycFrac).toFixed(1)}%`);
}
