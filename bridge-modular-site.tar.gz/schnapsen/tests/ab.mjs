/* A/B: each candidate style against the CURRENT bot, on identical deals, both seats. */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { SCOUT } from "./styles.mjs";

function mul(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }
const hash=(a,b)=>((a*0x9E3779B1)^(b*0x85EBCA77)^((a+b)*0xC2B2AE3D))>>>0;

function playDeal(s0,s1,ds){
  const d=RULES.newDeal(0, mul(ds)); const r=mul(ds^0x5bf03635); let g=0;
  while(d.phase==="play"&&g++<400){
    const p=d.turn;
    const dec=decide(d,p,{brain:"fritzl",skill:SCOUT,style:p===0?s0:s1,rnd:r});
    if(!dec) break;
    const a=dec.action;
    if(a.type==="PLAY")RULES.play(d,p,a.cardId,{}); else if(a.type==="MELD")RULES.meld(d,p,a.suit,{});
    else if(a.type==="EXCHANGE")RULES.exchange(d,p); else if(a.type==="CLOSE")RULES.close(d,p);
    else if(a.type==="CLAIM")RULES.claim(d,p); else break;
  }
  return d.result ? (d.result.winner===0?d.result.gp:-d.result.gp) : null;
}
function ab(cand, base, N, seed){
  const diff=[];
  for(let i=0;i<N;i++){
    const ds=hash(seed,i);
    const g1=playDeal(cand,base,ds), g2=playDeal(base,cand,ds);
    if(g1===null||g2===null) continue;
    diff.push((g1-g2)/2);
  }
  const n=diff.length, m=diff.reduce((a,b)=>a+b,0)/n;
  const v=diff.reduce((a,b)=>a+(b-m)*(b-m),0)/(n-1);
  return { m, ci: 1.96*Math.sqrt(v/n), n };
}

const N=+(process.argv[2]||600), SEED=+(process.argv[3]||2024);
const BASE = {};
const CAND = {
  "evCompare + margin 0.15                        ": { evCompare:1, evMargin:0.15 },
};
console.log(`\nA/B vs the current bot — ${N} paired deals, both seats, seed ${SEED}\n`);
for(const [name, st] of Object.entries(CAND)){
  const r = ab(st, BASE, N, hash(SEED, name.length));
  const sig = Math.abs(r.m) > r.ci ? (r.m>0?"  WIN":"  LOSS") : "  (ns)";
  console.log(`  ${name}  ${r.m>=0?"+":""}${r.m.toFixed(3)} +/- ${r.ci.toFixed(3)} gp/deal${sig}`);
}
