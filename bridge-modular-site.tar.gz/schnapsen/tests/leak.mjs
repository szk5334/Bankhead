/* =======================================================================
   LEAK — the world-anchor test for the grader.

   The grader is not allowed to be judged against its own outputs. So we point it at players whose
   mistakes we DESIGNED, and ask whether it finds them without being told what they are:

     xracer   — built to cash side aces the instant he sees them (aceLead 3.0, aceHold 0.15).
                His leak is deliberate, enormous, and has a name we already know: ACE_INTO_RUFF.
     xruffer  — built to never cash anything and duck everything.
     textbook — the shipped heuristics.
     greta    — belief + counterfactual close. Should be the cleanest player on the board.

   If the grader cannot catch a bot that leaks ON PURPOSE, it will never catch a human.

   node leak.mjs [deals] [seed]
   ===================================================================== */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
import { gradeDecision } from "../engine/grade.js";
import { STYLES, SCOUT } from "./styles.mjs";

function mul(a){ return function(){ a|=0; a=a+0x6D2B79F5|0; let t=Math.imul(a^a>>>15,1|a); t=t+Math.imul(t^t>>>7,61|t)^t; return ((t^t>>>14)>>>0)/4294967296; }; }

const N    = +(process.argv[2] || 40);
const SEED = +(process.argv[3] || 2024);
const OPP  = {};                                     // everyone is graded playing against textbook

const SUBJECTS = {
  greta:    { style:{ reads:"_base", ruffFear:0.9, denyRuff:0.7, honFear:0.9,
                      evCompare:1, evMargin:0.15, adjWin:1, meldNow:1, tenGuard:1 } },
  fritzl:   { style:{} },
  xruffer:  { style: STYLES.xruffer },
  xracer:   { style: STYLES.xracer },
  RANDOM:   { style:{}, random:true },
};

for(const [name, sub] of Object.entries(SUBJECTS)){
  let decisions=0, flagged=0, pts=0, loss=0, raw=0, deals=0;
  const tags = {};
  for(let s=0;s<N;s++){
    deals++;
    const d = RULES.newDeal(0, mul(70000 + s*13));
    const r = mul(s ^ 0x9e3);
    let g=0;
    while(d.phase==="play" && g++ < 400){
      const p = d.turn;
      let dec;
      if(p===0 && sub.random){
        const legal = RULES.legalCards(d, 0);
        dec = { action:{ type:"PLAY", seat:0, cardId: legal[Math.floor(r()*legal.length)].id } };
      } else {
        dec = decide(d, p, { brain:"fritzl", skill:SCOUT, style: p===0 ? sub.style : OPP, rnd:r });
      }
      if(!dec) break;
      if(p===0){                                     // grade the SUBJECT, every decision it makes
        const gr = gradeDecision(d, 0, dec.action, r, { worlds: 10 });
        if(gr){
          decisions++; pts += gr.pts; loss += gr.evLoss; raw += gr.rawLoss;
          if(gr.tag !== "OK"){ flagged++; tags[gr.tag] = (tags[gr.tag]||0) + 1; }
        }
      }
      const a = dec.action;
      if(a.type==="PLAY")          RULES.play(d,p,a.cardId,{});
      else if(a.type==="MELD")     RULES.meld(d,p,a.suit,{});
      else if(a.type==="EXCHANGE") RULES.exchange(d,p);
      else if(a.type==="CLOSE")    RULES.close(d,p);
      else if(a.type==="CLAIM")    RULES.claim(d,p);
      else break;
    }
  }
  const top = Object.entries(tags).sort((a,b)=>b[1]-a[1]).slice(0,4)
    .map(([k,v])=> `${k} x${v}`).join("  ");
  console.log(
    name.padEnd(8) +
    "  PLAY POINTS/deal " + (pts/deals >= 0 ? "+" : "") + (pts/deals).toFixed(0).padStart(5) +
    "   per decision " + (pts/decisions >= 0 ? "+" : "") + (pts/decisions).toFixed(1).padStart(6) +
    "   flagged " + (100*flagged/decisions).toFixed(0).padStart(3) + "%"
  );
}
