/* The guest never holds the truth. Everything a guest's UI does — legal moves, hints, the bot that covers
 * a dropped seat — runs on the REDACTED snapshot the host broadcast, where the opponent's hand and the
 * stock are card backs. If any of that quietly reads a face-down card, this test catches it. */
import { RULES, other } from "../engine/rules.js";
import { ENG } from "../engine/core.js";
import { decide } from "../engine/bot.js";
import { reducer, SETUP, botAction } from "../state/reducer.js";

import { redactFor, publicView } from "../engine/redact.js";
import { __sample } from "../engine/bot.js";
const GAME = { redactFor, publicView };

let fails = 0;
const bad = (m) => { console.log("  FAIL " + m); fails++; };

/* 1 — a hint computed on the redacted view must be legal in the TRUE state, and never reference a card
 *     the guest cannot see. Run it across many positions of many deals. */
let hints = 0, exact = 0;
for (let g = 0; g < 60; g++) {
  let s = reducer(SETUP, { type: "START", brains: ["human", "human"], names: ["AAA", "BBB"], target: 7, dealer: g % 2 });
  for (let step = 0; step < 200 && s.mode === "play" && s.phase === "play"; step++) {
    const me = s.turn;
    const view = GAME.redactFor(s, me);              // <- exactly what crosses the wire

    // the guest must not be able to see through the backs
    if (view.hands[other(me)].some((c) => !c.back)) bad("redacted hand leaked a face");
    if (view.stock.some((c) => !c.back)) bad("redacted stock leaked a face");

    // legality computed on the view must agree with legality computed on the truth
    const lv = RULES.legalCards(view, me).map((c) => c.id).sort().join(",");
    const lt = RULES.legalCards(s, me).map((c) => c.id).sort().join(",");
    if (lv !== lt) bad("legal moves differ on the redacted view (" + lv + " vs " + lt + ")");

    // The bot, asked to move while it can see NOTHING it isn't entitled to. In solo play the bot is handed
    // a state that does contain your hand — this proves it never reads it, because it plays just as well
    // when your hand isn't there at all.
    const adv = decide(view, me, { brain: "resi", strictClaim: !!s.strictClaim });
    if (!adv || !adv.action) { bad("bot could not move on a redacted view"); break; }
    hints++;

    const a = adv.action;
    if (a.type === "PLAY") {
      const ok = RULES.legalCards(s, me).some((c) => c.id === a.cardId);
      if (!ok) bad("bot proposed an illegal card in the true state");
    } else if (a.type === "CLOSE" && !RULES.canClose(s, me)) bad("bot proposed an illegal close");
    else if (a.type === "EXCHANGE" && !RULES.canExchange(s, me)) bad("bot proposed an illegal swap");
    else if (a.type === "CLAIM" && !RULES.canClaim(s, me)) bad("bot proposed an illegal claim");

    // 2 — when the stock is gone the unseen set IS the opponent's hand: the bot should now be reasoning
    //     about the real cards, deduced rather than peeked at.
    if (view.stock.length === 0 && !view.up && view.hands[other(me)].length > 0) {
      const truth = s.hands[other(me)].map((c) => c.rank + c.suit).sort().join(" ");
      const d2 = decide(view, me, { skill: 1, cap: 60000, samples: 1 });
      if (!d2 || !d2.action) bad("no decision at exhausted endgame");
      exact++;
      // the sampler's one world must reconstruct the opponent exactly
      {
        const w = __sample(view, me, Math.random);
        const got = w.hands[other(me)].map((c) => c.rank + c.suit).sort().join(" ");
        if (got !== truth) bad("endgame deduction wrong: got [" + got + "] want [" + truth + "]");
      }
    }

    // advance the true game with the host's own bot
    const d = botAction(s, s.turn);
    if (!d || !d.action) break;
    s = reducer(s, d.action);
  }
}
console.log("bot decisions made on card backs: " + hints + "  · exhausted-endgame positions: " + exact);

/* 3 — the guest's __SYNC__ path: a redacted snapshot must survive being loaded straight into the reducer. */
let s = reducer(SETUP, { type: "START", brains: ["human", "human"], names: ["AAA", "BBB"], target: 7, dealer: 0 });
for (let i = 0; i < 5; i++) { const d = botAction(s, s.turn); s = reducer(s, d.action); }
const snap = GAME.redactFor(s, 1);
const synced = reducer(SETUP, { type: "__SYNC__", state: snap });
if (synced.turn !== s.turn || synced.phase !== s.phase) bad("__SYNC__ did not adopt the snapshot");
if (synced.hands[1].some((c) => c.back)) bad("guest cannot see its own hand after sync");
const pv = GAME.publicView(s);
if (!pv.seats || pv.seats.length !== 2) bad("publicView shape wrong");
if (pv.seats.some((x) => typeof x.score !== "number")) bad("publicView seat needs a numeric score for the shell");

console.log(fails ? "\n" + fails + " FAILED" : "\nclean — the bot, the legal-move filter and the endgame deduction all\nrun on card backs. The bot cannot see your hand because it never has one.");
process.exit(fails ? 1 : 0);
