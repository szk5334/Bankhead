/* Head-to-head, paired deals, both seats: the ship gate for a new persona. */
import { RULES } from "../engine/rules.js";
import { decide } from "../engine/bot.js";
function mul(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return ((t^t>>>14)>>>0)/4294967296;};}
const hash=(a,b)=>((a*0x9E3779B1)^(b*0x85EBCA77)^((a+b)*0xC2B2AE3D))>>>0;
function playDeal(b0,b1,ds){
  const d=RULES.newDeal(0,mul(ds)); const r=mul(ds^0x5bf03635); let g=0;
  while(d.phase==="play"&&g++<400){
    const p=d.turn; const dec=decide(d,p,{brain:p===0?b0:b1,rnd:r});
    if(!dec)break; const a=dec.action;
    if(a.type==="PLAY")RULES.play(d,p,a.cardId,{}); else if(a.type==="MELD")RULES.meld(d,p,a.suit,{});
    else if(a.type==="EXCHANGE")RULES.exchange(d,p); else if(a.type==="CLOSE")RULES.close(d,p);
    else if(a.type==="CLAIM")RULES.claim(d,p); else break;
  }
  return d.result?(d.result.winner===0?d.result.gp:-d.result.gp):null;
}
const A=process.argv[2], B=process.argv[3], N=+process.argv[4], SEED=+process.argv[5];
const diff=[];
for(let i=0;i<N;i++){
  const ds=hash(SEED,i);
  const g1=playDeal(A,B,ds), g2=playDeal(B,A,ds);
  if(g1===null||g2===null) continue;
  diff.push((g1-g2)/2);
}
const n=diff.length,m=diff.reduce((a,b)=>a+b,0)/n;
const v=diff.reduce((a,b)=>a+(b-m)*(b-m),0)/(n-1);
const ci=1.96*Math.sqrt(v/n);
console.log(`  seed ${SEED}: ${A} vs ${B}  ${m>=0?"+":""}${m.toFixed(3)} +/- ${ci.toFixed(3)} gp/deal  ${Math.abs(m)>ci?(m>0?"WIN":"LOSS"):"(ns)"}`);
