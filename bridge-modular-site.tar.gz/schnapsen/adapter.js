import App from "./App.jsx";
import { redactFor, publicView } from "./engine/redact.js";

/* =======================================================================
   GAME ADAPTER — the standard contract the multiplayer shell consumes.
   The shell knows nothing about Schnapsen; it knows about `window.GAME`.
   ===================================================================== */

if(typeof window !== "undefined"){
  window.GAME = {
    id: "schnapsen",
    title: "SCHNAPSEN",
    minPlayers: 2,
    maxPlayers: 2,
    /* The lobby's "play to" segment. Schnapsen is a race to 7 game points — a Bummerl — not to 100. */
    targets: [{ v:7, l:"7" }, { v:11, l:"11" }],
    App,
    redactFor,
    publicView,
    actionTypes: ["PLAY","MELD","EXCHANGE","CLOSE","CLAIM","NEXT_DEAL","NEW_BUMMERL"],
    seatOf: (a)=> a.seat!=null ? a.seat : a.player,
  };
}
export { redactFor, publicView };
