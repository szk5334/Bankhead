# SESSION HANDOFF — Schnapsen: the RPS hunt, and what it found instead

## The question we came in with

*Can we build a rock-paper-scissors (later: RPS-Lizard-Spock) cycle of play styles into the bot roster?*

## The answer: no. And the "no" is the most valuable thing in this session.

**There is no non-transitive bot roster in two-player Schnapsen.** Five independent designs, five
ladders. This is a fact about the game, not a failure of the search:

| lever tried | cyclic energy | why it collapsed |
|---|---|---|
| skill (samples / noise / close bar) | **0.1%** | four of the five shipped bots are statistically the SAME BOT (edges <= 0.06 gp, inside the CI) |
| heuristic weights (16 styles, 8 knobs) | 0% significant | real edges (+-0.25 gp) but **zero** 3-cycles built from significant edges |
| objective / risk preference | ~0 | `safe` diverged from linear on **0 of 2274** decisions. Provable: monotone transforms of a zero-sum payoff cannot change minimax play, and "maximise P(win)" IS the existing win-rate bar, algebraically |
| opponent modelling (belief) | 6.8% | the read is real (+0.06 when right, -0.12 when wrong) but never closes a loop — aggression simply dominates |
| race-aware closing (Bummerl) | noise | fires on ~1% of decisions, in ONE direction only (see the close-gate bug below) |

**The structural reason, which held every single time:** both players solve the endgame exactly, every
deal ends there, and the open phase has no currency with which one strategy can *pay* to punish another.
RPS needs a rock that is genuinely worse in the abstract and eats scissors anyway. Schnapsen doesn't sell
one.

### Methodological warning for whoever picks this up

**Cyclic energy is a RATIO and it lies.** We twice found "pentagons" at 89% and 98% cyclic energy that
were pure noise: when the gradient is near zero and every edge sits inside its CI, noise fills the
residual and the fraction runs to 100%. Five coin-flips score ~100%. **Always gate on absolute edge size
AND significance** (`|edge| >= 0.15 gp` and `z >= 1.96`), never on the fraction alone.

## What shipped instead: GRETA

A new persona, and the first bot on this bench whose edge is not "searches harder".

**vs Resi, 500 paired deals x 5 seeds, seats swapped, common random numbers:**

```
  seed 2024:  +0.197 +/- 0.073   WIN
  seed 3024:  +0.182 +/- 0.074   WIN
  seed 4242:  +0.183 +/- 0.079   WIN
  seed 5024:  +0.139 +/- 0.082   WIN
  seed 6024:  +0.175 +/- 0.079   WIN
  pooled:     +0.175 +/- 0.035 gp/deal, 5/5 seeds
```

For scale: Resi's entire edge over Fritzl is about **+0.01**. Greta is an order of magnitude clear of the
whole existing ladder.

She does two things, and **both live outside the endgame solver — which is the only place left where
there was anything to win.**

### 1. She counts what he can still HOLD (`engine/belief.js`)

Not which cards have been played (every bot does that). She samples the unseen set and computes
`pRuff` — can he beat the ace she is about to cash — and `eHon` — how many aces and tens is he still
sitting on. She will not lead into a trump she believes is there, and will not fear an ace he cannot have.
Measured **+0.139 strength** on the style bench where textbook scores -0.017.

### 2. She closes by COMPARISON, not by bar (Tompa, Ch. 5)

Every other bot asks *"is closing safe enough?"* and checks the answer against a **constant**
(`wr >= 0.85 && ev > 0.6`). Tompa never asks that. He asks **"is closing BETTER than not closing?"** and
computes *both* expectations.

Our bot had never computed the right-hand side. So it was deaf in both directions: it would not close from
a hopeless position where a 55% close beats a 20% play-on, and it *would* close from a winning position
where a 90% close is worse than simply playing the hand out.

`closeCompare()` now samples a world and plays it **both ways** — closed and solved exactly, or left open
and rolled out under the bot's own policy — and compares.
**+0.030 +/- 0.012 gp/deal, positive on 5/5 seeds, 14,000 paired deals, z=4.83.**

## What the Tompa book gave us (and did not)

Read: *Winning Schnapsen*, Martin Tompa.

**The beginner guidelines are correct and worth NOTHING.** All three implemented and verified firing:

- `adjWin` — among ADJACENT cards, take the trick with the HIGHER one. Holding A+10, whichever you keep
  is master, so the ace's extra point is free. Unit-tested: the bot now plays the ace where it used to
  play the ten. **Changes one open-play follow in seven (14.3%). Worth -0.004 +/- 0.030. Nothing.**
- `meldNow` — show the marriage at once. Null.
- `tenGuard` — keep the bodyguard beside an unprotected ten. Null.

**Why:** these are *heuristic substitutes for a calculation the bot already performs exactly.* Pull
trumps, force the ruff, count the unseen cards, reconstruct his hand at exhaustion — the solver does all
of it, perfectly, every deal. **You cannot teach a solver rules of thumb about the phase it solves.**
Tompa is writing for a human with a memory and a headache.

They are shipped anyway, because they are free and because they generate the right *explanations* for a
teaching app. Just do not expect points from them.

## THE MAP (the one thing to remember)

> **Every lever that failed, failed because the solver had already eaten it. The one that worked, worked
> because the close happens BEFORE the solvable game begins.**
>
> **The value in this engine lives strictly outside the solver's horizon.** Anything you propose that
> operates inside strict play is already optimal and your change will measure zero. Check this first,
> before writing code.

## Known bug, not yet fixed

**The close gate is a CONJUNCTION** (`wr >= bar AND uev > evBar`), so an objective can only ever make the
bot *more* reluctant to close. The "risk is free when you are dying" half of real Schnapsen judgment is
**structurally unreachable**: at 2-6 down, where every loss is equally fatal and a human gambles, our bots
change nothing (measured: 0 divergence out of 888 decisions). Greta's `evCompare` path bypasses the bar
entirely and so does not suffer this — but the legacy bots still do. Worth fixing on its own merits.

## Files

**Engine (changed):**
- `engine/bot.js` — style vector (14 knobs), objective transforms (`OBJ`), `closeCompare()`, Tompa's
  `adjRunFloor`/`effCost`, `GRETA` style, `greta` in `SKILL`
- `engine/belief.js` — **NEW.** `worldWeight` (likelihood RATIO vs a measured baseline, not absolute fit —
  the absolute-fit version was inert and fooled us for a full round), `beliefSample`, `readHand`
- `engine/profiles.js` — **NEW, GENERATED.** Hand fingerprints per style. Regenerate with
  `node tests/profile.mjs > ../engine/profiles.js` (**stub the file first** — it is a bootstrap dependency
  of `belief.js`, and clobbering it breaks the profiler that writes it)
- `state/personas.js` — Greta added to `PROFILES` and `ALL_BRAINS`

**Harnesses (all new, all reusable):**
- `tests/bench.mjs` — persona round-robin, paired deals, Hodge decomposition
- `tests/rr.mjs` / `tests/hunt.mjs` / `tests/hunt2.mjs` / `tests/read.mjs` / `tests/obj.mjs` — style searches
- `tests/match.mjs` — Bummerl-level bench (the only place a race objective exists)
- `tests/ab.mjs` — A/B a style against the shipped bot
- `tests/duel.mjs` — head-to-head persona ship gate: `node duel.mjs greta resi 500 2024`
- `tests/profile.mjs` — the fingerprint profiler
- `tests/styles.mjs` — style tables (archetypes, objectives, readers, hunters)

**Identity gate used throughout:** every default knob is 0/identity, so with no style set the bot is
byte-identical to the one that shipped. `node bench.mjs 40 0 2024` must reproduce
`poldi vs ignaz: -0.450`, `vs fritzl: -0.512`, `vs vroni: -0.263`, `vs resi: -0.725`. It did, after every
single edit.

**Gates green:** rules 27/27 · redaction clean · 400-deal selfplay invariants · DOM (deal plays, Bummerl
ends, 6 themes render). NOTE: `dom.test.mjs` needs `npm install jsdom @babel/standalone react react-dom`
— not in the container by default.

## Next

1. **Fix the conjunction close gate** so the legacy bots can gamble when they are losing.
2. **Greta's `why` strings** are written but unreviewed — she now explains closes as *"closing is worth
   0.7 game points, playing on is worth 0.4"*, which is the actual lesson and much better than the old
   win-rate sentence. Worth an expert read.
3. **The teaching roster.** The wheel does not exist between the bots — but it exists between YOUR
   mistakes. `xruffer` punishes you for cashing aces. `xracer` punishes you for dawdling. `greta`
   punishes you for holding cards she knows you cannot have. Three bots, three lessons, each beatable once
   you learn the counter. That was always the real goal; the pentagon was only ever a proxy for it.
