import React from "react";
import { ENG } from "../engine/core.js";
import { RULES, effPts, stockLeft, isStrict, other } from "../engine/rules.js";
import { SUIT_GLYPH, suitColorClass, cardName } from "../state/constants.js";
import { seatPersona, who } from "../state/personas.js";
import { Card } from "./cards.jsx";
import { rankedScores } from "./storage.js";

const G = (su)=> <span className={suitColorClass(su)}>{SUIT_GLYPH[su]}</span>;

/* ---------------- top status bar (constant height, every screen) ----------------
 * It carries the three things you cannot play Schnapsen without: what's trumps, how much stock is left,
 * and the Bummerl score. Bridge counts up to a rubber; Schnapsen counts DOWN from seven, so that's what
 * this shows — "3 to go" is the number an Austrian actually says out loud. */
function StatusBar({s, focus, onMenu, turnText}){
  const left = stockLeft(s);
  const strict = isStrict(s);
  const need = s.target > 0 ? [s.target - s.gp[0], s.target - s.gp[1]] : null;
  const title = s.phase==="scored"
    ? "Result"
    : <span>{G(s.trump)} trumps · {s.closed ? "closed" : left ? <>stock <b className="num">{left}</b></> : "stock out"}</span>;
  return (
    <div className="gstatus">
      <button className="gs-menu" onClick={onMenu} aria-label="Menu">≡</button>
      <div className="gs-mid">
        <div className="gs-title">{title}</div>
        <div className="gs-turn">{turnText || (strict && s.phase==="play" ? "follow suit · head the trick · trump when void" : "\u00a0")}</div>
      </div>
      <div className="gs-score num">
        <span>B{s.bummerlNo||1}</span>
        <span className="gs-games">{need ? `${need[focus]}–${need[other(focus)]}` : `${s.gp[focus]}–${s.gp[other(focus)]}`}</span>
        <span style={{fontSize:8,letterSpacing:".1em",textTransform:"uppercase"}}>{need ? "to go" : "points"}</span>
      </div>
    </div>
  );
}

function TabBar({tab, onTab, phase, yourTurn}){
  return (
    <div className="gtabs">
      <button className={"gtab"+(tab==="game"?" on":"")} onClick={()=>onTab("game")}>
        {phase==="scored" ? "Result" : "Play"}{yourTurn && tab!=="game" ? <span className="gt-dot"/> : null}
      </button>
      <button className={"gtab"+(tab==="log"?" on":"")} onClick={()=>onTab("log")}>Log</button>
    </div>
  );
}

/* ---------------- the opponent, and you ----------------
 * MEMORY MODE hides their running total. That is the real game: at a real table nobody tells you what your
 * opponent has taken, and knowing when they are about to cross 33 (and so cost you a game point) is most of
 * the skill. The default is to show it, because most people want to learn the game before they learn to count it.
 */
function PtsBar({pts, them, hidden}){
  const w = Math.min(100, (pts/66)*100);
  return (
    <div className={"sc-bar"+(them?" them":"")}>
      {!hidden && <i style={{width:w+"%"}}/>}
      <span className="m66" style={{left:"50%"}}/>
    </div>
  );
}
function OppStrip({s, seat, focus, hidden}){
  const p = seatPersona(s, seat);
  const pts = effPts(s, seat);
  const act = s.turn===seat && s.phase==="play";
  return (
    <div className={"sc-opp"+(act?" act":"")} style={{"--accent":p.color}}>
      <span className="sc-av">{p.glyph}</span>
      <span className="sc-nm">{who(s, seat)}</span>
      <div className="sc-backs">
        {(s.hands[seat]||[]).map((c,i)=><div key={c.id!=null?c.id:i} className="brback"/>)}
      </div>
      <PtsBar pts={pts} them hidden={hidden}/>
      <div className="sc-pts">
        <div className={"p num"+(hidden?" hid":"")}>{hidden ? "··" : pts}</div>
        <div className="t num">{s.tricksWon[seat]} tricks</div>
      </div>
    </div>
  );
}
function YouStrip({s, seat}){
  const pts = effPts(s, seat);
  const act = s.turn===seat && s.phase==="play";
  const out = pts >= RULES.OUT;
  return (
    <div className={"sc-you"+(act?" act":"")}>
      <span className="sc-nm">{who(s, seat)}</span>
      <PtsBar pts={pts}/>
      <div className="sc-pts">
        <div className="p num" style={out?{color:"var(--green)"}:null}>{pts}</div>
        <div className="t num">{s.tricksWon[seat]} tricks{s.meldPts[seat] ? ` · ${s.meldPts[seat]} melded` : ""}</div>
      </div>
    </div>
  );
}

/* ---------------- the middle: the stock, the turn-up, and the trick ----------------
 * The turn-up lies crosswise under the stock, which is where it lies on a real table, and when the stock is
 * closed it is dimmed rather than removed — because you SAW it, and Schnapsen expects you to remember it. */
function StockZone({s}){
  const down = s.stock.length;
  const left = stockLeft(s);
  const shown = Math.min(3, down);
  return (
    <div className="sc-stock">
      <div className={"sc-deck"+(s.closed?" closed":"")}>
        {s.up && <div className="sc-up"><Card c={s.up} small showVal/></div>}
        {Array.from({length:shown}).map((_,i)=>(
          <div key={i} className={"brback"+(i===1?" d2":i===2?" d3":"")}/>
        ))}
        {!down && !s.up && <div className="sc-hole">—</div>}
      </div>
      <div className="sc-stock-l">
        {s.closed
          ? <span className="sc-shut">closed</span>
          : left ? <>stock <b className="num">{left}</b></> : <span className="sc-strict">stock out</span>}
      </div>
    </div>
  );
}
function TrickZone({s, focus, message}){
  const mine = s.trick.find(t=>t.seat===focus);
  const theirs = s.trick.find(t=>t.seat!==focus);
  const showLast = s.trick.length===0 && s.lastTrick;
  const lastMine = showLast ? s.lastTrick.trick.find(t=>t.seat===focus) : null;
  const lastTheirs = showLast ? s.lastTrick.trick.find(t=>t.seat!==focus) : null;
  const wonBy = showLast ? s.lastTrick.winner : null;
  const slot = (t, lastT, seat, label)=>{
    const c = (t && t.card) || (lastT && lastT.card);
    const win = showLast && wonBy===seat;
    return (
      <div className={"sc-slot"+(win?" win":"")}>
        {c ? <Card c={c} showVal/> : <div className="sc-hole">·</div>}
        <div className="sc-who">{label}</div>
      </div>
    );
  };
  return (
    <div className="sc-trick">
      <div className="sc-slots">
        {slot(theirs, lastTheirs, other(focus), "them")}
        {slot(mine, lastMine, focus, "you")}
      </div>
      <div className="sc-tmsg">{message}</div>
    </div>
  );
}

/* ---------------- the actions ----------------
 * Only the legal ones are rendered at all. In Schnapsen the whole art is in these four buttons — when to
 * swap, when to declare, when to close, when to say the word — so they get their own row and never move. */
function ActionBar({s, seat, dispatch, canAct}){
  if(!canAct) return <div className="sc-acts"><span className="sc-acts-none">{s.phase==="play" ? "their turn" : ""}</span></div>;
  const acts = [];

  if(RULES.canExchange(s, seat)){
    acts.push(
      <button key="x" className="sc-act" onClick={()=>dispatch({type:"EXCHANGE", seat})}>
        Swap J{SUIT_GLYPH[s.trump]} ↔ {s.up.rank}{SUIT_GLYPH[s.up.suit]}
      </button>);
  }
  for(const m of RULES.meldOptions(s, seat)){
    acts.push(
      <button key={"m"+m.suit} className="sc-act hot" onClick={()=>dispatch({type:"MELD", seat, suit:m.suit})}>
        Declare {m.value} {SUIT_GLYPH[m.suit]}
      </button>);
  }
  if(RULES.canClose(s, seat)){
    acts.push(
      <button key="c" className="sc-act" onClick={()=>dispatch({type:"CLOSE", seat})}>
        Close the stock
      </button>);
  }
  /* THE DECLARATION. It only exists in strict-claiming mode — otherwise the app counts for you and the
   * deal simply ends when you cross 66. With it on, forgetting to say it costs you the deal, which is
   * exactly what happens in Vienna. */
  if(s.strictClaim && RULES.canClaim(s, seat)){
    const out = effPts(s, seat) >= RULES.OUT;
    acts.push(
      <button key="d" className={"sc-act out"+(out?" hot":"")} onClick={()=>dispatch({type:"CLAIM", seat})}>
        Declare 66
      </button>);
  }
  if(!acts.length) return <div className="sc-acts"><span className="sc-acts-none">no declarations available</span></div>;
  return <div className="sc-acts">{acts}</div>;
}

/* ---------------- the score sheet ---------------- */
function ScoreSheet({s}){
  const rows = (s.sheet||[]);
  return (
    <div className="sheet">
      <div className="shead">
        <div className="scol">#</div><div className="scol">deal</div><div className="scol">pts</div><div className="scol" style={{textAlign:"right"}}>gp</div>
      </div>
      {!rows.length && <div className="srow"><div className="sc-c dim" style={{gridColumn:"1 / -1", textAlign:"center"}}>no deals yet</div></div>}
      {rows.map((r,i)=>(
        <div className="srow" key={i}>
          <div className="sc-c dim num">{r.dealNo}</div>
          <div className="sc-c">
            {who(s, r.winner)} {G(r.trump)}
            {r.closedBy!=null ? <span className="sc-c dim"> · closed</span> : null}
          </div>
          <div className="sc-c dim num">{r.pts[r.winner]}–{r.pts[other(r.winner)]}</div>
          <div className="sc-c gp num">+{r.gp}</div>
        </div>
      ))}
      <div className="srow">
        <div className="sc-c dim" style={{gridColumn:"1 / 3"}}>Bummerl</div>
        <div className="sc-c gp num" style={{gridColumn:"3 / -1"}}>{s.gp[0]}–{s.gp[1]}{s.target>0?` of ${s.target}`:""}</div>
      </div>
    </div>
  );
}

/* ---------------- HIGH SCORES ----------------
 * Keyed on the initials you typed to get in — the same three letters whether you came through the lobby or
 * started a solo game, because storage.js writes both to one key. Online, BOTH players' results are banked
 * on every device that watched the Bummerl end, so the board fills up with everyone you have ever played.
 */
function HighScores({table, meIni, limit}){
  const rows = rankedScores(table).slice(0, limit || 10);
  if(!rows.length) return <div className="hs"><div className="hs-empty">No Bummerls finished yet. Win one and your initials go up here.</div></div>;
  return (
    <div className="hs">
      {rows.map((r,i)=>(
        <div key={r.ini} className={"hs-row"+(r.ini===meIni?" me":"")}>
          <span className="hs-n num">{i+1}</span>
          <span className="hs-i">{r.ini}</span>
          <span className="hs-d num">
            {r.bummerls}W–{r.lost}L · {r.dealsWon}/{r.deals} deals · {r.gpFor - r.gpAgainst >= 0 ? "+" : ""}{r.gpFor - r.gpAgainst} gp
            {r.schneiders ? ` · ${r.schneiders}× 7–0` : ""}
          </span>
          <span className="hs-b num">{r.bummerls}</span>
        </div>
      ))}
    </div>
  );
}

export { StatusBar, TabBar, OppStrip, YouStrip, StockZone, TrickZone, ActionBar, ScoreSheet, HighScores, G };
