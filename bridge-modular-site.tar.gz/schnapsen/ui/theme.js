const C = { gold:"var(--purple)", brass:"var(--line)", cream:"var(--ink)", dim:"var(--dim)",
            card:"var(--card)", ink:"var(--fillink)", red:"var(--red)" };
const lbl = { fontSize:9, letterSpacing:".18em", textTransform:"uppercase", color:"var(--dim)", fontWeight:700, fontFamily:"var(--mono)" };
export { C, lbl };
