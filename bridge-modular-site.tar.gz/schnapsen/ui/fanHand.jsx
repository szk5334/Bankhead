import React from "react";
import { sortHandDisplay } from "../state/constants.js";
import { Card } from "./cards.jsx";

/* fanHand — LIFTED FROM BRIDGE, UNCHANGED IN BEHAVIOUR. Slide a finger along the hand, the card under your
 * thumb lifts and its neighbours spread away from it; flick up to play it. Five cards instead of thirteen
 * makes it easier, not different, and a player who learned the gesture at the bridge table should not have
 * to learn a second one here.
 *
 * The three invariants that make it work are all still load-bearing:
 *   1. the hand's footprint never changes — cards are displaced INSIDE a fixed box, and the displacement
 *      decays to zero at both ends, so nothing is ever pushed off screen;
 *   2. illegal cards are darkened, never removed — you can always see your whole hand;
 *   3. hit-testing runs against BASE positions, never the drawn ones, or the fan judders under your thumb.
 *
 * The only Schnapsen change is the SORT: trumps come first (sortHandDisplay takes the trump suit), because
 * in a game where trumping is the whole endgame you need to see your trumps without hunting for them.
 */
function fanLayout(n, width, cardW, focus, gap = 26, lift = 20){
  if(n <= 0) return [];
  if(n === 1) return [{ i:0, x:(width-cardW)/2, y: focus===0 ? -lift : 0, z:1, focused: focus===0 }];
  const pitch = (width - cardW) / (n - 1);
  const out = [];
  for(let i=0;i<n;i++){
    let d = 0;
    if(focus!=null && focus>=0 && focus<n && i!==focus){
      if(i < focus) d = -gap * (i / focus);                        // i=0 -> 0 (pinned)
      else          d = +gap * ((n-1-i) / (n-1-focus));            // i=n-1 -> 0 (pinned)
    }
    const focused = focus === i;
    out.push({ i, x: i*pitch + d, y: focused ? -lift : 0, z: focused ? 100 : i, focused });
  }
  return out;
}
function nearestLegal(px, n, width, cardW, legalIdx){
  if(!legalIdx.length) return null;
  const pitch = n > 1 ? (width - cardW) / (n - 1) : 0;
  let best = legalIdx[0], bestD = Infinity;
  for(const i of legalIdx){
    const c = i*pitch + cardW/2;                                   // BASE centre, not the drawn one
    const d = Math.abs(px - c);
    if(d < bestD){ bestD = d; best = i; }
  }
  return best;
}

const CARD_W = { normal:42, small:30 };
const CARD_H = { normal:58, small:42 };
const FLICK_PX = 26;

function FanHand({ hand, trump, legalIds, onFocus, onPlay, active, small=false, height, showVal }){
  const ref = React.useRef(null);
  const [w, setW] = React.useState(320);
  const [k, setK] = React.useState(1);
  const [focus, setFocus] = React.useState(null);
  const drag = React.useRef(null);

  const cards = React.useMemo(()=> sortHandDisplay(hand||[], trump), [hand, trump]);
  const size = small ? "small" : "normal";
  const cardW = CARD_W[size] * k;
  const cardH = CARD_H[size] * k;
  const H = height || (cardH + 22);

  React.useEffect(()=>{
    const el = ref.current; if(!el) return;
    const measure = ()=>{
      setW(el.clientWidth || 320);
      try{ const kv = parseFloat(getComputedStyle(el).getPropertyValue("--k")); if(kv && isFinite(kv) && kv>0) setK(kv); }catch(_){}
    };
    measure();
    if(typeof ResizeObserver !== "undefined"){ const ro = new ResizeObserver(measure); ro.observe(el); return ()=>ro.disconnect(); }
  }, []);

  const legalIdx = React.useMemo(
    ()=> cards.map((c,i)=> (legalIds && legalIds.has(c.id)) ? i : -1).filter(i=>i>=0),
    [cards, legalIds]);

  React.useEffect(()=>{
    if(focus!=null && !legalIdx.includes(focus)){ setFocus(null); onFocus && onFocus(null); }
  }, [legalIdx]);   // eslint-disable-line

  const setF = (i)=>{ if(i===focus) return; setFocus(i); onFocus && onFocus(i==null ? null : cards[i]); };
  const xOf = (e)=>{
    const el = ref.current; if(!el) return 0;
    const t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    return t.clientX - el.getBoundingClientRect().left;
  };
  const yOf = (e)=>{
    const t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    return t.clientY;
  };
  const start = (e)=>{
    if(!active || !legalIdx.length) return;
    drag.current = { y0: yOf(e), moved:false };
    setF(nearestLegal(xOf(e), cards.length, w, cardW, legalIdx));
  };
  const move = (e)=>{
    if(!drag.current || !active) return;
    drag.current.moved = true;
    setF(nearestLegal(xOf(e), cards.length, w, cardW, legalIdx));
  };
  const end = (e)=>{
    if(!drag.current || !active){ drag.current = null; return; }
    const dy = yOf(e) - drag.current.y0;
    drag.current = null;
    if(dy < -FLICK_PX && focus != null){ const c = cards[focus]; setF(null); onPlay && onPlay(c); }
  };

  const lay = fanLayout(cards.length, w, cardW, active ? focus : null, 0.62*cardW, 0.34*cardH);

  return (
    <div ref={ref}
      style={{ position:"relative", height:H, width:"100%", touchAction:"pan-y" }}
      onTouchStart={start} onTouchMove={move} onTouchEnd={end}
      onMouseDown={start} onMouseMove={(e)=>drag.current && move(e)} onMouseUp={end}
      onMouseLeave={()=>{ drag.current = null; }}>
      {lay.map(({i,x,y,z,focused})=>{
        const c = cards[i];
        const legal = !!(legalIds && legalIds.has(c.id));
        return (
          <div key={c.id} style={{
            position:"absolute", left:0, bottom:0,
            transform:`translate3d(${x}px, ${y}px, 0)`,
            transition:"transform 110ms cubic-bezier(.2,.8,.3,1)",
            zIndex:z, pointerEvents:"none",
            opacity:(active && legalIds && legalIds.size) ? (legal ? 1 : 0.34) : 1,
            filter:(active && legalIds && legalIds.size && !legal) ? "grayscale(0.85)" : "none",
          }}>
            <Card c={c} small={small} selected={focused} showVal={showVal}/>
          </div>
        );
      })}
    </div>
  );
}
export { FanHand, fanLayout, nearestLegal, FLICK_PX, CARD_W, CARD_H };
