import React from "react";
import { other } from "../engine/rules.js";
import { who } from "../state/personas.js";
import { displayRank } from "../state/constants.js";

/* =======================================================================
   THE TALK DOCK — permanently open, bottom of the table.

   Online, it is chat: it binds straight to the shell's Supabase Realtime channel via
   net.roomChat / net.sendRoomChat, which already existed and had simply never been surfaced on the
   game screen.

   Solo, there is nobody to talk to — so rather than leave a dead box taking up a fifth of a phone
   screen, the same dock runs the deal commentary: every trick, marriage and close, as it happens,
   in the same shape as the messages. The space is never wasted, the widget is never empty, and the
   two modes look like one thing because they ARE one thing: the talk at the table.
   ===================================================================== */

const SUIT = { S:"\u2660", H:"\u2665", D:"\u2666", C:"\u2663" };
const clock = (ts)=>{
  const d = new Date(ts || Date.now());
  return String(d.getHours()).padStart(2,"0") + ":" + String(d.getMinutes()).padStart(2,"0");
};

/* the solo feed: the deal's own log, flattened into one line per event */
function commentary(s, focus){
  const out = [];
  let n = 0;
  for(const e of (s.log || [])){
    if(e.k === "trick"){
      n++;
      out.push({ id:"t"+n, mine: e.winner===focus, sys:true,
                 text:`${who(s, e.lead)} led ${displayRank(e.led.rank)}${SUIT[e.led.suit]}, ${who(s, other(e.lead))} played ${displayRank(e.fol.rank)}${SUIT[e.fol.suit]} — ${who(s, e.winner)} takes it, ${e.pts}.` });
    } else if(e.k === "meld"){
      out.push({ id:"m"+out.length, mine: e.seat===focus, sys:true,
                 text:`${who(s, e.seat)} declared the ${e.value===40?"royal marriage":"marriage"} in ${SUIT[e.suit]} — ${e.value}.` });
    } else if(e.k === "close"){
      out.push({ id:"c"+out.length, mine: e.seat===focus, sys:true,
                 text:`${who(s, e.seat)} closed the stock.` });
    }
  }
  return out;
}

function TalkDock({ s, net, online, focus }){
  const [draft, setDraft] = React.useState("");
  const endRef = React.useRef(null);

  /* BOTH, always. The old version showed chat OR commentary, so the moment anyone said hello the deal
     stopped being reported — which is exactly backwards: the table talk is more useful when there is a
     table to talk about. Chat is appended after the play, because a message is a thing that just
     happened and the deal so far is context. */
  /* CHRONOLOGICAL, not concatenated. Appending all the chat after all the play looks fine until the
     next trick lands — and then the commentary for it appears ABOVE a message that was sent before it.
     There are no timestamps on the log, so we cannot sort. What we can do is watch both lists and append
     whatever is NEW, in the order we notice it. That reconstructs the true order of events for free.
     (This was also the "no log data in the chat" bug: the play WAS in there, sitting above the chat,
     scrolled out of a box two lines tall.) */
  const comm = commentary(s, focus);
  const chat = online ? (net.roomChat || []) : [];
  const [feed, setFeed] = React.useState([]);
  const seenC = React.useRef(0), seenM = React.useRef(0);

  React.useEffect(()=>{
    if(comm.length < seenC.current){                       // a new deal: the play resets, the chat does not
      seenC.current = 0;
      setFeed(f => f.filter(x => !x.sys));
      return;
    }
    const add = [];
    if(comm.length > seenC.current){ add.push(...comm.slice(seenC.current)); seenC.current = comm.length; }
    if(chat.length > seenM.current){
      add.push(...chat.slice(seenM.current).map(m =>
        ({ id:"c"+m.id, mine:!!m.me, from:m.from, ts:m.ts, text:m.text })));
      seenM.current = chat.length;
    }
    if(add.length) setFeed(f => f.concat(add));
  }, [comm.length, chat.length]);

  const msgs = feed;


  /* stick to the bottom as it grows — but only if the reader is already at the bottom, or we would
     yank the view out from under someone who scrolled up to re-read something */
  React.useEffect(()=>{
    const el = endRef.current;
    if(!el) return;
    const box = el.parentNode;
    const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
    if(atBottom && el.scrollIntoView) el.scrollIntoView({ block:"end" });   // jsdom has no scrollIntoView
  }, [msgs.length]);

  const send = ()=>{
    const t = draft.trim();
    if(!t || !online) return;
    net.sendRoomChat(t);
    setDraft("");
  };

  return (
    <div className="sc-talk">
      <div className="sc-talk-h">
        <span>{online ? "Table talk" : "The deal so far"}</span>
        {online && net.room && <em>room {net.room}</em>}
      </div>

      <div className="sc-talk-msgs">
        {!msgs.length && (
          <div className="sc-talk-empty">
            {online ? "Say something to your opponent." : "Play a card and the table will start talking."}
          </div>
        )}
        {msgs.map(m => (
          <div key={m.id} className={"sc-msg" + (m.sys ? " sys" : m.mine ? " me" : " them")}>
            {!m.sys && <span className="sc-msg-w">{m.mine ? "you" : (m.from || "opp")}</span>}
            <span className="sc-msg-t">{m.text}</span>
            {!m.sys && <span className="sc-msg-c">{clock(m.ts)}</span>}
          </div>
        ))}
        <div ref={endRef}/>
      </div>

      {online ? (
        <div className="sc-talk-in">
          <input
            value={draft}
            maxLength={140}
            placeholder="Type a message…"
            onChange={(e)=>setDraft(e.target.value)}
            onKeyDown={(e)=>{ if(e.key==="Enter"){ e.preventDefault(); send(); } }}
          />
          <button className="btn ghost" onClick={send} disabled={!draft.trim()}>Send</button>
        </div>
      ) : (
        <div className="sc-talk-in solo">
          <span className="hint">Chat opens when you play someone online.</span>
        </div>
      )}
    </div>
  );
}

export { TalkDock };
