import React from "react";
import { SUIT_GLYPH } from "../state/constants.js";
import { ENG } from "../engine/core.js";

/* The same deck bridge draws — pips and indices, no images, four-colour. Schnapsen only uses five ranks,
   so the ten is the only card that needs a pip pattern at all.

   Every card ALSO carries a plaintext token — the suit glyph then the rank, ♠A, ♥T — which the pip themes
   hide and the TEXT theme shows instead of the card face. One card component, two ways of being looked at.
   The ten becomes a T so that every card in the deck is exactly two characters wide, which is the whole
   point of setting a card game in a monospace font: the hand lines up. */
const PIPS = { "10":[[34,26],[66,26],[50,34],[34,42],[66,42],[34,58],[66,58],[50,66],[34,74],[66,74]] };
const suitClass = (su)=> su==="S"?"s-sp":su==="H"?"s-he":su==="D"?"s-di":"s-cl";
const TXT_RANK = { "10":"T" };                       // A K Q J stay themselves; the ten needs one column
const Plain = ({c})=>(
  <span className="bc-t" aria-hidden="true"><span className="bc-g">{SUIT_GLYPH[c.suit]}</span>{TXT_RANK[c.rank] || c.rank}</span>
);
const Corner = ({rank, glyph, pos})=>(
  <div className={"idx "+pos}><span className="ir">{rank}</span>{glyph!=null && <span className="is">{glyph}</span>}</div>
);

function Card({c, faceDown, onClick, disabled, selected, small, showVal}){
  if(faceDown || !c || c.back) return <div onClick={onClick} className={"brback"+(small?" sm":"")} style={{cursor:onClick?"pointer":"default"}}/>;
  const g = SUIT_GLYPH[c.suit];
  const cls = ["brcard", suitClass(c.suit), small?"sm":"", selected?"sel":"",
               (onClick&&!disabled)?"clk":"", disabled?"dis":""].filter(Boolean).join(" ");
  const idxGlyph = (c.rank==="10") ? null : g;
  let center;
  if(c.rank==="A") center = <div className="ctr"><span className="pip ace" style={{left:"50%",top:"50%"}}>{g}</span></div>;
  else if(c.rank==="10") center = <div className="ctr">{PIPS["10"].map(([x,y],i)=>(
    <span key={i} className={"pip"+(y>50?" flip":"")} style={{left:x+"%",top:y+"%"}}>{g}</span>))}</div>;
  else center = <div className="mid fc">{c.rank}</div>;
  return (
    <div onClick={disabled?undefined:onClick} className={cls}>
      {/* the inlay: equidistant from the card edge on all four sides. The corner indices had to shrink
          to make room — a uniformly-inset rectangle CANNOT clear an index that is 11px wide on a 42px
          card without collapsing to 12px across. Geometry, not taste. */}
      <div className="inlay" aria-hidden="true"/>
      <Corner rank={c.rank} glyph={idxGlyph} pos="tl"/>
      <Corner rank={c.rank} glyph={idxGlyph} pos="br"/>
      {center}
      <Plain c={c}/>
      {showVal && <span className="val num">{ENG.CARDVAL[c.rank]}</span>}
    </div>
  );
}
export { Card, PIPS, suitClass, TXT_RANK };
