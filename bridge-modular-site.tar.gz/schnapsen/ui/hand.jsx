import React from "react";
import { sortHandDisplay } from "../state/constants.js";
import { Card } from "./cards.jsx";

/* THE HAND. Five cards, not thirteen — and that changes everything.
 *
 * Bridge needed the scrub-and-flick gesture because thirteen cards cannot all be tap targets on a phone.
 * They have to overlap, so you need some way to address a card you can only half see, and the fan was the
 * answer: slide a thumb, the card under it lifts, flick up to play. Schnapsen deals five. Five cards fit
 * side by side with room to spare, every one of them is its own tap target, and the gesture is now solving
 * a problem that no longer exists. So it goes.
 *
 * What replaces it is a row that CENTRES rather than justifies, which matters more than it sounds like it
 * should. A justified row pins the outermost cards to the edges, so as the hand dwindles — five, four,
 * three, two — the cards drift APART, and the emptier your hand gets the wider it sprawls. Backwards. A
 * centred row with a fixed gap does the opposite: the hand contracts toward the middle of the table as it
 * empties. A hand of two should look like a hand of two, not like two cards that have had an argument.
 *
 * What survives from the fan, because it was never about the gesture:
 *   - illegal cards are DIMMED, never removed. You can always see your whole hand.
 *   - the hand's band is a fixed height, so nothing below it ever jumps.
 *
 * Tap to select; tap the selected card again to play it. (The Play button in the foot does the same thing,
 * for anyone who wants the confirmation.)
 */
function Hand({ hand, trump, legalIds, selId, onPick, active, small=false, showVal }){
  const cards = React.useMemo(()=> sortHandDisplay(hand||[], trump), [hand, trump]);
  const gating = !!(active && legalIds && legalIds.size);

  return (
    <div className="sc-fan">
      {cards.map(c=>{
        const legal    = !!(legalIds && legalIds.has(c.id));
        const playable = !!(active && legal);
        const sel      = selId === c.id;
        return (
          <Card key={c.id} c={c} small={small} showVal
            selected={sel}
            disabled={gating && !legal}
            onClick={playable ? ()=>onPick(c) : undefined}/>
        );
      })}
    </div>
  );
}
export { Hand };
