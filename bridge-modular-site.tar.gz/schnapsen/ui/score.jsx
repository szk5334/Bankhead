import React from "react";
import { gradeDecision } from "../engine/grade.js";
import { jget, jset } from "./storage.js";

/* =======================================================================
   PLAY POINTS — what your card play was worth, not what the scoreboard says.

   You can win a deal with three blunders and lose one having played perfectly. Game points measure
   the cards you were dealt at least as much as the way you played them. This measures only the second
   thing: at every decision, what did your move cost against the best move available?

   Graded AFTER the deal, never during it — one decision costs about nine hundred rollouts to price,
   and a teacher who makes you wait is a teacher you stop using.

   The scoring is deliberately lopsided, and this is a judgement, not an oversight:

     • A clean move pays MORE when the decision MATTERED. Following suit with your only legal card is
       worth nearly nothing; finding the one card that saves a hopeless deal is worth fifty. `stakes`
       is the spread between the best move and the worst, i.e. how much was riding on it.
     • A bad move only costs you when the grader is SURE. If the loss is inside its own confidence
       interval, you are charged nothing and told nothing. We would rather miss a real mistake than
       invent one — a teacher who falsely accuses is worse than one who stays quiet.
   ===================================================================== */

const KEY = "sc.playpoints.v1";
const loadCareer = ()=> jget(KEY, { total:0, deals:0, best:0, tags:{} });
const saveCareer = (v)=> jset(KEY, v);

const LESSON = {
  ACE_INTO_RUFF:  ["Cashed into a ruff", "You led an ace he could trump. Aces are only winners while he has no trumps left — count them before you cash."],
  MISSED_CLOSE:   ["Should have closed", "Closing beat playing on here. The question is never 'is closing safe' — it is 'is closing better than the alternative'."],
  BAD_CLOSE:      ["Closed too soon", "Playing on was worth more than closing. A close you make for 1 is worse than a deal you win for 2."],
  SAT_ON_A_MARRIAGE: ["Sat on a marriage", "Show it. A marriage you are still holding at the end of the deal is worth exactly nothing."],
  BROKE_A_MARRIAGE:["Broke up a marriage", "You led half of a marriage you had not declared. That is twenty points you set fire to."],
  LED_TRUMP_EARLY:["Led a trump too early", "He does not have to follow suit while the stock is open — so he just keeps his trumps and you have spent yours."],
  DUCKED_A_WINNER:["Ducked a trick worth taking", "You could have won that and banked the points. Ducking is for tricks that cost you more than they pay."],
  BURIED_AN_HONOUR:["Buried an honour", "You threw an ace or a ten under a trick you were losing. Give him jacks, not elevens."],
  DUMPED_THE_GUARD:["Threw the ten's guard", "That small card was protecting your ten. Now the ten falls to his ace the moment you must follow suit."],
  TOOK_A_TRICK_YOU_SHOULD_DUCK:["Took a trick you should have ducked", "Winning it cost you more than it paid — it burned a card you needed later."],
  WRONG_LEAD:     ["Better lead available", "Another card was worth more from this position."],
  GENERIC:        ["Better move available", "Another move was worth more from this position."],
};

/* grade a whole deal's worth of captured human decisions */
function gradeMoves(moves, rnd){
  const rows = [];
  for(const m of moves){
    const g = gradeDecision(m.snap, m.seat, m.action, rnd, { worlds: 8 });
    if(!g) continue;                                  // no real choice existed — not a decision
    rows.push(g);
  }
  return rows;
}

function ScoreCard({ moves, dealKey }){
  const [state, setState] = React.useState({ status:"idle", rows:[], gained:0 });
  const [career, setCareer] = React.useState(loadCareer);
  const doneRef = React.useRef(null);

  React.useEffect(()=>{
    if(!moves || !moves.length) return;
    if(doneRef.current === dealKey) return;           // grade each deal exactly once
    doneRef.current = dealKey;
    setState({ status:"grading", rows:[], gained:0 });

    /* yield a frame first so "Grading…" actually paints before we block the thread */
    const t = setTimeout(()=>{
      let seed = 0x9e3779b9 ^ (dealKey|0);
      const rnd = ()=>{ seed|=0; seed=seed+0x6D2B79F5|0; let x=Math.imul(seed^seed>>>15,1|seed);
                        x=x+Math.imul(x^x>>>7,61|x)^x; return ((x^x>>>14)>>>0)/4294967296; };
      const rows = gradeMoves(moves, rnd);
      const gained = rows.reduce((a,r)=>a+r.pts, 0);

      const nc = { ...career, tags: {...career.tags} };
      nc.total += gained; nc.deals += 1;
      nc.best = Math.max(nc.best, gained);
      for(const r of rows) if(r.tag!=="OK") nc.tags[r.tag] = (nc.tags[r.tag]||0)+1;
      saveCareer(nc); setCareer(nc);
      setState({ status:"done", rows, gained });
    }, 30);
    return ()=>clearTimeout(t);
  }, [dealKey, moves]);

  if(!moves || !moves.length) return null;
  if(state.status !== "done")
    return <div className="pp"><div className="pp-h">Play points</div><div className="pp-wait">Grading your play…</div></div>;

  const { rows, gained } = state;
  const clean = rows.filter(r=>r.tag==="OK").length;
  const worst = rows.filter(r=>r.tag!=="OK").sort((a,b)=>b.evLoss-a.evLoss)[0];
  const leak = Object.entries(career.tags).sort((a,b)=>b[1]-a[1])[0];

  return (
    <div className="pp">
      <div className="pp-h">
        <span>Play points</span>
        <b className={"num pp-tot " + (gained>=0?"good":"bad")} key={gained}>
          {gained>=0?"+":""}{gained}
        </b>
      </div>

      <div className="pp-bar">
        {rows.map((r,i)=>(
          <span key={i}
                className={"pp-pip " + (r.tag==="OK" ? (r.pts>=30?"gr":"ok") : "bd")}
                title={`${r.tag} · ${r.pts>=0?"+":""}${r.pts}`}/>
        ))}
      </div>

      <div className="pp-sub">
        {clean} of {rows.length} decisions clean
        {rows.length>clean && <> · {rows.length-clean} cost you</>}
      </div>

      {worst && (
        <div className="pp-lesson">
          <b>{LESSON[worst.tag] ? LESSON[worst.tag][0] : worst.tag}</b>
          <span>{LESSON[worst.tag] ? LESSON[worst.tag][1] : ""}</span>
          <em>−{worst.evLoss.toFixed(2)} game points</em>
        </div>
      )}

      <div className="pp-career">
        <span>Career <b className="num">{career.total>=0?"+":""}{career.total}</b> over {career.deals} deal{career.deals===1?"":"s"}</span>
        {leak && <span>Your habit: <b>{LESSON[leak[0]] ? LESSON[leak[0]][0].toLowerCase() : leak[0]}</b> ×{leak[1]}</span>}
      </div>
    </div>
  );
}

export { ScoreCard, loadCareer };
