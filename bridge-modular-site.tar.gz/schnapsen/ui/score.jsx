import React from "react";
import { gradeDecision } from "../engine/grade.js";
import { SUIT_GLYPH, suitColorClass } from "../state/constants.js";
import { jget, jset } from "./storage.js";

/* =======================================================================
   THE COACH. One grader, four faces:

     useDealGrades  — grades your decisions ONE AT A TIME, on a timer, so the thread is never held for
                      more than a single decision (~200ms). Live when the coach is on; and at the end of
                      the deal it finishes whatever is left regardless, because the feedback on the
                      result screen is not optional — only the LIVE feedback is.
     PlayPointsHUD  — the running play-points total on the table. Not the 66, not the 7: what your CARD
                      PLAY was worth. Glows green when you gain, shakes red when you drop one.
     CoachLog       — the same grades, as advice, in the log.
     ReplayDeck     — swipe back through every decision: what he led, what you played, what it cost,
                      what you should have played, and the running total at that point in the deal.
   ===================================================================== */

const KEY = "sc.playpoints.v2";
const loadCareer = ()=>{
  const v = jget(KEY, null);
  return (v && typeof v==="object" && typeof v.total==="number")
    ? v : { total:0, deals:0, best:0, tags:{} };     // an older or broken shape is discarded, not patched
};
const saveCareer = (v)=> jset(KEY, v);

const LESSON = {
  ACE_INTO_RUFF:  ["Cashed into a ruff", "You led an ace he could trump. An ace is a winner only while he has no trumps left."],
  MISSED_CLOSE:   ["Should have closed", "Closing beat playing on. The question is never 'is closing safe' — it is 'is closing better than the alternative'."],
  BAD_CLOSE:      ["Closed too soon", "Playing on was worth more. A close you scrape for 1 is worse than a deal you win for 2."],
  SAT_ON_A_MARRIAGE: ["Sat on a marriage", "Show it. A marriage still in your hand at the end of the deal is worth nothing at all."],
  BROKE_A_MARRIAGE:["Broke up a marriage", "You led half of a marriage you had not declared — twenty points set on fire."],
  LED_TRUMP_EARLY:["Led a trump too early", "He needn't follow suit while the stock is open. He keeps his trumps; you have spent yours."],
  DUCKED_A_WINNER:["Ducked a trick worth taking", "You could have won that and banked it. Duck the tricks that cost more than they pay — not this one."],
  BURIED_AN_HONOUR:["Buried an honour", "You threw an ace or a ten under a trick you were losing. Give him jacks, not elevens."],
  DUMPED_THE_GUARD:["Threw the ten's guard", "That small card was protecting your ten. Now the ten falls to his ace the moment you must follow suit."],
  TOOK_A_TRICK_YOU_SHOULD_DUCK:["Took a trick you should have ducked", "Winning it cost more than it paid — it burned a card you needed later."],
  WRONG_LEAD:     ["Better lead available", "Another card was worth more from here."],
  GENERIC:        ["Better move available", "Another move was worth more from here."],
  OK:             ["Clean", ""],
};
const title  = (t)=> (LESSON[t] || [t,""])[0];
const advice = (t)=> (LESSON[t] || [t,""])[1];

const Gl = ({su})=> <span className={suitColorClass(su)}>{SUIT_GLYPH[su]}</span>;
const CardTxt = ({c})=> c ? <b>{c.rank}<Gl su={c.suit}/></b> : null;

function actionText(m){
  const a = m.action;
  if(a.type==="CLOSE")    return <span>closed the stock</span>;
  if(a.type==="EXCHANGE") return <span>exchanged the trump jack</span>;
  if(a.type==="MELD")     return <span>declared <Gl su={a.suit}/></span>;
  const c = (m.snap.hands[m.seat]||[]).find(x=>x.id===a.cardId);
  return c ? <span>played <CardTxt c={c}/></span> : <span>played</span>;
}
function bestText(g, m){
  if(!g || !g.best) return null;
  const a = g.best;
  if(a.type==="CLOSE")    return <span>close the stock</span>;
  if(a.type==="MELD")     return <span>declare <Gl su={a.suit}/></span>;
  if(a.type==="EXCHANGE") return <span>exchange the trump jack</span>;
  const c = (m.snap.hands[m.seat]||[]).find(x=>x.id===a.cardId);
  return c ? <CardTxt c={c}/> : null;
}

/* ---- grade the deal, one decision per tick ---- */
function useDealGrades(moves, live, finish){
  const [grades, setGrades] = React.useState([]);

  React.useEffect(()=>{ if(!moves.length) setGrades(cur => cur.length ? [] : cur); }, [moves.length]);

  React.useEffect(()=>{
    const want = (live || finish) ? moves.length : 0;
    if(grades.length >= want) return;
    const i = grades.length;
    const m = moves[i];
    if(!m) return;
    /* one decision per tick. Grading costs about 200ms; doing a whole deal in one go would freeze the
       table for two seconds, and a coach who makes you wait is a coach you switch off. */
    const t = setTimeout(()=>{
      let seed = (0x9e3779b9 ^ (i*2654435761)) >>> 0;
      const rnd = ()=>{ seed|=0; seed=seed+0x6D2B79F5|0; let x=Math.imul(seed^seed>>>15,1|seed);
                        x=x+Math.imul(x^x>>>7,61|x)^x; return ((x^x>>>14)>>>0)/4294967296; };
      let g = null;
      try { g = gradeDecision(m.snap, m.seat, m.action, rnd, { worlds: 8 }); } catch(_){ g = null; }
      setGrades(cur => cur.length===i
        ? cur.concat([ g || { pts:0, tag:"OK", evLoss:0, stakes:0, forced:true } ])
        : cur);
    }, 30);
    return ()=>clearTimeout(t);
  }, [moves.length, grades.length, live, finish]);

  return grades;
}
const runTot = (grades, upto)=> grades.slice(0, upto+1).reduce((a,g)=>a+(g?g.pts:0), 0);

/* ---- the HUD ---- */
function PlayPointsHUD({ grades, moves, on }){
  const total = grades.reduce((a,g)=>a+(g?g.pts:0), 0);
  const [flash, setFlash] = React.useState(null);
  const seen = React.useRef(0);

  React.useEffect(()=>{
    if(grades.length <= seen.current){ seen.current = grades.length; return; }
    seen.current = grades.length;
    const last = grades[grades.length-1];
    if(!last || last.forced) return;
    setFlash(last.pts >= 0 ? "good" : "bad");
    const t = setTimeout(()=>setFlash(null), 950);
    return ()=>clearTimeout(t);
  }, [grades.length]);

  if(!on) return null;
  const last = grades[grades.length-1];
  const pending = moves.length > grades.length;

  return (
    <div className={"ppx" + (flash ? " ppx-"+flash : "")}>
      <span className="ppx-l">Play points</span>
      <b className={"num ppx-n " + (total>=0?"good":"bad")}>{total>=0?"+":""}{total}</b>
      {flash && last && (
        <span className={"ppx-d "+flash} key={grades.length}>
          {last.pts>=0?"+":""}{last.pts}{last.tag!=="OK" && <em>{title(last.tag)}</em>}
        </span>
      )}
      {pending && !flash && <span className="ppx-w">grading…</span>}
    </div>
  );
}

/* ---- the coach, in the log ---- */
function CoachLog({ moves, grades, on }){
  if(!on || !moves.length) return null;
  return (
    <div className="cl">
      <div className="cl-h"><span>Coach</span><span className="cl-tot num">{runTot(grades, grades.length-1)>=0?"+":""}{runTot(grades, grades.length-1)}</span></div>
      {moves.map((m,i)=>{
        const g = grades[i];
        if(!g) return (
          <div key={i} className="cl-row wait">
            <span className="cl-n num">{i+1}</span>
            <span className="cl-b">You {actionText(m)} — <em>grading…</em></span>
          </div>);
        const bad = g.tag !== "OK";
        return (
          <div key={i} className={"cl-row " + (bad?"bad":"ok")}>
            <span className="cl-n num">{i+1}</span>
            <span className="cl-b">
              You {actionText(m)}
              {bad
                ? <> — <b>{title(g.tag)}</b>. {advice(g.tag)}{bestText(g,m) && <> Better: {bestText(g,m)}.</>}</>
                : <> — clean.</>}
            </span>
            <span className={"cl-p num " + (g.pts>=0?"good":"bad")}>{g.pts>=0?"+":""}{g.pts}</span>
            <span className="cl-t num">{runTot(grades,i)>=0?"+":""}{runTot(grades,i)}</span>
          </div>
        );
      })}
    </div>
  );
}

/* ---- the replay ---- */
function ReplayDeck({ moves, grades }){
  const [idx, setIdx] = React.useState(0);
  const boxRef = React.useRef(null);
  if(!moves.length) return null;

  const onScroll = ()=>{
    const el = boxRef.current; if(!el) return;
    const w = el.clientWidth || 1;
    setIdx(Math.max(0, Math.min(moves.length-1, Math.round(el.scrollLeft / w))));
  };

  return (
    <div className="rp">
      <div className="rp-h">
        <span>Your decisions — swipe</span>
        <span className="rp-i num">{Math.min(idx+1, moves.length)}/{moves.length}</span>
      </div>
      <div className="rp-strip" ref={boxRef} onScroll={onScroll}>
        {moves.map((m,i)=>{
          const g = grades[i];
          const led = (m.snap.trick && m.snap.trick.length) ? m.snap.trick[0].card : null;
          const bad = g && g.tag!=="OK";
          return (
            <div key={i} className={"rp-c " + (!g ? "wait" : bad ? "bad" : "ok")}>
              <div className="rp-top">
                <span className="rp-n num">#{i+1}</span>
                <span className={"rp-p num " + (g && g.pts<0 ? "bad":"good")}>
                  {g ? (g.pts>=0?"+":"")+g.pts : "…"}
                </span>
              </div>
              <div className="rp-cards">
                {led ? <>He led <CardTxt c={led}/> · </> : <>You were on lead · </>}
                you {actionText(m)}
              </div>
              {!g ? <div className="rp-v">grading…</div> : (
                <>
                  <div className="rp-v"><b>{title(g.tag)}</b></div>
                  {bad && <div className="rp-a">{advice(g.tag)}</div>}
                  {bad && bestText(g,m) && (
                    <div className="rp-a">Better: {bestText(g,m)} <em>(−{g.evLoss.toFixed(2)} gp)</em></div>
                  )}
                </>
              )}
              <div className="rp-run">
                running <b className={"num " + (runTot(grades,i)>=0?"good":"bad")}>
                  {runTot(grades,i)>=0?"+":""}{runTot(grades,i)}
                </b>
              </div>
            </div>
          );
        })}
      </div>
      <div className="rp-dots">{moves.map((_,i)=><span key={i} className={"rp-dot"+(i===idx?" on":"")}/>)}</div>
    </div>
  );
}

/* ---- result-screen summary. Always shown, coach toggle or not. ---- */
function ScoreCard({ moves, grades, dealKey }){
  const [career, setCareer] = React.useState(loadCareer);
  const banked = React.useRef(null);
  const done = moves.length > 0 && grades.length === moves.length;

  React.useEffect(()=>{
    if(!done || banked.current === dealKey) return;        // bank each deal exactly once
    banked.current = dealKey;
    const gained = grades.reduce((a,g)=>a+g.pts, 0);
    const nc = { ...career, tags: { ...career.tags } };
    nc.total += gained; nc.deals += 1; nc.best = Math.max(nc.best, gained);
    for(const g of grades) if(g.tag!=="OK") nc.tags[g.tag] = (nc.tags[g.tag]||0)+1;
    saveCareer(nc); setCareer(nc);
  }, [done, dealKey]);

  if(!moves.length) return null;
  const gained = grades.reduce((a,g)=>a+(g?g.pts:0), 0);
  const clean  = grades.filter(g=>g && g.tag==="OK").length;
  const leak   = Object.entries(career.tags).sort((a,b)=>b[1]-a[1])[0];

  return (
    <div className="pp">
      <div className="pp-h">
        <span>Play points</span>
        <b className={"num pp-tot " + (gained>=0?"good":"bad")} key={gained}>{gained>=0?"+":""}{gained}</b>
      </div>
      <div className="pp-bar">
        {moves.map((_,i)=>{
          const g = grades[i];
          return <span key={i} className={"pp-pip " + (!g ? "" : g.tag==="OK" ? (g.pts>=30?"gr":"ok") : "bd")}/>;
        })}
      </div>
      <div className="pp-sub">
        {done ? <>{clean} of {grades.length} decisions clean</> : <>grading {grades.length}/{moves.length}…</>}
      </div>

      <ReplayDeck moves={moves} grades={grades}/>

      <div className="pp-career">
        <span>Career <b className="num">{career.total>=0?"+":""}{career.total}</b> over {career.deals} deal{career.deals===1?"":"s"}</span>
        {leak && <span>Habit: <b>{title(leak[0]).toLowerCase()}</b> ×{leak[1]}</span>}
      </div>
    </div>
  );
}

export { ScoreCard, PlayPointsHUD, CoachLog, ReplayDeck, useDealGrades, loadCareer };
