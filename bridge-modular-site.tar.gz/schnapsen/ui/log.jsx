import React from "react";
import { ENG } from "../engine/core.js";
import { RULES, effPts, stockLeft, other } from "../engine/rules.js";
import { SUIT_GLYPH, suitColorClass, displayRank } from "../state/constants.js";
import { who } from "../state/personas.js";

const G = (su)=> <span className={suitColorClass(su)}>{SUIT_GLYPH[su]}</span>;
const CardTxt = ({c})=> c ? <b>{displayRank(c.rank)}{G(c.suit)}</b> : null;

/* =======================================================================
   THE LOG — the public record of the deal, and nothing more.

   Every line here is information you already had: what was played, who took it, who declared what, who
   took the turn-up. It tells you nothing an attentive opponent wouldn't have in their head. It does not
   advise you.

   The one genuinely secret thing — the opponent's running total — sits behind MEMORY MODE. Switch it on
   and you get your own count and a dash for theirs, and you are on your own.
   ===================================================================== */
function Log({s, focus}){
  const me = effPts(s, focus), them = effPts(s, other(focus));
  const memory = !!s.memory;
  const rows = [];
  let trickNo = 0;
  /* THE RUNNING SCORE. The whole game is a race to 66 and the log never once told you where the race
     stood — you had to hold both totals in your head while reading a list of tricks. Melds only start
     counting once their owner has taken a trick, which is exactly the fiddly bit a human gets wrong, so
     the log now does that arithmetic in front of you rather than leaving it as an exercise. */
  const run = [0, 0];                       // trick points banked
  const meld = [0, 0];                      // declared, but only live once that player has a trick
  const won  = [false, false];
  const live = (i)=> run[i] + (won[i] ? meld[i] : 0);
  const scoreTag = ()=>(
    <span className="dl-run num">
      <b className={live(focus) >= 66 ? "out" : ""}>{live(focus)}</b>
      <i>–</i>
      <b className={live(other(focus)) >= 66 ? "out" : ""}>{live(other(focus))}</b>
    </span>
  );

  for(const e of (s.log||[])){
    const us = e.seat===focus || e.lead===focus;
    if(e.k==="trick"){
      trickNo++;
      run[e.winner] += e.pts;
      won[e.winner] = true;
      const winnerIsMe = e.winner===focus;
      rows.push(
        <div key={"t"+trickNo} className={"dl-ev "+(winnerIsMe?"us":"them")}>
          <span className="dl-n num">{trickNo}</span>
          <span className="dl-b">
            {who(s, e.lead)} led <CardTxt c={e.led}/>, {who(s, other(e.lead))} played <CardTxt c={e.fol}/> —{" "}
            <span className="w">{who(s, e.winner)} takes it, {e.pts}</span>
          </span>
          {scoreTag()}
        </div>);
    } else if(e.k==="meld"){
      meld[e.seat] += e.value;
      rows.push(
        <div key={"m"+rows.length} className={"dl-ev "+(e.seat===focus?"us":"them")}>
          <span className="dl-n">·</span>
          <span className="dl-b"><span className="tag meld">{e.value}</span>
            {who(s, e.seat)} declared the {e.value===40?"royal marriage":"marriage"} in {G(e.suit)}
            {!e.counts && <em style={{opacity:.7,fontStyle:"normal"}}> — not counting yet</em>}
          </span>
          {scoreTag()}
        </div>);
    } else if(e.k==="close"){
      rows.push(
        <div key={"c"+rows.length} className={"dl-ev "+(e.seat===focus?"us":"them")}>
          <span className="dl-n">·</span>
          <span className="dl-b"><span className="tag close">closed</span>
            {who(s, e.seat)} closed the stock, against {who(s, other(e.seat))}'s <b>{e.oppPts}</b> points and{" "}
            <b>{e.oppTricks}</b> {e.oppTricks===1?"trick":"tricks"} — the count at the moment it shut.
          </span>
        </div>);
    } else if(e.k==="exchange"){
      rows.push(
        <div key={"x"+rows.length} className={"dl-ev "+(e.seat===focus?"us":"them")}>
          <span className="dl-n">·</span>
          <span className="dl-b"><span className="tag swap">swap</span>
            {who(s, e.seat)} took the turn-up <CardTxt c={e.card}/> for the trump jack.
          </span>
        </div>);
    } else if(e.k==="tookup"){
      rows.push(
        <div key={"u"+rows.length} className={"dl-ev "+(e.seat===focus?"us":"them")}>
          <span className="dl-n">·</span>
          <span className="dl-b"><span className="tag up">turn-up</span>
            {who(s, e.seat)} drew the face-up <CardTxt c={e.card}/> as the last card of the stock.
          </span>
        </div>);
    }
  }

  return (
    <div className="talkwrap">
      <div className="dl-full">
        <div className="dl-count">
          <div className="dl-cbox">
            <div className="l">you</div>
            <div className="v num">{me}</div>
            <div className="s num">{me >= RULES.OUT ? "over 66 — the deal is yours" : `${RULES.OUT - me} to go`}</div>
          </div>
          <div className="dl-cbox them">
            <div className="l">them</div>
            <div className="v num">{memory ? "··" : them}</div>
            <div className="s num">{memory ? "count it yourself" : (them >= 33 ? "past 33 — only 1 game point now" : `${33 - them} to their 33`)}</div>
          </div>
        </div>

        <div className="dl-head">the deal</div>
        <div className="dl-ev">
          <span className="dl-n">·</span>
          <span className="dl-b">
            {G(s.trump)} is trumps. {who(s, other(s.dealer))} led first.
            {" "}{s.closed
              ? <>The stock is <b>closed</b>.</>
              : stockLeft(s) ? <>Stock: <b className="num">{stockLeft(s)}</b> left.</>
                             : <>The stock is <b>out</b>.</>}
          </span>
        </div>
        {rows.length ? rows : <div className="dl-empty">Nothing has happened yet.</div>}
      </div>
    </div>
  );
}
export { Log };
