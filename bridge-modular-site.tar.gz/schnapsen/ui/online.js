/* ---- multiplayer bindings. The shell (index.html) provides these globals; if it doesn't, every one of
   them is a no-op and the game runs solo exactly as before. Nothing here is Schnapsen-specific: this is
   the same contract bridge and BANKHEAD already bind to. ---- */
const INERT = { role:"off", seat:0, status:"", room:null, snap:null, snapV:0, roster:[],
  names:["",""], namesV:0, target:0, full:false, myInitials:"", playerCount:0, downSeats:[],
  isSeatDown:()=>false, prefillCode:"", savedSession:null, lobbyChat:[], roomChat:[], games:[], highScores:[],
  pub:null, pubV:0, requests:[], pendingRoom:null, started:false, availableSeats:()=>[],
  setInitials(){}, hostGame(){}, joinGame(){}, rejoin(){}, goSolo(){}, backToLobby(){}, closeRoom(){}, spectate(){},
  approveRequest(){}, denyRequest(){}, kickSeat(){}, cancelRequest(){},
  sendLobbyChat(){}, sendRoomChat(){}, send(){}, broadcastState(){} };

const useGameNet    = (typeof window!=="undefined" && (window.useGameNet || window.useBankheadNet)) || (()=>INERT);
const OnlineBar     = (typeof window!=="undefined" && (window.GameBar || window.OnlineBar)) || (()=>null);
const OnlineScreens = (typeof window!=="undefined" && (window.LobbyScreens || window.OnlineScreens)) || (()=>null);
const SpectatorView = (typeof window!=="undefined" && window.SpectatorView) || (()=>null);

export { useGameNet, OnlineBar, OnlineScreens, SpectatorView, INERT };
