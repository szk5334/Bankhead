/* =======================================================================
   PERSISTENCE — every call wrapped, because a sandboxed iframe with
   localStorage disabled must degrade to "no high scores", never to a crash.
   ===================================================================== */
const THEME_KEY  = "schnapsen.theme.v1";
const CAMP_KEY   = "schnapsen.campaign.v1";
const SET_KEY    = "schnapsen.settings.v1";
const HS_KEY     = "schnapsen.highscores.v1";
const INITIALS_KEY = "bh_initials";     // THE SAME KEY THE SHELL'S LOBBY USES — one identity, both doors.

function LS(){ try{ return window.localStorage; }catch(_){ return null; } }
function jget(k, dflt){ const s=LS(); if(!s) return dflt; try{ const v=JSON.parse(s.getItem(k)); return v==null?dflt:v; }catch(_){ return dflt; } }
function jset(k, v){ const s=LS(); if(s) try{ s.setItem(k, JSON.stringify(v)); }catch(_){} }
function sget(k, dflt){ const s=LS(); if(!s) return dflt; try{ const v=s.getItem(k); return v==null?dflt:v; }catch(_){ return dflt; } }
function sset(k, v){ const s=LS(); if(s) try{ s.setItem(k, v); }catch(_){} }
function jdel(k){ const s=LS(); if(s) try{ s.removeItem(k); }catch(_){} }

const loadTheme = ()=> sget(THEME_KEY, "casino");
const saveTheme = (t)=> sset(THEME_KEY, t);

/* THE INITIALS ARE THE IDENTITY. The lobby writes them to `bh_initials` when you join a room; the solo
 * setup screen writes the same key. So whichever door you came in by, your high scores land in one pile. */
const loadInitials = ()=> (sget(INITIALS_KEY, "") || "").toUpperCase().replace(/[^A-Z]/g,"").slice(0,3);
const saveInitials = (v)=> sset(INITIALS_KEY, (v||"").toUpperCase().replace(/[^A-Z]/g,"").slice(0,3));

const DEFAULT_SETTINGS = { strictClaim:false, memory:false };
const loadSettings = ()=> ({ ...DEFAULT_SETTINGS, ...jget(SET_KEY, {}) });
const saveSettings = (v)=> jset(SET_KEY, v);

const loadCampaign = ()=> jget(CAMP_KEY, null);
const saveCampaign = (c)=> c ? jset(CAMP_KEY, c) : jdel(CAMP_KEY);

/* ---------------- HIGH SCORES ----------------
 * One row per set of initials, accumulated across every Bummerl that device has seen — including the
 * opponent's, when you played online. Ranked by Bummerls won, then by the game-point difference, so a
 * player who wins narrowly and often outranks one who won once by 7–0 and never came back.
 */
function loadScores(){ const v = jget(HS_KEY, {}); return (v && typeof v==="object") ? v : {}; }
function saveScores(v){ jset(HS_KEY, v); }

function recordBummerl(entries){
  // entries: [{ ini, won, gpFor, gpAgainst, deals, dealsWon, schneider }]
  const t = loadScores();
  for(const e of entries){
    const ini = (e.ini||"").toUpperCase().replace(/[^A-Z]/g,"").slice(0,3);
    if(!ini) continue;                                   // no initials, no row — bots do not get a scoreboard
    const r = t[ini] || { ini, bummerls:0, lost:0, gpFor:0, gpAgainst:0, deals:0, dealsWon:0, schneiders:0, ts:0 };
    r.bummerls  += e.won ? 1 : 0;
    r.lost      += e.won ? 0 : 1;
    r.gpFor     += e.gpFor || 0;
    r.gpAgainst += e.gpAgainst || 0;
    r.deals     += e.deals || 0;
    r.dealsWon  += e.dealsWon || 0;
    r.schneiders+= (e.won && e.schneider) ? 1 : 0;       // 7–0: they never got off the mark
    r.ts = Date.now();
    t[ini] = r;
  }
  saveScores(t);
  return t;
}
function rankedScores(t){
  return Object.values(t || loadScores()).sort((a,b)=>
    (b.bummerls - a.bummerls) ||
    ((b.gpFor - b.gpAgainst) - (a.gpFor - a.gpAgainst)) ||
    (b.dealsWon - a.dealsWon) ||
    (a.ini < b.ini ? -1 : 1));
}
function clearScores(){ jdel(HS_KEY); }

export { jget, jset,
         THEME_KEY, CAMP_KEY, SET_KEY, HS_KEY, INITIALS_KEY, DEFAULT_SETTINGS,
         loadTheme, saveTheme, loadInitials, saveInitials, loadSettings, saveSettings,
         loadCampaign, saveCampaign, loadScores, saveScores, recordBummerl, rankedScores, clearScores };
