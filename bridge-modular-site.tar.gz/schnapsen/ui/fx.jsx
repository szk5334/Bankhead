import React from "react";
import { SUIT_GLYPH, suitColorClass } from "../state/constants.js";

/* =======================================================================
   FX — the glyphs.

   Select a card and its suit bursts out of it. Play it and a comet of the same glyphs runs from your
   hand to the middle of the table, arriving as the card lands.

   Three things this deliberately is NOT:

   • It is not canvas, and it is not a library. It is a fixed-position layer of about twenty spans that
     animate transform and opacity — the only two properties a phone can animate without touching
     layout. Nothing here can reflow the table, so nothing here can make the game janky.

   • It is not React state per frame. Particles are pushed into the layer once, the browser animates
     them, and they are swept when their animation is over. React is never in the loop.

   • It is not pointer-interactive. pointer-events:none, top to bottom. The prettiest effect in the world
     is not worth eating one tap on a card.

   It is also the FIRST thing to go under prefers-reduced-motion — a whole screen of flying glyphs is
   exactly what that setting exists to switch off.
   ===================================================================== */

/* the smallest possible bus: the FX layer subscribes, the table shouts. */
let listener = null;
let seq = 0;
const emit = (items)=>{ if(listener) listener(items); };

const centre = (el)=>{
  if(!el || !el.getBoundingClientRect) return null;
  const r = el.getBoundingClientRect();
  if(!r.width && !r.height) return null;
  return { x: r.left + r.width/2, y: r.top + r.height/2 };
};

/* a card was SELECTED — burst its suit out of it */
function fxBurst(el, suit){
  const c = centre(el);
  if(!c) return;
  const out = [];
  const n = 12;
  for(let i=0;i<n;i++){
    const a = (i / n) * Math.PI * 2 + Math.random()*0.5;
    const d = 26 + Math.random()*44;
    out.push({
      id: ++seq, kind:"burst", suit,
      x: c.x, y: c.y,
      tx: Math.cos(a)*d, ty: Math.sin(a)*d - 8,       // -8: drift up, so it reads as a spark not a spill
      rot: (Math.random()*140 - 70),
      sc: 0.5 + Math.random()*0.7,
      delay: Math.random()*70,
      life: 620,
    });
  }
  emit(out);
}

/* a card was PLAYED — run a comet of its suit from the hand to the trick */
function fxFly(el, suit){
  const from = centre(el);
  const to   = centre(document.querySelector(".br .sc-trick"));
  if(!from || !to) return;
  const dx = to.x - from.x, dy = to.y - from.y;
  const out = [];
  const n = 14;
  for(let i=0;i<n;i++){
    const j = i / (n-1);
    out.push({
      id: ++seq, kind:"fly", suit,
      x: from.x, y: from.y,
      dx: dx + (Math.random()*26 - 13),               // jitter, or fourteen glyphs travel as one glyph
      dy: dy + (Math.random()*26 - 13),
      rot: (Math.random()*220 - 110),
      sc: 1.05 - j*0.5,                               // the head of the comet is the biggest
      delay: j * 130,                                 // the stagger IS the trail
      life: 460,
    });
  }
  /* the caller needs to know WHEN the head of the comet gets there, so the card can appear on the beat
     instead of being already sitting in the trick while its own particles are still in flight. */
  /* and a small burst where it lands, so the comet arrives rather than just stopping */
  for(let i=0;i<6;i++){
    const a = (i/6)*Math.PI*2;
    out.push({
      id: ++seq, kind:"burst", suit,
      x: to.x, y: to.y,
      tx: Math.cos(a)*22, ty: Math.sin(a)*22,
      rot: 0, sc: 0.75, delay: 300 + Math.random()*40, life: 420,
    });
  }
  emit(out);
  return 170;                               // the middle of the trail reaches the table at ~170ms
}

function FxLayer(){
  const [items, setItems] = React.useState([]);
  const timers = React.useRef([]);

  React.useEffect(()=>{
    const reduced = typeof window!=="undefined" && window.matchMedia
      && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    listener = (batch)=>{
      if(reduced) return;                              // the setting means it: no glyphs at all
      setItems(cur => cur.concat(batch));
      const t = setTimeout(()=>{
        const ids = new Set(batch.map(b=>b.id));
        setItems(cur => cur.filter(p => !ids.has(p.id)));   // sweep: the layer never grows without bound
      }, Math.max.apply(null, batch.map(b=>b.delay + b.life)) + 60);
      timers.current.push(t);
    };
    return ()=>{
      listener = null;
      timers.current.forEach(clearTimeout);
      timers.current = [];
    };
  }, []);

  if(!items.length) return null;

  return (
    <div className="fx" aria-hidden="true">
      {items.map(p => (
        <span key={p.id}
              className={"fx-p fx-" + p.kind + " " + (p.suit ? suitColorClass(p.suit) : "fx-white")}
              style={{
                left: p.x + "px",
                top:  p.y + "px",
                "--tx": (p.tx||0) + "px", "--ty": (p.ty||0) + "px",
                "--dx": (p.dx||0) + "px", "--dy": (p.dy||0) + "px",
                "--rot": (p.rot||0) + "deg",
                "--sc": p.sc,
                animationDelay: p.delay + "ms",
                animationDuration: p.life + "ms",
              }}>
          {SUIT_GLYPH[p.suit]}
        </span>
      ))}
    </div>
  );
}

/* a directed JET from one element to another — used when you close the stock. White, because it is not
 * a suit doing it, it is you. Grey on the light themes, where white would be invisible. */
function fxStream(fromEl, toEl, n){
  const from = centre(fromEl), to = centre(toEl);
  if(!from || !to) return 0;
  const dx = to.x - from.x, dy = to.y - from.y;
  const out = [];
  const N = n || 22;
  for(let i=0;i<N;i++){
    const j = i / (N-1);
    out.push({
      id: ++seq, kind:"stream", suit:null,
      x: from.x, y: from.y,
      dx: dx + (Math.random()*18 - 9),
      dy: dy + (Math.random()*18 - 9),
      rot: 0, sc: 1.0 - j*0.35,
      delay: j * 200,
      life: 420,
    });
  }
  emit(out);
  return 200 + 210;                         // when the MIDDLE of the stream is arriving
}

export { FxLayer, fxBurst, fxFly, fxStream };
