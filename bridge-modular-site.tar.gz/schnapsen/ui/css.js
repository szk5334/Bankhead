/* The felt-and-brass card table. The variables, the card faces, the fixed app shell (status bar / screen /
   tab bar) and the overlays are all LIFTED UNCHANGED from bridge — same five themes, same
   four-colour deck, same buttons — so the two games feel like two rooms in one club rather than two apps.
   Only the table itself is new, because a two-hand trick-and-draw table looks nothing like a bridge diamond. */
const THEME_CSS = `
.br{
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  --k:1.15;
  --bg:#0f3b2b; --ink:#f2e8ce; --dim:#9a8f63; --line:rgba(212,175,55,.42); --line2:rgba(212,175,55,.20);
  --card:#f6efd9; --cardline:#cdc09a; --fill:#f2e8ce; --fillink:#0f3b2b;
  --purple:#e2c068; --pink:#ed7464; --cyan:#67cdbb; --green:#4fc47a;
  --yellow:#f0d27a; --orange:#e0a45a; --red:#ed7464; --comment:#9a8f63; --rule:#e2c068;
  --sp:#1c6fd4; --he:#b3232a; --di:#d6a51b; --cl:#1c7a3f;
  --selbg:#efe2bd; --playink:#0d3322;
  background:var(--bg); color:var(--ink);
}
.br[data-theme="blue"]{ --bg:#112c4f; --fillink:#112c4f; --playink:#0a1830; }
.br[data-theme="red"]{ --bg:#3c1418; --fillink:#3c1418; --playink:#220a0c; }
.br[data-theme="black"]{ --bg:#0d0d10; --fillink:#0d0d10; --playink:#060608; }
.br[data-theme="cream"]{
  --bg:#f3ead4; --ink:#2b2517; --dim:#857852; --line:rgba(150,116,30,.55); --line2:rgba(150,116,30,.26);
  --card:#fdf9f1; --cardline:#d8c8a0; --fill:#fdf9f1; --fillink:#2b2517;
  --purple:#a87e22; --pink:#bb3b2a; --cyan:#157a70; --green:#2e8b50;
  --yellow:#9c7d18; --orange:#b5611f; --red:#c0392b; --comment:#857852; --rule:#a87e22;
  --sp:#1c6fd4; --he:#b3232a; --di:#b8890f; --cl:#1c7a3f;
  --selbg:#f2e7c6; --playink:#f6efda;
}
.br *{font-family:var(--mono)!important;border-radius:0!important;box-shadow:none!important;text-shadow:none!important;-webkit-tap-highlight-color:transparent;box-sizing:border-box;}

/* ---- the deck (identical to bridge: four-colour, pip-drawn, no images) ---- */
.brcard{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;background:var(--card);border:1px solid var(--cardline);cursor:default;user-select:none;transition:transform .08s;}
.brcard.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}
.brcard.clk{cursor:pointer;} .brcard.dis{filter:brightness(.5) saturate(.8);}
.brcard.s-sp{color:var(--sp);} .brcard.s-he{color:var(--he);} .brcard.s-di{color:var(--di);} .brcard.s-cl{color:var(--cl);}
.brcard .idx,.brcard .ir,.brcard .is,.brcard .mid,.brcard .ctr,.brcard .pip{color:inherit;background:transparent;font-variant-emoji:text;-webkit-text-fill-color:currentColor;-webkit-backface-visibility:hidden;backface-visibility:hidden;}
.brcard .is,.brcard .pip{font-family:"DejaVu Sans","Noto Sans Symbols2","Noto Sans Symbols","Segoe UI Symbol","Apple Symbols","Arial Unicode MS",sans-serif!important;}
.brcard.sel{background:var(--selbg);border-color:var(--purple);transform:translateY(calc(-8px*var(--k)));}
.brcard .idx{position:absolute;display:flex;flex-direction:column;align-items:center;line-height:.9;font-weight:700;}
.brcard .idx.tl{top:calc(3px*var(--k));left:calc(4px*var(--k));} .brcard .idx.br{bottom:calc(3px*var(--k));right:calc(4px*var(--k));transform:rotate(180deg);}
.brcard .ir{font-size:calc(11px*var(--k));} .brcard .is{font-size:calc(8px*var(--k));margin-top:calc(1px*var(--k));}
.brcard.sm .ir{font-size:calc(8px*var(--k));} .brcard.sm .is{font-size:calc(6px*var(--k));}
.brcard .ctr{position:absolute;inset:0;}
.brcard .pip{position:absolute;font-size:calc(9.5px*var(--k));line-height:1;transform:translate(-50%,-50%);}
.brcard .pip.flip{transform:translate(-50%,-50%) rotate(180deg);}
.brcard .pip.ace{font-size:calc(27px*var(--k));}
.brcard.sm .pip.ace{font-size:calc(18px*var(--k));}
.brcard.sm .pip{font-size:calc(7px*var(--k));}
.brcard .mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:800;}
.brcard .mid.fc{font-size:calc(25px*var(--k));} .brcard.sm .mid.fc{font-size:calc(17px*var(--k));}
/* THE CARD'S POINT VALUE, in the corner where nothing else lives. Schnapsen is a counting game and this
   is the single most useful thing a beginner can be shown; an expert stops seeing it within a hand. */
.brcard .val{position:absolute;top:calc(3px*var(--k));right:calc(5px*var(--k));font-size:calc(8px*var(--k));font-weight:800;opacity:.34;}
.brcard.sm .val{font-size:calc(6.5px*var(--k));top:calc(2px*var(--k));right:calc(3px*var(--k));}
.brback{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;border:1px solid var(--line);background:repeating-linear-gradient(135deg,var(--bg) 0 4px,var(--line2) 4px 5px);}
.brback.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}

.br .num{font-variant-numeric:tabular-nums;}
.br .lbl2{font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:var(--dim);font-weight:700;}
.br .hint{font-size:11px;color:var(--dim);text-align:center;line-height:1.4;}
.br .hint b{color:var(--ink);}
.br .gsp{color:var(--sp);} .br .ghe{color:var(--he);} .br .gdi{color:var(--di);} .br .gcl{color:var(--cl);}
.br .btn{font:inherit;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;background:transparent;color:var(--ink);border:1px solid var(--ink);padding:6px 12px;cursor:pointer;}
.br .btn.primary{background:var(--green);color:var(--playink);border-color:var(--green);min-width:120px;text-align:center;}
.br .btn.ghost{border-color:var(--line);color:var(--dim);}
.br .btn.ghost.on{border-color:var(--purple);color:var(--purple);}
.br .btn.gold{background:var(--purple);color:var(--fillink);border-color:var(--purple);}
.br .btn:disabled{opacity:.3;cursor:default;color:var(--dim);border-color:var(--line);}
.br .toggle{display:flex;border:1px solid var(--line);}
.br .toggle button{font:inherit;font-size:8.5px;letter-spacing:.06em;text-transform:uppercase;background:transparent;color:var(--dim);border:0;padding:4px 6px;cursor:pointer;}
.br .toggle button.on{background:var(--purple);color:var(--fillink);}
.br .toggle button+button{border-left:1px solid var(--line);}
.br .app{width:100%;max-width:412px;margin:0 auto;display:flex;flex-direction:column;gap:9px;}
.br header{display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:6px;border-bottom:1px solid var(--rule);padding-bottom:6px;}
.br .wordmark{font-size:18px;font-weight:700;letter-spacing:.34em;padding-left:.34em;background:linear-gradient(92deg,var(--pink),var(--purple) 50%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}

/* ---- the fixed app shell: nothing at the top level scrolls ---- */
.br .stage{flex:1 1 auto;min-height:0;width:100%;max-width:640px;margin:0 auto;display:flex;flex-direction:column;overflow:hidden;}
.br .gstatus{flex:0 0 auto;display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid var(--rule);}
.br .gs-menu{font:inherit;font-size:19px;line-height:1;background:transparent;border:1px solid var(--line);color:var(--ink);padding:3px 9px;cursor:pointer;flex:0 0 auto;}
.br .gs-mid{flex:1 1 auto;min-width:0;text-align:center;}
.br .gs-title{font-size:12px;font-weight:800;letter-spacing:.04em;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-turn{font-size:9.5px;letter-spacing:.06em;color:var(--dim);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-score{flex:0 0 auto;display:flex;flex-direction:column;align-items:flex-end;gap:1px;font-size:9px;letter-spacing:.06em;color:var(--dim);line-height:1.25;}
.br .gs-score .gs-games{font-size:12px;font-weight:700;color:var(--yellow);}
.br .gscreen{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;overflow:hidden;}
.br .gtabs{flex:0 0 auto;display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--rule);padding-bottom:env(safe-area-inset-bottom,0);}
.br .gtab{position:relative;font:inherit;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;background:transparent;border:0;color:var(--dim);padding:15px 0;cursor:pointer;}
.br .gtab+.gtab{border-left:1px solid var(--line2);}
.br .gtab.on{color:var(--ink);background:var(--line2);box-shadow:inset 0 2px 0 var(--purple)!important;}
.br .gt-dot{position:absolute;top:11px;margin-left:5px;width:7px;height:7px;border-radius:50%!important;background:var(--green);display:inline-block;}

/* =========================================================================
   THE SCHNAPSEN TABLE. Five bands, all fixed height except the middle one,
   so nothing ever jumps: THEM · the stock and the trick · YOU · the buttons
   you may legally press · your hand.
   ========================================================================= */
.br .sctable{display:flex;flex-direction:column;height:100%;min-height:0;gap:5px;padding:7px 8px;position:relative;}

.br .sc-opp{flex:0 0 auto;display:flex;align-items:center;gap:8px;border:1px solid var(--line2);padding:5px 7px;}
.br .sc-opp .sc-av{font-size:14px;color:var(--accent,var(--purple));}
.br .sc-opp .sc-nm{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;white-space:nowrap;}
.br .sc-opp.act{border-color:var(--line);background:var(--line2);}
.br .sc-backs{flex:1 1 auto;display:flex;justify-content:center;gap:2px;min-width:0;}
.br .sc-backs .brback{width:calc(20px*var(--k));height:calc(28px*var(--k));}
.br .sc-pts{flex:0 0 auto;text-align:right;line-height:1.2;}
.br .sc-pts .p{font-size:15px;font-weight:800;color:var(--yellow);}
.br .sc-pts .t{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-pts .p.hid{color:var(--dim);font-size:12px;}

/* --- the middle: stock on the left, the trick in the centre, nothing on the right --- */
.br .sc-mid{flex:1 1 auto;min-height:0;display:grid;grid-template-columns:auto 1fr;gap:8px;align-items:center;
  border:1px solid var(--line);padding:8px;}
.br .sc-stock{display:flex;flex-direction:column;align-items:center;gap:4px;min-width:64px;}
.br .sc-deck{position:relative;height:calc(46px*var(--k));width:calc(56px*var(--k));}
.br .sc-deck .brback{position:absolute;left:0;top:0;width:calc(30px*var(--k));height:calc(42px*var(--k));}
.br .sc-deck .brback.d2{left:2px;top:2px;} .br .sc-deck .brback.d3{left:4px;top:4px;}
/* the turn-up sits crosswise UNDER the stock, exactly as it does on a real table */
.br .sc-deck .sc-up{position:absolute;left:calc(16px*var(--k));top:calc(9px*var(--k));transform:rotate(90deg);transform-origin:center;}
.br .sc-deck.closed .sc-up{filter:brightness(.55);}
.br .sc-stock-l{font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);text-align:center;line-height:1.35;}
.br .sc-stock-l b{color:var(--ink);}
.br .sc-shut{font-size:8px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--pink);border:1px solid var(--pink);padding:1px 5px;}
.br .sc-strict{font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--orange);}

.br .sc-trick{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-width:0;}
.br .sc-slots{display:flex;gap:10px;align-items:center;justify-content:center;}
.br .sc-slot{display:flex;flex-direction:column;align-items:center;gap:3px;}
.br .sc-slot .sc-who{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-slot.win .sc-who{color:var(--green);font-weight:800;}
.br .sc-slot.win .brcard{box-shadow:0 0 0 2px var(--green)!important;}
.br .sc-hole{width:calc(30px*var(--k));height:calc(42px*var(--k));border:1px dashed var(--line2);display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:9px;}
.br .sc-tmsg{font-size:9.5px;color:var(--dim);text-align:center;letter-spacing:.03em;min-height:13px;}
.br .sc-tmsg b{color:var(--ink);}

.br .sc-you{flex:0 0 auto;display:flex;align-items:center;gap:8px;border:1px solid var(--line2);padding:5px 7px;}
.br .sc-you.act{border-color:var(--green);}
.br .sc-you .sc-nm{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--ink);}
.br .sc-bar{flex:1 1 auto;height:7px;border:1px solid var(--line2);position:relative;overflow:hidden;min-width:40px;}
.br .sc-bar i{position:absolute;left:0;top:0;bottom:0;background:var(--green);display:block;}
.br .sc-bar.them i{background:var(--pink);}
.br .sc-bar .m66{position:absolute;top:-2px;bottom:-2px;width:1px;background:var(--yellow);left:55%;}

/* --- the actions you may legally take, and only those --- */
.br .sc-acts{flex:0 0 auto;display:flex;gap:5px;flex-wrap:wrap;justify-content:center;min-height:30px;align-items:center;}
.br .sc-act{font:inherit;font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;
  background:transparent;color:var(--purple);border:1px solid var(--purple);padding:6px 9px;cursor:pointer;}
.br .sc-act.hot{background:var(--purple);color:var(--fillink);}
.br .sc-act.out{color:var(--green);border-color:var(--green);}
.br .sc-act.out.hot{background:var(--green);color:var(--playink);}
.br .sc-act:disabled{opacity:.25;cursor:default;}
.br .sc-acts-none{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);opacity:.6;}

.br .sc-hand{flex:0 0 auto;height:clamp(96px,15dvh,118px);display:flex;flex-direction:column;justify-content:flex-end;}
.br .sc-handl{font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);margin-left:3px;display:flex;gap:8px;align-items:baseline;}
.br .sc-handl em{font-style:normal;font-size:8px;opacity:.75;text-transform:none;letter-spacing:.04em;}
.br .sc-foot{flex:0 0 auto;min-height:44px;display:flex;align-items:center;justify-content:center;}
.br .sc-play{font:inherit;font-size:15px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;width:100%;padding:11px;
  background:var(--green);color:var(--playink);border:1px solid var(--green);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:2px;}
.br .sc-foot .hint{font-size:10px;}

/* the "why" floats over the middle band, so toggling it never moves the table underneath */
  background:color-mix(in srgb,var(--bg) 93%,#000);border:1px solid var(--purple);-webkit-overflow-scrolling:touch;}

/* ---- result ---- */
.br .sc-result{height:100%;min-height:0;overflow-y:auto;display:flex;flex-direction:column;justify-content:center;gap:11px;padding:14px;}
.br .result{border:1px solid var(--line);padding:14px;text-align:center;}
.br .result .rhead{font-size:15px;font-weight:700;letter-spacing:.04em;}
.br .result .rhead.won{color:var(--green);} .br .result .rhead.lost{color:var(--red);}
.br .result .rdetail{font-size:10.5px;color:var(--dim);line-height:1.65;margin-top:7px;}
.br .result .rdetail b{color:var(--ink);}
.br .result .rbig{font-size:24px;font-weight:800;color:var(--yellow);letter-spacing:.06em;margin-top:9px;}
.br .result .rgp{font-size:34px;font-weight:800;color:var(--yellow);line-height:1;margin-top:6px;}
.br .result .rgp small{font-size:10px;color:var(--dim);letter-spacing:.14em;text-transform:uppercase;display:block;margin-top:3px;font-weight:700;}
.br .bar{display:flex;gap:7px;align-items:center;justify-content:center;flex-wrap:wrap;min-height:34px;}

/* ---- the score sheet + high scores ---- */
.br .sheet{border:1px solid var(--line);}
.br .shead,.br .srow{display:grid;grid-template-columns:34px 1fr 44px 34px;}
.br .shead{border-bottom:1px solid var(--line2);}
.br .scol{padding:4px 6px;font-size:8.5px;letter-spacing:.1em;color:var(--dim);text-transform:uppercase;}
.br .srow{border-top:1px solid var(--line2);font-size:10.5px;}
.br .srow .sc-c{padding:4px 6px;color:var(--ink);}
.br .srow .sc-c.dim{color:var(--dim);font-size:9.5px;}
.br .srow .sc-c.gp{color:var(--yellow);font-weight:700;text-align:right;}
.br .hs{border:1px solid var(--line);}
.br .hs-row{display:grid;grid-template-columns:20px 42px 1fr auto;gap:6px;padding:5px 8px;border-top:1px solid var(--line2);font-size:11px;align-items:baseline;}
.br .hs-row:first-child{border-top:0;}
.br .hs-row.me{background:var(--line2);}
.br .hs-n{color:var(--dim);font-size:9px;}
.br .hs-i{font-weight:800;letter-spacing:.1em;color:var(--purple);}
.br .hs-d{font-size:9px;color:var(--dim);letter-spacing:.04em;}
.br .hs-b{font-weight:800;color:var(--yellow);font-size:13px;}
.br .hs-empty{padding:12px 8px;text-align:center;font-size:10.5px;color:var(--dim);}

/* ---- setup ---- */
.br .setwrap{display:flex;flex-direction:column;gap:9px;}
.br .setcard{border:1px solid var(--line2);padding:9px 10px;display:flex;flex-direction:column;gap:7px;}
.br .setcard.resume{border-color:var(--purple);}
.br .sc-ini{width:100%;padding:9px 11px;font:inherit;font-size:16px;letter-spacing:4px;text-transform:uppercase;text-align:center;
  background:rgba(0,0,0,.22);color:var(--ink);border:1px solid var(--line);}
.br .sc-opps{display:flex;flex-direction:column;gap:0;}
.br .sc-oppr{display:grid;grid-template-columns:22px 66px 1fr;gap:8px;align-items:center;padding:6px 4px;border-top:1px solid var(--line2);cursor:pointer;background:transparent;border-left:0;border-right:0;border-bottom:0;text-align:left;font:inherit;color:var(--ink);}
.br .sc-oppr:first-child{border-top:0;}
.br .sc-oppr.on{background:var(--line2);}
.br .sc-oppr .g{font-size:15px;color:var(--accent);}
.br .sc-oppr .n{font-size:12px;font-weight:800;letter-spacing:.05em;}
.br .sc-oppr .b{font-size:9.5px;line-height:1.35;color:var(--dim);}
.br .startbtn{font:inherit;font-size:12px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;background:var(--green);color:var(--playink);
  border:1px solid var(--green);padding:11px 22px;cursor:pointer;width:100%;}
.br .startbtn:disabled{opacity:.35;cursor:default;}
.br .menu-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}
.br .menu-acts{display:grid;grid-template-columns:1fr 1fr;gap:8px;}

/* ---- overlays (menu / rules) ---- */
.br .overlay{position:fixed;inset:0;background:rgba(0,0,0,.66);display:flex;align-items:center;justify-content:center;padding:16px;z-index:40;}
.br .sheetmodal{background:var(--bg);border:1px solid var(--line);max-width:400px;width:100%;max-height:84vh;overflow:auto;}
.br .smhead{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid var(--rule);position:sticky;top:0;background:var(--bg);z-index:2;}
.br .smbody{padding:12px;display:flex;flex-direction:column;gap:12px;}
.br .dl-title{font-size:11px;font-weight:800;letter-spacing:.24em;background:linear-gradient(92deg,var(--pink),var(--purple) 55%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}
.br .dl-x{font:inherit;font-size:20px;line-height:1;background:transparent;border:0;color:var(--dim);cursor:pointer;padding:0 4px;}
.br .rsec{margin-bottom:11px;}
.br .rsh{font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--purple);margin-bottom:5px;}
.br .rsl{font-size:11.5px;color:var(--ink);line-height:1.55;margin-bottom:4px;}
.br .rsl b{color:var(--yellow);}
.br .sc-fail{padding:20px;text-align:center;}
.br .sc-fail-h{font-size:13px;color:var(--ink);margin-bottom:8px;}
.br .sc-fail-b{font-size:11px;color:var(--dim);line-height:1.5;margin-bottom:12px;}

/* ---- TABLE TALK ---- */
.br .talkwrap{height:100%;min-height:0;display:flex;flex-direction:column;}
.br .dl-full{flex:1 1 auto;min-height:0;overflow-y:auto;width:100%;padding:12px 14px 34px;-webkit-overflow-scrolling:touch;}
.br .dl-head{font-size:9px;font-weight:800;letter-spacing:.2em;text-transform:uppercase;color:var(--dim);margin:14px 0 7px;padding-bottom:4px;border-bottom:1px solid var(--line2);}
.br .dl-head:first-child{margin-top:0;}
.br .dl-ev{display:grid;grid-template-columns:20px 1fr;gap:9px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);align-items:start;}
.br .dl-ev .dl-n{font-size:9px;color:var(--dim);font-weight:700;padding-top:2px;}
.br .dl-ev .dl-b{font-size:11.5px;color:var(--ink);line-height:1.5;min-width:0;}
.br .dl-ev .dl-b .w{color:var(--green);font-weight:700;}
.br .dl-ev.us .dl-n{color:var(--cyan);} .br .dl-ev.them .dl-n{color:var(--pink);}
.br .dl-ev .tag{display:inline-block;font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:1px 5px;margin-right:5px;vertical-align:1px;}
.br .dl-ev .tag.meld{color:var(--purple);border:1px solid var(--purple);}
.br .dl-ev .tag.close{color:var(--pink);border:1px solid var(--pink);}
.br .dl-ev .tag.swap{color:var(--cyan);border:1px solid var(--cyan);}
.br .dl-ev .tag.up{color:var(--dim);border:1px solid var(--line2);}
.br .dl-empty{font-size:11.5px;color:var(--dim);line-height:1.5;padding:18px 4px;}
.br .dl-count{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}
.br .dl-cbox{border:1px solid var(--line2);padding:8px 10px;}
.br .dl-cbox .l{font-size:8.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);}
.br .dl-cbox .v{font-size:21px;font-weight:800;color:var(--yellow);line-height:1.15;}
.br .dl-cbox .s{font-size:9px;color:var(--dim);}
.br .dl-cbox.them .v{color:var(--pink);}
`;
export { THEME_CSS };
