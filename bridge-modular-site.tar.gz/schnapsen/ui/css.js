/* The felt-and-brass card table. The variables, the card faces, the fixed app shell (status bar / screen /
   tab bar) and the overlays are all LIFTED UNCHANGED from bridge — same five themes, same
   four-colour deck, same buttons — so the two games feel like two rooms in one club rather than two apps.
   Only the table itself is new, because a two-hand trick-and-draw table looks nothing like a bridge diamond. */
const THEME_CSS = `
.br{
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  --k:1.15;
  --bg:#0f3b2b; --ink:#f2e8ce; --dim:#9a8f63; --line:rgba(212,175,55,.42); --line2:rgba(212,175,55,.20);
  --card:#f6efd9; --cardline:#cdc09a; --fill:#f2e8ce; --fillink:#0f3b2b;
  --purple:#e2c068; --pink:#ed7464; --cyan:#67cdbb; --green:#4fc47a;
  --yellow:#f0d27a; --orange:#e0a45a; --red:#ed7464; --comment:#9a8f63; --rule:#e2c068;
  --sp:#1c6fd4; --he:#b3232a; --di:#d6a51b; --cl:#1c7a3f;
  --selbg:#efe2bd; --playink:#0d3322;
  background:var(--bg); color:var(--ink);
}
.br[data-theme="blue"]{ --bg:#112c4f; --fillink:#112c4f; --playink:#0a1830; }
.br[data-theme="red"]{ --bg:#3c1418; --fillink:#3c1418; --playink:#220a0c; }
.br[data-theme="black"]{ --bg:#0d0d10; --fillink:#0d0d10; --playink:#060608; }
.br[data-theme="cream"]{
  --bg:#f3ead4; --ink:#2b2517; --dim:#857852; --line:rgba(150,116,30,.55); --line2:rgba(150,116,30,.26);
  --card:#fdf9f1; --cardline:#d8c8a0; --fill:#fdf9f1; --fillink:#2b2517;
  --purple:#a87e22; --pink:#bb3b2a; --cyan:#157a70; --green:#2e8b50;
  --yellow:#9c7d18; --orange:#b5611f; --red:#c0392b; --comment:#857852; --rule:#a87e22;
  --sp:#1c6fd4; --he:#b3232a; --di:#b8890f; --cl:#1c7a3f;
  --selbg:#f2e7c6; --playink:#f6efda;
}
.br *{font-family:var(--mono)!important;border-radius:0!important;box-shadow:none!important;text-shadow:none!important;-webkit-tap-highlight-color:transparent;box-sizing:border-box;}

/* ---- the deck (identical to bridge: four-colour, pip-drawn, no images) ---- */
.brcard{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;background:var(--card);border:1px solid var(--cardline);cursor:default;user-select:none;transition:transform .08s;}
.brcard.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}
.brcard.clk{cursor:pointer;} .brcard.dis{filter:brightness(.5) saturate(.8);}
.brcard.s-sp{color:var(--sp);} .brcard.s-he{color:var(--he);} .brcard.s-di{color:var(--di);} .brcard.s-cl{color:var(--cl);}
.brcard .idx,.brcard .ir,.brcard .is,.brcard .mid,.brcard .ctr,.brcard .pip{color:inherit;background:transparent;font-variant-emoji:text;-webkit-text-fill-color:currentColor;-webkit-backface-visibility:hidden;backface-visibility:hidden;}
.brcard .is,.brcard .pip{font-family:"DejaVu Sans","Noto Sans Symbols2","Noto Sans Symbols","Segoe UI Symbol","Apple Symbols","Arial Unicode MS",sans-serif!important;}
.brcard.sel{background:var(--selbg);border-color:var(--purple);transform:translateY(calc(-8px*var(--k)));}
.brcard .idx{position:absolute;display:flex;flex-direction:column;align-items:center;line-height:.9;font-weight:700;}
.brcard .idx.tl{top:calc(3px*var(--k));left:calc(4px*var(--k));} .brcard .idx.br{bottom:calc(3px*var(--k));right:calc(4px*var(--k));transform:rotate(180deg);}
.brcard .ir{font-size:calc(11px*var(--k));} .brcard .is{font-size:calc(8px*var(--k));margin-top:calc(1px*var(--k));}
.brcard.sm .ir{font-size:calc(8px*var(--k));} .brcard.sm .is{font-size:calc(6px*var(--k));}
.brcard .ctr{position:absolute;inset:0;}
.brcard .pip{position:absolute;font-size:calc(9.5px*var(--k));line-height:1;transform:translate(-50%,-50%);}
.brcard .pip.flip{transform:translate(-50%,-50%) rotate(180deg);}
.brcard .pip.ace{font-size:calc(27px*var(--k));}
.brcard.sm .pip.ace{font-size:calc(18px*var(--k));}
.brcard.sm .pip{font-size:calc(7px*var(--k));}
.brcard .mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:800;}
.brcard .mid.fc{font-size:calc(25px*var(--k));} .brcard.sm .mid.fc{font-size:calc(17px*var(--k));}
/* THE CARD'S POINT VALUE, in the corner where nothing else lives. Schnapsen is a counting game and this
   is the single most useful thing a beginner can be shown; an expert stops seeing it within a hand. */
.brcard .val{position:absolute;top:calc(3px*var(--k));right:calc(5px*var(--k));font-size:calc(8px*var(--k));font-weight:800;opacity:.34;}
.brcard.sm .val{font-size:calc(6.5px*var(--k));top:calc(2px*var(--k));right:calc(3px*var(--k));}
.brback{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;border:1px solid var(--line);background:repeating-linear-gradient(135deg,var(--bg) 0 4px,var(--line2) 4px 5px);}
.brback.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}
.brcard .bc-t{display:none;}                                   /* the plaintext face — see the TEXT theme */
.br .bc-g{font-family:"DejaVu Sans","Noto Sans Symbols2","Noto Sans Symbols","Segoe UI Symbol","Apple Symbols","Arial Unicode MS",sans-serif!important;}

.br .num{font-variant-numeric:tabular-nums;}
.br .lbl2{font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:var(--dim);font-weight:700;}
.br .hint{font-size:11px;color:var(--dim);text-align:center;line-height:1.4;}
.br .hint b{color:var(--ink);}
.br .gsp{color:var(--sp);} .br .ghe{color:var(--he);} .br .gdi{color:var(--di);} .br .gcl{color:var(--cl);}
.br .btn{font:inherit;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;background:transparent;color:var(--ink);border:1px solid var(--ink);padding:6px 12px;cursor:pointer;}
.br .btn.primary{background:var(--green);color:var(--playink);border-color:var(--green);min-width:120px;text-align:center;}
.br .btn.ghost{border-color:var(--line);color:var(--dim);}
.br .btn.ghost.on{border-color:var(--purple);color:var(--purple);}
.br .btn.gold{background:var(--purple);color:var(--fillink);border-color:var(--purple);}
.br .btn:disabled{opacity:.3;cursor:default;color:var(--dim);border-color:var(--line);}
.br .toggle{display:flex;border:1px solid var(--line);}
.br .toggle button{font:inherit;font-size:8.5px;letter-spacing:.06em;text-transform:uppercase;background:transparent;color:var(--dim);border:0;padding:4px 6px;cursor:pointer;}
.br .toggle button.on{background:var(--purple);color:var(--fillink);}
.br .toggle button+button{border-left:1px solid var(--line);}
.br .app{width:100%;max-width:412px;margin:0 auto;display:flex;flex-direction:column;gap:9px;}
.br header{display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:6px;border-bottom:1px solid var(--rule);padding-bottom:6px;}
.br .wordmark{font-size:18px;font-weight:700;letter-spacing:.34em;padding-left:.34em;background:linear-gradient(92deg,var(--pink),var(--purple) 50%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}

/* ---- the fixed app shell: nothing at the top level scrolls ---- */
.br .stage{flex:1 1 auto;min-height:0;width:100%;max-width:640px;margin:0 auto;display:flex;flex-direction:column;overflow:hidden;}
.br .gstatus{flex:0 0 auto;display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid var(--rule);}
.br .gs-menu{font:inherit;font-size:19px;line-height:1;background:transparent;border:1px solid var(--line);color:var(--ink);padding:3px 9px;cursor:pointer;flex:0 0 auto;}
.br .gs-mid{flex:1 1 auto;min-width:0;text-align:center;}
.br .gs-title{font-size:12px;font-weight:800;letter-spacing:.04em;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-turn{font-size:9.5px;letter-spacing:.06em;color:var(--dim);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-score{flex:0 0 auto;display:flex;flex-direction:column;align-items:flex-end;gap:1px;font-size:9px;letter-spacing:.06em;color:var(--dim);line-height:1.25;}
.br .gs-score .gs-games{font-size:12px;font-weight:700;color:var(--yellow);}
.br .gscreen{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;overflow:hidden;}
.br .gtabs{flex:0 0 auto;display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--rule);padding-bottom:env(safe-area-inset-bottom,0);}
.br .gtab{position:relative;font:inherit;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;background:transparent;border:0;color:var(--dim);padding:15px 0;cursor:pointer;}
.br .gtab+.gtab{border-left:1px solid var(--line2);}
.br .gtab.on{color:var(--ink);background:var(--line2);box-shadow:inset 0 2px 0 var(--purple)!important;}
.br .gt-dot{position:absolute;top:11px;margin-left:5px;width:7px;height:7px;border-radius:50%!important;background:var(--green);display:inline-block;}

/* =========================================================================
   THE SCHNAPSEN TABLE. Five bands, all fixed height except the middle one,
   so nothing ever jumps: THEM · the stock and the trick · YOU · the buttons
   you may legally press · your hand.
   ========================================================================= */
.br .sctable{display:flex;flex-direction:column;height:100%;min-height:0;gap:5px;padding:7px 8px;position:relative;}

.br .sc-opp{flex:0 0 auto;display:flex;align-items:center;gap:8px;border:1px solid var(--line2);padding:5px 7px;}
.br .sc-opp .sc-av{font-size:14px;color:var(--accent,var(--purple));}
.br .sc-opp .sc-nm{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;white-space:nowrap;}
.br .sc-opp.act{border-color:var(--line);background:var(--line2);}
.br .sc-backs{flex:1 1 auto;display:flex;justify-content:center;gap:2px;min-width:0;}
.br .sc-backs .brback{width:calc(20px*var(--k));height:calc(28px*var(--k));}
.br .sc-pts{flex:0 0 auto;text-align:right;line-height:1.2;}
.br .sc-pts .p{font-size:15px;font-weight:800;color:var(--yellow);}
.br .sc-pts .t{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-pts .p.hid{color:var(--dim);font-size:12px;}

/* --- the middle: stock on the left, the trick in the centre, nothing on the right --- */
.br .sc-mid{flex:1 1 auto;min-height:0;display:grid;grid-template-columns:auto 1fr;gap:8px;align-items:center;
  border:1px solid var(--line);padding:8px;}
.br .sc-stock{display:flex;flex-direction:column;align-items:center;gap:4px;min-width:64px;}
.br .sc-deck{position:relative;height:calc(46px*var(--k));width:calc(56px*var(--k));}
.br .sc-deck .brback{position:absolute;left:0;top:0;width:calc(30px*var(--k));height:calc(42px*var(--k));}
.br .sc-deck .brback.d2{left:2px;top:2px;} .br .sc-deck .brback.d3{left:4px;top:4px;}
/* the turn-up sits crosswise UNDER the stock, exactly as it does on a real table */
.br .sc-deck .sc-up{position:absolute;left:calc(16px*var(--k));top:calc(9px*var(--k));transform:rotate(90deg);transform-origin:center;}
.br .sc-deck.closed .sc-up{filter:brightness(.55);}
.br .sc-stock-l{font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);text-align:center;line-height:1.35;}
.br .sc-stock-l b{color:var(--ink);}
.br .sc-shut{font-size:8px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--pink);border:1px solid var(--pink);padding:1px 5px;}
.br .sc-strict{font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--orange);}

.br .sc-trick{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:5px;min-width:0;}
.br .sc-slots{display:flex;gap:10px;align-items:center;justify-content:center;}
.br .sc-slot{display:flex;flex-direction:column;align-items:center;gap:3px;}
.br .sc-slot .sc-who{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-slot.win .sc-who{color:var(--green);font-weight:800;}
.br .sc-slot.win .brcard{box-shadow:0 0 0 2px var(--green)!important;}
.br .sc-hole{width:calc(30px*var(--k));height:calc(42px*var(--k));border:1px dashed var(--line2);display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:9px;}
.br .sc-tmsg{font-size:9.5px;color:var(--dim);text-align:center;letter-spacing:.03em;min-height:13px;}
.br .sc-tmsg b{color:var(--ink);}

.br .sc-you{flex:0 0 auto;display:flex;align-items:center;gap:8px;border:1px solid var(--line2);padding:5px 7px;}
.br .sc-you.act{border-color:var(--green);}
.br .sc-you .sc-nm{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--ink);}
.br .sc-bar{flex:1 1 auto;height:7px;border:1px solid var(--line2);position:relative;overflow:hidden;min-width:40px;}
.br .sc-bar i{position:absolute;left:0;top:0;bottom:0;background:var(--green);display:block;}
.br .sc-bar.them i{background:var(--pink);}
.br .sc-bar .m66{position:absolute;top:-2px;bottom:-2px;width:1px;background:var(--yellow);left:55%;}

/* --- the actions you may legally take, and only those --- */
.br .sc-acts{flex:0 0 auto;display:flex;gap:5px;flex-wrap:wrap;justify-content:center;min-height:30px;align-items:center;}
.br .sc-act{font:inherit;font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;
  background:transparent;color:var(--purple);border:1px solid var(--purple);padding:6px 9px;cursor:pointer;}
.br .sc-act.hot{background:var(--purple);color:var(--fillink);}
.br .sc-act.out{color:var(--green);border-color:var(--green);}
.br .sc-act.out.hot{background:var(--green);color:var(--playink);}
.br .sc-act:disabled{opacity:.25;cursor:default;}
.br .sc-acts-none{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);opacity:.6;}

.br .sc-hand{flex:0 0 auto;height:clamp(96px,15dvh,118px);display:flex;flex-direction:column;justify-content:flex-end;}
/* CENTRED, not justified. A justified row pins its outermost cards to the edges, so a hand SPREADS as it
   empties — exactly backwards. Centre it with a fixed gap and the hand contracts toward the middle instead. */
.br .sc-fan{flex:1 1 auto;display:flex;align-items:center;justify-content:center;gap:calc(7px*var(--k));min-height:0;}
.br .sc-handl{font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);margin-left:3px;display:flex;gap:8px;align-items:baseline;}
.br .sc-handl em{font-style:normal;font-size:8px;opacity:.75;text-transform:none;letter-spacing:.04em;}
.br .sc-foot{flex:0 0 auto;min-height:44px;display:flex;align-items:center;justify-content:center;}
.br .sc-play{font:inherit;font-size:15px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;width:100%;padding:11px;
  background:var(--green);color:var(--playink);border:1px solid var(--green);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:2px;}
.br .sc-foot .hint{font-size:10px;}

/* the "why" floats over the middle band, so toggling it never moves the table underneath */
  background:color-mix(in srgb,var(--bg) 93%,#000);border:1px solid var(--purple);-webkit-overflow-scrolling:touch;}

/* ---- result ---- */
.br .sc-result{height:100%;min-height:0;overflow-y:auto;display:flex;flex-direction:column;justify-content:center;gap:11px;padding:14px;}
.br .result{border:1px solid var(--line);padding:14px;text-align:center;}
.br .result .rhead{font-size:15px;font-weight:700;letter-spacing:.04em;}
.br .result .rhead.won{color:var(--green);} .br .result .rhead.lost{color:var(--red);}
.br .result .rdetail{font-size:10.5px;color:var(--dim);line-height:1.65;margin-top:7px;}
.br .result .rdetail b{color:var(--ink);}
.br .result .rbig{font-size:24px;font-weight:800;color:var(--yellow);letter-spacing:.06em;margin-top:9px;}
.br .result .rgp{font-size:34px;font-weight:800;color:var(--yellow);line-height:1;margin-top:6px;}
.br .result .rgp small{font-size:10px;color:var(--dim);letter-spacing:.14em;text-transform:uppercase;display:block;margin-top:3px;font-weight:700;}
.br .bar{display:flex;gap:7px;align-items:center;justify-content:center;flex-wrap:wrap;min-height:34px;}

/* ---- the score sheet + high scores ---- */
.br .sheet{border:1px solid var(--line);}
.br .shead,.br .srow{display:grid;grid-template-columns:34px 1fr 44px 34px;}
.br .shead{border-bottom:1px solid var(--line2);}
.br .scol{padding:4px 6px;font-size:8.5px;letter-spacing:.1em;color:var(--dim);text-transform:uppercase;}
.br .srow{border-top:1px solid var(--line2);font-size:10.5px;}
.br .srow .sc-c{padding:4px 6px;color:var(--ink);}
.br .srow .sc-c.dim{color:var(--dim);font-size:9.5px;}
.br .srow .sc-c.gp{color:var(--yellow);font-weight:700;text-align:right;}
.br .hs{border:1px solid var(--line);}
.br .hs-row{display:grid;grid-template-columns:20px 42px 1fr auto;gap:6px;padding:5px 8px;border-top:1px solid var(--line2);font-size:11px;align-items:baseline;}
.br .hs-row:first-child{border-top:0;}
.br .hs-row.me{background:var(--line2);}
.br .hs-n{color:var(--dim);font-size:9px;}
.br .hs-i{font-weight:800;letter-spacing:.1em;color:var(--purple);}
.br .hs-d{font-size:9px;color:var(--dim);letter-spacing:.04em;}
.br .hs-b{font-weight:800;color:var(--yellow);font-size:13px;}
.br .hs-empty{padding:12px 8px;text-align:center;font-size:10.5px;color:var(--dim);}

/* ---- setup ---- */
.br .setwrap{display:flex;flex-direction:column;gap:9px;}
.br .setcard{border:1px solid var(--line2);padding:9px 10px;display:flex;flex-direction:column;gap:7px;}
.br .setcard.resume{border-color:var(--purple);}
.br .sc-ini{width:100%;padding:9px 11px;font:inherit;font-size:16px;letter-spacing:4px;text-transform:uppercase;text-align:center;
  background:rgba(0,0,0,.22);color:var(--ink);border:1px solid var(--line);}
.br .sc-opps{display:flex;flex-direction:column;gap:0;}
.br .sc-oppr{display:grid;grid-template-columns:22px 66px 1fr;gap:8px;align-items:center;padding:6px 4px;border-top:1px solid var(--line2);cursor:pointer;background:transparent;border-left:0;border-right:0;border-bottom:0;text-align:left;font:inherit;color:var(--ink);}
.br .sc-oppr:first-child{border-top:0;}
.br .sc-oppr.on{background:var(--line2);}
.br .sc-oppr .g{font-size:15px;color:var(--accent);}
.br .sc-oppr .n{font-size:12px;font-weight:800;letter-spacing:.05em;}
.br .sc-oppr .b{font-size:9.5px;line-height:1.35;color:var(--dim);}
.br .startbtn{font:inherit;font-size:12px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;background:var(--green);color:var(--playink);
  border:1px solid var(--green);padding:11px 22px;cursor:pointer;width:100%;}
.br .startbtn:disabled{opacity:.35;cursor:default;}
.br .menu-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}
.br .menu-acts{display:grid;grid-template-columns:1fr 1fr;gap:8px;}

/* ---- overlays (menu / rules) ---- */
.br .overlay{position:fixed;inset:0;background:rgba(0,0,0,.66);display:flex;align-items:center;justify-content:center;padding:16px;z-index:40;}
.br .sheetmodal{background:var(--bg);border:1px solid var(--line);max-width:400px;width:100%;max-height:84vh;overflow:auto;}
.br .smhead{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid var(--rule);position:sticky;top:0;background:var(--bg);z-index:2;}
.br .smbody{padding:12px;display:flex;flex-direction:column;gap:12px;}
.br .dl-title{font-size:11px;font-weight:800;letter-spacing:.24em;background:linear-gradient(92deg,var(--pink),var(--purple) 55%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}
.br .dl-x{font:inherit;font-size:20px;line-height:1;background:transparent;border:0;color:var(--dim);cursor:pointer;padding:0 4px;}
.br .rsec{margin-bottom:11px;}
.br .rsh{font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--purple);margin-bottom:5px;}
.br .rsl{font-size:11.5px;color:var(--ink);line-height:1.55;margin-bottom:4px;}
.br .rsl b{color:var(--yellow);}
.br .sc-fail{padding:20px;text-align:center;}
.br .sc-fail-h{font-size:13px;color:var(--ink);margin-bottom:8px;}
.br .sc-fail-b{font-size:11px;color:var(--dim);line-height:1.5;margin-bottom:12px;}

/* ---- TABLE TALK ---- */
.br .talkwrap{height:100%;min-height:0;display:flex;flex-direction:column;}
.br .dl-full{flex:1 1 auto;min-height:0;overflow-y:auto;width:100%;padding:12px 14px 34px;-webkit-overflow-scrolling:touch;}
.br .dl-head{font-size:9px;font-weight:800;letter-spacing:.2em;text-transform:uppercase;color:var(--dim);margin:14px 0 7px;padding-bottom:4px;border-bottom:1px solid var(--line2);}
.br .dl-head:first-child{margin-top:0;}
.br .dl-ev{display:grid;grid-template-columns:20px 1fr;gap:9px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);align-items:start;}
.br .dl-ev .dl-n{font-size:9px;color:var(--dim);font-weight:700;padding-top:2px;}
.br .dl-ev .dl-b{font-size:11.5px;color:var(--ink);line-height:1.5;min-width:0;}
.br .dl-ev .dl-b .w{color:var(--green);font-weight:700;}
.br .dl-ev.us .dl-n{color:var(--cyan);} .br .dl-ev.them .dl-n{color:var(--pink);}
.br .dl-ev .tag{display:inline-block;font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:1px 5px;margin-right:5px;vertical-align:1px;}
.br .dl-ev .tag.meld{color:var(--purple);border:1px solid var(--purple);}
.br .dl-ev .tag.close{color:var(--pink);border:1px solid var(--pink);}
.br .dl-ev .tag.swap{color:var(--cyan);border:1px solid var(--cyan);}
.br .dl-ev .tag.up{color:var(--dim);border:1px solid var(--line2);}
.br .dl-empty{font-size:11.5px;color:var(--dim);line-height:1.5;padding:18px 4px;}
.br .dl-count{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}
.br .dl-cbox{border:1px solid var(--line2);padding:8px 10px;}
.br .dl-cbox .l{font-size:8.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);}
.br .dl-cbox .v{font-size:21px;font-weight:800;color:var(--yellow);line-height:1.15;}
.br .dl-cbox .s{font-size:9px;color:var(--dim);}
.br .dl-cbox.them .v{color:var(--pink);}

/* =========================================================================
   THE TEXT THEME.

   Cream, and then: no card faces, no rules, no boxes. A card is two characters — the suit glyph and the
   rank, ♠A, ♥T, ♦Q — coloured by suit, set in a monospace serif. The ten is a T precisely so that every
   card in the deck is exactly two columns wide, which is the entire reason to put a card game in a
   monospace font: the hand LINES UP. A face-down card is a question mark, because that is what it is.

   Buttons lose their borders and gain brackets, [ LIKE THIS ], which is what a button looks like when the
   only thing you have is text. The closed stock strikes through the turn-up. Nothing here is drawn; it is
   all typed.
   ========================================================================= */
.br[data-theme="text"]{
  --mono:"Courier New",Courier,"Nimbus Mono PS","Liberation Mono",monospace;
  --bg:#f3ead4; --ink:#2b2517; --dim:#8a7d54; --line:rgba(150,116,30,.42); --line2:rgba(150,116,30,.18);
  --card:transparent; --cardline:transparent; --fill:#fdf9f1; --fillink:#2b2517;
  --purple:#8c5cc4; --pink:#c0392b; --cyan:#157a70; --green:#1f8b4c;
  --yellow:#b07d0a; --orange:#b5611f; --red:#c0392b; --comment:#8a7d54; --rule:rgba(150,116,30,.5);
  --sp:#1660c9; --he:#c0392b; --di:#b8890f; --cl:#1f8b4c;
  --selbg:transparent; --playink:#f3ead4;
}
/* ---- a card is two characters ---- */
.br[data-theme="text"] .brcard{width:auto;height:auto;background:transparent;border:0;padding:0 calc(2px*var(--k));
  display:flex;align-items:flex-start;justify-content:center;transition:transform .1s;}
.br[data-theme="text"] .brcard .idx,
.br[data-theme="text"] .brcard .ctr,
.br[data-theme="text"] .brcard .mid{display:none;}
.br[data-theme="text"] .brcard .bc-t{display:inline-flex;align-items:baseline;font-size:calc(26px*var(--k));
  font-weight:700;line-height:1.1;letter-spacing:.01em;}
.br[data-theme="text"] .brcard .bc-g{font-size:.86em;margin-right:.04em;}
.br[data-theme="text"] .brcard.sm .bc-t{font-size:calc(17px*var(--k));}
.br[data-theme="text"] .brcard.dis{filter:none;opacity:.26;}
/* selected: no lozenge, just a rule under it and a lift */
.br[data-theme="text"] .brcard.sel{background:transparent;border:0;transform:translateY(calc(-5px*var(--k)));}
.br[data-theme="text"] .brcard.sel .bc-t{text-decoration:underline;text-decoration-thickness:2px;text-underline-offset:.2em;}
/* the point value rides along as a superscript, still plaintext */
.br[data-theme="text"] .brcard .val{position:static;font-size:calc(9px*var(--k));font-weight:700;opacity:.42;
  margin-left:.1em;line-height:1;}
/* ---- a face-down card is a question mark ---- */
.br[data-theme="text"] .brback{width:auto;height:auto;min-width:calc(15px*var(--k));background:none;border:0;
  display:flex;align-items:center;justify-content:center;}
.br[data-theme="text"] .brback::after{content:"?";font-size:calc(24px*var(--k));font-weight:700;color:var(--dim);opacity:.5;}
.br[data-theme="text"] .brback.sm::after,
.br[data-theme="text"] .sc-backs .brback::after{font-size:calc(17px*var(--k));}
.br[data-theme="text"] .sc-backs .brback{width:auto;height:auto;min-width:calc(11px*var(--k));}
/* ---- the stock lies down in a line, and closing it strikes the turn-up out ---- */
.br[data-theme="text"] .sc-deck{position:static;width:auto;height:auto;min-width:calc(58px*var(--k));
  display:flex;align-items:center;justify-content:center;gap:calc(1px*var(--k));}
.br[data-theme="text"] .sc-deck .brback{position:static;}
.br[data-theme="text"] .sc-deck .sc-up{position:static;transform:none;order:2;margin-left:calc(4px*var(--k));}
.br[data-theme="text"] .sc-deck .brback{order:1;}   /* stock first, then the turn-up: "? ? ? ♦K" reads left to right */
.br[data-theme="text"] .sc-deck.closed .sc-up{filter:none;}
.br[data-theme="text"] .sc-deck.closed .sc-up .bc-t{text-decoration:line-through;opacity:.5;}
.br[data-theme="text"] .sc-hole{width:auto;height:auto;min-width:calc(26px*var(--k));border:0;
  font-size:calc(22px*var(--k));opacity:.3;}
/* the winning card of a trick is underlined, not haloed */
.br[data-theme="text"] .sc-slot.win .brcard{box-shadow:none!important;}
.br[data-theme="text"] .sc-slot.win .bc-t{text-decoration:underline;text-decoration-thickness:2px;text-underline-offset:.2em;}
/* ---- buttons are brackets ---- */
.br[data-theme="text"] .btn,
.br[data-theme="text"] .sc-act,
.br[data-theme="text"] .sc-play,
.br[data-theme="text"] .gs-menu{background:transparent;border:0;}
.br[data-theme="text"] .btn::before,      .br[data-theme="text"] .btn::after,
.br[data-theme="text"] .sc-act::before,   .br[data-theme="text"] .sc-act::after,
.br[data-theme="text"] .sc-play::before,  .br[data-theme="text"] .sc-play::after{opacity:.4;font-weight:400;}
.br[data-theme="text"] .btn::before,   .br[data-theme="text"] .sc-act::before,  .br[data-theme="text"] .sc-play::before{content:"[ ";}
.br[data-theme="text"] .btn::after,    .br[data-theme="text"] .sc-act::after,   .br[data-theme="text"] .sc-play::after{content:" ]";}
.br[data-theme="text"] .btn.primary{color:var(--green);}
.br[data-theme="text"] .btn.gold{color:var(--purple);}
.br[data-theme="text"] .btn.ghost{color:var(--dim);}
.br[data-theme="text"] .btn.ghost.on{color:var(--purple);}
.br[data-theme="text"] .btn:disabled{opacity:.3;}
.br[data-theme="text"] .sc-act{color:var(--purple);}
.br[data-theme="text"] .sc-act.hot{background:transparent;color:var(--purple);text-decoration:underline;text-underline-offset:.24em;}
.br[data-theme="text"] .sc-act.out,
.br[data-theme="text"] .sc-act.out.hot{background:transparent;color:var(--green);}
.br[data-theme="text"] .sc-play{color:var(--green);padding:11px 0;}
.br[data-theme="text"] .toggle{border:0;gap:calc(4px*var(--k));}
.br[data-theme="text"] .toggle button+button{border-left:0;}
.br[data-theme="text"] .toggle button.on{background:transparent;color:var(--purple);text-decoration:underline;text-underline-offset:.22em;}
/* ---- panels lose their boxes; a hairline is enough ---- */
.br[data-theme="text"] .sc-mid{border:0;border-top:1px solid var(--line2);border-bottom:1px solid var(--line2);}
.br[data-theme="text"] .sc-opp,
.br[data-theme="text"] .sc-you{border:0;background:transparent;padding:5px 3px;}
.br[data-theme="text"] .sc-opp.act,
.br[data-theme="text"] .sc-you.act{background:transparent;}
.br[data-theme="text"] .sc-opp.act .sc-nm{color:var(--pink);}
.br[data-theme="text"] .sc-you.act .sc-nm{color:var(--green);}
.br[data-theme="text"] .sc-bar{display:none;}                    /* the numbers are right there */
.br[data-theme="text"] .sc-shut{border:0;color:var(--pink);}
.br[data-theme="text"] .sc-shut::before{content:"[ ";opacity:.45;} .br[data-theme="text"] .sc-shut::after{content:" ]";opacity:.45;}
.br[data-theme="text"] .gtab.on{background:transparent;box-shadow:none!important;text-decoration:underline;
  text-decoration-thickness:2px;text-underline-offset:6px;}

/* ---- TALK DOCK + a compacted play area to pay for it ----------------------------------------
   The dock needs about 130px. We take it from the middle of the table, which was the most
   generous part of the layout and the least informative: the stock, the turn-up and the two cards
   on the trick do not need to be the same size as the cards in your hand — you never tap them.
   Scaling only .sc-mid leaves the hand (which you DO tap) at full size. */
.br .app{gap:6px;}
.br .sc-mid{--k:0.78;gap:6px;}
.br .sc-mid .sc-stock-l{font-size:8px;line-height:1.25;}
.br .sc-stock{min-width:54px;gap:3px;}
.br .sc-trick{gap:3px;}

.br .sc-talk{display:flex;flex-direction:column;border:1px solid var(--line2);background:var(--fill);min-height:0;}
.br .sc-talk-h{display:flex;justify-content:space-between;align-items:baseline;padding:5px 8px;
  border-bottom:1px solid var(--line);font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-talk-h em{font-style:normal;font-size:8.5px;letter-spacing:.08em;color:var(--dim);opacity:.75;}
.br .sc-talk-msgs{height:clamp(84px,13dvh,116px);overflow-y:auto;padding:6px 8px;display:flex;flex-direction:column;gap:4px;}
.br .sc-talk-empty{color:var(--dim);font-size:10.5px;opacity:.7;padding:4px 0;}
.br .sc-msg{font-size:11px;line-height:1.35;display:flex;gap:5px;align-items:baseline;}
.br .sc-msg-w{flex:0 0 auto;font-weight:700;font-size:9px;letter-spacing:.06em;text-transform:uppercase;color:var(--dim);}
.br .sc-msg-t{flex:1 1 auto;min-width:0;word-break:break-word;}
.br .sc-msg-c{flex:0 0 auto;font-size:8.5px;color:var(--dim);opacity:.6;}
.br .sc-msg.me .sc-msg-w{color:var(--purple);}
.br .sc-msg.sys{color:var(--dim);font-size:10.5px;}
.br .sc-msg.sys .sc-msg-t::before{content:"· ";opacity:.5;}
.br .sc-talk-in{display:flex;gap:6px;padding:6px;border-top:1px solid var(--line);}
.br .sc-talk-in input{flex:1 1 auto;min-width:0;background:var(--bg);color:var(--ink);border:1px solid var(--line2);
  padding:6px 8px;font:inherit;font-size:12px;outline:none;}
.br .sc-talk-in input:focus{border-color:var(--purple);}
.br .sc-talk-in .btn{flex:0 0 auto;padding:6px 10px;font-size:11px;}
.br .sc-talk-in.solo{justify-content:center;padding:7px 6px;}

/* ================= MOTION =================================================================
   Everything here is transform/opacity only — those are the two properties a browser can animate
   without touching layout, which is what keeps it smooth on a phone. Nothing animates a width, a
   height or a margin. And all of it is switched off wholesale under prefers-reduced-motion, because
   a card game that lurches is worse than a card game that sits still. */

@keyframes sc-land   { from{ transform:translateY(16px) scale(.86); opacity:0; } to{ transform:none; opacity:1; } }
@keyframes sc-dealin { from{ transform:translateY(22px) rotate(-4deg); opacity:0; } to{ transform:none; opacity:1; } }
@keyframes sc-pop    { 0%{ transform:scale(.4); opacity:0; } 60%{ transform:scale(1.18); opacity:1; } 100%{ transform:scale(1); } }
@keyframes sc-pip    { from{ transform:scale(0); opacity:0; } to{ transform:scale(1); opacity:1; } }
@keyframes sc-shim   { from{ background-position:-220% 0; } to{ background-position:220% 0; } }
@keyframes sc-shake  { 10%,90%{ transform:translateX(-1px); } 30%,70%{ transform:translateX(2px); } 50%{ transform:translateX(-2px); } }
@keyframes sc-glow   { 0%,100%{ box-shadow:0 0 0 0 transparent; } 50%{ box-shadow:0 0 14px 1px var(--purple); } }

/* a card arriving on the trick drops onto the table; a fresh hand deals in, staggered */
.br .sc-trick .brcard{ animation:sc-land .19s cubic-bezier(.2,.9,.3,1.2) both; }
.br .sc-hand .brcard{ animation:sc-dealin .26s cubic-bezier(.2,.9,.3,1.1) both; }
.br .sc-hand .brcard:nth-child(1){ animation-delay:0ms; }
.br .sc-hand .brcard:nth-child(2){ animation-delay:34ms; }
.br .sc-hand .brcard:nth-child(3){ animation-delay:68ms; }
.br .sc-hand .brcard:nth-child(4){ animation-delay:102ms; }
.br .sc-hand .brcard:nth-child(5){ animation-delay:136ms; }
.br .brcard.sel{ animation:sc-glow 1.1s ease-in-out infinite; }

/* ================= PLAY POINTS ============================================================ */
.br .pp{ margin-top:10px; border:1px solid var(--line2); background:var(--fill); padding:9px 10px;
         display:flex; flex-direction:column; gap:7px; text-align:left; }
.br .pp-h{ display:flex; justify-content:space-between; align-items:center;
           font-size:8.5px; letter-spacing:.11em; text-transform:uppercase; color:var(--dim); }
.br .pp-wait{ font-size:11px; color:var(--dim); opacity:.75; }
.br .pp-tot{ font-size:21px; font-weight:800; letter-spacing:-.02em; animation:sc-pop .34s cubic-bezier(.2,.9,.3,1.4) both; }
.br .pp-tot.good{ color:var(--green); background:linear-gradient(90deg,var(--green),var(--cyan),var(--purple),var(--green));
                  background-size:220% 100%; -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;
                  animation:sc-pop .34s cubic-bezier(.2,.9,.3,1.4) both, sc-shim 2.4s linear .3s infinite; }
.br .pp-tot.bad{ color:var(--red); animation:sc-pop .3s ease-out both, sc-shake .34s ease-in-out .3s both; }

.br .pp-bar{ display:flex; gap:3px; flex-wrap:wrap; }
.br .pp-pip{ width:13px; height:5px; border-radius:2px; background:var(--line2); animation:sc-pip .22s ease-out both; }
.br .pp-pip:nth-child(2n){ animation-delay:40ms; } .br .pp-pip:nth-child(3n){ animation-delay:75ms; }
.br .pp-pip:nth-child(5n){ animation-delay:110ms; } .br .pp-pip:nth-child(7n){ animation-delay:150ms; }
.br .pp-pip.gr{ background:linear-gradient(90deg,var(--green),var(--cyan)); }
.br .pp-pip.ok{ background:var(--green); opacity:.55; }
.br .pp-pip.bd{ background:var(--red); }

.br .pp-sub{ font-size:10.5px; color:var(--dim); }
.br .pp-lesson{ display:flex; flex-direction:column; gap:2px; border-left:2px solid var(--purple);
                padding:4px 0 4px 8px; }
.br .pp-lesson b{ font-size:12px; color:var(--ink); }
.br .pp-lesson span{ font-size:11px; line-height:1.4; color:var(--dim); }
.br .pp-lesson em{ font-style:normal; font-size:10px; color:var(--red); letter-spacing:.04em; }
.br .pp-career{ display:flex; justify-content:space-between; gap:8px; flex-wrap:wrap;
                border-top:1px solid var(--line); padding-top:6px; font-size:10px; color:var(--dim); }
.br .pp-career b{ color:var(--ink); }

@media (prefers-reduced-motion: reduce){
  .br .sc-trick .brcard, .br .sc-hand .brcard, .br .brcard.sel,
  .br .pp-tot, .br .pp-tot.good, .br .pp-tot.bad, .br .pp-pip{ animation:none !important; }
  .br .pp-tot.good{ -webkit-text-fill-color:currentColor; color:var(--green); }
}

/* ================= PARTICLES =============================================================
   A fixed layer over everything, and utterly inert: pointer-events:none top to bottom, so a glyph
   flying across a card can never eat the tap that plays it. position:fixed means the particles are in
   viewport space, which is why the emitters can just hand them getBoundingClientRect() coordinates and
   not care what is scrolled or nested where. */
.br .fx{ position:fixed; inset:0; pointer-events:none; z-index:90; overflow:hidden; }
.br .fx-p{ position:fixed; pointer-events:none; will-change:transform,opacity;
           font-size:15px; line-height:1; font-weight:700; text-shadow:0 0 7px currentColor;
           animation-timing-function:cubic-bezier(.15,.75,.3,1); animation-fill-mode:both; }

/* the burst: straight out of the card, drifting up, spinning, gone */
@keyframes fx-burst{
  0%  { transform:translate(-50%,-50%) scale(.35) rotate(0deg);   opacity:0; }
  18% { opacity:1; }
  100%{ transform:translate(calc(-50% + var(--tx)), calc(-50% + var(--ty))) scale(var(--sc)) rotate(var(--rot));
        opacity:0; }
}
/* the comet: hand to table. The stagger across particles is what makes it read as a TRAIL rather
   than as fourteen glyphs going for a walk together. */
@keyframes fx-fly{
  0%  { transform:translate(-50%,-50%) scale(var(--sc)) rotate(0deg); opacity:0; }
  12% { opacity:1; }
  78% { opacity:.9; }
  100%{ transform:translate(calc(-50% + var(--dx)), calc(-50% + var(--dy))) scale(.42) rotate(var(--rot));
        opacity:0; }
}
.br .fx-burst{ animation-name:fx-burst; }
.br .fx-fly  { animation-name:fx-fly; }

/* the text theme has no colour to speak of, so give the glyphs a little more presence there */
.br[data-theme="text"] .fx-p{ text-shadow:none; opacity:.9; }

@media (prefers-reduced-motion: reduce){
  .br .fx{ display:none; }
}
`;
export { THEME_CSS };
