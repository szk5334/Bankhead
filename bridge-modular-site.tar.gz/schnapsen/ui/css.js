/* The felt-and-brass card table. The variables, the card faces, the fixed app shell (status bar / screen /
   tab bar) and the overlays are all LIFTED UNCHANGED from bridge — same five themes, same
   four-colour deck, same buttons — so the two games feel like two rooms in one club rather than two apps.
   Only the table itself is new, because a two-hand trick-and-draw table looks nothing like a bridge diamond. */
const THEME_CSS = `
.br{
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  --k:1.15;
  --bg:#0f3b2b; --ink:#f2e8ce; --dim:#9a8f63; --line:rgba(212,175,55,.42); --line2:rgba(212,175,55,.20);
  --card:#f6efd9; --cardline:#cdc09a; --fill:#f2e8ce; --fillink:#0f3b2b;
  --purple:#e2c068; --pink:#ed7464; --cyan:#67cdbb; --green:#4fc47a;
  --yellow:#f0d27a; --orange:#e0a45a; --red:#ed7464; --comment:#9a8f63; --rule:#e2c068;
  --sp:#1c6fd4; --he:#b3232a; --di:#d6a51b; --cl:#1c7a3f;
  --selbg:#efe2bd; --playink:#0d3322;
  background:var(--bg); color:var(--ink);
}
.br[data-theme="blue"]{ --bg:#112c4f; --fillink:#112c4f; --playink:#0a1830; }
.br[data-theme="red"]{ --bg:#3c1418; --fillink:#3c1418; --playink:#220a0c; }
.br[data-theme="black"]{ --bg:#0d0d10; --fillink:#0d0d10; --playink:#060608; }
.br[data-theme="cream"]{
  --bg:#f3ead4; --ink:#2b2517; --dim:#857852; --line:rgba(150,116,30,.55); --line2:rgba(150,116,30,.26);
  --card:#fdf9f1; --cardline:#d8c8a0; --fill:#fdf9f1; --fillink:#2b2517;
  --purple:#a87e22; --pink:#bb3b2a; --cyan:#157a70; --green:#2e8b50;
  --yellow:#9c7d18; --orange:#b5611f; --red:#c0392b; --comment:#857852; --rule:#a87e22;
  --sp:#1c6fd4; --he:#b3232a; --di:#b8890f; --cl:#1c7a3f;
  --selbg:#f2e7c6; --playink:#f6efda;
}
.br *{font-family:var(--mono)!important;border-radius:0!important;box-shadow:none!important;text-shadow:none!important;-webkit-tap-highlight-color:transparent;box-sizing:border-box;}

/* ---- the deck (identical to bridge: four-colour, pip-drawn, no images) ---- */
.brcard{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;background:var(--card);border:1px solid var(--cardline);cursor:default;user-select:none;transition:transform .08s;}
.brcard.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}
.brcard.clk{cursor:pointer;} .brcard.dis{filter:brightness(.5) saturate(.8);}
.brcard.s-sp{color:var(--sp);} .brcard.s-he{color:var(--he);} .brcard.s-di{color:var(--di);} .brcard.s-cl{color:var(--cl);}
.brcard .idx,.brcard .ir,.brcard .is,.brcard .mid,.brcard .ctr,.brcard .pip{color:inherit;background:transparent;font-variant-emoji:text;-webkit-text-fill-color:currentColor;-webkit-backface-visibility:hidden;backface-visibility:hidden;}
.brcard .is,.brcard .pip{font-family:"DejaVu Sans","Noto Sans Symbols2","Noto Sans Symbols","Segoe UI Symbol","Apple Symbols","Arial Unicode MS",sans-serif!important;}
.brcard.sel{background:var(--selbg);border-color:var(--purple);transform:translateY(calc(-8px*var(--k)));}
.brcard .idx{position:absolute;display:flex;flex-direction:column;align-items:center;line-height:.9;font-weight:700;}
.brcard .idx.tl{top:calc(2px*var(--k));left:calc(2px*var(--k));} .brcard .idx.br{bottom:calc(2px*var(--k));right:calc(2px*var(--k));transform:rotate(180deg);}
.brcard .ir{font-size:calc(7px*var(--k));} .brcard .is{font-size:calc(5.5px*var(--k));margin-top:calc(.5px*var(--k));}
.brcard.sm .ir{font-size:calc(8px*var(--k));} .brcard.sm .is{font-size:calc(6px*var(--k));}
.brcard .ctr{position:absolute;inset:0;}
.brcard .pip{position:absolute;font-size:calc(7.5px*var(--k));line-height:1;transform:translate(-50%,-50%);}
.brcard .pip.flip{transform:translate(-50%,-50%) rotate(180deg);}
.brcard .pip.ace{font-size:calc(17px*var(--k));}
.brcard.sm .pip.ace{font-size:calc(16px*var(--k));}
.brcard.sm .pip{font-size:calc(6px*var(--k));}
.brcard .mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:800;}
.brcard .mid.fc{font-size:calc(19px*var(--k));} .brcard.sm .mid.fc{font-size:calc(15px*var(--k));}
/* THE CARD'S POINT VALUE, in the corner where nothing else lives. Schnapsen is a counting game and this
   is the single most useful thing a beginner can be shown; an expert stops seeing it within a hand. */
.brcard .val{position:absolute;top:calc(3px*var(--k));right:calc(5px*var(--k));font-size:calc(8px*var(--k));font-weight:800;opacity:.34;}
.brcard.sm .val{font-size:calc(6.5px*var(--k));top:calc(2px*var(--k));right:calc(3px*var(--k));}
.brback{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;border:1px solid var(--line);background:repeating-linear-gradient(135deg,var(--bg) 0 4px,var(--line2) 4px 5px);}
.brback.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}
.brcard .bc-t{display:none;}                                   /* the plaintext face — see the TEXT theme */
.br .bc-g{font-family:"DejaVu Sans","Noto Sans Symbols2","Noto Sans Symbols","Segoe UI Symbol","Apple Symbols","Arial Unicode MS",sans-serif!important;}

.br .num{font-variant-numeric:tabular-nums;}
.br .lbl2{font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:var(--dim);font-weight:700;}
.br .hint{font-size:11px;color:var(--dim);text-align:center;line-height:1.4;}
.br .hint b{color:var(--ink);}
.br .gsp{color:var(--sp);} .br .ghe{color:var(--he);} .br .gdi{color:var(--di);} .br .gcl{color:var(--cl);}
.br .btn{font:inherit;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;background:transparent;color:var(--ink);border:1px solid var(--ink);padding:6px 12px;cursor:pointer;}
.br .btn.primary{background:var(--green);color:var(--playink);border-color:var(--green);min-width:120px;text-align:center;}
.br .btn.ghost{border-color:var(--line);color:var(--dim);}
.br .btn.ghost.on{border-color:var(--purple);color:var(--purple);}
.br .btn.gold{background:var(--purple);color:var(--fillink);border-color:var(--purple);}
.br .btn:disabled{opacity:.3;cursor:default;color:var(--dim);border-color:var(--line);}
.br .toggle{display:flex;border:1px solid var(--line);}
.br .toggle button{font:inherit;font-size:8.5px;letter-spacing:.06em;text-transform:uppercase;background:transparent;color:var(--dim);border:0;padding:4px 6px;cursor:pointer;}
.br .toggle button.on{background:var(--purple);color:var(--fillink);}
.br .toggle button+button{border-left:1px solid var(--line);}
.br .app{width:100%;max-width:412px;margin:0 auto;display:flex;flex-direction:column;gap:9px;}
.br header{display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:6px;border-bottom:1px solid var(--rule);padding-bottom:6px;}
.br .wordmark{font-size:18px;font-weight:700;letter-spacing:.34em;padding-left:.34em;background:linear-gradient(92deg,var(--pink),var(--purple) 50%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}

/* ---- the fixed app shell: nothing at the top level scrolls ---- */
/* GRID, not flex. After five attempts to make flex+min-height:0 bound the middle band reliably, the
   honest fix is to stop relying on the flex min-content quirk at all. A grid with rows auto/1fr/auto
   gives the middle row (the game screen) a DEFINITE track: 1fr resolves to "whatever is left after the
   auto rows", and grid clamps its content to that track instead of letting it push the layout taller.
   The status bar and the tab bar are the auto rows; they are always visible, and .gscreen gets exactly
   the space between them — no more, so the scroll area inside it can finally overflow and scroll. */
.br .stage{flex:1 1 auto;display:grid;grid-template-rows:auto 1fr auto;min-height:0;width:100%;max-width:640px;margin:0 auto;overflow:hidden;}
.br .gstatus{flex:0 0 auto;display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid var(--rule);}
.br .gs-menu{font:inherit;font-size:19px;line-height:1;background:transparent;border:1px solid var(--line);color:var(--ink);padding:3px 9px;cursor:pointer;flex:0 0 auto;}
.br .gs-mid{flex:1 1 auto;min-width:0;text-align:center;}
.br .gs-title{font-size:12px;font-weight:800;letter-spacing:.04em;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-turn{font-size:9.5px;letter-spacing:.06em;color:var(--dim);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-score{flex:0 0 auto;display:flex;flex-direction:column;align-items:flex-end;gap:1px;font-size:9px;letter-spacing:.06em;color:var(--dim);line-height:1.25;}
.br .gs-score .gs-games{font-size:12px;font-weight:700;color:var(--yellow);}
.br .gscreen{min-height:0;display:flex;flex-direction:column;overflow:hidden;}
.br .gtabs{flex:0 0 auto;display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--rule);padding-bottom:env(safe-area-inset-bottom,0);}

/* REPORT VIEWS (the result screen and the log) scroll the DOCUMENT rather than an inner overflow pane —
   the only thing that reliably scrolls on mobile here. The App drops the fixed root for these views; this
   turns the constraining grid into plain block flow so nothing is clipped, and keeps the header and the
   RESULT/LOG tabs in view with position:sticky while the report scrolls between them. */
.br.report{height:auto;overflow:visible;}
.br.report .stage{display:block;overflow:visible;min-height:0;height:auto;}
.br.report .gscreen{display:block;overflow:visible;min-height:0;}
.br.report .sc-result,
.br.report .logscroll{overflow:visible;min-height:0;height:auto;}
.br.report .gstatus{position:sticky;top:0;z-index:6;background:var(--bg);}
.br.report .gtabs{position:sticky;bottom:0;z-index:6;background:var(--bg);}
.br .gtab{position:relative;font:inherit;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;background:transparent;border:0;color:var(--dim);padding:7px 0;cursor:pointer;}
.br .gtab+.gtab{border-left:1px solid var(--line2);}
.br .gtab.on{color:var(--ink);background:var(--line2);box-shadow:inset 0 2px 0 var(--purple)!important;}
.br .gt-dot{position:absolute;top:6px;margin-left:5px;width:7px;height:7px;border-radius:50%!important;background:var(--green);display:inline-block;}

/* =========================================================================
   THE SCHNAPSEN TABLE. Five bands, all fixed height except the middle one,
   so nothing ever jumps: THEM · the stock and the trick · YOU · the buttons
   you may legally press · your hand.
   ========================================================================= */
.br .sctable{display:flex;flex-direction:column;height:100%;min-height:0;gap:5px;padding:7px 8px;position:relative;overflow-y:auto;-webkit-overflow-scrolling:touch;}

.br .sc-opp{flex:0 0 auto;display:flex;align-items:center;gap:8px;border:1px solid var(--line2);padding:5px 7px;}
.br .sc-opp .sc-av{font-size:14px;color:var(--accent,var(--purple));}
.br .sc-opp .sc-nm{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;white-space:nowrap;}
.br .sc-opp.act{border-color:var(--line);background:var(--line2);}
.br .sc-backs{flex:1 1 auto;display:flex;justify-content:center;gap:2px;min-width:0;}
.br .sc-backs .brback{width:calc(20px*var(--k));height:calc(28px*var(--k));}
.br .sc-pts{flex:0 0 auto;text-align:right;line-height:1.2;}
.br .sc-pts .p{font-size:15px;font-weight:800;color:var(--yellow);}
.br .sc-pts .t{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-pts .p.hid{color:var(--dim);font-size:12px;}

/* --- the middle: stock on the left, the trick in the centre, nothing on the right --- */
.br .sc-mid{flex:1 1 auto;min-height:calc(108px*var(--k));display:grid;grid-template-columns:auto 1fr;gap:8px;align-items:stretch;
  border:1px solid var(--line);padding:8px;overflow:hidden;}
.br .sc-stock{display:flex;flex-direction:column;align-items:center;gap:4px;min-width:64px;}
.br .sc-deck{position:relative;height:calc(46px*var(--k));width:calc(56px*var(--k));}
.br .sc-deck .brback{position:absolute;left:0;top:0;width:calc(30px*var(--k));height:calc(42px*var(--k));}
.br .sc-deck .brback.d2{left:2px;top:2px;} .br .sc-deck .brback.d3{left:4px;top:4px;}
/* the turn-up sits crosswise UNDER the stock, exactly as it does on a real table */
/* the turn-up lies crosswise, centred UNDER the stack — a real deck with the trump peeking out beneath.
   Centred by anchoring at 50% and pulling back half its own (rotated) size, so it stays under the stock
   at any scale instead of drifting right off a hardcoded pixel offset. */
/* Centred under the STACK, not the box. The deck box is wider than the cards so the crosswise turn-up
   has room to lie flat — but that means box-centre is well right of the stack. The stack is 30px*k wide
   anchored at the left (plus a 4px*k fan offset), so its centre sits at ~17px*k. Anchor the turn-up
   there. It peeks out below the stack, exactly as a real turn-up does under the talon. */
/* The stock backs sit at the left. The turn-up lies crosswise, tucked under the bottom-right corner of
   the stack but sticking out to the RIGHT so the trump is fully readable — a real talon with the trump
   card peeking out from under it. It renders on TOP (z-index) so the backs never cover its face. */
.br .sc-deck .sc-up{position:absolute;left:calc(44px*var(--k));top:64%;z-index:2;transform:translate(-50%,-50%) rotate(90deg);transform-origin:center;}
.br .sc-deck .brback{z-index:1;}
/* The turn-up DOES get an inlay — it is on show all deal. But the full-card 11.5px inset would leave a
   7px sliver on a 30px card, so it gets its OWN proportional inset (7px), and its pips/indices are pulled
   in and shrunk so nothing overlaps the way it did in the screenshot. */
.br .sc-deck .sc-up .brcard.sm .inlay{display:block;inset:calc(7px*var(--k));}
.br .sc-deck .sc-up .brcard.sm .ir{font-size:calc(6.5px*var(--k));}
.br .sc-deck .sc-up .brcard.sm .is{font-size:calc(5px*var(--k));}
.br .sc-deck .sc-up .brcard.sm .mid.fc{font-size:calc(12px*var(--k));}
.br .sc-deck .sc-up .brcard.sm .pip{font-size:calc(5px*var(--k));}
.br .sc-deck .sc-up .brcard.sm .pip.ace{font-size:calc(12px*var(--k));}
.br .sc-deck.closed .sc-up{filter:brightness(.55);}
.br .sc-stock-l{font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);text-align:center;line-height:1.35;}
.br .sc-stock-l b{color:var(--ink);}
.br .sc-shut{font-size:8px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;color:var(--pink);border:1px solid var(--pink);padding:1px 5px;}
.br .sc-strict{font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--orange);}

/* Cards stacked OVER their message — a column, always. The message is centred under the cards and is
   allowed to wrap to as many lines as it needs, because the row grows to fit it. It can never cross the
   border because there is no fixed height for it to overflow. */
.br .sc-trick{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;min-width:0;min-height:0;padding:4px 2px;overflow:hidden;}
.br .sc-slots{display:flex;gap:14px;align-items:flex-start;justify-content:center;}
.br .sc-slot{display:flex;flex-direction:column;align-items:center;gap:3px;}
.br .sc-slot .sc-who{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-slot.win .sc-who{color:var(--green);font-weight:800;}
.br .sc-slot.win .brcard{box-shadow:0 0 0 2px var(--green)!important;}
.br .sc-msg-trick{width:100%;text-align:center;font-size:11px;line-height:1.4;color:var(--dim);word-break:break-word;}
.br .sc-hole{width:calc(30px*var(--k));height:calc(42px*var(--k));border:1px dashed var(--line2);display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:9px;}
.br .sc-tmsg{font-size:9.5px;color:var(--dim);text-align:center;letter-spacing:.03em;min-height:13px;}
.br .sc-tmsg b{color:var(--ink);}

.br .sc-you{flex:0 0 auto;display:flex;align-items:center;gap:8px;border:1px solid var(--line2);padding:5px 7px;}
.br .sc-you.act{border-color:var(--green);}
.br .sc-you .sc-nm{font-size:10px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;color:var(--ink);}
.br .sc-bar{flex:1 1 auto;height:7px;border:1px solid var(--line2);position:relative;overflow:hidden;min-width:40px;}
.br .sc-bar i{position:absolute;left:0;top:0;bottom:0;background:var(--green);display:block;}
.br .sc-bar.them i{background:var(--pink);}
.br .sc-bar .m66{position:absolute;top:-2px;bottom:-2px;width:1px;background:var(--yellow);left:55%;}

/* --- the actions you may legally take, and only those --- */
.br .sc-acts{flex:0 0 auto;display:flex;gap:5px;flex-wrap:wrap;justify-content:center;min-height:30px;align-items:center;}
.br .sc-act{font:inherit;font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;
  background:transparent;color:var(--purple);border:1px solid var(--purple);padding:6px 9px;cursor:pointer;}
.br .sc-act.hot{background:var(--purple);color:var(--fillink);}
.br .sc-act.out{color:var(--green);border-color:var(--green);}
.br .sc-act.out.hot{background:var(--green);color:var(--playink);}
.br .sc-act:disabled{opacity:.25;cursor:default;}
.br .sc-acts-none{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);opacity:.6;}

.br .sc-hand{flex:0 0 auto;height:clamp(96px,15dvh,118px);display:flex;flex-direction:column;justify-content:flex-end;}
/* CENTRED, not justified. A justified row pins its outermost cards to the edges, so a hand SPREADS as it
   empties — exactly backwards. Centre it with a fixed gap and the hand contracts toward the middle instead. */
.br .sc-fan{flex:1 1 auto;display:flex;align-items:center;justify-content:center;gap:calc(7px*var(--k));min-height:0;}
.br .sc-handl{font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);margin-left:3px;display:flex;gap:8px;align-items:baseline;}
.br .sc-handl em{font-style:normal;font-size:8px;opacity:.75;text-transform:none;letter-spacing:.04em;}
/* The footer band (the "Tap a card to pick it up" hint + confirm-Play button) is gone: you play by
   tapping a card to select it and tapping again to commit, and the hand label carries that instruction.
   Removing the band hands its vertical budget to the talk dock and the trick zone below. */
.br .sc-play{font:inherit;font-size:15px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;width:100%;padding:11px;
  background:var(--green);color:var(--playink);border:1px solid var(--green);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:2px;}

/* the "why" floats over the middle band, so toggling it never moves the table underneath */
  background:color-mix(in srgb,var(--bg) 93%,#000);border:1px solid var(--purple);-webkit-overflow-scrolling:touch;}

/* ---- result ---- */
/* justify-content:center inside an overflow:auto flex column is the classic trap: when the content is
   taller than the box, the overflow is pushed out of BOTH ends and the bottom becomes unreachable —
   which is how the Next-deal button ended up behind the tab bar. Centre with auto margins instead, so
   short results still sit in the middle and long ones simply scroll. */
/* AUTO MARGINS on the children of an overflow container are the same trap as justify-content:center —
   when the content is taller than the box, the overflow is pushed past the scroll origin and the last
   thing on the screen becomes unreachable. That is the Next-deal button, twice now. No centring tricks:
   the result simply starts at the top and scrolls, with enough tail padding to clear the tab bar. */
/* NOT a flex column. That was the whole bug, through three attempts to fix it: a flex parent DISTRIBUTES
   height to its children, so when the result grew tall the trailing items (the Next-deal button, the
   score sheet) were compressed and pushed below the fold instead of overflowing — and overflow-y:auto
   only scrolls when content OVERFLOWS, which flex was preventing by construction. A plain block simply
   stacks its children at their natural height and scrolls the surplus. The two rules do not compose.
   Children are spaced with margins on .result rather than a flex gap. */
/* THE ACTUAL BUG, found on the fifth try by walking the height chain instead of the display property:
   height:100 percent. It resolves against the PARENT'S height — but .gscreen gets its height from
   flex-grow inside a min-height:0 chain, which is not a *definite* height, so height:100% computed
   against auto and .sc-result simply grew to fit its content. A box as tall as its content never
   overflows, so overflow-y:auto never engaged — and .gscreen's own overflow:hidden then clipped the
   surplus at the tab bar, which is why the Next-deal button vanished rather than scrolled.
   The fix is to NOT set an explicit height at all: flex:1 1 auto with min-height:0 makes flex itself give
   this element a definite, bounded box, and overflow-y:auto scrolls the surplus inside it. */
.br .sc-result{flex:1 1 auto;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;
  display:block;padding:14px 14px calc(56px + env(safe-area-inset-bottom,0));}
.br .sc-result > * + *{margin-top:11px;}
.br .result{border:1px solid var(--line);padding:14px;text-align:center;}
.br .result .rhead{font-size:15px;font-weight:700;letter-spacing:.04em;}
.br .result .rhead.won{color:var(--green);} .br .result .rhead.lost{color:var(--red);}
.br .result .rdetail{font-size:10.5px;color:var(--dim);line-height:1.65;margin-top:7px;}
.br .result .rdetail b{color:var(--ink);}
.br .result .rbig{font-size:24px;font-weight:800;color:var(--yellow);letter-spacing:.06em;margin-top:9px;}
.br .result .rgp{font-size:34px;font-weight:800;color:var(--yellow);line-height:1;margin-top:6px;}
.br .result .rgp small{font-size:10px;color:var(--dim);letter-spacing:.14em;text-transform:uppercase;display:block;margin-top:3px;font-weight:700;}
.br .bar{display:flex;gap:7px;align-items:center;justify-content:center;flex-wrap:wrap;min-height:34px;}

/* ---- the score sheet + high scores ---- */
.br .sheet{border:1px solid var(--line);}
.br .shead,.br .srow{display:grid;grid-template-columns:34px 1fr 44px 34px;}
.br .shead{border-bottom:1px solid var(--line2);}
.br .scol{padding:4px 6px;font-size:8.5px;letter-spacing:.1em;color:var(--dim);text-transform:uppercase;}
.br .srow{border-top:1px solid var(--line2);font-size:10.5px;}
.br .srow .sc-c{padding:4px 6px;color:var(--ink);}
.br .srow .sc-c.dim{color:var(--dim);font-size:9.5px;}
.br .srow .sc-c.gp{color:var(--yellow);font-weight:700;text-align:right;}
.br .hs{border:1px solid var(--line);}
.br .hs-row{display:grid;grid-template-columns:20px 42px 1fr auto;gap:6px;padding:5px 8px;border-top:1px solid var(--line2);font-size:11px;align-items:baseline;}
.br .hs-row:first-child{border-top:0;}
.br .hs-row.me{background:var(--line2);}
.br .hs-n{color:var(--dim);font-size:9px;}
.br .hs-i{font-weight:800;letter-spacing:.1em;color:var(--purple);}
.br .hs-d{font-size:9px;color:var(--dim);letter-spacing:.04em;}
.br .hs-b{font-weight:800;color:var(--yellow);font-size:13px;}
.br .hs-empty{padding:12px 8px;text-align:center;font-size:10.5px;color:var(--dim);}

/* ---- setup ---- */
.br .setwrap{display:flex;flex-direction:column;gap:9px;}
.br .setcard{border:1px solid var(--line2);padding:9px 10px;display:flex;flex-direction:column;gap:7px;}
.br .setcard.resume{border-color:var(--purple);}
.br .sc-ini{width:100%;padding:9px 11px;font:inherit;font-size:16px;letter-spacing:4px;text-transform:uppercase;text-align:center;
  background:rgba(0,0,0,.22);color:var(--ink);border:1px solid var(--line);}
.br .sc-opps{display:flex;flex-direction:column;gap:0;}
.br .sc-oppr{display:grid;grid-template-columns:22px 66px 1fr;gap:8px;align-items:center;padding:6px 4px;border-top:1px solid var(--line2);cursor:pointer;background:transparent;border-left:0;border-right:0;border-bottom:0;text-align:left;font:inherit;color:var(--ink);}
.br .sc-oppr:first-child{border-top:0;}
.br .sc-oppr.on{background:var(--line2);}
.br .sc-oppr .g{font-size:15px;color:var(--accent);}
.br .sc-oppr .n{font-size:12px;font-weight:800;letter-spacing:.05em;}
.br .sc-oppr .b{font-size:9.5px;line-height:1.35;color:var(--dim);}
.br .startbtn{font:inherit;font-size:12px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;background:var(--green);color:var(--playink);
  border:1px solid var(--green);padding:11px 22px;cursor:pointer;width:100%;}
.br .startbtn:disabled{opacity:.35;cursor:default;}
.br .menu-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}
.br .menu-acts{display:grid;grid-template-columns:1fr 1fr;gap:8px;}

/* ---- overlays (menu / rules) ---- */
.br .overlay{position:fixed;inset:0;background:rgba(0,0,0,.66);display:flex;align-items:center;justify-content:center;padding:16px;z-index:40;}
.br .sheetmodal{background:var(--bg);border:1px solid var(--line);max-width:400px;width:100%;max-height:84vh;overflow:auto;}
.br .smhead{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid var(--rule);position:sticky;top:0;background:var(--bg);z-index:2;}
.br .smbody{padding:12px;display:flex;flex-direction:column;gap:12px;}
.br .dl-title{font-size:11px;font-weight:800;letter-spacing:.24em;background:linear-gradient(92deg,var(--pink),var(--purple) 55%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}
.br .dl-x{font:inherit;font-size:20px;line-height:1;background:transparent;border:0;color:var(--dim);cursor:pointer;padding:0 4px;}
.br .rsec{margin-bottom:11px;}
.br .rsh{font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--purple);margin-bottom:5px;}
.br .rsl{font-size:11.5px;color:var(--ink);line-height:1.55;margin-bottom:4px;}
.br .rsl b{color:var(--yellow);}
.br .sc-fail{padding:20px;text-align:center;}
.br .sc-fail-h{font-size:13px;color:var(--ink);margin-bottom:8px;}
.br .sc-fail-b{font-size:11px;color:var(--dim);line-height:1.5;margin-bottom:12px;}

/* ---- TABLE TALK ---- */
.br .talkwrap{height:100%;min-height:0;display:flex;flex-direction:column;}
.br .dl-full{flex:1 1 auto;min-height:0;overflow-y:auto;width:100%;padding:12px 14px 34px;-webkit-overflow-scrolling:touch;}
.br .dl-head{font-size:9px;font-weight:800;letter-spacing:.2em;text-transform:uppercase;color:var(--dim);margin:14px 0 7px;padding-bottom:4px;border-bottom:1px solid var(--line2);}
.br .dl-head:first-child{margin-top:0;}
.br .dl-ev{display:grid;grid-template-columns:20px 1fr;gap:9px;padding:6px 0;border-bottom:1px solid rgba(255,255,255,.05);align-items:start;}
.br .dl-ev .dl-n{font-size:9px;color:var(--dim);font-weight:700;padding-top:2px;}
.br .dl-ev .dl-b{font-size:11.5px;color:var(--ink);line-height:1.5;min-width:0;}
.br .dl-ev .dl-b .w{color:var(--green);font-weight:700;}
.br .dl-ev.us .dl-n{color:var(--cyan);} .br .dl-ev.them .dl-n{color:var(--pink);}
.br .dl-ev .tag{display:inline-block;font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:1px 5px;margin-right:5px;vertical-align:1px;}
.br .dl-ev .tag.meld{color:var(--purple);border:1px solid var(--purple);}
.br .dl-ev .tag.close{color:var(--pink);border:1px solid var(--pink);}
.br .dl-ev .tag.swap{color:var(--cyan);border:1px solid var(--cyan);}
.br .dl-ev .tag.up{color:var(--dim);border:1px solid var(--line2);}
.br .dl-empty{font-size:11.5px;color:var(--dim);line-height:1.5;padding:18px 4px;}
.br .dl-count{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px;}
.br .dl-cbox{border:1px solid var(--line2);padding:8px 10px;}
.br .dl-cbox .l{font-size:8.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--dim);}
.br .dl-cbox .v{font-size:21px;font-weight:800;color:var(--yellow);line-height:1.15;}
.br .dl-cbox .s{font-size:9px;color:var(--dim);}
.br .dl-cbox.them .v{color:var(--pink);}

/* =========================================================================
   THE TEXT THEME.

   Cream, and then: no card faces, no rules, no boxes. A card is two characters — the suit glyph and the
   rank, ♠A, ♥T, ♦Q — coloured by suit, set in a monospace serif. The ten is a T precisely so that every
   card in the deck is exactly two columns wide, which is the entire reason to put a card game in a
   monospace font: the hand LINES UP. A face-down card is a question mark, because that is what it is.

   Buttons lose their borders and gain brackets, [ LIKE THIS ], which is what a button looks like when the
   only thing you have is text. The closed stock strikes through the turn-up. Nothing here is drawn; it is
   all typed.
   ========================================================================= */
.br[data-theme="text"]{
  --mono:"Courier New",Courier,"Nimbus Mono PS","Liberation Mono",monospace;
  --bg:#f3ead4; --ink:#2b2517; --dim:#8a7d54; --line:rgba(150,116,30,.42); --line2:rgba(150,116,30,.18);
  --card:transparent; --cardline:transparent; --fill:#fdf9f1; --fillink:#2b2517;
  --purple:#8c5cc4; --pink:#c0392b; --cyan:#157a70; --green:#1f8b4c;
  --yellow:#b07d0a; --orange:#b5611f; --red:#c0392b; --comment:#8a7d54; --rule:rgba(150,116,30,.5);
  --sp:#1660c9; --he:#c0392b; --di:#b8890f; --cl:#1f8b4c;
  --selbg:transparent; --playink:#f3ead4;
}
/* ---- a card is two characters ---- */
.br[data-theme="text"] .brcard{width:auto;height:auto;background:transparent;border:0;padding:0 calc(2px*var(--k));
  display:flex;align-items:flex-start;justify-content:center;transition:transform .1s;}
.br[data-theme="text"] .brcard .idx,
.br[data-theme="text"] .brcard .ctr,
.br[data-theme="text"] .brcard .mid{display:none;}
.br[data-theme="text"] .brcard .bc-t{display:inline-flex;align-items:baseline;font-size:calc(26px*var(--k));
  font-weight:700;line-height:1.1;letter-spacing:.01em;}
.br[data-theme="text"] .brcard .bc-g{font-size:.86em;margin-right:.04em;}
.br[data-theme="text"] .brcard.sm .bc-t{font-size:calc(17px*var(--k));}
.br[data-theme="text"] .brcard.dis{filter:none;opacity:.26;}
/* selected: no lozenge, just a rule under it and a lift */
.br[data-theme="text"] .brcard.sel{background:transparent;border:0;transform:translateY(calc(-5px*var(--k)));}
.br[data-theme="text"] .brcard.sel .bc-t{text-decoration:underline;text-decoration-thickness:2px;text-underline-offset:.2em;}
/* the point value rides along as a superscript, still plaintext */
.br[data-theme="text"] .brcard .val{position:static;font-size:calc(9px*var(--k));font-weight:700;opacity:.42;
  margin-left:.1em;line-height:1;}
/* ---- a face-down card is a question mark ---- */
.br[data-theme="text"] .brback{width:auto;height:auto;min-width:calc(15px*var(--k));background:none;border:0;
  display:flex;align-items:center;justify-content:center;}
.br[data-theme="text"] .brback::after{content:"?";font-size:calc(24px*var(--k));font-weight:700;color:var(--dim);opacity:.5;}
.br[data-theme="text"] .brback.sm::after,
.br[data-theme="text"] .sc-backs .brback::after{font-size:calc(17px*var(--k));}
.br[data-theme="text"] .sc-backs .brback{width:auto;height:auto;min-width:calc(11px*var(--k));}
/* ---- the stock lies down in a line, and closing it strikes the turn-up out ---- */
.br[data-theme="text"] .sc-deck{position:static;width:auto;height:auto;min-width:calc(58px*var(--k));
  display:flex;align-items:center;justify-content:center;gap:calc(1px*var(--k));}
.br[data-theme="text"] .sc-deck .brback{position:static;}
.br[data-theme="text"] .sc-deck .sc-up{position:static;transform:none;order:2;margin-left:calc(4px*var(--k));}
.br[data-theme="text"] .sc-deck .brback{order:1;}   /* stock first, then the turn-up: "? ? ? ♦K" reads left to right */
.br[data-theme="text"] .sc-deck.closed .sc-up{filter:none;}
.br[data-theme="text"] .sc-deck.closed .sc-up .bc-t{text-decoration:line-through;opacity:.5;}
.br[data-theme="text"] .sc-hole{width:auto;height:auto;min-width:calc(26px*var(--k));border:0;
  font-size:calc(22px*var(--k));opacity:.3;}
/* the winning card of a trick is underlined, not haloed */
.br[data-theme="text"] .sc-slot.win .brcard{box-shadow:none!important;}
.br[data-theme="text"] .sc-slot.win .bc-t{text-decoration:underline;text-decoration-thickness:2px;text-underline-offset:.2em;}
/* ---- buttons are brackets ---- */
.br[data-theme="text"] .btn,
.br[data-theme="text"] .sc-act,
.br[data-theme="text"] .sc-play,
.br[data-theme="text"] .gs-menu{background:transparent;border:0;}
.br[data-theme="text"] .btn::before,      .br[data-theme="text"] .btn::after,
.br[data-theme="text"] .sc-act::before,   .br[data-theme="text"] .sc-act::after,
.br[data-theme="text"] .sc-play::before,  .br[data-theme="text"] .sc-play::after{opacity:.4;font-weight:400;}
.br[data-theme="text"] .btn::before,   .br[data-theme="text"] .sc-act::before,  .br[data-theme="text"] .sc-play::before{content:"[ ";}
.br[data-theme="text"] .btn::after,    .br[data-theme="text"] .sc-act::after,   .br[data-theme="text"] .sc-play::after{content:" ]";}
.br[data-theme="text"] .btn.primary{color:var(--green);}
.br[data-theme="text"] .btn.gold{color:var(--purple);}
.br[data-theme="text"] .btn.ghost{color:var(--dim);}
.br[data-theme="text"] .btn.ghost.on{color:var(--purple);}
.br[data-theme="text"] .btn:disabled{opacity:.3;}
.br[data-theme="text"] .sc-act{color:var(--purple);}
.br[data-theme="text"] .sc-act.hot{background:transparent;color:var(--purple);text-decoration:underline;text-underline-offset:.24em;}
.br[data-theme="text"] .sc-act.out,
.br[data-theme="text"] .sc-act.out.hot{background:transparent;color:var(--green);}
.br[data-theme="text"] .sc-play{color:var(--green);padding:11px 0;}
.br[data-theme="text"] .toggle{border:0;gap:calc(4px*var(--k));}
.br[data-theme="text"] .toggle button+button{border-left:0;}
.br[data-theme="text"] .toggle button.on{background:transparent;color:var(--purple);text-decoration:underline;text-underline-offset:.22em;}
/* ---- panels lose their boxes; a hairline is enough ---- */
.br[data-theme="text"] .sc-mid{border:0;border-top:1px solid var(--line2);border-bottom:1px solid var(--line2);}
.br[data-theme="text"] .sc-opp,
.br[data-theme="text"] .sc-you{border:0;background:transparent;padding:5px 3px;}
.br[data-theme="text"] .sc-opp.act,
.br[data-theme="text"] .sc-you.act{background:transparent;}
.br[data-theme="text"] .sc-opp.act .sc-nm{color:var(--pink);}
.br[data-theme="text"] .sc-you.act .sc-nm{color:var(--green);}
.br[data-theme="text"] .sc-bar{display:none;}                    /* the numbers are right there */
.br[data-theme="text"] .sc-shut{border:0;color:var(--pink);}
.br[data-theme="text"] .sc-shut::before{content:"[ ";opacity:.45;} .br[data-theme="text"] .sc-shut::after{content:" ]";opacity:.45;}
.br[data-theme="text"] .gtab.on{background:transparent;box-shadow:none!important;text-decoration:underline;
  text-decoration-thickness:2px;text-underline-offset:6px;}

/* ---- TALK DOCK + a compacted play area to pay for it ----------------------------------------
   The dock needs about 130px. We take it from the middle of the table, which was the most
   generous part of the layout and the least informative: the stock, the turn-up and the two cards
   on the trick do not need to be the same size as the cards in your hand — you never tap them.
   Scaling only .sc-mid leaves the hand (which you DO tap) at full size. */
.br .app{gap:6px;}
/* The played cards are the two most important objects on the screen and I had shrunk them into
   illegibility — at 0.78 scale ON TOP of the .sm card size, the pips collided in the middle. They are
   now full-size cards at full scale. The stock keeps the small treatment: you never read the stock, you
   only count it. */
/* CONSOLIDATED. Earlier passes left three competing .sc-trick rules and two .sc-stock scales stacked
   down the file, describing two different layouts at once — which is why the trick message kept crossing
   the border. There is now exactly ONE definition of each, here, and the later duplicates are deleted.

   .sc-mid is a three-column grid: STOCK | TRICK | (message rides under the trick, in the trick's column).
   The cards are full size. The stock is large enough to READ the trump now, not merely count it. */
.br .sc-mid{gap:12px;grid-template-columns:auto 1fr;}
/* The stock and the turn-up are the trump — they sit on the table the whole deal and you have to be
   able to READ the turn-up, not squint at it. They get a LARGER scale than the hand, and the deck box
   is widened so the crosswise turn-up has room to lie flat without clipping. */
.br .sc-mid .sc-stock{--k:1.35;}
.br .sc-mid .sc-stock-l{font-size:10px;line-height:1.35;}
.br .sc-mid .sc-deck{height:calc(56px*var(--k));width:calc(66px*var(--k));}

.br .sc-talk{display:flex;flex-direction:column;border:1px solid var(--line2);background:transparent;min-height:0;}
.br .sc-talk-h{display:flex;justify-content:space-between;align-items:baseline;padding:5px 8px;
  border-bottom:1px solid var(--line);font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .sc-talk-h em{font-style:normal;font-size:8.5px;letter-spacing:.08em;color:var(--dim);opacity:.75;}
/* As tall as the budget allows. Two lines was not a chat box, it was a rumour of one — and it hid the
   deal commentary that was sitting right above the messages. With the footer band removed and the tabs
   halved, the freed budget goes here: at least five full rows of conversation are visible. */
.br .sc-talk-msgs{height:clamp(132px,26dvh,260px);overflow-y:auto;padding:6px 8px;display:flex;flex-direction:column;gap:4px;}
.br .sc-talk-empty{color:var(--dim);font-size:10.5px;opacity:.7;padding:4px 0;}
.br .sc-msg{font-size:11px;line-height:1.35;display:flex;gap:5px;align-items:baseline;}
.br .sc-msg-w{flex:0 0 auto;font-weight:700;font-size:9px;letter-spacing:.06em;text-transform:uppercase;color:var(--dim);}
.br .sc-msg-t{flex:1 1 auto;min-width:0;word-break:break-word;}
.br .sc-msg-c{flex:0 0 auto;font-size:8.5px;color:var(--dim);opacity:.6;}
.br .sc-msg.me .sc-msg-w{color:var(--purple);}
.br .sc-msg.sys{color:var(--dim);font-size:10.5px;}
.br .sc-msg.sys .sc-msg-t::before{content:"· ";opacity:.5;}
.br .sc-talk-in{display:flex;gap:6px;padding:6px;border-top:1px solid var(--line);}
.br .sc-talk-in input{flex:1 1 auto;min-width:0;background:var(--bg);color:var(--ink);border:1px solid var(--line2);
  padding:6px 8px;font:inherit;font-size:12px;outline:none;}
.br .sc-talk-in input:focus{border-color:var(--purple);}
.br .sc-talk-in .btn{flex:0 0 auto;padding:6px 10px;font-size:11px;}
.br .sc-talk-in.solo{display:none;}

/* ================= MOTION =================================================================
   Everything here is transform/opacity only — those are the two properties a browser can animate
   without touching layout, which is what keeps it smooth on a phone. Nothing animates a width, a
   height or a margin. And all of it is switched off wholesale under prefers-reduced-motion, because
   a card game that lurches is worse than a card game that sits still. */

@keyframes sc-land   { from{ transform:translateY(16px) scale(.86); opacity:0; } to{ transform:none; opacity:1; } }
@keyframes sc-dealin { from{ transform:translateY(22px) rotate(-4deg); opacity:0; } to{ transform:none; opacity:1; } }
@keyframes sc-pop    { 0%{ transform:scale(.4); opacity:0; } 60%{ transform:scale(1.18); opacity:1; } 100%{ transform:scale(1); } }
@keyframes sc-pip    { from{ transform:scale(0); opacity:0; } to{ transform:scale(1); opacity:1; } }
@keyframes sc-shim   { from{ background-position:-220% 0; } to{ background-position:220% 0; } }
@keyframes sc-shake  { 10%,90%{ transform:translateX(-1px); } 30%,70%{ transform:translateX(2px); } 50%{ transform:translateX(-2px); } }
@keyframes sc-glow   { 0%,100%{ box-shadow:0 0 0 0 transparent; } 50%{ box-shadow:0 0 14px 1px var(--purple); } }

/* a card arriving on the trick drops onto the table; a fresh hand deals in, staggered */
.br .sc-trick .brcard{ animation:sc-land .19s cubic-bezier(.2,.9,.3,1.2) both; }
.br .sc-hand .brcard{ animation:sc-dealin .26s cubic-bezier(.2,.9,.3,1.1) both; }
.br .sc-hand .brcard:nth-child(1){ animation-delay:0ms; }
.br .sc-hand .brcard:nth-child(2){ animation-delay:34ms; }
.br .sc-hand .brcard:nth-child(3){ animation-delay:68ms; }
.br .sc-hand .brcard:nth-child(4){ animation-delay:102ms; }
.br .sc-hand .brcard:nth-child(5){ animation-delay:136ms; }
.br .brcard.sel{ animation:sc-glow 1.1s ease-in-out infinite; }

/* ================= PLAY POINTS ============================================================ */
.br .pp{ margin-top:10px; border:1px solid var(--line2); background:transparent; padding:9px 10px;
         display:flex; flex-direction:column; gap:7px; text-align:left; }
.br .pp-h{ display:flex; justify-content:space-between; align-items:center;
           font-size:8.5px; letter-spacing:.11em; text-transform:uppercase; color:var(--dim); }
.br .pp-wait{ font-size:11px; color:var(--dim); opacity:.75; }
.br .pp-tot{ font-size:21px; font-weight:800; letter-spacing:-.02em; animation:sc-pop .34s cubic-bezier(.2,.9,.3,1.4) both; }
.br .pp-tot.good{ color:var(--green); background:linear-gradient(90deg,var(--green),var(--cyan),var(--purple),var(--green));
                  background-size:220% 100%; -webkit-background-clip:text; background-clip:text; -webkit-text-fill-color:transparent;
                  animation:sc-pop .34s cubic-bezier(.2,.9,.3,1.4) both, sc-shim 2.4s linear .3s infinite; }
.br .pp-tot.bad{ color:var(--red); animation:sc-pop .3s ease-out both, sc-shake .34s ease-in-out .3s both; }

.br .pp-bar{ display:flex; gap:3px; flex-wrap:wrap; }
.br .pp-pip{ width:13px; height:5px; border-radius:2px; background:var(--line2); animation:sc-pip .22s ease-out both; }
.br .pp-pip:nth-child(2n){ animation-delay:40ms; } .br .pp-pip:nth-child(3n){ animation-delay:75ms; }
.br .pp-pip:nth-child(5n){ animation-delay:110ms; } .br .pp-pip:nth-child(7n){ animation-delay:150ms; }
.br .pp-pip.gr{ background:linear-gradient(90deg,var(--green),var(--cyan)); }
.br .pp-pip.ok{ background:var(--green); opacity:.55; }
.br .pp-pip.bd{ background:var(--red); }

.br .pp-sub{ font-size:10.5px; color:var(--dim); }
.br .pp-lesson{ display:flex; flex-direction:column; gap:2px; border-left:2px solid var(--purple);
                padding:4px 0 4px 8px; }
.br .pp-lesson b{ font-size:12px; color:var(--ink); }
.br .pp-lesson span{ font-size:11px; line-height:1.4; color:var(--dim); }
.br .pp-lesson em{ font-style:normal; font-size:10px; color:var(--red); letter-spacing:.04em; }
.br .pp-career{ display:flex; justify-content:space-between; gap:8px; flex-wrap:wrap;
                border-top:1px solid var(--line); padding-top:6px; font-size:10px; color:var(--dim); }
.br .pp-career b{ color:var(--ink); }

@media (prefers-reduced-motion: reduce){
  .br .sc-trick .brcard, .br .sc-hand .brcard, .br .brcard.sel,
  .br .pp-tot, .br .pp-tot.good, .br .pp-tot.bad, .br .pp-pip{ animation:none !important; }
  .br .pp-tot.good{ -webkit-text-fill-color:currentColor; color:var(--green); }
}

/* ================= PARTICLES =============================================================
   A fixed layer over everything, and utterly inert: pointer-events:none top to bottom, so a glyph
   flying across a card can never eat the tap that plays it. position:fixed means the particles are in
   viewport space, which is why the emitters can just hand them getBoundingClientRect() coordinates and
   not care what is scrolled or nested where. */
.br .fx{ position:fixed; inset:0; pointer-events:none; z-index:90; overflow:hidden; }
.br .fx-p{ position:fixed; pointer-events:none; will-change:transform,opacity;
           font-size:15px; line-height:1; font-weight:700; text-shadow:0 0 7px currentColor;
           animation-timing-function:cubic-bezier(.15,.75,.3,1); animation-fill-mode:both; }

/* the burst: straight out of the card, drifting up, spinning, gone */
@keyframes fx-burst{
  0%  { transform:translate(-50%,-50%) scale(.35) rotate(0deg);   opacity:0; }
  18% { opacity:1; }
  100%{ transform:translate(calc(-50% + var(--tx)), calc(-50% + var(--ty))) scale(var(--sc)) rotate(var(--rot));
        opacity:0; }
}
/* the comet: hand to table. The stagger across particles is what makes it read as a TRAIL rather
   than as fourteen glyphs going for a walk together. */
@keyframes fx-fly{
  0%  { transform:translate(-50%,-50%) scale(var(--sc)) rotate(0deg); opacity:0; }
  12% { opacity:1; }
  78% { opacity:.9; }
  100%{ transform:translate(calc(-50% + var(--dx)), calc(-50% + var(--dy))) scale(.42) rotate(var(--rot));
        opacity:0; }
}
.br .fx-burst{ animation-name:fx-burst; }
.br .fx-fly  { animation-name:fx-fly; }

/* the text theme has no colour to speak of, so give the glyphs a little more presence there */
.br[data-theme="text"] .fx-p{ text-shadow:none; opacity:.9; }

@media (prefers-reduced-motion: reduce){
  .br .fx{ display:none; }
}

/* ================= PLAY POINTS HUD =======================================================
   The third score on the table, and the only one that is about YOU rather than about the cards you
   happened to be dealt. 66 measures the deal. The 7 measures the match. This measures your play. */
.br .ppx{ display:flex; align-items:center; gap:8px; padding:5px 9px; border:1px solid var(--line2);
          position:relative; overflow:hidden; }
.br .ppx-l{ font-size:8.5px; letter-spacing:.11em; text-transform:uppercase; color:var(--dim); }
.br .ppx-n{ font-size:16px; font-weight:800; letter-spacing:-.01em; }
.br .ppx-n.good{ color:var(--green); }
.br .ppx-n.bad { color:var(--red); }
.br .ppx-w{ margin-left:auto; font-size:9px; color:var(--dim); opacity:.6; }
.br .ppx-d{ margin-left:auto; display:flex; align-items:baseline; gap:6px; font-size:12px; font-weight:700;
            animation:sc-pop .3s cubic-bezier(.2,.9,.3,1.5) both; }
.br .ppx-d em{ font-style:normal; font-size:9.5px; letter-spacing:.03em; opacity:.85; }
.br .ppx-d.good{ color:var(--green); }
.br .ppx-d.bad { color:var(--red); }
/* the gradient sweep, same language as the result screen: green when you gain, red shake when you drop */
.br .ppx-good{ animation:sc-sweepg .95s ease-out both; border-color:var(--green); }
.br .ppx-bad { animation:sc-sweepr .5s ease-out both, sc-shake .34s ease-in-out both; border-color:var(--red); }
@keyframes sc-sweepg{
  0%  { box-shadow:inset 0 0 0 0 transparent; background:linear-gradient(90deg,transparent,transparent); }
  25% { box-shadow:inset 0 0 22px -6px var(--green); background:linear-gradient(90deg,transparent,var(--green),var(--cyan),transparent); }
  100%{ box-shadow:inset 0 0 0 0 transparent; background:linear-gradient(90deg,transparent,transparent); }
}
@keyframes sc-sweepr{
  0%,100%{ box-shadow:inset 0 0 0 0 transparent; }
  40%    { box-shadow:inset 0 0 22px -6px var(--red); }
}

/* ================= COACH, IN THE LOG =====================================================
   Toggleable. Off, you play in silence and still get the whole review at the end — the result screen's
   feedback is not a setting. On, it tells you what a decision cost the moment you make it. */
.br .cl{ border:1px solid var(--line2); margin-bottom:9px; }
.br .cl-h{ display:flex; justify-content:space-between; padding:5px 8px; border-bottom:1px solid var(--line);
           font-size:8.5px; letter-spacing:.11em; text-transform:uppercase; color:var(--dim); }
.br .cl-tot{ font-size:11px; font-weight:800; color:var(--ink); letter-spacing:0; }
.br .cl-row{ display:grid; grid-template-columns:16px 1fr auto auto; gap:6px; align-items:baseline;
             padding:5px 8px; border-bottom:1px solid var(--line); font-size:11px; line-height:1.4; }
.br .cl-row:last-child{ border-bottom:0; }
.br .cl-row.bad{ background:linear-gradient(90deg,color-mix(in srgb,var(--red) 12%,transparent),transparent 60%); }
.br .cl-row.wait{ opacity:.55; }
.br .cl-n{ color:var(--dim); font-size:9px; }
.br .cl-b b{ color:var(--ink); }
.br .cl-b em{ font-style:normal; color:var(--dim); }
.br .cl-p{ font-weight:800; font-size:11px; }
.br .cl-p.good{ color:var(--green); } .br .cl-p.bad{ color:var(--red); }
.br .cl-t{ font-size:10px; color:var(--dim); min-width:30px; text-align:right; }

/* ================= REPLAY DECK ===========================================================
   Scroll-snap, one decision per screen. No JS carousel — the browser's own snapping is smoother than
   anything I would write and it keeps working when the thread is busy grading. */
.br .rp{ margin-top:8px; }
.br .rp-h{ display:flex; justify-content:space-between; padding:0 1px 5px;
           font-size:8.5px; letter-spacing:.11em; text-transform:uppercase; color:var(--dim); }
.br .rp-i{ letter-spacing:0; }
.br .rp-strip{ display:flex; gap:8px; overflow-x:auto; scroll-snap-type:x mandatory;
               -webkit-overflow-scrolling:touch; scrollbar-width:none; }
.br .rp-strip::-webkit-scrollbar{ display:none; }
.br .rp-c{ flex:0 0 100%; scroll-snap-align:start; border:1px solid var(--line2); padding:8px 9px;
           display:flex; flex-direction:column; gap:5px; min-height:104px; }
.br .rp-c.bad{ border-color:var(--red); }
.br .rp-c.ok { border-color:var(--green); }
.br .rp-c.wait{ opacity:.6; }
.br .rp-top{ display:flex; justify-content:space-between; align-items:baseline; }
.br .rp-n{ font-size:9px; color:var(--dim); letter-spacing:.08em; }
.br .rp-p{ font-size:17px; font-weight:800; }
.br .rp-p.good{ color:var(--green); } .br .rp-p.bad{ color:var(--red); }
.br .rp-cards{ font-size:12px; line-height:1.45; }
.br .rp-v{ font-size:12px; } .br .rp-v b{ color:var(--ink); }
.br .rp-a{ font-size:11px; line-height:1.45; color:var(--dim); }
.br .rp-a em{ font-style:normal; color:var(--red); font-size:10px; }
.br .rp-run{ margin-top:auto; border-top:1px solid var(--line); padding-top:5px;
             font-size:10px; color:var(--dim); letter-spacing:.05em; }
.br .rp-run b.good{ color:var(--green); } .br .rp-run b.bad{ color:var(--red); }
.br .rp-dots{ display:flex; gap:4px; justify-content:center; padding-top:7px; }
.br .rp-dot{ width:5px; height:5px; border-radius:50%; background:var(--line2); transition:background .15s; }
.br .rp-dot.on{ background:var(--purple); }

@media (prefers-reduced-motion: reduce){
  .br .ppx-good, .br .ppx-bad, .br .ppx-d{ animation:none !important; }
}

/* ================= THE CARD INLAY ========================================================
   A darker-cream panel behind the centre of the card, inset EQUALLY on all four sides. The inset is
   12px because that is the smallest value that clears the corner index — anything less and the index
   touches it; anything more and the panel is too narrow for the letter. And the binding index is the
   TEN, because it is the only two-digit rank and so the only one that is twice as wide as it looks.
   That single number is why the index dropped from 11px to 7.5px and the centre letter from 25px to
   19px. Not a style choice: the only place the three constraints intersect. card.test.mjs holds it. */
.br .brcard .inlay{
  position:absolute; inset:calc(11.5px*var(--k)); z-index:0; pointer-events:none;
  background:color-mix(in srgb, var(--cardline) 26%, var(--card));
  border:1px solid color-mix(in srgb, var(--cardline) 72%, var(--card));
}
/* z-index ONLY. These are all position:absolute already, and setting position:relative here is what
   sent the corner indices into the flow and threw the point value clean off the card. Never restate a
   property you only meant to layer. */
.br .brcard .idx, .br .brcard .ctr, .br .brcard .mid, .br .brcard .val, .br .brcard .pip{ z-index:1; }
/* the small cards (stock, turn-up) are 30px across — there is no inset that clears the index AND leaves
   a panel worth drawing. So they do not get one. Better to omit an ornament than to cramp a card. */
.br .brcard.sm .inlay{ display:none; }
.br[data-theme="text"] .brcard .inlay{ display:none; }

/* ================= RAIN =================================================================
   Both rains fall from the SAME line — the top of .gscreen, i.e. the divider under the status bar.
   They are absolutely positioned inside it, so that line is structural rather than a magic number. */
.br .gscreen{ position:relative; }
.br .gscreen > *{ position:relative; z-index:1; }        /* the interface floats above the weather */
.br .gscreen > .rain{ z-index:0; }

.br .rain{ position:absolute; left:0; right:0; top:0; pointer-events:none; overflow:hidden; }
.br .rain-d{ position:absolute; top:0; line-height:1; will-change:transform;
             animation-name:rain-fall; animation-timing-function:linear; animation-iteration-count:infinite; }

/* the fade is ONE mask on the container, not an opacity animation on forty glyphs */
.br .rain-amb{ height:75%; opacity:.30;
  -webkit-mask-image:linear-gradient(to bottom, rgba(0,0,0,.55) 0%, rgba(0,0,0,1) 28%, rgba(0,0,0,0) 100%);
          mask-image:linear-gradient(to bottom, rgba(0,0,0,.55) 0%, rgba(0,0,0,1) 28%, rgba(0,0,0,0) 100%); }
.br .rain-trick{ height:34%; opacity:.55;
  -webkit-mask-image:linear-gradient(to bottom, rgba(0,0,0,1) 0%, rgba(0,0,0,.9) 40%, rgba(0,0,0,0) 100%);
          mask-image:linear-gradient(to bottom, rgba(0,0,0,1) 0%, rgba(0,0,0,.9) 40%, rgba(0,0,0,0) 100%); }
.br .rain-trick .rain-d{ text-shadow:0 0 8px currentColor; }

@keyframes rain-fall{
  from{ transform:translate3d(0, -28px, 0) rotate(0deg); }
  to  { transform:translate3d(var(--drift), 105vh, 0) rotate(var(--spin)); }
}

/* ================= FIREWORKS ============================================================
   Behind the result modal, in the play-points gradient: green, cyan, purple. */
.br .fw{ position:absolute; inset:0; pointer-events:none; overflow:hidden; z-index:0; }
.br .fw-s{ position:absolute; width:0; height:0; }
.br .fw-p{ position:absolute; border-radius:50%; left:0; top:0;
           animation:fw-burst 1600ms cubic-bezier(.12,.72,.28,1) both; will-change:transform,opacity; }
.br .fw-h0{ background:var(--green); box-shadow:0 0 10px 1px var(--green); }
.br .fw-h1{ background:var(--cyan);  box-shadow:0 0 10px 1px var(--cyan); }
.br .fw-h2{ background:var(--purple);box-shadow:0 0 10px 1px var(--purple); }
@keyframes fw-burst{
  0%  { transform:translate(-50%,-50%) scale(.3); opacity:0; }
  8%  { opacity:1; }
  60% { opacity:.85; }
  100%{ transform:translate(calc(-50% + var(--dx)), calc(-50% + var(--dy))) scale(.22); opacity:0; }
}
.br .sc-result{ position:relative; }
.br .sc-result > *:not(.fw){ position:relative; z-index:1; }

@media (prefers-reduced-motion: reduce){
  .br .rain, .br .fw{ display:none; }
}

/* ================= BOUNTY ================================================================ */
.br .bo{ border:1px solid var(--purple); padding:7px 9px; display:flex; flex-direction:column; gap:5px; }
.br .bo-h{ display:flex; justify-content:space-between; align-items:baseline; font-size:11px; }
.br .bo-h b{ color:var(--purple); letter-spacing:.03em; }
.br .bo-h .num{ color:var(--ink); font-weight:800; }
.br .bo-bar{ height:4px; background:var(--line2); overflow:hidden; }
.br .bo-bar span{ display:block; height:100%; background:linear-gradient(90deg,var(--green),var(--cyan),var(--purple));
                  transition:width .5s cubic-bezier(.2,.9,.3,1); }
.br .bo-s{ font-size:10px; line-height:1.45; color:var(--dim); }
.br .bo-s b{ color:var(--ink); }
.br .bo-done{ border-color:var(--green); align-items:center; text-align:center; animation:sc-pop .4s cubic-bezier(.2,.9,.3,1.4) both; }
.br .bo-done b{ color:var(--green); letter-spacing:.14em; font-size:12px; }
.br .bo-done span{ font-size:10.5px; color:var(--dim); }

.br .rp-bonus{ display:flex; gap:8px; font-size:9.5px; letter-spacing:.05em; color:var(--dim); text-transform:uppercase; }
.br .rp-bonus .fine{ color:var(--cyan); }
.br .ppx-m{ font-size:11px; font-weight:800; color:var(--cyan); letter-spacing:.02em; }

/* ================= PLAY AREA GEOMETRY ====================================================
   From the screenshots: the empty slot was smaller than a card, so the two piles jumped size as soon as
   one was filled; and the trick message sat under the piles where it collided with the zone's own
   border. Fix both: the hole is EXACTLY a card, the piles centre themselves in the zone, and the message
   gets its own column on the right where it has room to wrap. */
.br .sc-hole{
  width:calc(42px*var(--k)); height:calc(58px*var(--k));   /* a card-shaped absence, not a small square */
  border:1px dashed var(--line2); display:flex; align-items:center; justify-content:center;
  color:var(--dim); opacity:.5; flex:0 0 auto;
}
/* ================= TALK DOCK: as tall as the budget allows ==============================
   The footer band is gone and the tabs are half height; that freed budget is spent here so the dock
   shows at least five rows of conversation instead of a two-line rumour of a chat box. */
.br .sc-talk-msgs{ height:clamp(132px,26dvh,260px); }

/* ================= SUIT GRADIENTS ========================================================
   The play-points total shimmers through a gradient. The cards now do the same, one gradient per suit,
   in that suit's own colour: spades blue, hearts red, diamonds yellow, clubs green. Every glyph and
   every number on the face runs it — index, centre, pips.

   The phase is per CARD (--tw, seeded from the card id), so no two cards are at the same point in the
   cycle and the deck twinkles instead of pulsing as one object. Background-clip:text is the whole trick:
   it costs one composited layer per card and nothing per frame. */
@keyframes suit-shim{ from{ background-position:0% 50%; } to{ background-position:200% 50%; } }

.br .brcard .idx, .br .brcard .mid.fc, .br .brcard .pip{
  background-size:200% 100%;
  -webkit-background-clip:text; background-clip:text;
  -webkit-text-fill-color:transparent; color:transparent;
  animation:suit-shim 6s linear infinite;
  animation-delay:var(--tw, 0s);
}
.br .brcard.s-sp .idx, .br .brcard.s-sp .mid.fc, .br .brcard.s-sp .pip{
  background-image:linear-gradient(100deg,var(--sp),#8fb6ff,var(--sp),#5f86d8,var(--sp)); }
.br .brcard.s-he .idx, .br .brcard.s-he .mid.fc, .br .brcard.s-he .pip{
  background-image:linear-gradient(100deg,var(--he),#ff9a86,var(--he),#c2452f,var(--he)); }
.br .brcard.s-di .idx, .br .brcard.s-di .mid.fc, .br .brcard.s-di .pip{
  background-image:linear-gradient(100deg,var(--di),#ffe9a3,var(--di),#c79a2e,var(--di)); }
.br .brcard.s-cl .idx, .br .brcard.s-cl .mid.fc, .br .brcard.s-cl .pip{
  background-image:linear-gradient(100deg,var(--cl),#8ff0b4,var(--cl),#2f9159,var(--cl)); }

/* the text theme has no faces to paint, and the point-value badge must stay plain and readable */
.br[data-theme="text"] .brcard .idx, .br[data-theme="text"] .brcard .mid.fc, .br[data-theme="text"] .brcard .pip{
  background-image:none; -webkit-text-fill-color:currentColor; color:inherit; animation:none; }
@media (prefers-reduced-motion: reduce){ .br .brcard .idx, .br .brcard .mid.fc, .br .brcard .pip{ animation:none; } }

/* ================= THE NEON DECK (theme) =================================================
   Black. Straight lines. Monospace. The only colour in the room comes from the suits themselves, and it
   is loud. Everything structural stays exactly where it was — this is a repaint, not a redesign. */
.br[data-theme="neon"]{
  --bg:#000000; --ink:#f2f2f2; --dim:#7d7d86; --line:#1e1e24; --line2:#33333d;
  --fill:#0a0a0c; --fillink:#f2f2f2; --card:#08080a; --cardline:#2a2a33; --selbg:#12121a;
  --sp:#3d7bff; --he:#ff3b4e; --di:#ffd23d; --cl:#2fe07a;
  --purple:#ffd23d; --pink:#ff3b4e; --cyan:#3d7bff; --green:#2fe07a;
  --yellow:#ffd23d; --orange:#ff9a3d; --red:#ff3b4e; --comment:#5a5a63; --rule:#33333d;
}
.br[data-theme="neon"] .brcard{ background:var(--card); border-color:var(--cardline); }
.br[data-theme="neon"] .brcard .inlay{ background:#0f0f14; border-color:#2a2a33; }
.br[data-theme="neon"] .brcard .idx, .br[data-theme="neon"] .brcard .mid.fc,
.br[data-theme="neon"] .brcard .pip{ filter:drop-shadow(0 0 5px currentColor); }
/* bold: on black, the suit colours can be pushed all the way up without turning to mush */
.br[data-theme="neon"] .brcard.s-sp .idx, .br[data-theme="neon"] .brcard.s-sp .mid.fc, .br[data-theme="neon"] .brcard.s-sp .pip{
  background-image:linear-gradient(100deg,#3d7bff,#a9c8ff,#3d7bff,#1f4fd0,#3d7bff); }
.br[data-theme="neon"] .brcard.s-he .idx, .br[data-theme="neon"] .brcard.s-he .mid.fc, .br[data-theme="neon"] .brcard.s-he .pip{
  background-image:linear-gradient(100deg,#ff3b4e,#ffb0b8,#ff3b4e,#c01326,#ff3b4e); }
.br[data-theme="neon"] .brcard.s-di .idx, .br[data-theme="neon"] .brcard.s-di .mid.fc, .br[data-theme="neon"] .brcard.s-di .pip{
  background-image:linear-gradient(100deg,#ffd23d,#fff3b8,#ffd23d,#c9a017,#ffd23d); }
.br[data-theme="neon"] .brcard.s-cl .idx, .br[data-theme="neon"] .brcard.s-cl .mid.fc, .br[data-theme="neon"] .brcard.s-cl .pip{
  background-image:linear-gradient(100deg,#2fe07a,#b3ffd4,#2fe07a,#13a054,#2fe07a); }
.br[data-theme="neon"] .rain-d{ text-shadow:0 0 10px currentColor, 0 0 22px currentColor; }
.br[data-theme="neon"] .fx-p{ text-shadow:0 0 9px currentColor, 0 0 20px currentColor; }
.br[data-theme="neon"] .btn.primary{ box-shadow:0 0 14px -2px var(--green); }

/* ================= PARTICLE GLOW TRAILS ==================================================
   A soft, blurred, half-transparent smear of the same colour BEHIND each glyph — so the particle reads
   as a thing moving through space rather than a symbol being teleported. One pseudo-element, no extra
   DOM, no extra JS, and it inherits currentColor so it is always the right colour by construction. */
.br .fx-p{ position:fixed; isolation:isolate; }
.br .fx-p::before{
  content:""; position:absolute; left:50%; top:50%; width:230%; height:230%;
  transform:translate(-50%,-50%);
  background:radial-gradient(circle, currentColor 0%, transparent 62%);
  filter:blur(5px); opacity:.42; z-index:-1; pointer-events:none;
}
.br .rain-d{ position:absolute; }
.br .rain-trick .rain-d::before{
  content:""; position:absolute; left:50%; top:50%; width:200%; height:260%;
  transform:translate(-50%,-50%); background:radial-gradient(ellipse, currentColor 0%, transparent 65%);
  filter:blur(6px); opacity:.30; z-index:-1;
}

/* ================= THE STOCK, BIG ENOUGH TO READ =========================================
   You have to be able to see the turn-up — it is the trump, and it is on the table all deal. It was
   being drawn at 0.72 scale inside an already-shrunken row. */

/* ================= THE CLOSE-THE-STOCK JET ===============================================
   White on the dark themes, grey on the light ones — where white would simply be an absence. */
.br .fx-white{ color:#ffffff; }
.br[data-theme="cream"] .fx-white, .br[data-theme="text"] .fx-white{ color:#8a8577; }
.br .fx-stream{ animation-name:fx-fly; font-size:9px; }
.br .fx-stream::before{ opacity:.30; filter:blur(6px); }

/* the running 66-race, on every line of the log */
.br .dl-run{ flex:0 0 auto; margin-left:auto; padding-left:8px; font-size:10.5px; letter-spacing:0;
             color:var(--dim); white-space:nowrap; align-self:center; }
.br .dl-run b{ color:var(--ink); font-weight:700; }
.br .dl-run b.out{ color:var(--green); }
.br .dl-run i{ font-style:normal; opacity:.5; padding:0 2px; }
.br .dl-ev{ display:flex; align-items:baseline; }

/* the LOG tab now holds all the feedback (summary, replay, coach, deal log) and must scroll within the
   1fr game-screen track — same bounded-flex-child pattern as the result screen. */
.br .logscroll{flex:1 1 auto;min-height:0;overflow-y:auto;-webkit-overflow-scrolling:touch;
  display:block;padding:8px 8px calc(20px + env(safe-area-inset-bottom,0));}
.br .logscroll > * + *{margin-top:9px;}
.br .pp-good{color:var(--green);} .br .pp-bad{color:var(--red);}

/* =========================================================================================
   LARGE — a BRIGHT, high-contrast, big-print theme for reading a phone with glasses.
   It keeps the real card faces (pip patterns and all) but scales the whole deck up via --k, drops the
   decorative inlay for a clean uncluttered face, fattens the corner indices (the bit you actually read
   in a fanned hand), and enlarges every label that would otherwise be too small. Light parchment ground,
   near-black ink, four strong dark suit colours — bright enough to turn the screen up against, contrasty
   enough to read without squinting. A deliberately simplified relative of the Cream theme.
   ========================================================================================= */
.br[data-theme="large"]{
  --k:1.45;                                    /* the deck, and everything sized off it, grows */
  --bg:#ece5d4;                                /* calm bright parchment — not a glary pure white */
  --ink:#17130d; --dim:#544b3a;                /* near-black primary, a genuinely readable secondary */
  --line:#4a4234; --line2:rgba(46,40,28,.34);  /* strong, visible borders */
  --card:#fffdf7; --cardline:#241f16;          /* bright card, dark outline so every card is defined */
  --fill:#fffdf7; --fillink:#17130d;
  --purple:#8a6412; --pink:#a81f27; --cyan:#0e685f; --green:#1c7a3f;
  --yellow:#8a6412; --orange:#a8560f; --red:#a81f27; --comment:#544b3a; --rule:#8a6412;
  --sp:#123f78; --he:#a81f27; --di:#b0530c; --cl:#166a38;   /* four strong suits, all dark on white */
  --selbg:#ffe6a0; --playink:#fffdf7;
}
/* ---- the card face: simplified and enlarged ---- */
.br[data-theme="large"] .brcard .inlay{display:none;}            /* one fewer line to parse */
.br[data-theme="large"] .brcard .ir{font-size:calc(11px*var(--k));font-weight:800;}   /* fat corner rank */
.br[data-theme="large"] .brcard .is{font-size:calc(8.5px*var(--k));}
.br[data-theme="large"] .brcard.sm .ir{font-size:calc(9px*var(--k));}
.br[data-theme="large"] .brcard.sm .is{font-size:calc(6.5px*var(--k));}
.br[data-theme="large"] .brcard .idx.tl{top:calc(3px*var(--k));left:calc(3px*var(--k));}
.br[data-theme="large"] .brcard .idx.br{bottom:calc(3px*var(--k));right:calc(3px*var(--k));}
/* pip patterns STAY — the whole card is 45% bigger via --k, so they come along enlarged. Only the ace's
   lone centre pip and the court letter get an extra bump, since they have the whole face to themselves. */
.br[data-theme="large"] .brcard .pip.ace{font-size:calc(22px*var(--k));}
.br[data-theme="large"] .brcard .mid.fc{font-size:calc(23px*var(--k));}
/* the corner point-value becomes a real, readable number rather than a faint grey hint */
.br[data-theme="large"] .brcard .val{font-size:calc(9px*var(--k));opacity:.72;color:var(--dim);font-weight:800;}
.br[data-theme="large"] .brcard.sel{border-width:2px;}           /* selection is unmistakable */
/* ---- give the bigger cards room, and trim the chat so the table still fits ---- */
.br[data-theme="large"] .sc-hand{height:clamp(122px,23dvh,168px);}
.br[data-theme="large"] .sc-fan{gap:calc(5px*var(--k));}
.br[data-theme="large"] .sc-talk-msgs{height:clamp(92px,15dvh,150px);}
/* ---- enlarge every label that print-size would otherwise hide ---- */
.br[data-theme="large"] .sc-nm{font-size:14px;}
.br[data-theme="large"] .sc-opp .sc-av{font-size:19px;}
.br[data-theme="large"] .sc-pts .p{font-size:19px;} .br[data-theme="large"] .sc-pts .p.hid{font-size:16px;}
.br[data-theme="large"] .sc-pts .t{font-size:10px;}
.br[data-theme="large"] .sc-msg-trick{font-size:15px;line-height:1.45;color:var(--ink);}
.br[data-theme="large"] .sc-tmsg{font-size:13px;}
.br[data-theme="large"] .sc-slot .sc-who{font-size:11px;}
.br[data-theme="large"] .sc-stock-l{font-size:11px;line-height:1.4;}
.br[data-theme="large"] .sc-handl{font-size:11px;} .br[data-theme="large"] .sc-handl em{font-size:11px;}
.br[data-theme="large"] .sc-act{font-size:14px;padding:9px 13px;}
.br[data-theme="large"] .sc-acts{min-height:40px;}
.br[data-theme="large"] .gtab{font-size:14px;padding:9px 0;}
.br[data-theme="large"] .sc-msg{font-size:14px;line-height:1.4;}
.br[data-theme="large"] .sc-msg.sys{font-size:13px;}
.br[data-theme="large"] .sc-msg-w{font-size:11px;} .br[data-theme="large"] .sc-msg-c{font-size:10px;}
.br[data-theme="large"] .btn{font-size:14px;}
.br[data-theme="large"] .hint{font-size:14px;} .br[data-theme="large"] .lbl2{font-size:11px;}
/* setup screen: the opponent picker (name + blurb) and the Deal button are read here too */
.br[data-theme="large"] .sc-oppr{grid-template-columns:28px 88px 1fr;}
.br[data-theme="large"] .sc-oppr .g{font-size:21px;}
.br[data-theme="large"] .sc-oppr .n{font-size:14px;}
.br[data-theme="large"] .sc-oppr .b{font-size:12.5px;line-height:1.4;}
.br[data-theme="large"] .startbtn{font-size:15px;padding:13px;}
.br[data-theme="large"] .sc-ini{font-size:19px;}
/* rules sheet */
.br[data-theme="large"] .rsh{font-size:13px;} .br[data-theme="large"] .rsl{font-size:13.5px;line-height:1.6;}
`;
export { THEME_CSS };
