import React from "react";
import { SUIT_GLYPH, suitColorClass } from "../state/constants.js";

/* =======================================================================
   ATMOSPHERE.

   Three effects, one rule: none of them may ever cost a frame or eat a tap.

     AmbientRain — all four suits, falling forever from the line under the status bar, three quarters of
                   the way down the screen, fading out as they go. It sits BEHIND the whole interface.
     TrickRain   — when YOU take a trick, the suit of your winning card rains from that same line over
                   the play area, a third of the way down. It keeps falling until you play your next card.
     Fireworks   — behind the result modal when you win the deal, in the play-points gradient.

   How this stays cheap: every glyph is one <span> with a transform animation and nothing else. No canvas,
   no requestAnimationFrame, no React in the loop — the elements are created once and the compositor does
   the rest. The fade at the bottom is a single mask-image on the CONTAINER rather than an opacity
   animation on every glyph, which is one composited layer instead of forty.

   Negative animation-delays are the trick that makes the ambient rain look like it has always been
   falling: each glyph starts life already partway through its fall, so there is no moment at load where
   the sky is empty and then suddenly rains.
   ===================================================================== */

const SUITS = ["S","H","D","C"];
const rand = (a,b)=> a + Math.random()*(b-a);

/* ---- the perpetual background ---- */
const AmbientRain = React.memo(function AmbientRain(){
  const drops = React.useMemo(()=>{
    const out = [];
    for(let i=0;i<40;i++){
      const su = SUITS[i % 4];                       // exactly even across the four suits, not random
      const dur = rand(9, 20);
      out.push({
        id:i, su,
        left: rand(-2, 102),
        size: rand(10, 19),
        dur,
        delay: -rand(0, dur),                        // already falling when the app opens
        drift: rand(-16, 16),
        spin:  rand(-40, 40),
      });
    }
    return out;
  }, []);

  return (
    <div className="rain rain-amb" aria-hidden="true">
      {drops.map(d=>(
        <span key={d.id} className={"rain-d " + suitColorClass(d.su)}
          style={{ left:d.left+"%", fontSize:d.size+"px",
                   animationDuration:d.dur+"s", animationDelay:d.delay+"s",
                   "--drift":d.drift+"px", "--spin":d.spin+"deg" }}>
          {SUIT_GLYPH[d.su]}
        </span>
      ))}
    </div>
  );
});

/* ---- you took the trick ---- */
function TrickRain({ suit, seed }){
  const drops = React.useMemo(()=>{
    if(!suit) return [];
    const out = [];
    for(let i=0;i<26;i++){
      const dur = rand(1.9, 3.8);
      out.push({
        id:i,
        left: rand(-2, 102),
        size: rand(13, 26),
        dur,
        delay: -rand(0, dur),
        drift: rand(-20, 20),
        spin:  rand(-70, 70),
      });
    }
    return out;
  }, [suit, seed]);

  if(!suit) return null;
  return (
    <div className={"rain rain-trick " + suitColorClass(suit)} aria-hidden="true" key={seed}>
      {drops.map(d=>(
        <span key={d.id} className="rain-d"
          style={{ left:d.left+"%", fontSize:d.size+"px",
                   animationDuration:d.dur+"s", animationDelay:d.delay+"s",
                   "--drift":d.drift+"px", "--spin":d.spin+"deg" }}>
          {SUIT_GLYPH[suit]}
        </span>
      ))}
    </div>
  );
}

/* ---- you won the deal ---- */
function Fireworks({ on }){
  const shells = React.useMemo(()=>{
    if(!on) return [];
    const out = [];
    for(let s=0;s<7;s++){
      const cx = rand(12, 88), cy = rand(14, 62);
      const sparks = [];
      const n = 18;
      for(let i=0;i<n;i++){
        const a = (i/n) * Math.PI * 2 + rand(-0.12, 0.12);
        const d = rand(40, 118);
        sparks.push({
          id:i,
          dx: Math.cos(a)*d,
          dy: Math.sin(a)*d + 26,                    // +26: gravity, so the shell droops as it dies
          size: rand(3, 7),
          hue: i % 3,                                // the play-points gradient: green, cyan, purple
        });
      }
      out.push({ id:s, cx, cy, sparks, delay: s * rand(190, 340) });
    }
    return out;
  }, [on]);

  if(!on) return null;
  return (
    <div className="fw" aria-hidden="true">
      {shells.map(sh=>(
        <div key={sh.id} className="fw-s" style={{ left:sh.cx+"%", top:sh.cy+"%" }}>
          {sh.sparks.map(p=>(
            <span key={p.id} className={"fw-p fw-h"+p.hue}
              style={{ width:p.size+"px", height:p.size+"px",
                       "--dx":p.dx+"px", "--dy":p.dy+"px",
                       animationDelay:(sh.delay)+"ms" }}/>
          ))}
        </div>
      ))}
    </div>
  );
}

export { AmbientRain, TrickRain, Fireworks };
