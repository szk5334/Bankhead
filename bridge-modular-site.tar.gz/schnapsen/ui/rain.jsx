import React from "react";
import { SUIT_GLYPH, suitColorClass } from "../state/constants.js";

/* =======================================================================
   ATMOSPHERE.

   Three effects, one rule: none of them may ever cost a frame or eat a tap.

     AmbientRain — all four suits, three quarters of the way down the screen, fading as they go.
     TrickRain   — the suit of your WINNING card, over the play area, a third of the way down, brighter.

   Both fire together, and ONLY when you take a trick. That is the whole effect: two layers of rain at
   two depths and two speeds, one of them in your suit and one in all four. The parallax between them is
   what makes it read as depth rather than as decoration — and running the four-suit layer all the time
   spent that depth on nothing. It is worth more as a reward than as wallpaper.
     Fireworks   — behind the result modal when you win the deal, in the play-points gradient.

   How this stays cheap: every glyph is one <span> with a transform animation and nothing else. No canvas,
   no requestAnimationFrame, no React in the loop — the elements are created once and the compositor does
   the rest. The fade at the bottom is a single mask-image on the CONTAINER rather than an opacity
   animation on every glyph, which is one composited layer instead of forty.

   The delays are POSITIVE, not negative. A negative delay starts each glyph partway through its fall,
   which is right for weather that has always been there — and wrong for weather that ARRIVES. Since the
   rain now only comes when you take a trick, it has to begin: the glyphs enter at the top, staggered
   over the first second, and fall. Blinking a full sky into existence reads as a glitch, not a reward.
   ===================================================================== */

const SUITS = ["S","H","D","C"];
const rand = (a,b)=> a + Math.random()*(b-a);

/* ---- the perpetual background ---- */
function AmbientRain({ on, seed }){
  const drops = React.useMemo(()=>{
    if(!on) return [];
    const out = [];
    for(let i=0;i<40;i++){
      const su = SUITS[i % 4];                       // exactly even across the four suits, not random
      const dur = rand(4.5, 9);
      out.push({
        id:i, su,
        left: rand(-2, 102),
        size: rand(10, 19),
        dur,
        /* SECONDS, not milliseconds — this is fed straight to animationDelay + "s". The previous value
           (0..900) meant a fifteen-minute wait, so most of the sky never rained at all. Stagger across a
           fraction of the fall instead: every drop enters from above the line, and the shower fills in. */
        delay: rand(0, dur * 0.5),
        drift: rand(-16, 16),
        spin:  rand(-40, 40),
      });
    }
    return out;
  }, [on, seed]);

  if(!on) return null;
  return (
    <div className="rain rain-amb" aria-hidden="true" key={seed}>
      {drops.map(d=>(
        <span key={d.id} className={"rain-d " + suitColorClass(d.su)}
          style={{ left:d.left+"%", fontSize:d.size+"px",
                   animationDuration:d.dur+"s", animationDelay:d.delay+"s",
                   "--drift":d.drift+"px", "--spin":d.spin+"deg" }}>
          {SUIT_GLYPH[d.su]}
        </span>
      ))}
    </div>
  );
}

/* ---- you took the trick ---- */
function TrickRain({ suit, seed }){
  const drops = React.useMemo(()=>{
    if(!suit) return [];
    const out = [];
    for(let i=0;i<26;i++){
      const dur = rand(1.9, 3.8);
      out.push({
        id:i,
        left: rand(-2, 102),
        size: rand(13, 26),
        dur,
        delay: rand(0, dur * 0.45),                  // seconds. it BEGINS from the top; it does not blink in
        drift: rand(-20, 20),
        spin:  rand(-70, 70),
      });
    }
    return out;
  }, [suit, seed]);

  if(!suit) return null;
  return (
    <div className={"rain rain-trick " + suitColorClass(suit)} aria-hidden="true" key={seed}>
      {drops.map(d=>(
        <span key={d.id} className="rain-d"
          style={{ left:d.left+"%", fontSize:d.size+"px",
                   animationDuration:d.dur+"s", animationDelay:d.delay+"s",
                   "--drift":d.drift+"px", "--spin":d.spin+"deg" }}>
          {SUIT_GLYPH[suit]}
        </span>
      ))}
    </div>
  );
}

/* ---- you won the deal ---- */
function Fireworks({ on }){
  /* A looping CSS animation replays the SAME shells in the SAME places forever, and the eye catches that
     inside three cycles — at which point it stops being fireworks and starts being a screensaver. So we
     re-seed instead: every volley is a fresh set of shells at fresh positions, on a randomised delay, in
     a randomly chosen colour family. It never repeats because it is never the same twice. */
  const [volley, setVolley] = React.useState(0);

  React.useEffect(()=>{
    if(!on) return;
    let t;
    const again = ()=>{
      t = setTimeout(()=>{ setVolley(v => v + 1); again(); }, 900 + Math.random()*1900);
    };
    again();
    return ()=> clearTimeout(t);
  }, [on]);

  const shells = React.useMemo(()=>{
    if(!on) return [];
    /* colour FAMILIES, not a rainbow per shell. A single shell is one colour with its neighbours mixed
       in — that is what a real firework looks like, and it is why a shell reads as one object. */
    const FAM = [[0,1],[1,2],[2,0],[0,0],[1,1],[2,2]];
    const fam = FAM[Math.floor(Math.random()*FAM.length)];
    const out = [];
    const n = 2 + Math.floor(Math.random()*3);          // two to four shells in a volley
    for(let s=0;s<n;s++){
      const cx = rand(10, 90), cy = rand(10, 66);
      const sparks = [];
      const m = 14 + Math.floor(Math.random()*10);
      for(let i=0;i<m;i++){
        const a = (i/m) * Math.PI*2 + rand(-0.14, 0.14);
        const d = rand(38, 130);
        sparks.push({
          id:i,
          dx: Math.cos(a)*d,
          dy: Math.sin(a)*d + 30,                       // gravity: the shell droops as it dies
          size: rand(3, 8),
          hue: fam[i % fam.length],
        });
      }
      out.push({ id: volley + "-" + s, cx, cy, sparks, delay: rand(0, 420) });
    }
    return out;
  }, [on, volley]);

  if(!on) return null;
  return (
    <div className="fw" aria-hidden="true">
      {shells.map(sh=>(
        <div key={sh.id} className="fw-s" style={{ left:sh.cx+"%", top:sh.cy+"%" }}>
          {sh.sparks.map(p=>(
            <span key={p.id} className={"fw-p fw-h"+p.hue}
              style={{ width:p.size+"px", height:p.size+"px",
                       "--dx":p.dx+"px", "--dy":p.dy+"px",
                       animationDelay: sh.delay+"ms" }}/>
          ))}
        </div>
      ))}
    </div>
  );
}

export { AmbientRain, TrickRain, Fireworks };
