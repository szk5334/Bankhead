import React from "react";
class UIErrorBoundary extends React.Component{
  constructor(p){ super(p); this.state={err:null}; }
  static getDerivedStateFromError(err){ return {err}; }
  render(){
    if(this.state.err) return (
      <div className="sc-fail">
        <div className="sc-fail-h">Something went wrong on this screen.</div>
        <div className="sc-fail-b">{String((this.state.err&&this.state.err.message)||this.state.err)}</div>
        {this.props.onClose && <button className="btn ghost" onClick={this.props.onClose}>Close</button>}
      </div>
    );
    return this.props.children;
  }
}
export { UIErrorBoundary };
