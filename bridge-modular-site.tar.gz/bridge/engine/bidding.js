//#region gen (auto — removed when bundled to a single bridge.jsx)
import { AUC } from "./auction.js";
import { ENG } from "./core.js";
import { who } from "../state/personas.js";
import { C } from "../ui/theme.js";
//#endregion gen

const BID = (function(){
  const { STRAINS } = ENG;
  const { auctionInfo, turnSeat, callLegal, bidVal } = AUC;
  
  const HCPV = { A:4, K:3, Q:2, J:1 };
  const ORDER = ["C","D","H","S"];
  const isMajor = (s)=> s==="H"||s==="S";
  const isMinor = (s)=> s==="C"||s==="D";
  
  /* ---------- hand evaluation ---------- */
  function evalHand(hand){
    const by = { S:[], H:[], D:[], C:[] };
    for(const c of hand) by[c.suit].push(c.rank);
    const RV = { "2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"10":10,"J":11,"Q":12,"K":13,"A":14 };
    for(const s in by) by[s].sort((a,b)=>RV[b]-RV[a]);
    const len = { S:by.S.length, H:by.H.length, D:by.D.length, C:by.C.length };
    let hcp=0; for(const c of hand) hcp += HCPV[c.rank]||0;
    // long-suit distribution points (for suit-oriented valuation)
    let lp=0; for(const s of ORDER) if(len[s]>4) lp += len[s]-4;
    const shape = [len.S,len.H,len.D,len.C].slice().sort((a,b)=>b-a);
    const shapeKey = shape.join("");
    const balanced = shapeKey==="4333" || shapeKey==="4432" || shapeKey==="5332";
    // suit honor quality: count of top-3 (A,K,Q) and top-5
    const top3 = (s)=> by[s].filter(r=>r==="A"||r==="K"||r==="Q").length;
    const top5 = (s)=> by[s].filter(r=>["A","K","Q","J","10"].includes(r)).length;
    const longest = ORDER.slice().sort((a,b)=> (len[b]-len[a]) || (ORDER.indexOf(b)-ORDER.indexOf(a)))[0];
    const stopper = (s)=>{
      const rs=by[s];
      if(!rs) return false;   // NT or unknown strain has no single-suit stopper
      if(rs.includes("A")) return true;
      if(rs.includes("K") && len[s]>=2) return true;
      if(rs.includes("Q") && len[s]>=3) return true;
      if(rs.includes("J") && len[s]>=4) return true;
      return false;
    };
    return { by, len, hcp, lp, tp:hcp+lp, shape, balanced, longest, top3, top5, stopper, RV };
  }
  // dummy points for raising partner's suit: hcp + shortness (void5/singleton3/doubleton1) given fit
  function raiseValue(ev){
    let sp=0; for(const s of ORDER){ if(ev.len[s]===0) sp+=5; else if(ev.len[s]===1) sp+=3; else if(ev.len[s]===2) sp+=1; }
    return ev.hcp + sp;
  }
  function bestMinor(ev){ // longer minor, 4-4→D, 3-3→C
    if(ev.len.D>ev.len.C) return "D";
    if(ev.len.C>ev.len.D) return "C";
    return ev.len.D>=4 ? "D" : "C";
  }
  function ruleOf20(ev){ const two=[...ORDER].sort((a,b)=>ev.len[b]-ev.len[a]).slice(0,2); return ev.hcp + ev.len[two[0]] + ev.len[two[1]] >= 20; }
  
  /* ---------- auction parsing for a seat ---------- */
  function callsBy(calls){ const m={0:[],1:[],2:[],3:[]}; for(const c of calls) m[c.by].push(c); return m; }
  function lastBidOf(list){ for(let i=list.length-1;i>=0;i--) if(list[i].k==="B") return list[i]; return null; }
  function anyBid(list){ return list.some(c=>c.k==="B"); }
  
  // build a rich context for the seat about to call
  function context(calls, dealer, seat, vul){
    const info = auctionInfo(calls, dealer);
    const by = callsBy(calls);
    const partner = (seat+2)%4;
    const lho = (seat+1)%4, rho = (seat+3)%4;
    const iOpened = anyBid(by[seat]);
    const partnerOpened = anyBid(by[partner]);
    const oppsBid = anyBid(by[lho]) || anyBid(by[rho]);
    // vulnerability, side-indexed [nsVul, ewVul] (side = seat%2; seats 0=S,1=W,2=N,3=E).
    // Absent → both false, so decisions that don't read vul are unaffected (zero-behavior-change wire).
    const side = seat%2;
    const weVul   = Array.isArray(vul) ? !!vul[side]    : false;
    const theyVul = Array.isArray(vul) ? !!vul[side^1]  : false;
    // who opened the auction (first bid)?
    let openerSeat=-1; for(const c of calls){ if(c.k==="B"){ openerSeat=c.by; break; } }
    return { info, by, calls, partner, lho, rho, iOpened, partnerOpened, oppsBid, openerSeat, weVul, theyVul,
      myBids:by[seat], partnerBids:by[partner], lhoBids:by[lho], rhoBids:by[rho],
      myLast:lastBidOf(by[seat]), partnerLast:lastBidOf(by[partner]),
      lhoLast:lastBidOf(by[lho]), rhoLast:lastBidOf(by[rho]) };
  }
  
  const P={k:"P"}, DBL={k:"D"}, RDBL={k:"R"};
  const B=(level,strain)=>({k:"B",level,strain});
  
  /* ---- estimate partner's shown HCP range from their calls ---- */
  function estimatePartner(ctx){
    const bids = ctx.partnerBids.filter(c=>c.k==="B");
    if(!bids.length) return {min:0,max:0,bid:false};
    const first=bids[0];
    let min=6, max=21;
    if(first.strain==="NT"){
      if(first.level===1){ min=15; max=17; }
      else if(first.level===2){ min=20; max=21; }
      else if(first.level===3){ min=25; max=27; }
    } else if(first.level===2 && first.strain==="C"){ min=22; max=30; }
    else if(first.level===2){ min=5; max=11; }      // weak two
    else if(first.level===3){ min=5; max=10; }       // preempt
    else if(first.level===1){ min=12; max=21; }      // one of a suit (opener)
    const partnerOpened = ctx.openerSeat===ctx.partner;
    // refine an OPENER partner by their rebid ladder (classic SAYC)
    if(partnerOpened && bids.length>=2 && first.level===1 && first.strain!=="NT"){
      const rb=bids[1], myFirst=ctx.myBids.find(c=>c.k==="B");
      const openStrain=first.strain;
      const gap = bidVal(rb)-bidVal(first);
      if(rb.strain==="NT"){
        if(rb.level===1){ min=12; max=14; }
        else if(rb.level===2){ min=18; max=19; }
        else { min=19; max=21; }
      } else if(myFirst && rb.strain===myFirst.strain){        // raised my suit
        if(rb.level<= (rankLevelOfRaise(myFirst,1))){ min=12; max=15; }
        else if(rb.level===myFirst.level+2){ min=19; max=21; } // double-jump raise → to game usually
        else { min=16; max=18; }                                // jump raise / game try
      } else if(rb.strain===openStrain){                        // rebid own suit
        min=12; max= (rb.level>=first.level+2)?18:15;            // jump rebid = 16-18
        if(rb.level>=first.level+2) min=16;
      } else {                                                   // new suit
        const reverse = ORDER.indexOf(rb.strain)>ORDER.indexOf(openStrain) && rb.level>first.level;
        if(reverse){ min=16; max=18; }
        else if(gap>=6){ min=19; max=21; }                       // jump shift
        else { min=12; max=16; }
      }
    } else if(partnerOpened && bids.length>=2 && first.level===2 && first.strain==="C"){
      // strong 2C opener's rebid: NT rebid pins a balanced range; suit rebid shows a strong 5+ suit
      const rb=bids[1];
      if(rb.strain==="NT"){
        if(rb.level===2){ min=22; max=24; }        // 2C then 2NT
        else if(rb.level===3){ min=25; max=27; }   // 2C then 3NT
        else { min=22; max=30; }
      } else { min=22; max=30; }                    // 2C then a suit = huge, unbounded upward
    } else if(partnerOpened && bids.length>=2 && first.strain!=="NT" && first.level!==2){
      if(looksStrong(bids)) min=Math.max(min,16); else max=Math.min(max,17);
    }
    // if partner is the RESPONDER (I opened) their range is from responses
    if(ctx.iOpened && ctx.openerSeat!==ctx.partner){
      const r=first;
      const myOpen=ctx.myBids.find(c=>c.k==="B");
      const iOpened2C = myOpen && myOpen.level===2 && myOpen.strain==="C";
      if(iOpened2C){
        // Over a strong, artificial 2C, 2D is a WAITING response (0+, may be a complete bust); any other
        // response is a positive showing ~8+. A later 3NT/game call is a SIGN-OFF, not a jump-shift, so we
        // also suppress the looksStrong bump below. Without this, opener reads the 2D waiting bid as a 10+
        // 2-over-1 and drives to slam opposite nothing (measured: 2C sequences made only ~39% double-dummy).
        if(r.strain==="D" && r.level===2){ min=0; max=21; }
        else { min=8; max=21; }
      }
      else if(r.strain==="NT" && r.level===1){ min=6; max=9; }
      else if(r.strain==="NT" && r.level===2){ min=13; max=15; }
      else if(r.strain==="NT" && r.level===3){ min=16; max=18; }
      else if(myOpen && r.strain===myOpen.strain){             // raised my suit
        if(r.level===myOpen.level+1){ min=6; max=10; }
        else if(r.level===myOpen.level+2){ min=10; max=12; }   // limit raise
        else { min=6; max=10; }
      }
      else if(r.level>=2 && r.strain!=="NT"){ min=10; max=21; } // 2-over-1
      else { min=6; max=12; }                                   // 1-level new suit
      if(bids.length>=2 && looksStrong(bids) && !iOpened2C) min=Math.max(min,12);
    }
    return {min,max,bid:true,first};
  }
  function rankLevelOfRaise(myFirst, extra){ return myFirst.level + extra; }
  function looksStrong(bids){
    // crude: a jump between successive own bids implies extras
    for(let i=1;i<bids.length;i++){
      if(bidVal(bids[i])-bidVal(bids[i-1])>=6) return true;
    }
    return false;
  }
  
  /* ======================================================================
     MAIN: choose a call for `seat` given the hand and auction so far.
     Returns a legal call. Falls back to Pass.
     ====================================================================== */
  function chooseBid(hand, calls, dealer, seat, vul){
    const ev = evalHand(hand);
    const ctx = context(calls, dealer, seat, vul);
    let call = decide(ev, ctx, hand, seat);
    // ---- sanity ceiling: don't climb past what our combined strength supports ----
    if(call && call.k==="B" && call.level>=5){
      const pl=ctx.partnerLast, myLast=ctx.myLast;
      // exemptions: convention answers/placements where high bids are demanded
      const answeringAces = pl && ((pl.strain==="NT"&&pl.level===4) || (pl.strain==="C"&&pl.level===4)); // Blackwood/Gerber ask
      const placingSlam    = myLast && ((myLast.strain==="NT"&&myLast.level===4) || (myLast.strain==="C"&&myLast.level===4)); // I asked, now placing
      if(!answeringAces && !placingSlam){
        const est=estimatePartner(ctx);
        const combined = ev.hcp + (est.bid?est.min:0) + Math.floor(ev.lp/2);
        let ceil=4;                         // game is the default ceiling
        if(combined>=37) ceil=7;
        else if(combined>=33) ceil=6;
        else if(combined>=28) ceil=5;       // minor-suit game / stretch
        if(call.level>ceil) call = P;
      }
    }
    if(!call || !callLegal(call, calls, dealer)){
      // try pass; if the intended bid was illegal, pass is the safe fallback
      call = P;
    }
    return call;
  }
  
  function decide(ev, ctx, hand, seat){
    const { info } = ctx;
    const iHaveBid = ctx.myBids.some(c=>c.k==="B");
    const iAmOpener = ctx.openerSeat===seat;
    const partnerIsOpener = ctx.openerSeat===ctx.partner;
    // -------- opening (no bid yet by anyone) --------
    if(!info.opened){
      return openingBid(ev, ctx);
    }
    // -------- I opened the auction; this is my rebid / later --------
    if(iAmOpener){
      return openerRebid(ev, ctx);
    }
    // -------- partner opened; I respond (responderBid dispatches to continuation) --------
    if(partnerIsOpener){
      return responderBid(ev, ctx);
    }
    // -------- opponents opened (neither partner nor I) --------
    // if I made a Michaels/Unusual/Cappelletti bid, handle my own continuation first
    if(iHaveBid){
      const cc = cappellettiContinue(ev, ctx); if(cc) return cc;
      const mc = twoSuiterContinue(ev, ctx); if(mc) return mc;
    }
    // partner already acted (overcalled/doubled) → I advance
    if(ctx.partnerBids.some(c=>c.k==="B")) return advancerBid(ev, ctx);
    // partner made a takeout double of the opponents' suit and it's standing to me → ADVANCE it.
    // A takeout double is FORCING: never pass without a penalty holding. (Routing/advancerBid/partnerLast
    // all key on k==="B", so partner's double was invisible and the advancer passed a cold game.)
    const ptd = partnerTakeoutDouble(ctx);
    if(ptd) return respondToTakeoutDouble(ev, ctx, ptd);
    // I already overcalled → competitive continuation (treat my overcall as "opener")
    if(iHaveBid) return openerRebid(ev, ctx);
    // first chance to act over their opening
    const oc = overcallBid(ev, ctx);
    // a lead-directing double replaces a pass only — never a values-showing overcall
    if(oc.k==="P"){ const ldd = leadDirectingDouble(ev, ctx); if(ldd) return ldd; }
    return oc;
  }
  
  /* ---------------- OPENING ---------------- */
  function openingBid(ev, ctx){
    const { hcp, tp, balanced, len } = ev;
    // strong, artificial 2C
    if(hcp>=22 || (tp>=23 && longestGood(ev))) return B(2,"C");
    // balanced NT ladders
    if(balanced){
      if(hcp>=15 && hcp<=17) return B(1,"NT");
      if(hcp>=20 && hcp<=21) return B(2,"NT");
      if(hcp>=25 && hcp<=27) return B(3,"NT");
    }
    // one of a suit (all 12+ HCP, 13+ total points, or a shapely 11 by Rule of 20)
    if(hcp>=12 || tp>=13 || (ev.hcp>=11 && ruleOf20(ev))){
      // 5-card major (higher of 5-5/6-6)
      if(len.S>=5 || len.H>=5){
        if(len.S>len.H) return B(1,"S");
        if(len.H>len.S) return B(1,"H");
        return B(1,"S"); // 5-5 or 6-6 → higher
      }
      // no 5-card major → longer minor (4-4→D, 3-3→C); 4441 pick a minor
      return B(1, bestMinor(ev));
    }
    // weak two in D/H/S: 6-card suit, 5-10 hcp, decent suit, no better opening
    for(const s of ["S","H","D"]){
      if(len[s]===6 && ev.hcp>=5 && ev.hcp<=10 && ev.top3(s)>=1 && ev.top5(s)>=2 && !hasOutsideMajor4(ev,s)) return B(2,s);
    }
    // 3-level preempt: 7-card suit, ~5-10 hcp
    for(const s of ["S","H","D","C"]){
      if(len[s]>=7 && ev.hcp>=5 && ev.hcp<=10 && ev.top5(s)>=2) return B(3,s);
    }
    return P;
  }
  function longestGood(ev){ return ev.top3(ev.longest)>=2 && ev.len[ev.longest]>=5; }
  function hasOutsideMajor4(ev, s){ return ORDER.some(x=> x!==s && isMajor(x) && ev.len[x]>=4); }
  
  /* ---- Negative double (responder): partner opened 1-of-a-suit, RHO overcalled
     a suit through 2S, and we hold the unbid major(s) but can't show them cheaply.
     Conservative by design: only fires on textbook shapes, never in an uncontested
     auction (guarded by ctx.rhoLast), so ordinary responses are untouched. ---- */
  function negativeDouble(ev, ctx, op){
    const rho = ctx.rhoLast;
    if(!rho || rho.k!=="B" || rho.strain==="NT") return null;   // RHO must have overcalled a suit
    if(bidVal(rho) > bidVal(B(2,"S"))) return null;              // negative doubles apply through 2S
    if(rho.strain===op.strain) return null;
    const h=ev.hcp, len=ev.len;
    const need = rho.level>=2 ? 8 : 6;                           // more values needed at the 2 level
    if(h<need) return null;
    if(isMajor(op.strain) && len[op.strain]>=3) return null;     // 3+ support → raise partner instead
    const bidSuits = new Set([op.strain, rho.strain]);
    const unbidMajors = ["H","S"].filter(m=> !bidSuits.has(m));
    if(!unbidMajors.length) return null;
    // both majors unbid and held 4+ each → the flagship negative double
    if(unbidMajors.length===2 && len.H>=4 && len.S>=4) return DBL;
    // a single unbid four-card major that cannot be bid at the one level over the overcall
    for(const m of unbidMajors){
      if(len[m]===4){
        const oneAvailable = rho.level===1 && higher(m, rho.strain);
        if(!oneAvailable) return DBL;
      }
    }
    return null;
  }
  function cheapestLevel(strain, ctx){
    const last=ctx.info.lastBid;
    for(let L=1;L<=7;L++){ if(!last || bidVal(B(L,strain))>bidVal(last)) return L; }
    return 7;
  }
  /* ---- Opener answering partner's negative double: bid the promised unbid major,
     jumping with extras; otherwise rebid naturally. ---- */
  function respondToNegDouble(ev, ctx, myOpen){
    const over = ctx.lhoLast;                                    // the overcall (opener's LHO)
    if(!over || over.k!=="B") return null;
    const bidSuits = new Set([myOpen.strain, over.strain]);
    const unbidMajors = ["H","S"].filter(m=> !bidSuits.has(m));
    let pick=null, best=-1;
    for(const m of unbidMajors){ if(ev.len[m]>best){ best=ev.len[m]; pick=m; } }
    const tp=ev.tp;
    if(pick && ev.len[pick]>=3){
      const lvl = cheapestLevel(pick, ctx);
      if(tp>=19) return B(Math.max(4,lvl), pick);                // extras → jump toward game
      if(tp>=16 && lvl===1) return B(2, pick);                   // invitational jump
      return B(lvl, pick);
    }
    if(ev.len[myOpen.strain]>=6) return B(cheapestLevel(myOpen.strain,ctx), myOpen.strain);
    if(ev.balanced && ev.stopper(over.strain)) return B(cheapestLevel("NT",ctx), "NT");
    const second = secondSuit(ev, myOpen.strain, 2);
    if(second) return second;
    return P;
  }

  /* Jordan: over an opponent's takeout double of partner's 1-of-a-major opening,
     2NT shows a limit-raise-or-better (10+ dummy points, 3+ support). Redouble
     shows 10+ with no clear fit. */
  function jordanBid(ev, ctx, op){
    const s=op.strain, h=ev.hcp, rv=raiseValue(ev), len=ev.len;
    if(isMajor(s) && len[s]>=3 && rv>=10) return B(2,"NT");        // Jordan limit-raise+
    if(h>=10 && len[s]<3){
      // SAYC prefers a descriptive bid; redouble only when there isn't one
      const canBidSuitAtOne = ORDER.some(x=> x!==s && len[x]>=4 && higher(x,s));
      const cleanNT = ev.balanced && allStopped(ev,s);
      if(!canBidSuitAtOne && !cleanNT) return RDBL;                // 10+, nothing better to say
    }
    return null;
  }

  /* ---------------- RESPONDING TO PARTNER'S OPENING ---------------- */
  function responderBid(ev, ctx){
    const op = ctx.partnerBids.find(c=>c.k==="B"); // partner's first bid = the opening
    // if I've already responded once, this is my rebid → use the continuation driver
    if(ctx.myBids.some(c=>c.k==="B")) return responderContinue(ev, ctx, op);
    // negative double: partner opened 1-of-a-suit and RHO overcalled a suit
    if(op.level===1 && op.strain!=="NT" && ctx.rhoLast){
      const nd = negativeDouble(ev, ctx, op);
      if(nd) return nd;
    }
    // Jordan 2NT / redouble: partner opened 1-of-a-suit and RHO made a takeout double
    if(op.level===1 && op.strain!=="NT"){
      const rhoLastCall = ctx.rhoBids[ctx.rhoBids.length-1];
      if(rhoLastCall && rhoLastCall.k==="D"){
        const jr = jordanBid(ev, ctx, op);
        if(jr) return jr;
      }
    }
    // route by opening type
    if(op.strain==="NT"){
      if(op.level===1){
        // partner's 1NT OPENING with a suit overcall by RHO → systems off (cuebid = Stayman)
        const rl = ctx.rhoLast;
        if(rl && rl.k==="B" && rl.strain!=="NT" && ctx.openerSeat===ctx.partner)
          return respTo1NTInterf(ev, ctx, rl);
        return respTo1NT(ev, ctx);
      }
      if(op.level===2) return respTo2NT(ev, ctx);
      if(op.level===3) return P;
    }
    if(op.level===2 && op.strain==="C") return respTo2C(ev, ctx);
    if(op.level===2 && op.strain!=="C") return respToWeak2(ev, ctx, op);
    if(op.level===3) return respToPreempt(ev, ctx, op);
    if(op.level===1) return respTo1Suit(ev, ctx, op);
    return P;
  }
  
  /* Responding to partner's 1NT OPENING after RHO overcalls a suit (interference).
     Systems are OFF: Stayman and transfers do not apply. A cuebid of the opponent's
     suit is Stayman with game-forcing values (asks partner for a 4-card major); new-suit
     bids are natural. (Over a double, by contrast, systems stay on — handled by respTo1NT.) */
  function respTo1NTInterf(ev, ctx, over){
    const h=ev.hcp, len=ev.len, theirs=over.strain;
    const stopTheirs = ev.stopper(theirs);
    const NTgame = Math.max(3, cheapestLevel("NT",ctx));   // 3NT (or higher if forced)
    // 1) a natural 5-card major (other than their suit) with invitational+ values: bid it
    for(const m of (len.S>=len.H ? ["S","H"] : ["H","S"])){
      if(len[m]>=5 && m!==theirs && h>=8) return B(cheapestLevel(m,ctx), m);
    }
    // 2) cuebid their suit = game-forcing Stayman: 10+ with a 4-card UNBID major (a major
    //    other than the one they overcalled, so a 4-4 fit is still findable)
    if(h>=10 && ((len.H===4 && theirs!=="H") || (len.S===4 && theirs!=="S")))
      return B(cheapestLevel(theirs,ctx), theirs);
    // 3) natural 3NT to play: game values with their suit stopped
    if(h>=10 && stopTheirs) return B(NTgame, "NT");
    // 4) natural, forcing 5-card minor (jump to 3-level): game values, long minor, no NT stopper
    for(const m of (len.D>=len.C ? ["D","C"] : ["C","D"])){
      if(h>=10 && len[m]>=5 && m!==theirs) return B(Math.max(3, cheapestLevel(m,ctx)), m);
    }
    // 5) competitive 2NT: a balanced invitational hand (8-9) with a stopper, if 2NT is free
    if(h>=8 && h<=9 && ev.balanced && stopTheirs && bidVal(B(2,"NT"))>bidVal(ctx.info.lastBid))
      return B(2,"NT");
    // otherwise nothing constructive to say over the interference
    return P;
  }

  function respTo1NT(ev, ctx){
    const h=ev.hcp, len=ev.len;
    // with a 5+ major, transfer; with 4-4 majors and game interest, Stayman
    const has5M = len.H>=5 || len.S>=5;
    // 8-9 invite, 10+ game, 0-7 signoff
    if(len.H>=5 && len.H>=len.S){
      // transfer to hearts (bid 2D)
      if(h>=10 || (h>=8 && len.H>=6)) { /* will complete after accept */ }
      return B(2,"D");
    }
    if(len.S>=5){
      return B(2,"H"); // transfer to spades
    }
    // Stayman with a 4-card major and invitational+ values
    if((len.H===4||len.S===4) && h>=8) return B(2,"C");
    // quantitative
    if(h>=8 && h<=9) return B(2,"NT");
    if(h>=10 && h<=15) return B(3,"NT");
    if(h>=16 && h<=17) return B(4,"NT"); // invite 6NT
    if(h>=18) return B(6,"NT");
    // 2S puppet: a weak hand (0-7) with a long (6+) minor and no 5-card major —
    // forces opener to 3C so we can sign off in the right minor.
    if(h<=7 && (len.C>=6 || len.D>=6) && len.H<5 && len.S<5) return B(2,"S");
    return P;
  }
  function respTo2NT(ev, ctx){
    const h=ev.hcp, len=ev.len;
    if(len.H>=5) return B(3,"D"); // transfer
    if(len.S>=5) return B(3,"H");
    if((len.H===4||len.S===4) && h>=4) return B(3,"C"); // Stayman
    if(h>=4 && h<=10) return B(3,"NT");
    if(h>=11) return B(4,"NT"); // quantitative slam invite
    return P;
  }
  function respTo2C(ev, ctx){
    // if partner (opener) has already rebid, handle continuation; else give first response
    const opnRebid = ctx.partnerBids.filter(c=>c.k==="B").length>=2;
    if(!opnRebid){
      const h=ev.hcp;
      if(h>=8 && ev.longest && ev.len[ev.longest]>=5 && ev.top3(ev.longest)>=1){
        // positive
        const s=ev.longest;
        return B(2, s==="C"?"C":s==="D"?"D":s); // natural positive
      }
      return B(2,"D"); // waiting
    }
    // after opener's rebid, keep bidding toward game (game-forcing)
    return continueGameForce(ev, ctx);
  }
  function respToWeak2(ev, ctx, op){
    const h=ev.hcp, s=op.strain, fit=ev.len[s];
    // raises are preemptive; 2NT is the feature/strength ask (forcing)
    if(h>=15 || (h>=13 && fit>=3)) return B(2,"NT"); // ask
    if(fit>=4) return B(4,s);   // extend the preempt / to play
    if(fit>=2 && h>=8 && h<=14 && raiseValue(ev)>= (op.level*0+8)) return B(3,s); // mild raise (preemptive)
    if(h>=14 && ev.balanced) return B(3,"NT");
    return P;
  }
  function respToPreempt(ev, ctx, op){
    const h=ev.hcp, s=op.strain, fit=ev.len[s];
    if(fit>=3 && (h+ev.lp)>=12) return B(4,s); // raise to game if likely
    if(h>=16 && ev.balanced && ev.stopper(s)) return B(3,"NT");
    if(fit<3 && h<16) return P;
    return P;
  }
  function respTo1Suit(ev, ctx, op){
    const s=op.strain, h=ev.hcp, len=ev.len;
    const rv = raiseValue(ev);
    const majorOpen = isMajor(s);
    // ---- support for opener's MAJOR ----
    if(majorOpen && len[s]>=3){
      if(rv>=13) return B(2,"NT");             // Jacoby 2NT game-forcing raise
      if(rv>=10 && rv<=11 && len[s]>=3) return B(3,s); // limit raise
      if(rv>=6 && rv<=9) return B(2,s);        // single raise
      if(rv<6 && len[s]>=4) return B(2,s);     // stretch weak raise with 4 trumps
    }
    // ---- 1-over-1 new suit at the one level (spades over hearts/minors, etc.) ----
    // respond a 4+ card suit up the line at the 1 level with 6+
    if(h>=6){
      // 1-level responses: bid a 4+ major at the 1 level, cheapest, spades priority if 5+
      const oneLevel = [];
      if(s!=="H" && len.H>=4 && higher("H",s)) oneLevel.push("H");
      if(s!=="S" && len.S>=4 && higher("S",s)) oneLevel.push("S");
      if(s==="C" && len.D>=4) oneLevel.push("D"); // 1D over 1C
      // pick longest, then up the line
      oneLevel.sort((a,b)=> (len[b]-len[a]) || (ORDER.indexOf(a)-ORDER.indexOf(b)));
      if(oneLevel.length) return B(1, oneLevel[0]);
    }
    // ---- 2-over-1 new suit (needs 10+; game-forcing-ish, treat as forcing) ----
    if(h>=10){
      const twoLevel = ORDER.filter(x=> x!==s && lowerRankThanOpening(x,s) && len[x]>=4 );
      // prefer a good 5+ suit; only bid a minor at 2-level if 4+
      twoLevel.sort((a,b)=> (len[b]-len[a]) || (ORDER.indexOf(b)-ORDER.indexOf(a)));
      for(const x of twoLevel){
        if(len[x]>=5 || (isMinor(x)&&len[x]>=4)) return B(2,x);
      }
    }
    // ---- support opener's MINOR (only if no major to show and enough) ----
    if(isMinor(s) && len[s]>=4){
      if(rv>=13 && !hasFourMajor(ev)) return B(3, s);  // strong minor raise (inverted-ish; keep simple)
      if(rv>=6 && rv<=10 && !hasFourMajor(ev)) return B(2, s);
    }
    // ---- notrump responses (no fit, no biddable suit) ----
    if(ev.balanced || !hasBiddableSuit(ev,s)){
      if(h>=6 && h<=9) return B(1,"NT");     // 1NT: 6-9, not forcing
      if(h>=13 && h<=15 && ev.balanced && allStopped(ev,s)) return B(2,"NT");
      if(h>=16 && h<=18 && ev.balanced && allStopped(ev,s)) return B(3,"NT");
    }
    if(h>=6 && h<=9) return B(1,"NT");
    return P;
  }
  // after I asked Blackwood (my last bid 4NT) and partner answered at the 5-level, place slam/game.
  function handleBlackwoodResult(ev, ctx){
    const myLast=ctx.myLast, pl=ctx.partnerLast;
    if(!(myLast && myLast.strain==="NT" && myLast.level===4)) return null;
    if(!(pl && pl.level===5 && pl.strain!=="NT")) return null;
    const idx={C:0,D:1,H:2,S:3}[pl.strain];           // 5C=0/4 aces,5D=1,5H=2,5S=3
    const partnerAces = idx;                            // (0 or 4 both map to 5C; treat as ≥? assume worst=0)
    const myAces = countAces(ev);
    const total = myAces + partnerAces;
    // agreed trump: prefer a real suit fit
    const fit=findFit(ev,ctx);
    const trump = fit ? fit.suit : lastOurSuit(ctx) || ev.longest;
    const mk=(L)=> bidVal(B(L,trump))>bidVal(ctx.info.lastBid)?B(L,trump):P;
    if(total<=2) return mk(5);           // missing 2+ aces → sign off in 5
    if(total>=4) return mk(7);           // all aces → grand
    return mk(6);                        // small slam
  }
  function lastOurSuit(ctx){ const all=[...ctx.myBids,...ctx.partnerBids].filter(c=>c.k==="B"&&c.strain!=="NT"); return all.length?all[all.length-1].strain:null; }
  
  /* responder's rebid: partner opened, I responded, partner rebid — now place the contract. */
  /* ---- Fourth Suit Forcing (FSF) ---- */
  // Responder bids the only unbid suit at the 2 level (artificial, game-forcing) to
  // ask opener for more, when holding game values but no stopper in the 4th and no fit.
  function fsfBid(ev, ctx, op){
    const myB = ctx.myBids.filter(c=>c.k==="B"&&c.strain!=="NT");
    const opB = ctx.partnerBids.filter(c=>c.k==="B"&&c.strain!=="NT");
    if(myB.length!==1 || opB.length<2) return null;
    const bidSuits = new Set([...myB.map(c=>c.strain), ...opB.map(c=>c.strain)]);
    if(bidSuits.size!==3) return null;                       // exactly three suits bid
    const fourth = ORDER.find(s=> !bidSuits.has(s));
    if(!fourth) return null;
    if(ev.hcp<12) return null;                               // game-forcing values
    if(ev.stopper(fourth)) return null;                      // stopper → bid NT naturally
    const openerSuits=[...new Set(opB.map(c=>c.strain))];
    if(openerSuits.some(s=> ev.len[s]>=4)) return null;      // clear fit → raise instead
    const L=cheapestLevel(fourth, ctx);
    if(L<2) return null;                                     // FSF is 2-level or higher
    return B(L, fourth);
  }
  // Opener answers FSF: notrump with a stopper, else raise responder, rebid, or show shape.
  function answerFSF(ev, ctx, myOpen){
    const opB = ctx.myBids.filter(c=>c.k==="B"&&c.strain!=="NT");
    const rpB = ctx.partnerBids.filter(c=>c.k==="B"&&c.strain!=="NT");
    const pl = ctx.partnerLast;
    if(!pl || pl.strain==="NT" || pl.level<2) return null;
    if(opB.length!==2 || rpB.length!==2) return null;
    const before = new Set([...opB.map(c=>c.strain), ...rpB.slice(0,-1).map(c=>c.strain)]);
    if(before.size!==3 || before.has(pl.strain)) return null; // partner's last bid is the 4th suit
    const fourth = pl.strain, respFirst = rpB[0].strain;
    if(ev.stopper(fourth)) return B(cheapestLevel("NT",ctx),"NT");
    if(ev.len[respFirst]>=3) return B(cheapestLevel(respFirst,ctx), respFirst);
    if(ev.len[myOpen.strain]>=6) return B(cheapestLevel(myOpen.strain,ctx), myOpen.strain);
    if(ev.len[fourth]>=4) return B(cheapestLevel(fourth,ctx), fourth);
    return B(cheapestLevel(opB[1].strain,ctx), opB[1].strain);
  }

  /* Responder's reverse: after a 1-level suit response and opener's rebid, bidding a NEW
     suit that ranks HIGHER than the first response — at the 2 level, which forces opener to
     the 3 level to give preference — shows a game-forcing hand with a second suit and extra
     values ("we're going at least to game; keep describing"). Only offered when responder
     has no fit with opener to show instead. */
  function responderReverse(ev, ctx, op){
    if(ev.hcp < 12) return null;                        // a reverse promises game-forcing extras
    const myReal = ctx.myBids.filter(c=>c.k==="B");
    if(myReal.length !== 1) return null;                // this is responder's SECOND bid
    const first = myReal[0];
    if(first.strain==="NT" || first.level !== 1) return null;  // first response was a 1-level suit
    const ourSuits = new Set([...ctx.myBids, ...ctx.partnerBids]
      .filter(c=>c.k==="B" && c.strain!=="NT").map(c=>c.strain));
    // lowest NEW 4+ suit ranking above the first suit that bids as a genuine 2-level reverse
    for(const s of ORDER){
      if(s==="NT") continue;
      if(ev.len[s]>=4 && higher(s, first.strain) && !ourSuits.has(s) && cheapestLevel(s,ctx)===2)
        return B(2, s);
    }
    return null;
  }

  function responderContinue(ev, ctx, op){
    const bwr=handleBlackwoodResult(ev,ctx); if(bwr) return bwr;
    // 2S puppet follow-up: I bid 2S over partner's 1NT and opener bid the forced 3C.
    // Pass to play 3C (long clubs) or correct to 3D (long diamonds). Signoff.
    const myFirst = ctx.myBids.find(c=>c.k==="B");
    if(op && op.strain==="NT" && op.level===1 && myFirst && myFirst.strain==="S" && myFirst.level===2){
      return (ev.len.D > ev.len.C) ? B(3,"D") : P;
    }
    // I used Stayman (2C over partner's 1NT) and opener answered (2D/2H/2S). The engine only bids Stayman
    // with 8+, so I always have invitational+ values — NEVER pass opener's answer. Take a 4-4 major fit to
    // game/invite; otherwise place 3NT (game) or 2NT (invite).
    if(op && op.strain==="NT" && op.level===1 && myFirst && myFirst.strain==="C" && myFirst.level===2 &&
       !ctx.oppsBid && ctx.myBids.filter(c=>c.k==="B").length===1){
      const ans=ctx.partnerLast, h=ev.hcp;
      if(ans && ans.k==="B" && ans.strain!=="NT" && ans.level===2 && h<=15){  // 16+ slam hands: use existing logic
        if(isMajor(ans.strain) && ev.len[ans.strain]>=4) return (h>=10) ? B(4,ans.strain) : B(3,ans.strain);
        return (h>=10) ? B(3,"NT") : B(2,"NT");
      }
    }
    // Fourth suit forcing: three suits bid, game-forcing values, no stopper in the
    // fourth suit and no clear fit — bid the fourth suit artificially to force & ask.
    const fsf = fsfBid(ev, ctx, op);
    if(fsf) return fsf;
    const est=estimatePartner(ctx);
    const combinedMin = ev.hcp + est.min;
    const combinedMax = ev.hcp + est.max;
    // if partner just asked Blackwood/Gerber, answer
    const bw=blackwoodResponse(ev,ctx); if(bw) return bw;
    const gb=gerberResponse(ev,ctx); if(gb) return gb;
    // did I show/find a fit? look for a suit where partner bid it and I have 3+, or I bid it and partner raised
    const fit = findFit(ev, ctx);
    // game-forcing two-suiter with no fit: reverse into the higher suit to keep describing
    if(!fit){ const rev = responderReverse(ev, ctx, op); if(rev) return rev; }
    let call = placeContract(ev, ctx, combinedMin, combinedMax, fit);
    // 2-over-1 obligation: after a 2-level new-suit response, responder must bid
    // again below game (SAYC). Never pass opener's non-game rebid — describe instead.
    const myReal = ctx.myBids.filter(c=>c.k==="B");
    const twoOverOne = op && op.level===1 && op.strain!=="NT" &&
                       myFirst && myFirst.level===2 && myFirst.strain!=="NT" && myReal.length===1;
    if(call.k==="P" && twoOverOne && !isGameBid(ctx.partnerLast)){
      call = forcedRebid(ev, ctx, fit);
    }
    return call;
  }
  function isGameBid(b){
    if(!b || b.k!=="B") return false;
    if(b.strain==="NT") return b.level>=3;
    return isMajor(b.strain) ? b.level>=4 : b.level>=5;
  }
  // a descriptive, always-legal rebid to honour the 2-over-1 obligation (never passes)
  function forcedRebid(ev, ctx, fit){
    const legalB=(b)=> bidVal(b)>bidVal(ctx.info.lastBid);
    const pB = ctx.partnerBids.filter(c=>c.k==="B");
    const openerFirst = pB[0], openerLast = pB[pB.length-1];
    if(fit && fit.suit){ const b=B(cheapestLevel(fit.suit,ctx),fit.suit); if(legalB(b)) return b; }
    const mySuit = ctx.myBids.filter(c=>c.k==="B"&&c.strain!=="NT").map(c=>c.strain)[0];
    if(mySuit && ev.len[mySuit]>=6){ const b=B(cheapestLevel(mySuit,ctx),mySuit); if(legalB(b)) return b; }
    if(ev.balanced){ const b=B(cheapestLevel("NT",ctx),"NT"); if(legalB(b)) return b; }
    if(openerLast && openerLast.strain!=="NT" && ev.len[openerLast.strain]>=3){ const b=B(cheapestLevel(openerLast.strain,ctx),openerLast.strain); if(legalB(b)) return b; }
    if(openerFirst && openerFirst.strain!=="NT" && ev.len[openerFirst.strain]>=2){ const b=B(cheapestLevel(openerFirst.strain,ctx),openerFirst.strain); if(legalB(b)) return b; }
    const nt=B(cheapestLevel("NT",ctx),"NT"); return legalB(nt)?nt:P;
  }
  // find an agreed/likely trump fit (suit + our combined length estimate)
  // partner's SHOWN length in suit s, from auction role (fractional = average given the bid).
  // Calibrated vs actual combined length (meas_fit.mjs): RMSE 1.22->0.88, bias +0.47->~0.
  function shownLen(ctx, s){
    const pB = ctx.partnerBids.filter(c=>c.k==="B");
    if(!pB.length) return 3.3;
    const partnerIsOpener = ctx.openerSeat===ctx.partner;
    const firstInS = pB.find(c=>c.strain===s);
    const mySuits = ctx.myBids.filter(c=>c.k==="B"&&c.strain!=="NT").map(c=>c.strain);
    if(!firstInS) return 3.3;
    const idx = pB.indexOf(firstInS);
    if(idx===0 && partnerIsOpener){
      if(firstInS.level===1){ if(s==="S"||s==="H") return 5.4; if(s==="D") return 4.4; return 3.6; }
      if(firstInS.level===2){ if(s==="C") return 3.3; return 6.0; }   // 2C artificial; else weak two
      if(firstInS.level>=3) return 6.8;                               // preempt
    }
    if(idx===0 && !partnerIsOpener){ return firstInS.level===1 ? 5.4 : 6.0; } // overcall
    if(mySuits.includes(s)) return 3.5;                              // partner raised my suit
    return 4.4;                                                      // partner's new-suit response/rebid
  }
  function findFit(ev, ctx){
    const pB = ctx.partnerBids.filter(c=>c.k==="B");
    // the strong, artificial 2C opening is NOT a real club suit
    const strong2C = ctx.openerSeat===ctx.partner && pB[0] && pB[0].level===2 && pB[0].strain==="C";
    const partnerSuits = pB.filter((c,i)=> c.strain!=="NT" && !(strong2C && i===0)).map(c=>c.strain);
    const mySuits = ctx.myBids.filter(c=>c.k==="B" && c.strain!=="NT").map(c=>c.strain);
    // a raise happened: partner bid a suit I have 4+, or I bid a suit partner raised.
    // len = my length + partner's SHOWN length (calibrated), used by the trick estimate.
    for(const s of partnerSuits){ if(ev.len[s]>=(isMajor(s)?3:4)) return {suit:s, len:ev.len[s]+shownLen(ctx,s)}; }
    for(const s of mySuits){ if(partnerSuits.includes(s)) return {suit:s, len:ev.len[s]+shownLen(ctx,s)}; }
    for(const s of ["S","H"]){ if(ev.len[s]>=5 && partnerSuits.includes(s)) return {suit:s,len:ev.len[s]+shownLen(ctx,s)}; }
    return null;
  }
  // choose invite/game/slam/pass at the cheapest legal level given combined strength
  function placeContract(ev, ctx, cmin, cmax, fit){
    const legalNT=(L)=> bidVal(B(L,"NT"))>bidVal(ctx.info.lastBid);
    const raise=(s,L)=> B(L,s);
    // with 33+/37+ combined and a balanced hand, stoppers are guaranteed across the partnership
    const ntSlamOK = allStopped(ev,"") || ev.balanced;
    // GRAND SLAM zone (37+): drive to 7 when balanced/stopped or via Blackwood in a major fit
    if(cmin>=37){
      if(fit && isMajor(fit.suit) && bidVal(B(4,"NT"))>bidVal(ctx.info.lastBid)) return B(4,"NT"); // Blackwood → 7 after aces
      if(ntSlamOK && legalNT(7)) return B(7,"NT");
      if(fit && isMajor(fit.suit) && bidVal(B(7,fit.suit))>bidVal(ctx.info.lastBid)) return B(7,fit.suit);
    }
    // SMALL SLAM zone
    if(cmin>=33){
      if(fit && isMajor(fit.suit) && bidVal(B(4,"NT"))>bidVal(ctx.info.lastBid)) return B(4,"NT"); // Blackwood
      if(ntSlamOK && legalNT(6)) return B(6,"NT");
      if(fit && isMajor(fit.suit) && bidVal(B(6,fit.suit))>bidVal(ctx.info.lastBid)) return B(6,fit.suit);
    }
    if(fit && isMajor(fit.suit)){
      const s=fit.suit;
      if(cmin>=25) return legalOrPass(B(4,s),ctx);
      if(cmax>=24 && cmin>=22) return legalOrPass(B(3,s),ctx); // invite (only if not already at 3)
      return signoff(B(2,s),ctx);
    }
    if(fit && isMinor(fit.suit) && !balancedGameNT(ev,ctx,cmin)){
      const s=fit.suit;
      if(cmin>=29) return legalOrPass(B(5,s),ctx);
      return signoff(B(3,s),ctx);
    }
    // NT placement
    // Partner's NT bid (opener's NT rebid / a NT opening/response) promises stoppers + a balanced hand,
    // so responder may raise NT on combined values WITHOUT independently stopping every suit. Without this,
    // an unbalanced responder passes partner's NT rebid with invitational+ values (the missed-3NT pocket).
    const partnerShowedNT = ctx.partnerLast && ctx.partnerLast.k==="B" && ctx.partnerLast.strain==="NT";
    // Standard NT-stopper test: the partnership only needs the UNBID suits stopped (each bid suit is
    // presumed guarded by whoever bid it). Without this, an invitational responder with stoppers in the
    // unbid suits but an unbalanced shape passes opener's minimum suit rebid (the 1C-1S-2C-P cluster).
    const ourSuits = new Set([...ctx.myBids, ...ctx.partnerBids].filter(c=>c.k==="B" && c.strain!=="NT").map(c=>c.strain));
    const unbidStopped = ORDER.every(s=> ourSuits.has(s) || ev.stopper(s));
    if(allStopped(ev,"") || ev.balanced || partnerShowedNT || unbidStopped){
      if(cmin>=25) return legalNT(3)?B(3,"NT"):P;
      if(cmin>=23) return legalNT(2)?B(2,"NT"):P;
      return P;
    }
    // no fit, not enough for NT → pass or take a cheap preference
    return P;
  }
  function balancedGameNT(ev,ctx,cmin){ return ev.balanced && cmin>=25 && allStopped(ev,""); }
  function legalOrPass(bid,ctx){ return bidVal(bid)>bidVal(ctx.info.lastBid) ? bid : P; }
  function signoff(bid,ctx){ return bidVal(bid)>bidVal(ctx.info.lastBid) ? bid : P; }
  
  function higher(a,b){ return ORDER.indexOf(a)>ORDER.indexOf(b); }
  function lowerRankThanOpening(x, s){ return ORDER.indexOf(x)<ORDER.indexOf(s); }
  function hasFourMajor(ev){ return ev.len.H>=4 || ev.len.S>=4; }
  function hasBiddableSuit(ev,s){ return ORDER.some(x=> x!==s && ev.len[x]>=4); }
  function allStopped(ev,openSuit){ return ORDER.every(x=> x===openSuit || ev.stopper(x)); }
  
  /* ---------------- OPENER'S REBID ---------------- */
  function openerRebid(ev, ctx){
    const myOpen = ctx.myBids.find(c=>c.k==="B");
    // partner made a negative double (I opened 1-suit, LHO overcalled, partner doubled)
    const pLastCall = ctx.partnerBids[ctx.partnerBids.length-1];
    if(myOpen && myOpen.level===1 && myOpen.strain!=="NT" && pLastCall && pLastCall.k==="D" &&
       ctx.lhoLast && ctx.lhoLast.k==="B" && ctx.lhoLast.strain!=="NT" &&
       !ctx.myBids.slice(1).some(c=>c.k==="B")){
      const r = respondToNegDouble(ev, ctx, myOpen);
      if(r) return r;
    }
    // partner used fourth suit forcing → answer it (NT with a stopper, raise, or show shape)
    if(myOpen){ const fa = answerFSF(ev, ctx, myOpen); if(fa) return fa; }
    const pr = ctx.partnerLast;
    // partner passed / no response info → often pass or rebid
    if(!pr){ return P; }
    const h=ev.hcp, tp=ev.tp, s=myOpen?myOpen.strain:null;
  
    // If we opened 1NT/2NT and partner used Stayman/transfer, respond to the convention.
    if(myOpen && myOpen.strain==="NT"){
      return ntOpenerRebid(ev, ctx, myOpen);
    }
    if(myOpen && myOpen.level===2 && myOpen.strain==="C"){
      return twoCOpenerRebid(ev, ctx);
    }
    // partner's uncontested 2NT over our 1M opening = Jacoby 2NT (game-forcing raise, 4+ trumps).
    // openerRebid had no handler → it fell into the new-suit branch and could PASS. Never pass: drive to game.
    if(myOpen && myOpen.level===1 && isMajor(s) && pr.strain==="NT" && pr.level===2 && !ctx.oppsBid){
      return B(4,s);
    }
    // Natural invitational 2NT over our MINOR opening, UNCONTESTED (paired-IMP A/B, 5 seeds/30k deals:
    // uncontested +269 IMP; contested -28 → gated to !oppsBid). Accept to 3NT with a max, else pass.
    if(myOpen && isMinor(s) && pr.strain==="NT" && pr.level===2 && !ctx.oppsBid){
      return (ev.hcp>=14) ? legalOrPass(B(3,"NT"),ctx) : P;
    }
  
    // if I asked Blackwood and partner answered → place slam
    const bwr = handleBlackwoodResult(ev, ctx);
    if(bwr) return bwr;
    // Blackwood / slam responses if partner asked
    const bw = blackwoodResponse(ev, ctx);
    if(bw) return bw;
    const gb = gerberResponse(ev, ctx);
    if(gb) return gb;
  
    // partner raised our suit → place the contract on combined strength
    if(pr.strain===s){
      const est=estimatePartner(ctx);
      const cmin=ev.tp+est.min, cmax=ev.tp+est.max;
      const fit={suit:s, len: ev.len[s]+4};
      return placeContract(ev, ctx, cmin, cmax, fit);
    }
    // partner responded 1NT (6-9): rebid
    if(pr.strain==="NT" && pr.level===1){
      // rebid a 6-card suit, or a lower new suit, or pass
      if(ev.len[s]>=6) return B(2,s);
      const second = secondSuit(ev, s, 2);
      if(second) return second;
      return P;
    }
    // partner bid a new suit
    if(pr.strain!==s){
      const rs=pr.strain;
      // raise partner's major with 4-card support
      if(isMajor(rs) && ev.len[rs]>=4){
        if(tp>=19) return B(4,rs);
        if(tp>=17) return B(3,rs);
        return B(2,rs);
      }
      // rebid NT with balanced extras
      if(ev.balanced){
        if(tp>=18 && tp<=19) return jumpNT(ev,ctx);
        if(tp>=12 && tp<=14 && canRebid1NT(ctx)) return B(1,"NT");
        if(tp>=12 && tp<=14) return B(ntLevelToRebid(ctx),"NT");
      }
      // rebid own 6-card suit
      if(ev.len[s]>=6){ return B(rebidLevel(ctx,s), s); }
      // show a second suit (lower ranking, non-reverse if minimum)
      const second = secondSuit(ev, s, rebidLevel(ctx,null));
      if(second) return second;
      // raise partner's minor
      if(isMinor(rs) && ev.len[rs]>=4) return B(minRaiseLevel(ctx,rs), rs);
      // fallback NT
      if(allStopped(ev,s)) return B(ntLevelToRebid(ctx),"NT");
      // a 2-over-1 (new suit at the 2 level, uncontested first response) is FORCING — opener must not pass.
      const p2o1 = myOpen && myOpen.level===1 && !ctx.oppsBid && pr.level===2 && pr.strain!=="NT" &&
                   lowerRankThanOpening(pr.strain,s) && ctx.partnerBids.filter(c=>c.k==="B").length===1;
      if(p2o1){
        if(ev.len[s]>=5) return B(rebidLevel(ctx,s), s);                 // rebid a 5-card suit (2M)
        const forced2 = secondSuit(ev, s, 2);
        if(forced2) return forced2;                                      // any second suit
        if(bidVal(B(2,"NT"))>bidVal(ctx.info.lastBid)) return B(2,"NT"); // last-resort minimum 2NT
      }
      return P;
    }
    return P;
  }
  function allStoppedExcept(ev,s){ return ORDER.every(x=> x===s || ev.stopper(x)); }
  function canRebid1NT(ctx){ return bidVal(B(1,"NT")) > bidVal(ctx.info.lastBid); }
  function ntLevelToRebid(ctx){ // lowest legal NT level
    for(let L=1;L<=3;L++){ if(bidVal(B(L,"NT"))>bidVal(ctx.info.lastBid)) return L; } return 3;
  }
  function jumpNT(ctx){ return B(2,"NT"); }
  function rebidLevel(ctx, s){ for(let L=2;L<=4;L++){ if(s? bidVal(B(L,s))>bidVal(ctx.info.lastBid): true) return L; } return 2; }
  function minRaiseLevel(ctx,s){ for(let L=2;L<=5;L++){ if(bidVal(B(L,s))>bidVal(ctx.info.lastBid)) return L; } return 3; }
  function secondSuit(ev, openSuit, minLevel){
    // pick a 4+ suit other than opener's, lowest ranking that keeps it a non-reverse when minimum
    const cand = ORDER.filter(x=> x!==openSuit && ev.len[x]>=4);
    cand.sort((a,b)=> (ev.len[b]-ev.len[a]) || (ORDER.indexOf(a)-ORDER.indexOf(b)));
    if(!cand.length) return null;
    const x=cand[0];
    return B(2, x);
  }
  
  function ntOpenerRebid(ev, ctx, myOpen){
    // partner's last convention call
    const pl = ctx.partnerLast;
    if(!pl) return P;
    // Stayman (2C over 1NT, 3C over 2NT)
    const stayLevel = myOpen.level===1?2:3;
    if(pl.strain==="C" && pl.level===stayLevel){
      if(ev.len.H===4 && ev.len.S===4) return B(stayLevel,"H"); // show hearts first w/ both
      if(ev.len.H===4) return B(stayLevel,"H");
      if(ev.len.S===4) return B(stayLevel,"S");
      return B(stayLevel,"D"); // no 4-card major
    }
    // Transfers: over 1NT: 2D→H, 2H→S ; over 2NT: 3D→H, 3H→S
    const tRankBase = myOpen.level===1?2:3;
    if(pl.level===tRankBase && pl.strain==="D") return B(tRankBase,"H"); // accept transfer to hearts
    if(pl.level===tRankBase && pl.strain==="H") return B(tRankBase,"S"); // accept transfer to spades
    // partner invited 2NT/4NT (quantitative) → accept with a max
    if(pl.strain==="NT" && pl.level===2 && myOpen.level===1){ return (ev.hcp>=17)? B(3,"NT"):P; }
    if(pl.strain==="NT" && pl.level===4){ return (ev.hcp>=17)? B(6,"NT"):P; }
    // 2S puppet (long weak minor over 1NT): opener is forced to 3C
    if(myOpen.level===1 && pl.strain==="S" && pl.level===2) return B(3,"C");
    // after we accepted a transfer and partner raised NT / bid game, pass or convert
    return P;
  }
  function twoCOpenerRebid(ev, ctx){
    const pl = ctx.partnerLast;
    const myBids = ctx.myBids.filter(c=>c.k==="B");
    if(myBids.length===1){
      // first rebid after 2C
      if(ev.balanced){
        if(ev.hcp>=22 && ev.hcp<=24) return B(2,"NT");
        if(ev.hcp>=25) return B(3,"NT");
      }
      // natural: bid longest suit at cheapest level (game forcing)
      const s=ev.longest;
      return B(cheapestSuitLevel(ctx,s), s);
    }
    // later — drive to game
    return continueGameForce(ev, ctx);
  }
  function cheapestSuitLevel(ctx,s){ for(let L=2;L<=4;L++){ if(bidVal(B(L,s))>bidVal(ctx.info.lastBid)) return L; } return 3; }
  
  /* ---------------- OVERCALLS / DOUBLES / ADVANCES ---------------- */
  /* ---- Michaels cuebid & Unusual 2NT: direct-seat 5-5 two-suiters ----
     Michaels: cuebid of opener's suit. Over a minor = both majors; over a major
     = the other major + an unspecified minor. Unusual 2NT: jump to 2NT = 5-5 in
     the two lowest UNBID suits. Only in the direct seat over a 1-level suit
     opening, and only on genuine 5-5 shape, so natural overcalls are untouched. */
  function michaelsOrUnusual(ev, ctx){
    const opp = ctx.info.lastBid;
    if(!opp || opp.level!==1 || opp.strain==="NT") return null;   // their opening: 1 of a suit
    if(ctx.openerSeat!==ctx.rho) return null;                     // direct seat only
    const len=ev.len, h=ev.hcp, their=opp.strain;
    const unbid = ["C","D","H","S"].filter(x=>x!==their);
    const lowTwo = unbid.slice(0,2);                              // two lowest unbid suits
    // Unusual 2NT first (shapes are mutually exclusive with Michaels)
    if(len[lowTwo[0]]>=5 && len[lowTwo[1]]>=5 && h>=8) return B(2,"NT");
    if(isMinor(their)){
      if(len.H>=5 && len.S>=5 && h>=8) return B(2, their);        // both majors
    } else {
      const otherMajor = their==="H" ? "S" : "H";
      const bestMinor = len.C>=len.D ? "C" : "D";
      if(len[otherMajor]>=5 && len[bestMinor]>=5 && h>=10) return B(2, their); // major + minor
    }
    return null;
  }
  /* ---- Cappelletti: defence to an opponent's 1NT opening (direct seat) ----
     Dbl = an equal balanced hand (15+); 2C = a one-suiter (relay 2D to find it);
     2D = both majors; 2H = hearts + a minor; 2S = spades + a minor; 2NT = both
     minors. Only over a 1-level 1NT opening we're sitting directly over. */
  function cappelletti(ev, ctx){
    const opening = openingBidOf(ctx);
    if(!opening || opening.strain!=="NT" || opening.level!==1) return null;
    if(!ctx.info.lastBid || bidVal(ctx.info.lastBid)!==bidVal(opening)) return null; // directly over their 1NT
    const len=ev.len, h=ev.hcp, minor=Math.max(len.C,len.D);
    if(ev.balanced && h>=15) return DBL;                                   // equal hand
    if(len.H>=5 && len.S>=5 && h>=9) return B(2,"D");                      // both majors
    if(len.H>=5 && minor>=5 && h>=9) return B(2,"H");                      // hearts + a minor
    if(len.S>=5 && minor>=5 && h>=9) return B(2,"S");                      // spades + a minor
    if(len.C>=5 && len.D>=5 && h>=9) return B(2,"NT");                     // both minors
    if(len[ev.longest]>=6 && ev.top5(ev.longest)>=2 && h>=8) return B(2,"C"); // one-suiter
    return null;
  }
  function advanceCappelletti(ev, ctx){
    const pFirst = ctx.partnerBids.find(c=>c.k==="B");
    const pLastCall = ctx.partnerBids[ctx.partnerBids.length-1];
    if(pLastCall && pLastCall.k==="D") return P;                          // penalty double → defend
    if(!pFirst || pFirst.level!==2) return null;
    if(pFirst.strain==="C") return B(cheapestLevel("D",ctx),"D");         // relay to find the one-suiter
    if(pFirst.strain==="D"){ const m=ev.len.S>=ev.len.H?"S":"H"; return B(cheapestLevel(m,ctx),m); } // majors → longer
    if(pFirst.strain==="NT"){ const m=ev.len.D>=ev.len.C?"D":"C"; return B(cheapestLevel(m,ctx),m); } // minors → longer
    return P;                                                             // 2H/2S show a known major → pass, playable
  }
  function cappellettiContinue(ev, ctx){
    const opening = openingBidOf(ctx);
    const myFirst = ctx.myBids.find(c=>c.k==="B");
    if(!opening || opening.strain!=="NT" || !myFirst) return null;
    if(myFirst.level===2 && myFirst.strain==="C"){                         // I bid the one-suiter 2C
      const pl=ctx.partnerLast;
      if(pl && pl.level===2 && pl.strain==="D"){ const s=ev.longest; return B(cheapestLevel(s,ctx), s); }
    }
    return null;
  }

  function advanceTwoSuiter(ev, ctx, oppOpen, isUnusual){
    const their = oppOpen.strain;
    // Michaels over a major: partner has the OTHER major + an unknown minor
    if(!isUnusual && isMajor(their)){
      const om = their==="H" ? "S" : "H";
      if(ev.len[om]>=3){ const L=cheapestLevel(om,ctx); return B(ev.hcp>=11?Math.min(4,L+1):L, om); }
      return B(2,"NT");                         // ask partner which minor
    }
    let suits;
    if(isUnusual){ suits = ["C","D","H","S"].filter(x=>x!==their).slice(0,2); }
    else { suits = ["H","S"]; }                 // Michaels over a minor = both majors
    let pick=suits[0], best=-1;
    for(const s of suits){ if(ev.len[s]>best){ best=ev.len[s]; pick=s; } }
    const L=cheapestLevel(pick, ctx);
    const lvl = (ev.hcp>=11 && best>=4) ? Math.min(4, L+1) : L;
    return B(lvl, pick);
  }
  /* the two-suiter bidder's own continuation: answer partner's 2NT minor-ask,
     otherwise let partner place the contract. */
  function twoSuiterContinue(ev, ctx){
    const myFirst = ctx.myBids.find(c=>c.k==="B");
    const oppOpen = openingBidOf(ctx);
    if(!myFirst || !oppOpen || oppOpen.level!==1 || oppOpen.strain==="NT") return null;
    const wasMichaels = myFirst.strain===oppOpen.strain && myFirst.level===2;
    const wasUnusual  = myFirst.strain==="NT" && myFirst.level===2;
    if(!wasMichaels && !wasUnusual) return null;
    const pl = ctx.partnerLast;
    if(wasMichaels && isMajor(oppOpen.strain) && pl && pl.strain==="NT"){
      const m = ev.len.C>=ev.len.D ? "C" : "D";        // reveal my minor
      return B(cheapestLevel(m,ctx), m);
    }
    return P;                                            // partner has placed the contract
  }

  /* Lead-directing double of the opponents' conventional response to a 1NT opening.
     Position: our LHO opened 1NT, partner passed, RHO made a conventional 2-level bid
     (Stayman 2C / red-suit transfer 2D or 2H) and it's our first turn. With a strong holding
     in the doubled suit we double to ask partner to lead that suit. Gated very tightly (LHO
     opener, 1NT, partner silent, RHO's conventional bid is the last call, and we hold 5+ with
     two of the top three honours) so it cannot fire in ordinary competitive auctions. */
  function leadDirectingDouble(ev, ctx){
    if(ctx.openerSeat !== ctx.lho) return null;                 // LHO opened
    const openBid = ctx.lhoBids.find(c=>c.k==="B");
    if(!openBid || openBid.level!==1 || openBid.strain!=="NT") return null;   // ...a 1NT opening
    if(ctx.partnerBids.some(c=>c.k==="B")) return null;         // partner stayed out
    if(ctx.info.lastBidder !== ctx.rho) return null;            // RHO made the last bid...
    const conv = ctx.info.lastBid;
    if(!conv || conv.level!==2 || !(conv.strain==="C"||conv.strain==="D"||conv.strain==="H")) return null; // ...a conventional 2C/2D/2H
    const s = conv.strain;
    if(ev.len[s]>=5 && ev.top3(s)>=2) return DBL;               // strong suit → direct its lead
    return null;
  }

  function overcallBid(ev, ctx){
    const oppBid = ctx.info.lastBid;
    const oppOpen = firstOppBid(ctx);
    const h=ev.hcp;
    // Cappelletti over their 1NT opening
    const cp = cappelletti(ev, ctx);
    if(cp) return cp;
    // two-suited conventions take priority over a natural one-suit overcall
    const mu = michaelsOrUnusual(ev, ctx);
    if(mu) return mu;
    // 1NT overcall: 15-18 balanced with a stopper in their suit
    if(ev.balanced && h>=15 && h<=18 && ev.stopper(oppOpen.strain) && oppBid.level===1) return B(1,"NT");
    // takeout double: opening values, short in their suit, support for unbid suits
    if(h>=12 && ev.len[oppOpen.strain]<=2 && shapeForTakeout(ev, oppOpen.strain) && oppBid.level<=2){
      return DBL;
    }
    // simple suit overcall: a good 5+ suit with sound values (no more junk 1-level overcalls)
    for(const s of ["S","H","D","C"]){
      if(s===oppOpen.strain) continue;
      if(ev.len[s]>=5 && ev.top5(s)>=2){
        // suit overcall at the opponents' level: HCP floor scales with how high we're forced to bid
        const floor = oppBid.level<=1 ? 8 : oppBid.level===2 ? 11 : 14;
        if(h>=floor && higherStrainSameLevel(s, oppBid)) return B(oppBid.level, s);
        // else two level needs a stronger hand/suit
        if(h>=10 && ev.top3(s)>=2) return B(oppBid.level+ (bidVal(B(oppBid.level,s))>bidVal(oppBid)?0:1), s);
      }
    }
    // weak jump overcall with a good 6-card suit
    for(const s of ["S","H","D","C"]){
      if(s===oppOpen.strain) continue;
      if(ev.len[s]>=6 && h>=6 && h<=10 && ev.top3(s)>=1){
        const L=oppBid.level+1; if(bidVal(B(L,s))>bidVal(oppBid)) return B(L,s);
      }
    }
    return P;
  }
  function firstOppBid(ctx){ for(const c of [...ctx.lhoBids,...ctx.rhoBids]){ if(c.k==="B") return c; }
    // fallback: scan info
    return ctx.info.lastBid; }
  // the genuine opening bid: the first bid of the auction (by openerSeat)
  function openingBidOf(ctx){
    const ob = ctx.by[ctx.openerSeat];
    if(!ob) return null;
    return ob.find(c=>c.k==="B") || null;
  }
  function shapeForTakeout(ev, theirSuit){ // support (3+) for the other suits, esp. majors
    const others=ORDER.filter(x=>x!==theirSuit);
    const supp=others.filter(x=>ev.len[x]>=3).length;
    return supp>=3 || (isMinor(theirSuit) && ev.len.H>=4 && ev.len.S>=4);
  }
  function higherStrainSameLevel(s, oppBid){ return bidVal(B(oppBid.level,s))>bidVal(oppBid); }
  
  function advancerBid(ev, ctx){
    // partner overcalled or doubled; simple advances
    const pOver = ctx.partnerLast;
    if(!pOver) return P;
    // partner made a Michaels cuebid or Unusual 2NT → pick the right long suit
    const oppOpen = openingBidOf(ctx);
    // partner made a Cappelletti bid over the opponents' 1NT
    if(oppOpen && oppOpen.strain==="NT" && oppOpen.level===1){
      const ac = advanceCappelletti(ev, ctx);
      if(ac) return ac;
    }
    const pFirst = ctx.partnerBids.find(c=>c.k==="B");
    if(pOver.k==="B" && oppOpen && oppOpen.level===1 && oppOpen.strain!=="NT" && pFirst){
      const isMichaels = pFirst.strain===oppOpen.strain && pFirst.level===2;
      const isUnusual  = pFirst.strain==="NT" && pFirst.level===2;
      if(isMichaels || isUnusual) return advanceTwoSuiter(ev, ctx, oppOpen, isUnusual);
    }
    if(pOver.k==="B"){
      const s=pOver.strain, h=ev.hcp;
      if(s!=="NT" && ev.len[s]>=3){
        if(h>=13) return cueRaise(ev,ctx,s);                 // game-forcing values: cue toward game
        // LIMITED raise, disciplined by the Law of Total Tricks: don't contract for more tricks than our
        // combined trump length. partner's shown length = 5 if partner OVERCALLED this suit, else 3 (a
        // raise). This stops the "1S-2S-3S-4S" competitive cascade that was going down repeatedly.
        const pFirst = ctx.partnerBids.find(c=>c.k==="B");
        const pShown = (pFirst && pFirst.strain===s) ? 5 : 3;
        const fit = ev.len[s] + pShown;
        const lawCap = Math.min(3, Math.max(pOver.level, fit-6));   // never past 3 without game values
        // reaching the 3-level competitively also needs some HIGH-CARD values, not just trumps — a huge
        // fit with a bust is a phantom that goes down (undoubled -250s). Cap at 2 unless we hold ~8+ HCP.
        const valueCap = (h>=8 || fit>=10) ? 3 : 2;
        const want = pOver.level+1;                          // competitive/invitational: one higher...
        const target = Math.min(want, lawCap, valueCap);     // ...capped by trump fit AND values
        if(target>pOver.level && bidVal(B(target,s))>bidVal(ctx.info.lastBid)) return B(target, s);
        return P;                                            // Law/values say stop -> pass
      }
      if(h>=9 && ev.balanced) return B(pOver.strain==="NT"?3:1,"NT");
      return P;
    }
    return P;
  }
  function cueRaise(ev,ctx,s){ return B(Math.min(4,3), s); }

  // Is partner's last call a takeout double of the opponents' suit, still standing to me?
  // Returns the doubled opponents' bid (suit to avoid) or null.
  function partnerTakeoutDouble(ctx){
    const calls = ctx.calls;
    let pi=-1; for(let i=calls.length-1;i>=0;i--){ if(calls[i].by===ctx.partner){ pi=i; break; } }
    if(pi<0 || calls[pi].k!=="D") return null;                 // partner's last call wasn't a double
    for(let i=pi+1;i<calls.length;i++){ if(calls[i].k!=="P") return null; }  // must still stand to me (only passes since)
    // the doubled bid = the last opponents' SUIT bid before partner's double (takeout target)
    let dbl=null; for(let i=pi-1;i>=0;i--){ const c=calls[i]; if(c.k==="B" && c.by%2!==ctx.partner%2){ dbl=c; break; } }
    if(!dbl || dbl.strain==="NT") return null;                 // only suit takeout doubles here
    if(dbl.level>=5) return null;                              // high-level doubles are penalty, not takeout
    return dbl;
  }
  // Advance partner's takeout double. Never pass without a penalty holding; bid the best suit at a level
  // scaled by strength (partner promised ~12+ opening values + support for the unbid suits).
  function respondToTakeoutDouble(ev, ctx, dbl){
    const their = dbl.strain, h = ev.hcp;
    // penalty pass (convert): strong length in their suit → defend the doubled contract
    if(ev.len[their]>=4 && ev.top3(their)>=2) return P;
    // choose the best suit to advance: longest non-their suit; prefer a major on a tie, then higher rank.
    const four = ORDER.filter(s=> s!==their && ev.len[s]>=4);
    const pick = (four.length ? four : ORDER.filter(s=>s!==their))
      .slice().sort((a,b)=> (ev.len[b]-ev.len[a]) || ((isMajor(b)?1:0)-(isMajor(a)?1:0)) || (ORDER.indexOf(b)-ORDER.indexOf(a)))[0];
    const cheap = cheapestLevel(pick, ctx);
    const legal=(bid)=> bidVal(bid)>bidVal(ctx.info.lastBid);
    // 12+: game-forcing. Bid game in a 4+ card major; else cuebid their suit to ask; else 3NT with a stopper.
    if(h>=12){
      if(isMajor(pick) && ev.len[pick]>=4 && legal(B(4,pick))) return B(4,pick);
      if(ev.balanced && ev.stopper(their) && legal(B(3,"NT"))) return B(3,"NT");
      const cl=cheapestLevel(their, ctx); if(cl<=3 && legal(B(cl,their))) return B(cl,their); // cuebid = GF ask
    }
    // balanced with their suit stopped → natural NT (6-10 → 1NT, 11-12 → 2NT)
    if(ev.balanced && ev.stopper(their)){
      if(h>=11 && legal(B(2,"NT"))) return B(2,"NT");
      if(h>=6  && legal(B(1,"NT"))) return B(1,"NT");
    }
    // 9-11: invitational jump in the best suit
    if(h>=9 && four.length && legal(B(cheap+1,pick))) return B(cheap+1, pick);
    // 0-8: forced minimum response at the cheapest level (never pass)
    return legal(B(cheap,pick)) ? B(cheap,pick) : P;
  }
  
  /* ---------------- SLAM: Blackwood / Gerber ---------------- */
  // If PARTNER just bid 4NT (Blackwood) and there's an agreed trump/context, answer aces.
  function blackwoodResponse(ev, ctx){
    const pl = ctx.partnerLast;
    if(!pl || !(pl.strain==="NT" && pl.level===4)) return null;
    // only treat as Blackwood if a suit fit was established (not a jump from NT which is quantitative)
    const aces = countAces(ev);
    const step = aces%5; // 0/4→5C,1→5D,2→5H,3→5S
    const map = ["C","D","H","S","C"];
    const strain = (aces===4)?"C":map[aces];
    return B(5, aces===4?"C":map[aces]);
  }
  function gerberResponse(ev, ctx){
    const pl = ctx.partnerLast;
    if(!pl || !(pl.strain==="C" && pl.level===4)) return null;
    // Gerber only over our NT bid
    const myNT = ctx.myBids.some(c=>c.k==="B" && c.strain==="NT");
    if(!myNT) return null;
    const aces=countAces(ev);
    const map=["D","H","S","NT","D"];
    return B(4, map[aces]);
  }
  function countAces(ev){ let a=0; for(const s of ORDER) if(ev.by[s].includes("A")) a++; return a; }
  
  // generic "keep going to game" for GF auctions
  function continueGameForce(ev, ctx){
    const pl=ctx.partnerLast;
    const legal=(c)=> bidVal(c)>bidVal(ctx.info.lastBid);
    const est=estimatePartner(ctx);
    // conservative combined strength: partner's shown floor + my points
    const combined = ev.hcp + (est.bid?est.min:6) + Math.floor(ev.lp/2);
    // is there a known 8-card major fit?
    let fitSuit=null;
    for(const s of ["S","H"]){
      const pBidIt = ctx.partnerBids.some(c=>c.k==="B"&&c.strain===s);
      const iBidIt = ctx.myBids.some(c=>c.k==="B"&&c.strain===s);
      if(pBidIt && ev.len[s]>=3) fitSuit=s;
      else if(iBidIt && pBidIt) fitSuit=s;
    }
    const ntOK = ev.balanced && allStopped(ev,"");
    // ---- NT slam ladder (balanced auctions / partner rebid NT) ----
    if((pl && pl.strain==="NT") || ntOK){
      if(combined>=37 && legal(B(7,"NT"))) return B(7,"NT");
      if(combined>=33 && legal(B(6,"NT"))) return B(6,"NT");
      if(combined>=33 && legal(B(4,"NT"))) return B(4,"NT"); // quantitative invite
      const L=ntLevelToRebid(ctx); return B(Math.max(L,3),"NT");
    }
    // ---- suit fit: Blackwood toward slam, else raise to game ----
    if(fitSuit){
      if(combined>=33 && legal(B(4,"NT"))) return B(4,"NT"); // Blackwood (fit agreed)
      const target=Math.max(4, (pl&&pl.strain===fitSuit)?pl.level:4);
      for(let L=target; L<=7; L++){ if(legal(B(L,fitSuit))) return B(L,fitSuit); }
    }
    // ---- fallbacks (original behavior) ----
    if(pl && pl.strain!=="NT" && ev.len[pl.strain]>=3 && isMajor(pl.strain)){
      if(legal(B(4,pl.strain))) return B(4,pl.strain);
    }
    if(ntOK){ const L=ntLevelToRebid(ctx); return B(Math.max(L,3),"NT"); }
    const s=ev.longest; const L=cheapestSuitLevel(ctx,s); return B(L,s);
  }
  
  
  
  return { chooseBid, evalHand, context, raiseValue, ruleOf20 };
})();


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { BID };
//#endregion gen
