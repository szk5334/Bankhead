//#region gen (auto — removed when bundled to a single bridge.jsx)
import { C } from "../ui/theme.js";
//#endregion gen

const SCO = (function(){
  /* Standard rubber-bridge scoring. */
  
  const isMinor = (st)=> st==="C"||st==="D";
  const isMajor = (st)=> st==="H"||st==="S";
  
  // trick score that goes BELOW the line for a made contract, on the bid level.
  function belowLineTrickScore(level, strain, dbl /*1|2|4*/){
    let per;
    if(strain==="NT") return (40 + 30*(level-1)) * dbl;
    per = isMinor(strain) ? 20 : 30;
    return per * level * dbl;
  }
  
  // Score one played hand. Inputs:
  //   contract {level, strain, dbl:1|2|4, declarer}   tricks = tricks won by the declaring side
  //   vulnerable = declaring side vulnerable?
  // Returns { made, below, above, under, over, detail } — below goes toward game, above is bonuses/penalties.
  function scoreHand(contract, tricks, vulnerable){
    const { level, strain, dbl } = contract;
    const need = 6 + level;
    const made = tricks >= need;
    let below=0, above=0;
    const detail = [];
    if(made){
      below = belowLineTrickScore(level, strain, dbl);
      detail.push(`contract ${below} below`);
      // overtricks
      const over = tricks - need;
      if(over>0){
        let ot=0;
        if(dbl===1){ const rate = (strain==="NT"||isMajor(strain))?30:20; ot = over*rate; }
        else if(dbl===2){ ot = over*(vulnerable?200:100); }
        else { ot = over*(vulnerable?400:200); }
        above += ot; detail.push(`+${ot} overtricks (${over})`);
      }
      // insult
      if(dbl===2){ above+=50; detail.push("+50 insult"); }
      else if(dbl===4){ above+=100; detail.push("+100 insult"); }
      // slam
      if(level===6){ const s=vulnerable?750:500; above+=s; detail.push(`+${s} small slam`); }
      else if(level===7){ const s=vulnerable?1500:1000; above+=s; detail.push(`+${s} grand slam`); }
      return { made:true, below, above, over, under:0, detail };
    } else {
      const under = need - tricks;
      let pen=0;
      if(dbl===1){ pen = under*(vulnerable?100:50); }
      else {
        // doubled schedule (redoubled = ×2)
        for(let i=1;i<=under;i++){
          let step;
          if(vulnerable){ step = (i===1)?200:300; }
          else { step = (i===1)?100 : (i<=3?200:300); }
          pen += step;
        }
        if(dbl===4) pen *= 2;
      }
      above = pen;  // note: penalty is credited to the OPPONENTS (caller assigns to the defending side)
      detail.push(`down ${under} = ${pen} to defenders`);
      return { made:false, below:0, above:pen, over:0, under, detail };
    }
  }
  
  // Honours held in ONE hand (optional). hand = array of {rank,suit}. trump strain.
  // Returns bonus points (0/100/150) for THAT hand.
  function honoursForHand(hand, strain){
    if(strain==="NT"){
      const aces = hand.filter(c=>c.rank==="A").length;
      return aces===4 ? 150 : 0;
    }
    const set = new Set(hand.filter(c=>c.suit===strain).map(c=>c.rank));
    const top = ["A","K","Q","J","10"].filter(r=>set.has(r)).length;
    return top===5 ? 150 : (top===4 ? 100 : 0);
  }
  
  
  
  return { belowLineTrickScore, scoreHand, honoursForHand, isMinor, isMajor };
})();


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { SCO };
//#endregion gen
