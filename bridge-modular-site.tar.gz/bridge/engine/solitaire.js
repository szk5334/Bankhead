/* solitaire.js — DD-OPTIMAL SOLITAIRE: one player, all four hands, perfect information.
 *
 * WHY THIS MODE IS DIFFERENT, AND WHY IT IS EASY WHERE THE REST OF THE APP IS HARD.
 * Every grading problem this project has fought comes from HIDDEN INFORMATION. Declarer play needed belief
 * sampling. Defence needed convention-consistency, because double-dummy overstates defensive error ~18x.
 * Bidding needed convention-consistency too, because expected score has an irreducible policy floor.
 *
 * Here there is nothing hidden. All four hands are face up. So:
 *
 *     DOUBLE DUMMY IS NOT AN APPROXIMATION OF THE TRUTH. IT IS THE TRUTH.
 *
 * No sampling. No belief. No two-lens. No eps band. No policy floor. The best card is exactly the card the
 * solver says is best, and "a perfect game" is an exactly-defined object. This is the one place in the app
 * where a hard grade is unambiguously correct, and the scoring should be as sharp as the oracle allows.
 *
 * ------------------------------------------------------------------------------------------------------
 * THE ONE THING THAT WOULD RUIN THE SCORE: SCORING NON-DECISIONS.
 *
 * Of the 52 cards in a deal, a large share are not decisions at all — a singleton you must follow with, a
 * suit where every legal card is double-dummy identical. If those pay points, the score measures how many
 * cards were dealt, not how well they were played, and a "perfect game" becomes mostly forced discards.
 *
 * So every card is first classified:
 *     FORCED   only one legal card            -> no decision. 0 pts. Streak untouched.
 *     FREE     every legal card ties on DD    -> no decision. 0 pts. Streak untouched.
 *     REAL     a genuine choice               -> scored, and it is the ONLY thing that moves the streak.
 *
 * This is the same discipline as the rest of the grader: deftech's `applies`, the bidding grade's Tier 3
 * silence. Grade the decisions; stay quiet about everything else.
 * ------------------------------------------------------------------------------------------------------
 *
 * PURE. No DDS, no async, no state. The caller supplies the double-dummy facts; this module turns them into
 * a grade and a score. That keeps the scoring rules testable without a solver, and lets the DD work sit
 * wherever it is cheapest (worker, pre-solve, cache).
 *
 * EXTENSIBLE BY DESIGN. Scoring is DATA (`DEFAULT_RULES`), not code. A new bonus is a new object in
 * `rules.bonuses` — `{ id, label, points, when(ctx) }` — and needs no change to this file. `scoreDeal` is a
 * pure fold over events, so a custom rule set is just a different argument.
 */

const SOL = (function(){

  /* ================= 1. THE CARD GRADE (perfect information) =================
   * dd     : { cardKey: tricks THIS SIDE takes, with double-dummy play by everyone } — for every LEGAL card.
   * played : the card key actually played.
   * Returns the exact verdict. `lost` is in TRICKS, and it is exact — not an estimate, not a band.
   */
  function gradeCard(dd, played){
    const keys = Object.keys(dd || {});
    if(!keys.length) return { kind:"none", scored:false };

    let best = -Infinity;
    for(const k of keys) if(dd[k] > best) best = dd[k];
    const equiv = keys.filter(k => dd[k] === best);          // DD-identical: ALL of these are perfect
    const val   = (played in dd) ? dd[played] : best;         // an illegal key can't lose you tricks
    const lost  = Math.max(0, best - val);
    const optimal = lost === 0;

    // FORCED: no choice existed. FREE: choice existed but every option is double-dummy identical.
    // Neither is a decision, so neither is scored and neither can move the streak.
    const kind = keys.length === 1 ? "forced"
               : equiv.length === keys.length ? "free"
               : "real";

    return { kind, scored: kind === "real", optimal, lost, best, val,
             equiv, nEquiv: equiv.length, nLegal: keys.length, played };
  }

  /* ================= 2. THE RULES (data, not code) =================
   * Every number a player can argue about lives here. Add a bonus by adding an object; the engine never
   * needs to know what it means.
   */
  const DEFAULT_RULES = {
    card: {
      optimal:    10,     // a REAL decision, played double-dummy perfectly
      perTrickLost: -25,  // per trick actually thrown away (exact, not a band)
      forced:      0,     // no choice — pays nothing, costs nothing
      free:        0,     // every option tied — pays nothing, costs nothing
    },
    /* STREAK. Built ONLY from real decisions, so a run of forced discards can neither build nor break it.
     * multiplier = 1 + floor(streak / step), capped. Applied to the card's POSITIVE points only — a
     * multiplier that also scaled the penalties would make a long streak a liability. */
    streak: { step: 5, per: 1, cap: 5 },

    /* CONTRACT (the bidding half). Par is the double-dummy optimum for BOTH sides, sacrifices included —
     * DealerPar from the solver, not a heuristic. */
    contract: {
      atPar:      150,    // you found the par contract
      perImpOff:  -10,    // per IMP your contract is worse than par
    },

    bonuses: [
      { id:"CLEAN_TRICK",  label:"Clean trick",   points:15,
        when:(c)=> c.type==="trick" && c.realDecisions>0 && c.mistakes===0 },
      { id:"FLAWLESS_DEAL",label:"Flawless deal", points:250,
        when:(c)=> c.type==="deal" && c.tricksLost===0 && c.realDecisions>0 },
      { id:"NO_MISTAKES",  label:"No mistakes",   points:100,
        when:(c)=> c.type==="deal" && c.mistakes===0 && c.tricksLost>0 },
      { id:"PAR_AND_PERFECT", label:"Par contract, played perfectly", points:200,
        when:(c)=> c.type==="deal" && c.atPar && c.tricksLost===0 },
    ],
  };

  /* Merge a partial custom rule set over the defaults. Bonuses REPLACE wholesale when supplied (so a caller
   * can strip them), but `extraBonuses` appends — the common case, and the one Seth asked for room for. */
  function withRules(custom){
    const c = custom || {};
    return {
      card:     Object.assign({}, DEFAULT_RULES.card,     c.card),
      streak:   Object.assign({}, DEFAULT_RULES.streak,   c.streak),
      contract: Object.assign({}, DEFAULT_RULES.contract, c.contract),
      bonuses:  (c.bonuses || DEFAULT_RULES.bonuses).concat(c.extraBonuses || []),
    };
  }

  const multiplierFor = (streak, st)=>
    Math.min(st.cap, 1 + Math.floor(streak / Math.max(1, st.step)) * st.per);

  /* ================= 3. THE SCORE (a pure fold) =================
   * plays    : [{ trick, seat, grade }]  in play order; grade from gradeCard().
   * contract : { impVsPar, atPar } or null (no bidding half).
   * Returns { total, lines, stats } — `lines` is the itemised breakdown a scoreboard renders.
   */
  function scoreDeal(plays, contract, custom){
    const R = withRules(custom);
    const lines = [];
    const add = (id,label,points,detail)=>{ if(points) lines.push({ id, label, points, detail }); };

    let total=0, streak=0, bestStreak=0, mult=1;
    let real=0, optimal=0, mistakes=0, tricksLost=0, forced=0, free=0;
    let cardPts=0, penaltyPts=0;

    // ---- per card ----
    const byTrick = new Map();
    for(const p of (plays||[])){
      const g = p.grade;
      if(!g) continue;
      if(g.kind === "forced"){ forced++; total += R.card.forced; cardPts += R.card.forced; }
      else if(g.kind === "free"){ free++; total += R.card.free; cardPts += R.card.free; }
      else if(g.kind === "real"){
        real++;
        if(g.optimal){
          optimal++;
          mult = multiplierFor(streak, R.streak);        // multiplier from the streak BEFORE this card
          const pts = R.card.optimal * mult;
          total += pts; cardPts += pts;
          streak++; if(streak > bestStreak) bestStreak = streak;
        } else {
          mistakes++; tricksLost += g.lost;
          const pen = R.card.perTrickLost * g.lost;      // penalties are NEVER multiplied
          total += pen; penaltyPts += pen;
          streak = 0;
        }
      }
      const t = byTrick.get(p.trick) || { realDecisions:0, mistakes:0 };
      if(g.kind === "real"){ t.realDecisions++; if(!g.optimal) t.mistakes++; }
      byTrick.set(p.trick, t);
    }
    add("CARDS", "Card play", cardPts, `${optimal}/${real} decisions optimal`);
    if(penaltyPts) add("LOST", "Tricks thrown away", penaltyPts, `${tricksLost} trick${tricksLost===1?"":"s"}`);

    // ---- contract ----
    let atPar = false;
    if(contract){
      atPar = !!contract.atPar;
      if(atPar) add("PAR", "Par contract", R.contract.atPar, null);
      else if(contract.impVsPar > 0)
        add("OFFPAR", "Off par", R.contract.perImpOff * contract.impVsPar, `${contract.impVsPar} IMP below par`);
      total += atPar ? R.contract.atPar
                     : (contract.impVsPar > 0 ? R.contract.perImpOff * contract.impVsPar : 0);
    }

    // ---- bonuses (data-driven; the engine does not know what any of them mean) ----
    const dealCtx = { type:"deal", real, realDecisions:real, optimal, mistakes, tricksLost,
                      forced, free, bestStreak, atPar, impVsPar: contract ? contract.impVsPar : null };
    for(const b of R.bonuses){
      let fired=false;
      try{ fired = !!b.when(dealCtx); }catch(_){ fired = false; }
      if(fired){ total += b.points; add(b.id, b.label, b.points, null); }
    }
    for(const [trick, t] of byTrick){
      const tCtx = { type:"trick", trick, ...t };
      for(const b of R.bonuses){
        let fired=false;
        try{ fired = !!b.when(tCtx); }catch(_){ fired = false; }
        if(fired){ total += b.points; add(b.id+":"+trick, b.label, b.points, `trick ${trick+1}`); }
      }
    }

    const accuracy = real ? optimal/real : 1;
    return {
      total,
      lines,
      stats: { real, optimal, mistakes, tricksLost, forced, free, bestStreak,
               accuracy, perfect: real>0 && tricksLost===0 && mistakes===0, atPar },
    };
  }

  /* A live run — the same fold, incrementally, for the scoreboard while you play. Kept deliberately thin:
   * `scoreDeal` remains the single source of truth, and this just re-folds. A deal is 52 cards; re-folding
   * is free, and one scoring path that can never disagree with itself is worth more than a fast one. */
  function runningScore(plays, contract, custom){ return scoreDeal(plays, contract, custom); }

  return { gradeCard, scoreDeal, runningScore, withRules, multiplierFor, DEFAULT_RULES };
})();

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { SOL };
//#endregion gen
