//#region gen (auto — removed when bundled to a single bridge.jsx)
//#endregion gen

/* ==== Hand valuation — pure, oracle-tuned. Single source consumed by bidding.js. ====
   Multiple axes; the bidding stage selects the right metric per decision.
   Honor point-values and fit-length weight are DERIVED from the double-dummy oracle
   (val_derive.mjs), not asserted. K-anchored scale averaged over 3 seeds (~1400 deals):
   A/K/Q/J/T = 4.5/3/1.6/0.75/0.5, fit ~0.77 tricks/card. Milton's blind spots confirmed:
   aces & tens underrated, quacks overrated. Fractional by design — judgment lives in the fractions. */
const VAL = (function(){
  const ORDER=["S","H","D","C"];
  const MILTON={A:4,K:3,Q:2,J:1};
  const DERIVED={A:4.5,K:3,Q:1.6,J:0.75,T:0.5};    // oracle-derived point scale (K-anchored, 3-seed avg)
  const BAD_DOUBLETON=-0.4;   // unguarded Qx/Jx (no A/K in a doubleton): dead high card. Oracle-derived.
  const RV={"2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"10":10,"J":11,"Q":12,"K":13,"A":14};
  // fitted trick model (val_validate): fit tricks ~= I + a*adjHcp + b*fitLen. qt AND controls dropped —
  // both are redundant once adjHcp weights aces at 4.5 (dropping controls costs 0.0001 R). RMSE ~1 trick.
  const TRICK={I:0, adjHcp:0, fitLen:0, controls:0};  // filled by setTrickModel (default locked below)

  const has=(rs,r)=>rs.includes(r);
  function parse(hand){
    const by={S:[],H:[],D:[],C:[]};
    for(const c of hand) by[c.suit].push(c.rank);
    for(const s in by) by[s].sort((a,b)=>RV[b]-RV[a]);
    const len={S:by.S.length,H:by.H.length,D:by.D.length,C:by.C.length};
    return {by,len};
  }
  const shapeKey=(len)=>[len.S,len.H,len.D,len.C].slice().sort((a,b)=>b-a).join("");
  const balanced=(len)=>{const k=shapeKey(len);return k==="4333"||k==="4432"||k==="5332";};
  const semiBalanced=(len)=>{const k=shapeKey(len);return k==="5422"||k==="6322";};

  function hcp(hand){ let h=0; for(const c of hand) h+=MILTON[c.rank]||0; return h; }
  // oracle-derived adjusted HIGH-CARD points (fractional). PURE high-card strength:
  // honor scale = DERIVED; the one genuine high-card-quality effect is a dead Qx/Jx doubleton.
  // Distribution (shortness/ruffing) is a SEPARATE axis (shortnessPoints) — never folded in here,
  // so adjHcp stays correct for NT as well as suit decisions.
  function adjHcp(by,len){ let a=0;
    for(const s of ORDER){ const rs=by[s];
      for(const r of rs){
        if(r==="A")a+=DERIVED.A; else if(r==="K")a+=DERIVED.K; else if(r==="Q")a+=DERIVED.Q;
        else if(r==="J")a+=DERIVED.J; else if(r==="10")a+=DERIVED.T;
      }
      if(len[s]===2 && !has(rs,"A") && !has(rs,"K") && (has(rs,"Q")||has(rs,"J"))) a+=BAD_DOUBLETON;
    } return a; }
  function controls(by){ let c=0; for(const s of ORDER){ if(has(by[s],"A"))c+=2; if(has(by[s],"K"))c+=1; } return c; }
  function quickTricks(by,len){ let q=0;
    for(const s of ORDER){ const rs=by[s], L=len[s];
      if(has(rs,"A")&&has(rs,"K")) q+=2; else if(has(rs,"A")&&has(rs,"Q")) q+=1.5;
      else if(has(rs,"A")) q+=1; else if(has(rs,"K")&&has(rs,"Q")) q+=1;
      else if(has(rs,"K")&&L>=2) q+=0.5;
    } return q; }
  function lengthPoints(len){ let lp=0; for(const s of ORDER) if(len[s]>4) lp+=len[s]-4; return lp; }
  function shortnessPoints(len,trump){ let sp=0; for(const s of ORDER){ if(s===trump) continue;
    if(len[s]===0)sp+=5; else if(len[s]===1)sp+=3; else if(len[s]===2)sp+=1; } return sp; }
  function ltc(by,len){ let L=0;
    for(const s of ORDER){ const rs=by[s], n=len[s];
      if(n===0) continue;
      else if(n===1) L+=has(rs,"A")?0:1;
      else if(n===2) L+=(2-(has(rs,"A")?1:0)-(has(rs,"K")?1:0));
      else L+=(3-(has(rs,"A")?1:0)-(has(rs,"K")?1:0)-(has(rs,"Q")?1:0));
    } return L; }
  function top3(by,s){ return by[s].filter(r=>r==="A"||r==="K"||r==="Q").length; }
  function top5(by,s){ return by[s].filter(r=>["A","K","Q","J","10"].includes(r)).length; }
  function stopper(by,len,s){ const rs=by[s]; if(!rs) return false;
    if(has(rs,"A"))return true; if(has(rs,"K")&&len[s]>=2)return true;
    if(has(rs,"Q")&&len[s]>=3)return true; if(has(rs,"J")&&len[s]>=4)return true; return false; }

  function evaluate(hand){
    const {by,len}=parse(hand);
    return { by, len,
      hcp:hcp(hand), adjHcp:adjHcp(by,len), tp:hcp(hand)+lengthPoints(len),
      controls:controls(by), quickTricks:quickTricks(by,len),
      lengthPoints:lengthPoints(len), ltc:ltc(by,len),
      shape:shapeKey(len), balanced:balanced(len), semiBalanced:semiBalanced(len),
      longest: ORDER.slice().sort((a,b)=>(len[b]-len[a])||(ORDER.indexOf(b)-ORDER.indexOf(a)))[0],
      top3:(s)=>top3(by,s), top5:(s)=>top5(by,s),
      stopper:(s)=>stopper(by,len,s),
      shortness:(trump)=>shortnessPoints(len,trump), RV };
  }
  // estimate combined tricks given a fit (both hands' adjHcp+controls, combined trump length)
  function estTricks(evA, evB, fitLen){
    return TRICK.I + TRICK.adjHcp*(evA.adjHcp+evB.adjHcp) + TRICK.fitLen*fitLen
                   + TRICK.controls*(evA.controls+evB.controls);
  }
  function setTrickModel(I,a,b,c){ TRICK.I=I; TRICK.adjHcp=a; TRICK.fitLen=b; TRICK.controls=c; }
  setTrickModel(-4.40, 0.3217, 0.7555, 0);   // LOCKED vs current adjHcp (2-seed avg, seeds 9001/2024). Re-lock if DERIVED changes.

  return { evaluate, hcp, adjHcp, controls, quickTricks, lengthPoints, shortnessPoints, ltc,
           balanced, semiBalanced, parse, estTricks, setTrickModel, DERIVED, TRICK };
})();

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { VAL };
//#endregion gen
