//#region gen (auto — removed when bundled to a single bridge.jsx)
import { ENG } from "./core.js";
import { callLabel } from "../state/constants.js";
import { C } from "../ui/theme.js";
//#endregion gen

const AUC = (function(){
  const { STRAINS, STRAIN_IDX } = ENG;
  
  /* A call is one of:
     {k:"P"}  pass
     {k:"D"}  double
     {k:"R"}  redouble
     {k:"B", level, strain}  a bid
     Each stored call also carries .by (seat).
     Auction context is derived by scanning the calls array (in call order). */
  
  const bidVal = (b)=> b.level*5 + STRAIN_IDX[b.strain];
  
  // summarize the auction so far. seats 0..3, partners = seat and seat^2? no: partners are i and (i+2)%4.
  function auctionInfo(calls, dealer){
    let lastBid=null, lastBidder=-1, dbl=0; // 0 none,1 doubled,2 redoubled
    let consecPass=0, opened=false;
    // track first mention of each strain by each SIDE (for declarer)
    const firstStrainBySide = { 0:{}, 1:{} }; // side 0 = seats {0,2}, side 1 = {1,3}
    const side = (seat)=> seat%2;
    for(const c of calls){
      if(c.k==="B"){
        opened=true; lastBid=c; lastBidder=c.by; dbl=0;
        const sd=side(c.by);
        if(firstStrainBySide[sd][c.strain]===undefined) firstStrainBySide[sd][c.strain]=c.by;
        consecPass=0;
      } else if(c.k==="D"){ dbl=1; consecPass=0; }
      else if(c.k==="R"){ dbl=2; consecPass=0; }
      else { consecPass++; }
    }
    // auction ends: 4 passes with no bid → passed out; or a bid then 3 passes
    let ended=false, passedOut=false;
    if(!opened && consecPass>=4){ ended=true; passedOut=true; }
    else if(opened && consecPass>=3){ ended=true; }
    // declarer: on the winning side, first to name the contract strain
    let declarer=-1, contract=null;
    if(ended && !passedOut && lastBid){
      const sd=side(lastBidder);
      declarer = firstStrainBySide[sd][lastBid.strain];
      contract = { level:lastBid.level, strain:lastBid.strain, dbl:(dbl===2?4:dbl===1?2:1), declarer };
    }
    return { lastBid, lastBidder, dbl, consecPass, opened, ended, passedOut, declarer, contract, firstStrainBySide };
  }
  
  // whose turn is it? dealer first, then clockwise. calls length tells us.
  function turnSeat(calls, dealer){ return (dealer + calls.length) % 4; }
  
  // is a call legal given the current auction?
  function callLegal(call, calls, dealer){
    const info = auctionInfo(calls, dealer);
    if(info.ended) return false;
    const seat = turnSeat(calls, dealer);
    if(call.k==="P") return true;
    if(call.k==="B"){
      if(call.level<1 || call.level>7) return false; // no bid above 7
      if(!info.lastBid) return true;
      return bidVal(call) > bidVal(info.lastBid);
    }
    if(call.k==="D"){
      // double an opponent's undoubled bid
      if(!info.lastBid || info.dbl!==0) return false;
      return (info.lastBidder%2) !== (seat%2);
    }
    if(call.k==="R"){
      // redouble your side's bid that an opponent has doubled
      if(!info.lastBid || info.dbl!==1) return false;
      return (info.lastBidder%2) === (seat%2);
    }
    return false;
  }
  
  // human-readable label
  function callLabel(c){
    if(c.k==="P") return "Pass";
    if(c.k==="D") return "Dbl";
    if(c.k==="R") return "Rdbl";
    const g={C:"♣",D:"♦",H:"♥",S:"♠",NT:"NT"}[c.strain];
    return c.level+g;
  }
  
  
  
  return { auctionInfo, turnSeat, callLegal, callLabel, bidVal };
})();


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { AUC };
//#endregion gen
