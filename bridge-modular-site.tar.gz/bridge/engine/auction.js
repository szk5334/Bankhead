//#region gen (auto — removed when bundled to a single bridge.jsx)
import { ENG } from "./core.js";
import { BELIEF } from "./belief.js";
import { callLabel } from "../state/constants.js";
import { C } from "../ui/theme.js";
//#endregion gen

const AUC = (function(){
  const { STRAINS, STRAIN_IDX } = ENG;
  
  /* A call is one of:
     {k:"P"}  pass
     {k:"D"}  double
     {k:"R"}  redouble
     {k:"B", level, strain}  a bid
     Each stored call also carries .by (seat).
     Auction context is derived by scanning the calls array (in call order). */
  
  const bidVal = (b)=> b.level*5 + STRAIN_IDX[b.strain];
  
  // summarize the auction so far. seats 0..3, partners = seat and seat^2? no: partners are i and (i+2)%4.
  function auctionInfo(calls, dealer){
    let lastBid=null, lastBidder=-1, dbl=0; // 0 none,1 doubled,2 redoubled
    let consecPass=0, opened=false;
    // track first mention of each strain by each SIDE (for declarer)
    const firstStrainBySide = { 0:{}, 1:{} }; // side 0 = seats {0,2}, side 1 = {1,3}
    const side = (seat)=> seat%2;
    for(const c of calls){
      if(c.k==="B"){
        opened=true; lastBid=c; lastBidder=c.by; dbl=0;
        const sd=side(c.by);
        if(firstStrainBySide[sd][c.strain]===undefined) firstStrainBySide[sd][c.strain]=c.by;
        consecPass=0;
      } else if(c.k==="D"){ dbl=1; consecPass=0; }
      else if(c.k==="R"){ dbl=2; consecPass=0; }
      else { consecPass++; }
    }
    // auction ends: 4 passes with no bid → passed out; or a bid then 3 passes
    let ended=false, passedOut=false;
    if(!opened && consecPass>=4){ ended=true; passedOut=true; }
    else if(opened && consecPass>=3){ ended=true; }
    // declarer: on the winning side, first to name the contract strain
    let declarer=-1, contract=null;
    if(ended && !passedOut && lastBid){
      const sd=side(lastBidder);
      declarer = firstStrainBySide[sd][lastBid.strain];
      contract = { level:lastBid.level, strain:lastBid.strain, dbl:(dbl===2?4:dbl===1?2:1), declarer };
    }
    return { lastBid, lastBidder, dbl, consecPass, opened, ended, passedOut, declarer, contract, firstStrainBySide };
  }
  
  // whose turn is it? dealer first, then clockwise. calls length tells us.
  function turnSeat(calls, dealer){ return (dealer + calls.length) % 4; }
  
  // is a call legal given the current auction?
  function callLegal(call, calls, dealer){
    const info = auctionInfo(calls, dealer);
    if(info.ended) return false;
    const seat = turnSeat(calls, dealer);
    if(call.k==="P") return true;
    if(call.k==="B"){
      if(call.level<1 || call.level>7) return false; // no bid above 7
      if(!info.lastBid) return true;
      return bidVal(call) > bidVal(info.lastBid);
    }
    if(call.k==="D"){
      // double an opponent's undoubled bid
      if(!info.lastBid || info.dbl!==0) return false;
      return (info.lastBidder%2) !== (seat%2);
    }
    if(call.k==="R"){
      // redouble your side's bid that an opponent has doubled
      if(!info.lastBid || info.dbl!==1) return false;
      return (info.lastBidder%2) === (seat%2);
    }
    return false;
  }
  
  // human-readable label
  function callLabel(c){
    if(c.k==="P") return "Pass";
    if(c.k==="D") return "Dbl";
    if(c.k==="R") return "Rdbl";
    const g={C:"♣",D:"♦",H:"♥",S:"♠",NT:"NT"}[c.strain];
    return c.level+g;
  }

  /* ---- auction-conditioned belief: per-seat constraints on ORIGINAL hands, from the bidding ----
   * Feeds the grader's belief sampler so it samples defender/declarer layouts consistent with the auction,
   * not uniformly. Deliberately CONSERVATIVE — only the highest-confidence SAYC signals, wide windows —
   * because a too-tight constraint that excludes the real hand biases the estimate. Callers MUST truth-
   * guard the output against the actual hands (drop any constraint the real hand violates). Ranges match
   * BID.openingBid so they line up with the auctions the bots actually produce. */
  // Constraint test comes from the shared belief module (single source of truth; == frozen sampler.handOk).
  const handOk = BELIEF.handOk;

  function _openCon(bid){   // opening bid -> constraint on the opener's ORIGINAL hand
    const { level, strain } = bid;
    if(strain==="NT"){
      if(level===1) return { hcpMin:15, hcpMax:17 };
      if(level===2) return { hcpMin:20, hcpMax:21 };
      if(level===3) return { hcpMin:25, hcpMax:27 };
      return { hcpMin:15 };
    }
    if(level===1){                                   // 1-of-suit: 11+ (Rule of 20 floor); 5-card majors, 3+ minors
      const suitMin={}; suitMin[strain] = (strain==="H"||strain==="S") ? 5 : 3;
      return { hcpMin:11, suitMin };
    }
    if(level===2){
      if(strain==="C") return { hcpMin:20 };         // strong, artificial 2C
      return { hcpMin:5, hcpMax:11, suitMin:{[strain]:6} };   // weak two
    }
    return { hcpMin:5, hcpMax:11, suitMin:{[strain]:7} };     // 3-level+ preempt
  }
  function _overCon(bid){   // first-time suit/NT bid by an opponent of the opener = an overcall
    if(bid.strain==="NT") return { hcpMin:15, hcpMax:18 };
    return { hcpMin:7, suitMin:{[bid.strain]:5} };
  }

  function deriveConstraints(calls, dealer){
    const con=[null,null,null,null];
    const acted=[false,false,false,false];
    let opened=false, opener=-1;
    for(let i=0;i<calls.length;i++){
      const seat=(dealer+i)%4;
      const c=calls[i];
      if(!acted[seat]){
        acted[seat]=true;
        if(!opened){
          if(c.k==="B"){ con[seat]=_openCon(c); opener=seat; }
          else con[seat]={ hcpMax:11 };              // declined to open -> sub-opening values
        } else if(c.k==="B" && (seat%2)!==(opener%2)){
          con[seat]=_overCon(c);                      // opponent bidding for the first time = overcall
        }
        // responder / pass-after-opening: no reliable v1 constraint
      }
      if(c.k==="B") opened=true;
    }
    return con;
  }


  return { auctionInfo, turnSeat, callLegal, callLabel, bidVal, deriveConstraints, handOk };
})();


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { AUC };
//#endregion gen
