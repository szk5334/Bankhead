//#region gen (auto — removed when bundled to a single bridge.jsx)
// dependency-free — no imports
//#endregion gen

/* belief.js — the SINGLE source of truth for the auction/belief CONSTRAINT test. Historically this logic was
 * copied three times: grader `sampler.js handOk` (parity-frozen, JS↔Python bit-identical), engine
 * `auction.js handOk`, and engine `play.js _handOk` (whose comment admitted it "Mirrors AUC.handOk"). This
 * module is the ONE copy the app engine imports (auction + play), byte-for-byte identical to the frozen
 * sampler.js canonical (verified by test_handok_parity.mjs). The grader's sampler.js stays frozen; this makes
 * the ENGINE side conform to it, so there is one spec, not three drifting mirrors.
 *
 * handOk(originalCards, con): does a candidate ORIGINAL 13-card holding satisfy an auction/belief constraint
 *   { hcpMin?, hcpMax?, suitMin?:{S,H,D,C}, suitMax?:{...}, honor?:[suits needing a J+] } ?
 * Constraints may only ever narrow; an absent field is a no-op. Pure, dependency-free.
 */
const BELIEF = (function(){
  const HCPV = { A: 4, K: 3, Q: 2, J: 1 };
  const SUITS = ["S", "H", "D", "C"];
  function hcp(cards){ let h = 0; for (const c of cards) h += HCPV[c.rank] || 0; return h; }
  function suitLen(cards, s){ let n = 0; for (const c of cards) if (c.suit === s) n++; return n; }

  function handOk(originalCards, con){
    if (con === null || con === undefined) return true;
    const h = hcp(originalCards);
    if (h < (con.hcpMin ?? 0) || h > (con.hcpMax ?? 37)) return false;
    const smin = con.suitMin || {};
    for (const s of SUITS) {
      if (suitLen(originalCards, s) < (smin[s] || 0)) return false;
    }
    const smax = con.suitMax; // optional; deriveConstraints doesn't emit it yet
    if (smax) {
      for (const s of SUITS) {
        if (suitLen(originalCards, s) > (smax[s] ?? 13)) return false;
      }
    }
    const honor = con.honor; // optional: suits the ORIGINAL hand must hold an honour (J+) in (partner ATTITUDE signal)
    if (honor) {
      for (const s of honor) {
        let has = false;
        for (const c of originalCards) { if (c.suit === s && (c.rank === "J" || c.rank === "Q" || c.rank === "K" || c.rank === "A")) { has = true; break; } }
        if (!has) return false;
      }
    }
    return true;
  }

  return { handOk, hcp, suitLen, HCPV };
})();

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { BELIEF };
//#endregion gen
