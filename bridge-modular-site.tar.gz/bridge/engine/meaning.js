//#region gen (auto — removed when bundled to a single bridge.jsx)
import { BELIEF } from "./belief.js";
//#endregion gen

/* meaning.js — the BIDDING DESCRIBER: for ANY legal call in ANY auction, what does it PROMISE partner?
 *
 * This is the linchpin of the bidding trainer. It returns, for a call in context:
 *   constraint : {hcpMin,hcpMax,suitMin,suitMax} on MY hand — the same shape handOk/deriveConstraints use, so a
 *                bid's promise can be tested against the actual hand (BELIEF.handOk) to detect a MISREPRESENTATION.
 *   text       : a one-line teaching statement of what the call says ("5+ hearts, 11+ points").
 *   role       : opening | response | rebid | overcall | raise | preempt | notrump | competitive | conventional
 *   forcing    : does it force partner to bid again?
 *   artificial : does it say something OTHER than "I have this suit"? (Stayman, Blackwood, 2C, negative double)
 *   confidence : "standard" (a firm SAYC promise, safe to darken a lie) | "judgment" (a range/style call where a
 *                deviation is legitimate — NEVER darken these; teaching rigidity is worse than teaching nothing)
 *
 * DESIGN: the promise semantics MIRROR the app's own SAYC brain (bidding.js openingBid/responderBid/… and
 * auction.js deriveConstraints), so a hint never teaches something the table doesn't play. Where SAYC leaves
 * genuine choice (upgrades for shape/controls, tactical underbids, competitive judgment) we mark it `judgment`
 * rather than inventing a false rule — the same degrade-don't-corrupt discipline the graders use.
 */

const MEAN = (function(){
  const SUITS = ["S","H","D","C"];
  const isMajor = (s)=> s==="H"||s==="S";
  const HCPV = BELIEF.HCPV;   // canonical HCP table (one definition, in belief.js)
  const GLYPH = { S:"\u2660", H:"\u2665", D:"\u2666", C:"\u2663", NT:"NT" };
  const sname = (s)=> s==="NT" ? "notrump" : GLYPH[s];

  function evalHand(hand){
    const len={S:0,H:0,D:0,C:0}; let hcp=0;
    for(const c of hand){ hcp += HCPV[c.rank]||0; if(len[c.suit]!=null) len[c.suit]++; }
    const lp = SUITS.reduce((a,s)=> a + Math.max(0, len[s]-4), 0);   // long-suit points
    const shape = SUITS.map(s=>len[s]).sort((a,b)=>b-a);
    const balanced = shape[0]<=4 && shape[3]>=2 && shape[2]>=2 && !(shape[0]===5&&shape[3]<2);
    let longest="S"; for(const s of SUITS) if(len[s]>len[longest]) longest=s;
    return { len, hcp, lp, tp:hcp+lp, balanced, longest, shape };
  }

  const call = (c)=> c.k==="P" ? "Pass" : c.k==="D" ? "Double" : c.k==="R" ? "Redouble"
                    : `${c.level}${c.strain==="NT"?"NT":GLYPH[c.strain]}`;

  const bidsBy = (calls, seat)=> calls.filter(c=>c.by===seat && c.k==="B");
  const anyBid = (calls, seat)=> bidsBy(calls, seat).length>0;

  /* ---- situation: who has done what? (mirrors bidding.js context()) ---- */
  function situate(calls, dealer, seat){
    const partner=(seat+2)%4, lho=(seat+1)%4, rho=(seat+3)%4;
    let openerSeat=-1; for(const c of calls){ if(c.k==="B"){ openerSeat=c.by; break; } }
    const myBids=bidsBy(calls,seat), pBids=bidsBy(calls,partner);
    const oppBids=[...bidsBy(calls,lho), ...bidsBy(calls,rho)];
    return { partner, lho, rho, openerSeat, myBids, pBids, oppBids,
      iOpened: openerSeat===seat, partnerOpened: openerSeat===partner,
      oppsOpened: openerSeat===lho || openerSeat===rho, noBidsYet: openerSeat===-1,
      partnerLast: pBids.length?pBids[pBids.length-1]:null,
      myLast: myBids.length?myBids[myBids.length-1]:null };
  }

  /* `forcing` and `mustAnswer` are DIFFERENT AXES, and conflating them is a trap.
   *   forcing    : partner is expected to bid again.
   *   mustAnswer : partner may NOT pass. There is no hand on which passing is legal.
   * A takeout double is `forcing` but NOT `mustAnswer` — passing it to convert it to penalties, with long
   * strong trumps in their suit, is a real expert action. Blackwood, Stayman, a transfer, a strong 2C, a
   * new suit by an unpassed responder: those genuinely cannot be passed. The bidding grade's obligation
   * check keys on `mustAnswer` ALONE, so that firming up a promise's `confidence` (a statement about the
   * hand) can never silently change whether passing it is an error (a statement about the auction). */
  const M = (o)=> Object.assign({ constraint:null, forcing:false, mustAnswer:false, artificial:false,
                                  confidence:"judgment", role:"other", text:"", exempt:null }, o);

  /* ================= the describer ================= */
  function callMeaning(c, calls, dealer, seat){
    const S = situate(calls, dealer, seat);

    // ---------- PASS ----------
    if(c.k==="P"){
      if(S.noBidsYet) return M({ role:"opening", confidence:"standard", text:"Fewer than opening values (roughly under 12 points, and no Rule-of-20 hand).",
        constraint:{ hcpMax:11 } });
      // "Too weak to respond" is only a FIRM promise in the narrow case: partner OPENED at the 1 level, the
      // opponents have NOT bid (so I'm not passing a competitive decision), and it is my first call. Any other
      // pass (partner preempted, opponents intervened, the auction is winding up, I've already bid) can be made
      // with real values — describing it as weakness would flag the app's OWN bots. Degrade, don't corrupt.
      const partnerOpened1 = S.partnerOpened && S.pBids.length===1 && S.pBids[0].level===1 && S.pBids[0].strain!=="NT";
      const quiet = S.oppBids.length===0;
      // partner's opening must be the LAST bid made (nothing has happened since) — otherwise the pass is a
      // competitive/positional judgment, which players legitimately make with real values.
      const lastBidNow = [...calls].reverse().find(x=>x.k==="B");
      const partnerBidIsLast = lastBidNow && lastBidNow.by===S.partner;
      if(partnerOpened1 && quiet && partnerBidIsLast && !S.myBids.length) return M({ role:"response", confidence:"standard",
        text:"Too weak to respond — fewer than 6 points. (With 6+ you must keep the auction alive.)", constraint:{ hcpMax:5 } });
      if(S.partnerOpened && !S.myBids.length) return M({ role:"response", confidence:"judgment",
        text:"Passing partner's bid — you judge the hand has nothing more to say." });
      return M({ role:"other", text:"No further values to show — content to defend or let the auction rest." });
    }
    // ---------- DOUBLE ----------
    if(c.k==="D"){
      const lastBid = [...calls].reverse().find(x=>x.k==="B");
      if(!lastBid) return M({ text:"Double." });
      const oppLast = lastBid.by===S.lho || lastBid.by===S.rho;
      if(!oppLast) return M({ text:"Double of partner's bid — not a normal action." });
      // takeout vs penalty: low-level double of a suit, partner hasn't bid = TAKEOUT
      const lowLevel = lastBid.level<=3 && lastBid.strain!=="NT";
      if(lowLevel && !S.pBids.length && !S.myBids.length){
        /* FIRST: is the bid I am doubling even NATURAL? Doubling an ARTIFICIAL bid — a Jacoby transfer, a
         * Stayman 2C, a cuebid, a strong 2C — is a LEAD-DIRECTING double. It says "partner, I have THIS suit,
         * lead it", which is the exact OPPOSITE of the takeout meaning (short in the suit, support for the
         * others). The suit named isn't even the opponents' real suit. Describing 2D-transfer-doubled as
         * "takeout, short in diamonds" and then flagging the doubler for holding AKJ93 of diamonds accuses a
         * textbook lead-directing double of being a lie. callMeaning already computes `artificial`, so ask it. */
        const idxLast = calls.lastIndexOf(lastBid);
        let lastM = null;
        try{ lastM = callMeaning(lastBid, calls.slice(0, idxLast<0?calls.length:idxLast), dealer, lastBid.by); }catch(_){}
        if(lastM && lastM.artificial) return M({ role:"competitive", confidence:"judgment",
          text:`Double of an artificial ${call(lastBid)}: LEAD-DIRECTING \u2014 it shows ${sname(lastBid.strain)} and asks partner to lead it. It is not takeout, and it does not promise opening values.` });
        /* THE TEXT TEACHES THE STANDARD; THE CONSTRAINT ENCODES ONLY THE INDEFENSIBLE.
         * A takeout double normally shows opening values + shortness + support for the others — but SAYC has a
         * genuine second hand for it (too strong to overcall, 17+, ANY shape), and light doubles on 4-4-4-1
         * with 10-11 are ordinary expert style. Darkening the full "12+ and short" promise would mark a
         * student wrong for playing real bridge. So the promise we enforce is only what no style permits:
         *   - hcpMin 10 : below that a takeout double at these levels is indefensible in any system.
         *   - suitMax 4 in THEIR suit : a double asks partner to bid the suits you are SHORT in. With five of
         *     their suit you want to defend, not take out. Never a takeout double in any style.
         * Same operating principle as the Tier-2 blunder gate: speak only about the indefensible.
         *
         * BUT THE SHORTNESS CLAUSE NEEDS EXACTLY ONE ENEMY SUIT TO EVEN MEAN ANYTHING. After (1D)-P-(1S) a
         * double is takeout of BOTH their suits, showing the two UNBID ones — there is no single suit the
         * promise is "short in", and the app's table targets the OPENING suit while a naive reading targets
         * the LAST BID one. When we cannot say which suit the promise is about, we do not make the promise.
         * The strength floor still holds; the shape clause is dropped.
         * NOTE mustAnswer stays FALSE — passing a takeout double to convert it to penalties is expert play. */
        const theirSuits = [...new Set(S.oppBids.filter(b=>b.strain!=="NT").map(b=>b.strain))];
        if(theirSuits.length !== 1) return M({ role:"competitive", artificial:true, forcing:true,
          confidence:"standard",
          text:`Takeout double: the opponents have bid ${theirSuits.map(sname).join(" and ")}, so this asks partner to pick one of the OTHER suits. Opening values \u2014 it does not offer to defend.`,
          constraint:{ hcpMin:10 } });
        return M({ role:"competitive", artificial:true, forcing:true, confidence:"standard",
          text:`Takeout double: opening values, short in ${sname(lastBid.strain)}, support for the other suits — asking partner to pick a suit. It does NOT show ${sname(lastBid.strain)}.`,
          constraint:{ hcpMin:10, suitMax:{ [lastBid.strain]:4 } } });
      }
      if(S.pBids.length && S.myBids.length)
        return M({ role:"competitive", text:"Penalty double — you expect to beat this contract." });
      return M({ role:"competitive", text:"Double — takeout or penalty depending on the auction; judgment call." });
    }
    if(c.k==="R") return M({ role:"competitive", text:"Redouble — typically 10+ points, showing values after an opponent's double." });

    // ---------- BIDS ----------
    const { level, strain } = c;

    // ===== 1) OPENING (no one has bid) =====
    if(S.noBidsYet || (!S.iOpened && !S.partnerOpened && !S.oppsOpened)){
      if(strain==="NT"){
        if(level===1) return M({ role:"opening", confidence:"standard", text:"15–17 points, balanced.", constraint:{ hcpMin:15, hcpMax:17 } });
        if(level===2) return M({ role:"opening", confidence:"standard", text:"20–21 points, balanced.", constraint:{ hcpMin:20, hcpMax:21 } });
        if(level===3) return M({ role:"opening", confidence:"standard", text:"25–27 points, balanced.", constraint:{ hcpMin:25, hcpMax:27 } });
      }
      if(level===1){
        const need = isMajor(strain) ? 5 : 3;
        // The FIRM promise is the SUIT LENGTH. Strength is deliberately NOT a hard bound: a sound opening can be
        // an 11-count by the Rule of 20 or a shapely hand on total points (which is what the app's own bots do),
        // so a hard hcpMin would flag legitimate openings. Length is inviolable; strength is judgment.
        return M({ role:"opening", confidence:"standard",
          text:`Opening bid: ${need}+ ${sname(strain)}, about 12+ points (a shapely 11 can qualify by the Rule of 20).`,
          constraint:{ suitMin:{ [strain]:need } } });
      }
      if(level===2 && strain==="C") return M({ role:"opening", artificial:true, forcing:true, confidence:"standard",
        mustAnswer:true, mustAnswer:true, text:"Strong, artificial 2\u2663: 20+ points (or 9+ playing tricks). Says NOTHING about clubs — forcing.",
        constraint:{ hcpMin:20 } });
      if(level===2) return M({ role:"preempt", confidence:"standard",
        text:`Weak two: 6 ${sname(strain)}, about 5\u201311 points — preemptive, not an opening bid.`,
        constraint:{ hcpMin:5, hcpMax:11, suitMin:{ [strain]:6 } } });
      if(level>=3 && strain!=="NT") return M({ role:"preempt", confidence:"standard",
        text:`Preempt: ${level+4}+ ${sname(strain)}, about 5\u201311 points — take away the opponents' bidding room.`,
        constraint:{ hcpMin:5, hcpMax:11, suitMin:{ [strain]:level+4 } } });
    }

    // ===== 2) OPPONENTS OPENED — my first call =====
    // FIRST: am I ADVANCING partner's takeout double? A takeout double ASKS me to name my best suit, so any
    // 4-card suit is correct here — it is NOT an overcall and promises no 5-card suit. (Missing this case made
    // the describer flag the app's own correct bids.)
    const partnerDoubled = calls.some(x=>x.k==="D" && x.by===S.partner);
    if(S.oppsOpened && partnerDoubled && !S.myBids.length){
      if(strain==="NT") return M({ role:"response", confidence:"judgment",
        text:"Notrump in reply to partner's takeout double: a stopper in their suit and some values." });
      // CUEBID of the opponents' OWN suit. Partner's double asked me to name a suit of MY OWN, so bidding
      // THEIRS cannot be that answer — it is the artificial game-forcing ask (which is exactly what the app's
      // table bids: bidding.js respondToTakeoutDouble, "cuebid = GF ask"). It promises nothing about the suit,
      // so describing it as "your best suit, 4+" and then flagging a lie was accusing the bot of its own system.
      const theirSuits = new Set(S.oppBids.filter(b=>b.strain!=="NT").map(b=>b.strain));
      if(theirSuits.has(strain)) return M({ role:"conventional", artificial:true, forcing:true,
        confidence:"judgment",
        text:`Cuebid of the opponents' ${sname(strain)} over partner's takeout double: artificial and game-forcing \u2014 a strong hand asking partner to describe further. It does NOT show ${sname(strain)}.` });
      // The genuine answer: name your best suit. The promise is 4+ — but ONLY when a 4-card suit EXISTS. The
      // convention is "bid your LONGEST suit outside theirs", and with no 4-card suit that forces a 3-card bid
      // (which is what the table does: bidding.js falls back to the longest non-enemy suit). Flagging that as a
      // lie punishes a player for obeying the convention, so the length clause carries a `bestSuit` exemption
      // that checkHonesty waives in exactly that forced case. Degrade, don't corrupt.
      return M({ role:"response", confidence:"standard",
        text:`Answering partner's takeout double: naming your best suit (4+ ${sname(strain)}). Partner ASKED you to bid \u2014 you are not promising strength.`,
        constraint:{ suitMin:{ [strain]:4 } },
        exempt:{ kind:"bestSuit", exclude:[...theirSuits] } });
    }
    if(S.oppsOpened && !S.myBids.length && !S.pBids.length){
      // CUEBID: bidding the opponents' OWN suit is artificial (a strong takeout / asking bid), never natural.
      const oppSuits = new Set(S.oppBids.filter(b=>b.strain!=="NT").map(b=>b.strain));
      if(strain!=="NT" && oppSuits.has(strain)) return M({ role:"conventional", artificial:true, forcing:true,
        confidence:"judgment", text:`Cuebid of the opponents' ${sname(strain)}: artificial and very strong — it does NOT show ${sname(strain)}.` });
      if(strain==="NT" && level===1) return M({ role:"overcall", confidence:"judgment",
        text:"1NT overcall: 15\u201318 points, balanced, with a stopper in their suit." });
      if(strain!=="NT"){
        // Only a SIMPLE (non-jump) overcall is reliably a natural 5+ suit. A JUMP overcall is preemptive, and a
        // jump to game is a shape/shut-out bid — both can be made on other shapes, and treating them as a firm
        // 5+ promise would flag the app's own bots. Describe them, but do NOT make a darkenable claim.
        const lastOppBid = [...S.oppBids].pop();
        const cheapest = lastOppBid ? (lastOppBid.strain==="NT" || SUITS.indexOf(strain) < SUITS.indexOf(lastOppBid.strain)
                           ? lastOppBid.level : lastOppBid.level+1) : 1;
        const isJump = level > cheapest;
        if(!isJump) return M({ role:"overcall", confidence:"standard",
          text:`Overcall: 5+ ${sname(strain)} \u2014 a good suit matters more than the point count.`,
          constraint:{ suitMin:{ [strain]:5 } } });
        return M({ role:"preempt", confidence:"judgment",
          text:`Jump overcall: preemptive \u2014 a long ${sname(strain)} suit and shape, taking away the opponents' room. Not a strength-showing bid.` });
      }
    }

    // ===== 3) PARTNER OPENED — I am the RESPONDER =====
    if(S.partnerOpened && S.partnerLast){
      const op = S.pBids[0];   // partner's opening bid
      // SYSTEMS ON/OFF. Every conventional response below (Stayman, Jacoby, the artificial 2D waiting bid)
      // exists only in an UNCONTESTED auction. The app's own table plays SYSTEMS OFF over an opponent's suit
      // overcall (bidding.js: "Systems are OFF: Stayman and transfers do not apply") — over interference a
      // new suit is NATURAL and competitive. Describing a natural 2H as a "transfer showing 5+ spades" would
      // teach something the table does not play, and would flag the app's own correct bids as lies.
      // NOTE: `oppBids` counts BIDS only, not doubles — systems stay ON over a double, exactly as the bot plays.
      const systemsOn = S.oppBids.length===0;
      // --- responses to 1NT ---
      if(op.level===1 && op.strain==="NT" && !S.myBids.length && systemsOn){
        if(level===2 && strain==="C") return M({ role:"conventional", artificial:true, forcing:true, confidence:"standard",
          mustAnswer:true, mustAnswer:true, text:"Stayman: 8+ points, asking for a 4-card major. Says NOTHING about clubs.", constraint:{ hcpMin:8 } });
        if(level===2 && (strain==="D"||strain==="H")){
          const shows = strain==="D" ? "H" : "S";
          return M({ role:"conventional", artificial:true, forcing:true, confidence:"standard",
            mustAnswer:true, mustAnswer:true, text:`Jacoby transfer: shows 5+ ${sname(shows)} (any strength) and asks partner to bid ${sname(shows)}. Says NOTHING about ${sname(strain)}.`,
            constraint:{ suitMin:{ [shows]:5 } } });
        }
        if(strain==="NT" && level===2) return M({ role:"response", confidence:"standard", text:"Invitational: 8\u20139 points, balanced. Partner passes with 15, bids game with 16\u201317.", constraint:{ hcpMin:8, hcpMax:9 } });
        if(strain==="NT" && level===3) return M({ role:"response", confidence:"standard", text:"Game: 10\u201315 points, balanced, no 4-card major.", constraint:{ hcpMin:10, hcpMax:15 } });
      }
      // --- responses to a 1-of-a-suit opening ---
      if(op.level===1 && op.strain!=="NT" && !S.myBids.length){
        // raise of partner's suit
        if(strain===op.strain){
          if(level===2) return M({ role:"raise", confidence:"standard",
            text:`Simple raise: 3+ ${sname(strain)} support, about 6\u201310 points (shortness adds value).`,
            constraint:{ suitMin:{ [strain]:3 } } });   // support is the firm promise; strength counts shape -> judgment
          if(level===3) return M({ role:"raise", confidence:"standard",
            text:`Limit raise: 3+ ${sname(strain)} support, about 11\u201312 points — invitational.`,
            constraint:{ suitMin:{ [strain]:3 } } });
          if(level===4 && isMajor(strain)) return M({ role:"raise", confidence:"judgment",
            text:`Game raise: 5+ ${sname(strain)} support but WEAK in high cards — preemptive, shutting the opponents out.`,
            constraint:{ suitMin:{ [strain]:5 } } });
        }
        // new suit at the 1 level
        if(level===1 && strain!=="NT") return M({ role:"response", forcing:true, confidence:"standard",
          mustAnswer:true, mustAnswer:true, text:`New suit at the 1 level: 4+ ${sname(strain)}, 6+ points. Forcing — partner must bid again.`,
          constraint:{ hcpMin:6, suitMin:{ [strain]:4 } } });
        // new suit at the 2 level (two-over-one)
        if(level===2 && strain!=="NT" && strain!==op.strain) return M({ role:"response", forcing:true, confidence:"standard",
          mustAnswer:true, mustAnswer:true, text:`New suit at the 2 level: 4+ ${sname(strain)} and around 10+ points \u2014 forcing (partner must bid again).`,
          constraint:{ suitMin:{ [strain]:4 } } });   // length is the firm promise; the strength floor is judgment
        if(strain==="NT"){
          if(level===1) return M({ role:"response", confidence:"standard", text:"6\u201310 points, no fit for partner's suit and no suit of your own to bid at the 1 level.", constraint:{ hcpMin:6, hcpMax:10 } });
          if(level===2) return M({ role:"response", confidence:"judgment", text:"Invitational: about 11\u201312 points, balanced." });
          if(level===3) return M({ role:"response", confidence:"standard", text:"Game: 13\u201315 points, balanced, no major fit.", constraint:{ hcpMin:13, hcpMax:15 } });
        }
      }
      // --- responses to a weak two / preempt ---
      if(op.level>=2 && op.strain!=="NT" && op.strain!=="C" && !S.myBids.length){
        if(strain===op.strain) return M({ role:"raise", confidence:"judgment",
          text:`Raising partner's preempt — usually further preemption (fit + shape), not extra strength.`,
          constraint:{ suitMin:{ [strain]:2 } } });
      }
      // --- responses to a strong 2C ---
      if(op.level===2 && op.strain==="C" && !S.myBids.length && systemsOn){
        if(level===2 && strain==="D") return M({ role:"conventional", artificial:true, forcing:true, confidence:"standard",
          mustAnswer:true, mustAnswer:true, text:"Waiting: the standard artificial reply to 2\u2663 (0\u20137 points, or any hand waiting to hear more). Says NOTHING about diamonds.",
          constraint:{ } });
      }
    }

    // ===== 4) I OPENED — my REBID =====
    if(S.iOpened && S.myBids.length && S.pBids.length){
      const myOpen = S.myBids[0];
      /* THE NATURAL NOTRUMP REBID — a firm, teachable promise, but only in a tightly fenced position.
       * Fenced because the SAME bid means different things elsewhere: 2NT is 18-19 as a JUMP over a 1-level
       * response, but only 12-14 over a 2-level response (where it isn't a jump at all). Same call, six-point
       * difference. So: I opened ONE of a SUIT, partner responded ONCE at the ONE level, nobody interfered,
       * and this is my first rebid. Outside that, it stays judgment.
       *
       * THE RANGE IS IN HCP, BUT THE TABLE BIDS ON TOTAL POINTS. bidding.js counts 5332 as balanced, so a
       * 5332 hand carries one length point and the bot rebids 1NT on tp 12-14 — i.e. on ELEVEN HCP. A naive
       * hcpMin:12 would flag the app's own correct rebid. Balanced tops out at a 5-card suit, so lp <= 1 and
       * tp in [12,14] => hcp in [11,14]. That is the honest floor, and it is still firmly teachable: rebidding
       * 1NT with 15+ conceals extras, and with 10 or fewer you have no business in the auction. */
      const cleanRebid = myOpen.level===1 && myOpen.strain!=="NT" && S.myBids.length===1
                      && S.oppBids.length===0 && S.pBids.length===1 && S.pBids[0].level===1;
      if(strain==="NT" && cleanRebid && level===1) return M({ role:"rebid", confidence:"standard",
        text:"12\u201314 points, balanced \u2014 the minimum notrump rebid. With more you must show it.",
        constraint:{ hcpMin:11, hcpMax:14 } });
      if(strain==="NT" && cleanRebid && level===2) return M({ role:"rebid", confidence:"standard",
        text:"Jump to 2NT: 18\u201319 points, balanced \u2014 too strong for a 1NT rebid, invitational to game.",
        constraint:{ hcpMin:17, hcpMax:19 } });
      // Rebidding my own suit shows 6+ — but NOT firmly. When partner's new suit is forcing and nothing else
      // is biddable, the table rebids a FIVE-card suit rather than pass (bidding.js forcing guard). A promise
      // you were forced to break is not a lie, so this stays judgment.
      if(strain===myOpen.strain && level>myOpen.level) return M({ role:"rebid", confidence:"judgment",
        text:`Rebidding your own suit shows extra length (6+) — the higher the level, the more strength.`,
        constraint:{ suitMin:{ [strain]:6 } } });
      if(strain===S.partnerLast.strain) return M({ role:"raise", confidence:"standard",
        text:`Raising partner's suit shows ${level>=3?"extra values and":"minimum values with"} genuine support (4+ preferred, 3+ acceptable).`,
        constraint:{ suitMin:{ [strain]:3 } } });
      if(strain==="NT") return M({ role:"rebid", confidence:"judgment",
        text:`${level===1?"12\u201314":level===2?"18\u201319":"Strong"} points, balanced — a natural notrump rebid.` });
      /* THE REVERSE — a new suit, at the 2 level, ranking HIGHER than the suit opened. It forces partner to
       * the 3 level to give preference back to opener's first suit, so it PROMISES EXTRAS and is forcing.
       * Partner will drive to game on it. Reversing with 11 points is not aggression; it is a lie.
       *
       * NOTE THE SUIT ORDER. `SUITS` here is ["S","H","D","C"] — DESCENDING rank, so higher-ranking means a
       * LOWER index. bidding.js uses the opposite convention (`ORDER = ["C","D","H","S"]`, higher index =
       * higher rank). Same predicate, inverted test; getting it backwards would darken every bid that is NOT
       * a reverse and none that is.
       *
       * This promise could not be firmed until the BOT stopped breaking it. It was reversing on 11 HCP —
       * 294 of 327 reverses were light (reports/BIDDING_REVERSE.md), from two separate bugs in secondSuit().
       * Both are now fixed and the bot reverses only on 17+, so the promise is finally safe to enforce.
       *
       * TEXT TEACHES THE STANDARD (17+); THE CONSTRAINT ENFORCES ONLY THE INDEFENSIBLE (16). SAYC says "17+,
       * or a good 16", and a student who reverses on a good 16 is playing real bridge, not lying. Below 16
       * there is no style that permits it.
       *
       * UNCONTESTED ONLY, and that is not fussiness — it is the cuebid trap again. If an opponent has bid the
       * suit, a 2-level bid of it is a CUEBID (artificial, game-forcing), not a reverse: after 1C-(1S)-... a
       * rebid of 2S is bidding THEIR suit, and reading it as "a strong hand with four spades" is a category
       * error. Over interference the strength requirement for a genuine second suit is murkier anyway (a free
       * bid says its own thing), so we describe but do not darken. */
      const contested = S.oppBids.length > 0;
      const isReverse = !contested && level===2 && strain!==myOpen.strain
                     && myOpen.level===1 && myOpen.strain!=="NT"
                     && S.myBids.length===1 && SUITS.indexOf(strain) < SUITS.indexOf(myOpen.strain);
      if(isReverse) return M({ role:"rebid", forcing:true, mustAnswer:true, confidence:"standard",
        text:`Reverse: a NEW suit at the 2 level ranking above your first — 4+ ${sname(strain)} and a strong hand (17+). It forces partner to the 3 level to go back to your first suit, so it promises the extra values to be safe there. Forcing.`,
        constraint:{ hcpMin:16, suitMin:{ [strain]:4 } } });
      if(strain!=="NT") return M({ role:"rebid", forcing:false, confidence:"judgment",
        text:`A new suit shows a second suit (4+ cards) — a minimum rebid, no extra strength promised.`,
        constraint:{ suitMin:{ [strain]:4 } } });
    }

    // ===== 5) Blackwood / slam machinery =====
    // 4NT is Blackwood only in a SUIT context. With no suit bid by our side the auction is natural notrump and
    // 4NT is QUANTITATIVE — an invitation to 6NT that partner may PASS with a minimum. The distinction is not
    // cosmetic: Blackwood is FORCING (partner must answer the ace-ask) and quantitative is not, so mislabelling
    // a quantitative 4NT would make the grade accuse a correct pass of abandoning a force. Same call, opposite
    // obligation. (bidding.js draws the same line: "not a jump from NT which is quantitative".)
    if(level===4 && strain==="NT"){
      const ourSuitBid = [...S.myBids, ...S.pBids].some(b=>b.strain!=="NT");
      if(ourSuitBid) return M({ role:"conventional", artificial:true, forcing:true, mustAnswer:true, confidence:"standard",
        mustAnswer:true, text:"Blackwood: asking how many aces partner holds. Says NOTHING about notrump \u2014 partner MUST answer." });
      return M({ role:"rebid", confidence:"judgment",
        text:"Quantitative 4NT: a natural invitation to 6NT. Not Blackwood, and not forcing \u2014 partner passes with a minimum and bids the slam with extras." });
    }

    // ===== fallback: honest about uncertainty =====
    return M({ role:"other", confidence:"judgment",
      text: strain==="NT" ? `${level}NT — a natural notrump bid; strength depends on the auction.`
                          : `${level}${GLYPH[strain]} — natural: shows ${sname(strain)}. Exact strength depends on the auction.` });
  }

  /* Does a call MISREPRESENT the hand? Only fires when the promise is a FIRM standard one (confidence
   * "standard") AND the hand fails it. Judgment calls are NEVER flagged — punishing a legitimate upgrade or a
   * tactical underbid teaches rigidity. Returns {lie:bool, why} */
  function checkHonesty(c, calls, dealer, seat, hand){
    const m = callMeaning(c, calls, dealer, seat);
    if(!m.constraint || m.confidence!=="standard") return { lie:false, why:null, meaning:m };
    const orig = hand.map(x=>({rank:x.rank, suit:x.suit}));
    const ok = BELIEF.handOk(orig, m.constraint);
    if(ok) return { lie:false, why:null, meaning:m };
    const ev = evalHand(orig);
    /* BEST-SUIT EXEMPTION. Some conventions promise a length the hand may be UNABLE to supply, and then tell
     * you to bid anyway: answering a takeout double, you name your longest suit outside theirs even if it is
     * only three cards. Length is inviolable — but a promise you were ORDERED to break is not a lie, and
     * flagging it teaches a player to disobey the convention. So when (a) no suit of the promised length exists
     * outside the excluded suits and (b) the suit actually bid IS the longest available, the length clause is
     * waived. It is NOT waived if a longer suit was available: choosing the wrong suit is still a real error. */
    if(m.exempt && m.exempt.kind==="bestSuit" && c.k==="B" && c.strain!=="NT"){
      const avail = SUITS.filter(s=>!m.exempt.exclude.includes(s));
      const need = (m.constraint.suitMin||{})[c.strain] || 0;
      const hasNeeded = avail.some(s=>ev.len[s] >= need);
      const longest = avail.reduce((a,s)=>Math.max(a, ev.len[s]), 0);
      if(!hasNeeded && ev.len[c.strain] >= longest) return { lie:false, why:null, meaning:m, forced:true };
    }
    // name the specific breach (so the hint teaches, not just forbids)
    const con = m.constraint;
    const parts=[];
    if(con.hcpMin!=null && ev.hcp < con.hcpMin) parts.push(`you have ${ev.hcp} points, this promises ${con.hcpMin}+`);
    if(con.hcpMax!=null && ev.hcp > con.hcpMax) parts.push(`you have ${ev.hcp} points, this promises at most ${con.hcpMax}`);
    if(con.suitMin) for(const s in con.suitMin){ if(ev.len[s] < con.suitMin[s]) parts.push(`you have ${ev.len[s]} ${sname(s)}, this promises ${con.suitMin[s]}+`); }
    if(con.suitMax) for(const s in con.suitMax){ if(ev.len[s] > con.suitMax[s]) parts.push(`you have ${ev.len[s]} ${sname(s)}, this promises at most ${con.suitMax[s]}`); }
    return { lie:true, why: parts.join("; ") || "this doesn't match what the bid promises", meaning:m };
  }

  /* Hand metrics for the trainer panel — everything a player needs to read the buttons against. */
  function handMetrics(hand){
    const ev = evalHand(hand.map(x=>({rank:x.rank,suit:x.suit})));
    return { hcp:ev.hcp, lengthPoints:ev.lp, total:ev.tp, balanced:ev.balanced,
      lengths:ev.len, longest:ev.longest, shape:ev.shape.join("-"),
      ruleOf20: (()=>{ const two=SUITS.slice().sort((a,b)=>ev.len[b]-ev.len[a]).slice(0,2);
                       return ev.hcp + ev.len[two[0]] + ev.len[two[1]] >= 20; })() };
  }

  return { callMeaning, checkHonesty, handMetrics, evalHand };
})();

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { MEAN };
//#endregion gen
