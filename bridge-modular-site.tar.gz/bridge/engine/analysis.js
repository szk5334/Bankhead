//#region gen (auto — removed when bundled to a single bridge.jsx)
import { SOL } from "./solitaire.js";
//#endregion gen

/* analysis.js — THE POST-HAND ANALYSIS. Pure: no solver, no async. It takes the two lenses, already
 * computed, and says what they MEAN together.
 *
 * ─────────────────────────────────────────────────────────────────────────────────────────────────────────
 * THE ONE NUMBER THIS MODE EXISTS TO PRODUCE
 * ─────────────────────────────────────────────────────────────────────────────────────────────────────────
 * Every card gets two verdicts:
 *
 *   DD (perfect information)  — did you play the best card, with all four hands face up? EXACT. Not a
 *                               sample, not an estimate: with nothing hidden, double-dummy IS the truth.
 *   SD (belief-sampled)       — would you have played it if you COULDN'T see their hands?
 *
 * Crossing them gives four cells, and the app's own `twoLensGrade` already computes exactly this crossing.
 * But ONE OF THE FOUR MEANS SOMETHING COMPLETELY DIFFERENT HERE, and that difference is the whole mode:
 *
 *      DD ✓  SD ✓   'right'    ->  SOUND.        You found it, and you'd have found it blind.
 *      DD ✗  SD ✓   'unlucky'  ->  UNLUCKY.      Right by the odds; this layout beat it. NOT a mistake.
 *      DD ✓  SD ✗   'lucky'    ->  CLAIRVOYANT.  <<<< THE POINT
 *      DD ✗  SD ✗   'wrong'    ->  MISTAKE.      Wrong both ways.
 *
 * In the NORMAL game, 'lucky' means *you got away with it* — a curiosity, the least interesting cell.
 * In SOLITAIRE it means: **you played the double-dummy best card, but it is not the card a player who
 * could not see the other hands would ever have chosen.** You did not get lucky. YOU LOOKED.
 *
 * So the headline metric is the CLAIRVOYANCE RATE: of your correct-looking plays, how many did you only
 * find by peeking? A player who chases the DD-best card every time will score 100% on the puzzle and learn
 * nothing about bridge, and this is the number that says so out loud.
 *
 * ─────────────────────────────────────────────────────────────────────────────────────────────────────────
 * WHAT IS NOT A DECISION
 * ─────────────────────────────────────────────────────────────────────────────────────────────────────────
 * A singleton is not a decision. Neither is a card that ties every alternative double-dummy. If those paid
 * the same credit as a real choice, "playing well" would mean "being dealt easy cards". They are counted and
 * reported, and they are NEVER scored. (SOL.gradeCard already draws this line; we honour it.)
 */

const ANA = (function(){

  /* Solitaire renames one cell of twoLensGrade's classification, because here it means the opposite thing. */
  const CELL = {
    right:   { key:"sound",       label:"sound",       tone:"good",
               blurb:"Best card, and the one you'd have found without seeing their hands." },
    unlucky: { key:"unlucky",     label:"unlucky",     tone:"neutral",
               blurb:"The percentage play. This layout beat it — that is not a mistake." },
    lucky:   { key:"clairvoyant", label:"clairvoyant", tone:"warn",
               blurb:"The double-dummy best card — but NOT the play a blind player would find. You only found this because you can see their hands." },
    wrong:   { key:"mistake",     label:"mistake",     tone:"bad",
               blurb:"Wrong on both lenses: it is not best here, and it is not the percentage play either." },
  };

  /* Which positions are worth spending the SD lens on?
   * FORCED cards are excluded: with one legal card there is no question to ask, blind or sighted — the SD
   * answer is trivially the same card. Everything else earns its 16 belief worlds.
   * This is not only a saving (it typically cuts ~14 of 52 positions); it is the correct thing to ask. */
  function sdWorklist(ddByPos, playedByPos){
    const out=[];
    for(const posKey of Object.keys(playedByPos)){
      const dd = ddByPos[posKey];
      if(!dd) continue;
      const g = SOL.gradeCard(dd, playedByPos[posKey]);
      if(g.kind === "forced" || g.kind === "none") continue;
      out.push(posKey);
    }
    return out;
  }

  /* Combine. `positions` = [{posKey, seat, trick, dd, playedKey, sd}] where `sd` is the worker's two-lens
   * grade for that position, or null if it hasn't landed (or wasn't asked for). */
  function analyse({ calls = [], positions = [], contract = null, tricks = null, par = null }){
    // ---- bidding ----
    const myCalls = calls.filter(c => c.grade);
    const bidMarked = myCalls.filter(c => c.grade.points < 100);
    const bidding = {
      total: myCalls.length,
      marked: bidMarked.length,
      calls: myCalls,
      worst: bidMarked.slice().sort((a,b)=>a.grade.points-b.grade.points),
    };

    // ---- play ----
    const cards=[]; let forced=0, free=0;
    const tally = { sound:0, unlucky:0, clairvoyant:0, mistake:0, unknown:0 };
    let ddLost = 0;

    for(const p of positions){
      const g = SOL.gradeCard(p.dd, p.playedKey);
      if(g.kind === "none") continue;
      if(g.kind === "forced"){ forced++; continue; }
      if(g.kind === "free"){ free++; continue; }

      ddLost += g.lost;
      /* The two-lens verdict lives on `g.lens`, not at the top level — computeGrade attaches twoLensGrade's
       * output under that key. Reading `sd.classification` gets you `undefined`, which silently classifies
       * every decision as "not analysed" while the pass reports success. Ask for the field that exists. */
      const cname = p.sd ? ((p.sd.lens && p.sd.lens.classification) || p.sd.classification) : null;
      const cls = cname ? CELL[cname] : null;
      const cell = cls ? cls.key : "unknown";
      tally[cell] = (tally[cell]||0) + 1;

      cards.push({
        posKey: p.posKey, seat: p.seat, trick: p.trick,
        playedKey: p.playedKey,
        hinted: p.hinted || null,          // "dd" | "sd" | null — was this decision TOLD to you?
        ddOptimal: g.optimal, ddLost: g.lost, ddVal: g.val, ddBest: g.best, ddEquiv: g.equiv,
        cell, cellLabel: cls ? cls.label : "not analysed", blurb: cls ? cls.blurb : null,
        sd: p.sd || null,
        // The SD lens's own name for the sharpest case: the DD-best card isn't even SD-*sound*.
        needsClairvoyance: !!(p.sd && p.sd.needs_clairvoyance),
        why: p.sd ? ((p.sd.lens && p.sd.lens.why) || p.sd.best_why || null) : null,
        sdBest: p.sd ? (p.sd.best_named || p.sd.best || null) : null,
      });
    }

    const decisions = cards.length;
    const analysed = decisions - tally.unknown;

    /* AIDED vs UNAIDED. A hinted decision is NOT a decision you made — you were told the answer. Counting it
     * toward your play would inflate every number in this report, and a teaching tool that flatters the
     * student about their own progress is worse than useless: it is actively lying to them.
     *
     * So the headline numbers are computed over the UNAIDED decisions only, and the aided ones are reported
     * separately and honestly. Play a whole hand on auto-hint and the report will say, correctly, that you
     * made no unaided decisions and there is nothing here to measure. That is the truth, and it should sting
     * a little. */
    const unaided = cards.filter(c => !c.hinted);
    const aided   = cards.filter(c =>  c.hinted);
    const uTally = { sound:0, unlucky:0, clairvoyant:0, mistake:0, unknown:0 };
    let uLost = 0;
    for(const c of unaided){ uTally[c.cell] = (uTally[c.cell]||0)+1; uLost += c.ddLost; }

    // Of the UNAIDED plays that LOOK right double-dummy, how many did you only find by peeking at the hands?
    const looksRight = uTally.sound + uTally.clairvoyant;
    const clairvoyanceRate = looksRight ? uTally.clairvoyant / looksRight : 0;

    // Rank the real errors: a mistake outranks clairvoyance, and within each, more tricks lost is worse.
    const RANK = { mistake:0, clairvoyant:1, unlucky:2, unknown:3, sound:4 };
    const worst = cards.slice().sort((a,b)=>
      (RANK[a.cell]-RANK[b.cell]) || (b.ddLost-a.ddLost) || (a.trick-b.trick));

    return {
      bidding,
      play: {
        decisions, forced, free, analysed,
        // headline counts are the UNAIDED ones — the decisions you actually made
        ...uTally,
        ddTricksLost: uLost,
        clairvoyanceRate,
        // and the aided ones, reported, never hidden
        aided: aided.length,
        unaided: unaided.length,
        aidedTricksLost: ddLost - uLost,
        totals: tally,                 // every decision, hinted or not
        totalTricksLost: ddLost,
        cards, worst,
      },
      contract, tricks, par,
      complete: tally.unknown === 0 && decisions > 0,
    };
  }

  /* One honest sentence. No score, no praise inflation — V1 has no points, and the summary must not smuggle
   * them back in by tone. */
  function headline(a){
    const p = a.play;
    if(!p.decisions) return "No real decisions in this hand — every card was forced or double-dummy indifferent.";
    if(!p.unaided) return `All ${p.decisions} of your real decision${p.decisions===1?" was":"s were"} hinted. `
      + `A guided tour, not a test — there is nothing here to measure. Turn the hints off and play it again.`;
    const bits = [`${p.unaided} unaided decision${p.unaided===1?"":"s"}`];
    if(p.aided) bits.push(`${p.aided} hinted`);
    if(p.forced || p.free) bits.push(`${p.forced} forced, ${p.free} indifferent`);
    let s = bits.join(" \u00b7 ") + ".";
    if(p.mistake)     s += ` ${p.mistake} mistake${p.mistake===1?"":"s"}, costing ${p.ddTricksLost} trick${p.ddTricksLost===1?"":"s"} double-dummy.`;
    else if(p.ddTricksLost) s += ` No outright mistakes, but ${p.ddTricksLost} trick${p.ddTricksLost===1?"":"s"} went by.`;
    else              s += " Nothing given away.";
    if(p.clairvoyant) s += ` ${p.clairvoyant} play${p.clairvoyant===1?"":"s"} you would NOT have found without seeing their hands.`;
    if(p.unlucky)     s += ` ${p.unlucky} right-but-beaten (not your fault).`;
    return s;
  }

  return { analyse, headline, sdWorklist, CELL };
})();

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { ANA };
//#endregion gen
