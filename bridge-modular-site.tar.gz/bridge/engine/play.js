//#region gen (auto — removed when bundled to a single bridge.jsx)
import { ENG } from "./core.js";
import { partnerOf, sideOf } from "../state/constants.js";
import { who } from "../state/personas.js";
import { C } from "../ui/theme.js";
//#endregion gen

const PLY = (function(){
  /* Standard contract-bridge card play — sound single-dummy technique.
     Every decision returns {card, why} so "teaching mode" can explain the exact
     card the engine chose (single source of truth). chooseCard() unwraps to the card.
  
     ctx = { hand, trick:[{rank,suit,player}], ledSuit, trump, seat, declarer, dummy,
             seen[], dummyHand?, mateHand? } */
  const { resolveTrick, legalPlays, RANKVAL, makeDeck } = ENG;
  
  const SUITS=["S","H","D","C"];
  const partnerOf=(s)=>(s+2)%4;
  const sideOf=(s)=>s%2;
  const W=(card,code,p)=>({card, why:Object.assign({code}, p||{})});
  
  const byAsc  =(cs)=> cs.slice().sort((a,b)=>RANKVAL[a.rank]-RANKVAL[b.rank]);
  const byDesc =(cs)=> cs.slice().sort((a,b)=>RANKVAL[b.rank]-RANKVAL[a.rank]);
  function buckets(hand){ const b={S:[],H:[],D:[],C:[]}; for(const c of hand) b[c.suit].push(c); return b; }
  function currentWinner(trick, ledSuit, trump){
    if(!trick.length) return { winner:-1, card:null };
    const r=resolveTrick(trick, ledSuit, trump);
    return { winner:r.winner, card:trick.find(c=>c.player===r.winner) };
  }
  function cheapestWinner(ctx, legal){
    const { trick, ledSuit, trump, seat } = ctx;
    const wins=legal.filter(card=>{
      const r=resolveTrick([...trick,{rank:card.rank,suit:card.suit,player:seat}], ledSuit, trump);
      return r.winner===seat;
    });
    return wins.length ? byAsc(wins)[0] : null;
  }
  function outstanding(suit, known, seen){
    const have=new Set();
    known.forEach(c=>{ if(c.suit===suit) have.add(c.rank); });
    (seen||[]).forEach(c=>{ if(c.suit===suit) have.add(c.rank); });
    return ["A","K","Q","J","10","9","8","7","6","5","4","3","2"].filter(r=>!have.has(r));
  }
  function topOut(suit, known, seen){ const o=outstanding(suit,known,seen); return o.length?RANKVAL[o[0]]:0; }
  
  // full-reason entry point
  function chooseCardWhy(ctx){
    const { hand, trick, ledSuit } = ctx;
    const legal = legalPlays(hand, trick.length? ledSuit : null);
    if(legal.length===1) return W(legal[0], "ONLY");
    return trick.length===0 ? chooseLead(ctx, legal) : chooseFollow(ctx, legal);
  }
  // card-only entry point (bots)
  function chooseCard(ctx){ return chooseCardWhy(ctx).card; }
  
  /* ---------- leading ---------- */
  /* Unblock: when the hand on lead is the SHORT hand in a suit (singleton/doubleton) and holds a
     top honour that outranks the mate's longer holding, cash that honour NOW so it doesn't strand the
     mate's length behind it. This is the "play the high card from the short hand first" discipline. */
  function unblockCash(ctx, hereB, mateB, known, seen){
    const { trump } = ctx;
    for(const s of SUITS){
      if(s===trump) continue;
      const here=byDesc(hereB[s]||[]), mate=byDesc(mateB[s]||[]);
      if(here.length===0 || here.length>2) continue;              // short hand only
      if(mate.length<4) continue;                                 // mate must be a real long suit
      const topOutV=topOut(s, known, seen);
      if(!(RANKVAL[here[0].rank] > topOutV && RANKVAL[here[0].rank] > RANKVAL[mate[0].rank])) continue;
      // only when the mate is a genuinely RUNNING suit (top two touching honours) — otherwise
      // cashing early just wastes an entry rather than unblocking a run
      if(RANKVAL[mate[0].rank]>=11 && RANKVAL[mate[0].rank]-RANKVAL[mate[1].rank]===1) return here[0];
    }
    return null;
  }

  function chooseLead(ctx, legal){
    const { seat, declarer } = ctx;
    const declaring = sideOf(seat)===sideOf(declarer);
    if(declaring && ctx.mateHand) return declarerLead(ctx, legal);
    return defenderLead(ctx, legal);
  }
  
  function declarerLead(ctx, legal){
    // rollout oracle (NTDECL_PLAN_SPEC) — overrides the cascade only on a measured strict improvement.
    // Skipped while _inRollout (so worlds + the cascade-pick eval run the pure cascade, no recursion).
    if(!_inRollout){ const r=declarerLeadRollout(ctx, legal); if(r) return r; }
    const { hand, mateHand, trump, seen } = ctx;
    const combined = hand.concat(mateHand);
    const known = combined;
    const hereB = buckets(hand), mateB = buckets(mateHand), combB = buckets(combined);
  
    // 0) ruff a loser in the short (mate) hand BEFORE drawing trumps, if drawing would strip
    //    the trumps the mate needs to ruff
    const rbd = ruffBeforeDraw(ctx, hereB, mateB, known, seen);
    if(rbd) return W(rbd,"DECL_RUFF_FIRST",{suit:rbd.suit});
    // 1) draw trumps while opponents hold one and I own the master trump
    if(trump!=="NT"){
      const combT = combB[trump]||[];
      const oppT = outstanding(trump, known, seen);
      const iHaveMaster = combT.length && RANKVAL[byDesc(combT)[0].rank] > (oppT.length?RANKVAL[oppT[0]]:0);
      if(oppT.length>0 && iHaveMaster){
        const hereT = hereB[trump]||[];
        if(hereT.length){
          const top=byDesc(hereT)[0];
          if(RANKVAL[top.rank] >= (oppT.length?RANKVAL[oppT[0]]:0)) return W(top,"DECL_DRAW",{suit:trump,card:top.rank});
        }
      }
    }
    // 2) if a finessable tenace sits in THIS hand, cross to the other hand to lead toward it
    const cross = crossToFinesse(ctx, hereB, mateB, known, seen);
    if(cross) return W(cross,"DECL_CROSS",{suit:cross.suit});
    // 2b) unblock: cash a short-hand top honour that would otherwise strand the mate's longer suit
    const unb = unblockCash(ctx, hereB, mateB, known, seen);
    if(unb) return W(unb,"DECL_UNBLOCK",{suit:unb.suit,card:unb.rank});
    // 3) cash a side winner this hand holds
    for(const s of SUITS){
      if(s===trump) continue;
      const here=byDesc(hereB[s]||[]); if(!here.length) continue;
      if(RANKVAL[here[0].rank] > topOut(s, known, seen)) return W(here[0],"DECL_CASH",{suit:s,card:here[0].rank});
    }
    // 4) finesse: lead low toward a broken honour in the other hand
    const fin = finesseLead(ctx, hereB, mateB, known);
    if(fin) return W(fin.card,"DECL_FINESSE",{suit:fin.card.suit,honor:fin.honor});
    // 5) ruff a loser: short side suit here, trumps opposite
    if(trump!=="NT"){
      for(const s of SUITS){
        if(s===trump) continue;
        const here=hereB[s]||[];
        if(here.length && here.length<=2 && (mateB[trump]||[]).length){
          const losers=byAsc((here).filter(c=>RANKVAL[c.rank]<topOut(s,known,seen)));
          if(losers.length) return W(losers[0],"DECL_RUFF",{suit:s});
        }
      }
    }
    // 5) establish: low from the longest combined non-trump suit
    let best=null,len=-1;
    for(const s of SUITS){ if(s===trump) continue; const l=(combB[s]||[]).length; if(l>len && (hereB[s]||[]).length){ len=l; best=s; } }
    if(best && (hereB[best]||[]).length) return W(byAsc(hereB[best])[0],"DECL_ESTABLISH",{suit:best});
    return W(byAsc(legal)[0],"LEAD_LOW",{suit:byAsc(legal)[0].suit});
  }
  
  function finesseLead(ctx, hereB, mateB, known){
    const { seen } = ctx;
    let best=null, bestVal=-1;
    for(const s of SUITS){
      const mate=byDesc(mateB[s]||[]); const here=byAsc(hereB[s]||[]);
      if(!mate.length || !here.length) continue;
      const out=outstanding(s, known, seen);
      const topOutV = out.length?RANKVAL[out[0]]:0;
      for(const h of mate){
        const hv=RANKVAL[h.rank];
        if(hv<12) break;
        if(hv>topOutV) continue;
        const lead=here[0];
        if(RANKVAL[lead.rank] < hv && hv>bestVal){ bestVal=hv; best={card:lead, honor:h.rank}; }
      }
    }
    return best;
  }

  /* Is `mineDesc` (my cards in suit s, byDesc) a finessable tenace — a broken honour holding
     whose missing higher honour is still outstanding, so the trick is won by leading TOWARD it
     rather than cashing? Handles the common A-Q (K out) and A-J-10 (K,Q out) shapes. */
  function isFinessableTenace(mineDesc, s, known, seen){
    const r = mineDesc.map(c=>c.rank);
    const out = outstanding(s, known, seen);
    const has = x=>r.includes(x);
    if(has("A") && has("Q") && !has("K") && out.includes("K")) return { honor:"Q" };
    if(has("A") && has("J") && has("10") && !has("K") && !has("Q") && out.includes("K")) return { honor:"J" };
    return null;
  }

  /* Find a card in my hand whose suit lets the OTHER hand win the trick — an entry to cross
     over (never via the trump suit). Returns my lowest card in that suit. */
  function findEntryToMate(ctx, hereB, mateB, known, seen){
    const { trump } = ctx;
    for(const s of SUITS){
      if(s===trump) continue;
      const mine=byAsc(hereB[s]||[]); const mate=byDesc(mateB[s]||[]);
      if(!mine.length || !mate.length) continue;
      const topV = topOut(s, known, seen);
      if(RANKVAL[mate[0].rank] > topV && RANKVAL[mate[0].rank] > RANKVAL[mine[0].rank]) return mine[0];
    }
    return null;
  }

  /* If a finessable tenace sits in the hand ON LEAD, we're in the WRONG hand to finesse it.
     Cross to the other hand (lead an entry) so we can lead toward the tenace next time. */
  function crossToFinesse(ctx, hereB, mateB, known, seen){
    const { trump } = ctx;
    for(const s of SUITS){
      if(s===trump) continue;
      const mine=byDesc(hereB[s]||[]);
      if(!isFinessableTenace(mine, s, known, seen)) continue;
      const entry=findEntryToMate(ctx, hereB, mateB, known, seen);
      if(entry && entry.suit!==s) return entry;
    }
    return null;
  }

  /* Ruff a loser in the SHORT trump hand (the mate) BEFORE drawing trumps, when drawing would
     strip the trumps the mate needs to ruff. Returns the side-suit loser to lead now. */
  function ruffBeforeDraw(ctx, hereB, mateB, known, seen){
    const { trump } = ctx;
    if(trump==="NT") return null;
    const myTr=hereB[trump]||[], mateTr=mateB[trump]||[];
    if(!mateTr.length || mateTr.length>myTr.length) return null;   // mate must be short (ruffing) hand
    // Only ruff-first when drawing would WASTE the mate's trumps: every mate trump is lower than
    // my lowest trump, so pulling trumps forces the mate to follow helplessly instead of ruffing.
    if(RANKVAL[byDesc(mateTr)[0].rank] >= RANKVAL[byAsc(myTr)[0].rank]) return null;
    for(const s of SUITS){
      if(s===trump) continue;
      const mine=hereB[s]||[], mate=mateB[s]||[];
      if(mine.length <= mate.length) continue;           // need a shortage in mate to ruff into
      const losers=byAsc(mine.filter(c=>RANKVAL[c.rank] < topOut(s, known, seen)));
      if(losers.length) return losers[0];
    }
    return null;
  }
  
  function topOfSequence(cards){
    // top of a 2+ touching-honour sequence WITHIN a suit (top >= J); best across suits
    const b=buckets(cards); let best=null;
    for(const s of SUITS){
      const d=byDesc(b[s]);
      for(let i=0;i+1<d.length;i++){
        if(RANKVAL[d[i].rank]-RANKVAL[d[i+1].rank]===1 && RANKVAL[d[i].rank]>=11){
          if(!best || RANKVAL[d[i].rank]>RANKVAL[best.rank]) best=d[i];
          break;
        }
      }
    }
    return best;
  }
  /* Top of a 2+ touching-honour sequence within ONE suit's descending cards (top >= J), else null.
     Used by the declarer oracle to offer a knock-out honour lead (KQJ.. -> lead the K) as a candidate. */
  function topOfSequenceInSuit(desc){
    for(let i=0;i+1<desc.length;i++){
      if(RANKVAL[desc[i].rank]-RANKVAL[desc[i+1].rank]===1 && RANKVAL[desc[i].rank]>=11) return desc[i];
    }
    return null;
  }
  /* Reading layer: reconstruct what partner has asked for from the seat-tagged play history.
     - partner led a suit  -> that's partner's suit, worth returning
     - I led a suit and partner followed with a high spot (>=7) -> encourage; a low spot (<=5) -> discourage
     - partner discarded a high spot -> come-on for that suit
     Later signals override earlier ones. Defenders only. */
  function readDefense(ctx){
    const { seat, trump, history } = ctx;
    const partner = partnerOf(seat);
    const prefer = new Set(), discourage = new Set();
    const reason = {};   // suit -> "return" (partner's suit) | "encourage" (partner's signal)
    if(!history || !history.length) return { prefer, discourage, reason };
    const like = (s,why)=>{ prefer.add(s); discourage.delete(s); reason[s]=why; };
    const dislike = s=>{ discourage.add(s); prefer.delete(s); delete reason[s]; };
    for(const tr of history){
      const cards = tr.cards||[]; if(!cards.length) continue;
      const leaderSeat = cards[0].player;
      const led = tr.ledSuit;
      const pc = cards.find(c=>c.player===partner);
      if(leaderSeat===partner){ like(led,"return"); continue; }      // partner's suit
      if(leaderSeat===seat && pc && pc.suit===led){                 // partner's attitude to my lead
        const rv=RANKVAL[pc.rank];
        if(tr.winner!==partner && rv<=9){ if(rv>=7) like(led,"encourage"); else if(rv<=5) dislike(led); }
        continue;
      }
      if(pc && pc.suit!==led && pc.suit!==trump && RANKVAL[pc.rank]>=7) like(pc.suit,"encourage"); // come-on discard
    }
    return { prefer, discourage, reason };
  }

  /* Hand-reading: if I lead into dummy (dummy plays right after me), avoid feeding a suit where
     dummy holds a tenace (A-Q, K-J, A-J) — that hands declarer a free finesse. Lead up to weakness. */
  function leadIntoDummyTenace(ctx){
    const { seat, dummy, dummyHand } = ctx;
    const avoid=new Set();
    if(!dummyHand || dummy!==(seat+1)%4) return avoid;
    for(const s of SUITS){
      const ds=dummyHand.filter(c=>c.suit===s).map(c=>c.rank);
      const has=r=>ds.includes(r);
      if((has("A")&&has("Q")&&!has("K")) || (has("K")&&has("J")&&!has("Q")) || (has("A")&&has("J")&&!has("K")&&!has("Q"))) avoid.add(s);
    }
    return avoid;
  }

  /* ---------- live defensive-lead rollout (scoped mini-oracle) ----------
     Mining showed the defensive "which suit to switch to" leak is single-strategy-robust (not a
     strategy-fusion artifact): a correct per-deal switch exists but no cheap fixed rule captures it.
     So at a DEFENSIVE LEAD (dummy already visible), we sample worlds consistent with what we see and
     roll each candidate lead out under the base heuristic, picking the suit that holds declarer to the
     fewest tricks. Fires only when ROLLOUT_K>0 (off by default → identical to v16). Deterministic:
     the world sample is seeded from the visible state, so the harness stays reproducible. A reentrancy
     guard makes the rollout's own defenders use the fast policy (no infinite recursion). */
  // Live-rollout depth for the defensive-lead mini-oracle. 0 disables it (engine == v16). ~16 is a
  // good phone-affordable default (one lead decision ≈ K×suits×40 fast plays). Env-overridable so the
  // offline harness can A/B it; in the browser there is no process, so the constant governs.
  let LIVE_ROLLOUT_K = 16;
  if(typeof process!=='undefined' && process.env && process.env.ROLLOUT_K!==undefined) LIVE_ROLLOUT_K = +process.env.ROLLOUT_K;
  let _inRollout=false;
  function _mulb(a){ a=a>>>0; return function(){ a|=0; a=(a+0x6D2B79F5)|0; let t=Math.imul(a^(a>>>15),1|a); t=(t+Math.imul(t^(t>>>7),61|t))^t; return ((t^(t>>>14))>>>0)/4294967296; }; }
  function _stateSeed(ctx){ let h=2166136261>>>0; const p=[ctx.seat,(ctx.history||[]).length]; for(const c of (ctx.hand||[])) p.push(c.id); for(const c of (ctx.seen||[])) p.push(c.rank+c.suit); const s=p.join(","); for(let i=0;i<s.length;i++){ h^=s.charCodeAt(i); h=Math.imul(h,16777619); } return h>>>0; }
  // Auction constraint test on an ORIGINAL 13-card holding. Mirrors AUC.handOk (HCP bounds + suit-length
  // min/max) exactly, so the in-engine rollout belief matches the grader/harness constraint semantics.
  const _HCPV={A:4,K:3,Q:2,J:1};
  function _handOk(cards, con){
    if(!con) return true;
    let h=0; const len={S:0,H:0,D:0,C:0};
    for(const c of cards){ h+=(_HCPV[c.rank]||0); if(len[c.suit]!==undefined) len[c.suit]++; }
    const lo=(con.hcpMin!=null)?con.hcpMin:0, hi=(con.hcpMax!=null)?con.hcpMax:37;
    if(h<lo || h>hi) return false;
    if(con.suitMin) for(const s in con.suitMin){ if(len[s] < con.suitMin[s]) return false; }
    if(con.suitMax) for(const s in con.suitMax){ if(len[s] > con.suitMax[s]) return false; }
    return true;
  }
  /* cfg (optional) overrides the seat framing:
       cfg.hiddenSeats : seats whose cards are unknown and to be dealt (default: everyone but me+dummy — the
                         DEFENSIVE framing: partner + declarer).
       cfg.knownCards  : the cards I can see (default: my hand + dummy). For a DECLARER-side rollout pass
                         hiddenSeats = the two defenders and knownCards = my hand + the partner declaring hand. */
  function _sampleWorld(ctx, rng, cfg){
    const { seat, dummy, hand, dummyHand, seen, history } = ctx;
    const hiddenSeats = (cfg && cfg.hiddenSeats) ? cfg.hiddenSeats
                        : [0,1,2,3].filter(s=> s!==seat && s!==dummy);   // partner + declarer
    const key=c=>c.rank+c.suit; const known=new Set();
    const knownCards = (cfg && cfg.knownCards) ? cfg.knownCards : hand.concat(dummyHand||[]);
    for(const c of knownCards) known.add(key(c));
    for(const c of (seen||[])) known.add(key(c));
    const _trickCards=(cfg && cfg.trickCards)||[];
    for(const c of _trickCards) known.add(key(c));               // current (incomplete) trick cards are on the table
    const unseen=makeDeck().filter(c=> !known.has(key(c)));
    const nplayed=(history||[]).length; const need={}; const voids={};
    for(const s of hiddenSeats){ need[s]=13-nplayed; voids[s]=new Set(); }
    for(const tr of (history||[])){ const led=tr.ledSuit; for(const c of (tr.cards||[])){ if(hiddenSeats.includes(c.player) && c.suit!==led) voids[c.player].add(led); } }
    // current-trick: hidden seats that already played hold one fewer card; an off-suit play reveals a void.
    const _curLed=_trickCards.length? _trickCards[0].suit : null;
    for(const c of _trickCards){ if(hiddenSeats.includes(c.player)){ need[c.player]-=1; if(_curLed && c.suit!==_curLed) voids[c.player].add(_curLed); } }
    const _honor=(cfg && cfg.honorConstraints) || [];               // [{seat,suit}] partner signalled an honour
    const _count=(cfg && cfg.countConstraints) || [];               // [{seat,suit,parity}] partner's remaining-length parity
    // auction-conditioned belief: sample hidden hands consistent with SAYC constraints derived from the
    // bidding. handOk tests the ORIGINAL holding, so reconstruct each hidden seat's original = dealt-remaining
    // + the cards it has already played (completed tricks + current trick).
    const _auc=(cfg && cfg.cons) || null;
    const _playedBy={};
    if(_auc){ for(const s of hiddenSeats) _playedBy[s]=[];
      for(const tr of (history||[])) for(const c of (tr.cards||[])){ if(_playedBy[c.player]) _playedBy[c.player].push(c); }
      for(const c of _trickCards){ if(_playedBy[c.player]) _playedBy[c.player].push(c); } }
    let _aucAny=false; if(_auc){ for(const s of hiddenSeats){ if(_auc[s]){ _aucAny=true; break; } } }
    const _consOK=(out)=>{
      for(const hc of _honor){ const hand=out[hc.seat]; if(!hand) continue;
        if(!hand.some(c=>c.suit===hc.suit && RANKVAL[c.rank]>=11)) return false; }
      for(const cc of _count){ const hand=out[cc.seat]; if(!hand) continue;
        if((hand.filter(c=>c.suit===cc.suit).length % 2) !== cc.parity) return false; }
      if(_auc){ for(const s of hiddenSeats){ const con=_auc[s]; if(!con) continue;
        if(!_handOk(out[s].concat(_playedBy[s]), con)) return false; } }
      return true; };
    const _anyCons=_honor.length || _count.length || _aucAny;
    let _fallback=null;
    for(let attempt=0; attempt<40; attempt++){
      const pool=unseen.slice();
      for(let i=pool.length-1;i>0;i--){ const j=(rng()*(i+1))|0; [pool[i],pool[j]]=[pool[j],pool[i]]; }
      const out={}; for(const s of hiddenSeats) out[s]=[]; let ok=true;
      for(const c of pool){ const elig=hiddenSeats.filter(s=> out[s].length<need[s] && !voids[s].has(c.suit)); if(!elig.length){ ok=false; break; } elig.sort((a,b)=>(need[a]-out[a].length)-(need[b]-out[b].length)); out[elig[0]].push(c); }
      if(ok && hiddenSeats.every(s=>out[s].length===need[s])){
        if(!_anyCons) return out;                                    // no signal constraints: first feasible wins
        if(!_fallback) _fallback=out;                               // remember a signal-agnostic feasible deal
        if(_consOK(out)) return out;                               // prefer a signal-consistent deal
      }
    }
    return _fallback;                                               // fall back gracefully if none was consistent
  }
  function _playoutAfterLead(ctx, h, leadCard){
    const { trump, declarer, dummy, seat, seen, history } = ctx;
    const seen2=(seen||[]).map(c=>({rank:c.rank,suit:c.suit}));
    const hist2=(history||[]).map(t=>({ledSuit:t.ledSuit,winner:t.winner,cards:t.cards.map(c=>({rank:c.rank,suit:c.suit,player:c.player}))}));
    let declTricks=hist2.reduce((a,tr)=> a+(sideOf(tr.winner)===sideOf(declarer)?1:0),0);
    { const i=h[seat].findIndex(x=>x.id===leadCard.id); if(i>=0) h[seat].splice(i,1); }
    let leader=seat; const startTrick=hist2.length;
    for(let t=startTrick;t<13;t++){
      const trick=[]; let led=null;
      for(let k=0;k<4;k++){ const s=(leader+k)%4;
        let card;
        if(t===startTrick && k===0){ card=leadCard; }
        else { const dg=sideOf(s)===sideOf(declarer);
          const c2={ hand:h[s], trick:trick.slice(), ledSuit:led, trump, seat:s, declarer, dummy,
            seen:seen2.slice(), history:hist2.slice(), dummyHand:h[dummy].slice(),
            mateHand:(dg&&s===declarer)?h[dummy].slice():(dg&&s===dummy)?h[declarer].slice():undefined };
          try{ card=chooseCard(c2); }catch(_){ card=null; }
          const legal=legalPlays(h[s], trick.length?led:null); if(!card||!legal.find(x=>x.id===card.id)) card=legal[0];
          const i=h[s].findIndex(x=>x.id===card.id); h[s].splice(i,1); }
        if(k===0) led=card.suit; trick.push({rank:card.rank,suit:card.suit,player:s,id:card.id});
      }
      const win=resolveTrick(trick,led,trump).winner; if(sideOf(win)===sideOf(declarer))declTricks++;
      for(const tc of trick) seen2.push({rank:tc.rank,suit:tc.suit});
      hist2.push({ledSuit:led,winner:win,cards:trick.map(x=>({rank:x.rank,suit:x.suit,player:x.player}))}); leader=win;
    }
    return declTricks;
  }
  // Exact double-dummy solver over a small endgame: perfect play by BOTH sides from `leader` on lead
  // (leadCard forced). Returns declarer-side tricks TO GO. Memoised on remaining cards + leader.
  function _ddAfterLead(hands, trump, declarer, leader, leadCard){
    const memo=new Map();
    function key(hs, ld){ let s=""; for(let i=0;i<4;i++) s+=hs[i].map(c=>c.suit+c.rank).sort().join(",")+"|"; return s+"#"+ld; }
    function fromLead(hs, ld){
      if(!hs[0].length && !hs[1].length && !hs[2].length && !hs[3].length) return 0;
      const k=key(hs,ld); const m=memo.get(k); if(m!==undefined) return m;
      const r=trickSearch(hs, ld, null, []); memo.set(k,r); return r;
    }
    function trickSearch(hs, toPlay, ledSuit, played){
      if(played.length===4){
        const win=resolveTrick(played, ledSuit, trump).winner;
        return ((win%2)===(declarer%2)?1:0) + fromLead(hs, win);
      }
      const hand=hs[toPlay];
      const follow=ledSuit? hand.filter(c=>c.suit===ledSuit):[];
      const legal=(ledSuit && follow.length)? follow : hand;
      const decl=((toPlay%2)===(declarer%2));
      let best=decl?-1:999;
      for(const c of legal){
        const nh=hs.slice(); nh[toPlay]=hand.filter(x=>x!==c);
        const nled=played.length===0?c.suit:ledSuit;
        const v=trickSearch(nh, (toPlay+1)%4, nled, played.concat([{rank:c.rank,suit:c.suit,player:toPlay}]));
        if(decl){ if(v>best)best=v; } else { if(v<best)best=v; }
      }
      return best;
    }
    const hs=hands.slice(); hs[leader]=hands[leader].filter(x=>x.id!==leadCard.id);
    return trickSearch(hs, (leader+1)%4, leadCard.suit, [{rank:leadCard.rank,suit:leadCard.suit,player:leader}]);
  }
  const DD_MAX = 0;   // 0 = ship heuristic rollout (metric-optimal); set 4 for exact "sound endgame" mode (see report)   // when each hand has <= DD_MAX cards, evaluate worlds EXACTLY (double-dummy) not by heuristic playout

  function defensiveLeadRollout(ctx, legal){
    const K = LIVE_ROLLOUT_K;
    if(!K || _inRollout || !ctx.dummyHand || (ctx.trick && ctx.trick.length)) return null;
    _inRollout=true;
    try{
      const rng=_mulb(_stateSeed(ctx));
      const worlds=[]; for(let n=0;n<K;n++){ const w=_sampleWorld(ctx,rng); if(w) worlds.push(w); }
      if(!worlds.length) return null;
      // one lead per SUIT is enough (the cascade decides the spot); evaluate the cheapest card per suit
      const bySuit={}; for(const c of legal){ if(!bySuit[c.suit] || RANKVAL[c.rank]<RANKVAL[bySuit[c.suit].rank]) bySuit[c.suit]=c; }
      const cands=Object.values(bySuit);
      if(cands.length<2) return null;
      // GRANULARITY DISPATCH: exact double-dummy in the endgame, sampled heuristic rollout earlier.
      const useDD = DD_MAX>0 && ctx.hand.length<=DD_MAX;
      const histDecl = useDD ? (ctx.history||[]).reduce((a,tr)=> a+(sideOf(tr.winner)===sideOf(ctx.declarer)?1:0),0) : 0;
      let best=null, bestVal=Infinity;
      for(const cand of cands){
        let sum=0;
        for(const w of worlds){ const h=[null,null,null,null];
          h[ctx.seat]=ctx.hand.slice(); h[ctx.dummy]=ctx.dummyHand.slice();
          for(const s of Object.keys(w)) h[+s]=w[s].slice();
          sum += useDD ? (histDecl + _ddAfterLead(h, ctx.trump, ctx.declarer, ctx.seat, cand))
                       : _playoutAfterLead(ctx, h, cand); }
        const val=sum/worlds.length;
        if(val<bestVal-1e-9){ bestVal=val; best=cand; }
      }
      return best;
    } finally { _inRollout=false; }
  }

  /* ---------- DECLARER-side lead oracle (rollout; NTDECL_PLAN_SPEC Phase 0) ----------
     Mirror of defensiveLeadRollout for the declaring side: sample the two hidden DEFENDERS' cards,
     roll each candidate lead out under the base heuristic, pick the line that MAXIMISES declarer tricks.
     Establish-before-cash / entry preservation / finesse timing fall out emergently. STRICT-OVERRIDE
     GATE: only override the cascade when the best candidate beats the cascade's own pick by >= MARGIN,
     which bounds the deal footprint to measured improvements (the attempt-1 regressions came from firing
     broadly). Phase 0 default DECL_ROLLOUT_K=0 => inert (returns null => cascade unchanged, byte-identical).
     Phase 1 enables it for NT and tunes the margin; scope is NT-only for now. */
  let DECL_ROLLOUT_K = 16;  // Phase 1 SHIPPED: NT declarer oracle on. 0 disables. Env-overridable (offline A/B).
  if(typeof process!=='undefined' && process.env && process.env.DECL_ROLLOUT_K!==undefined) DECL_ROLLOUT_K = +process.env.DECL_ROLLOUT_K;
  let DECL_ROLLOUT_MARGIN = 0.5;   // tuned (3-seed A/B: 30 fixes/4 regr vs 0.35's 30/5, 0.6's 27/3)
  if(typeof process!=='undefined' && process.env && process.env.DECL_MARGIN!==undefined) DECL_ROLLOUT_MARGIN = +process.env.DECL_MARGIN;
  let DECL_SUITS = true;    // Phase 3 SHIPPED: declarer oracle extended to SUIT contracts. 0/false disables (env-overridable).
  if(typeof process!=='undefined' && process.env && process.env.DECL_SUITS!==undefined) DECL_SUITS = (process.env.DECL_SUITS==="1"||process.env.DECL_SUITS==="true");
  let DECL_SUIT_MARGIN = 0.75;  // Phase-3 knee (3-seed A/B: 27 fixes/4 regr @0.75 vs 41/12 @0.5; NT keeps DECL_ROLLOUT_MARGIN, byte-identical).
  if(typeof process!=='undefined' && process.env && process.env.DECL_SUIT_MARGIN!==undefined) DECL_SUIT_MARGIN = +process.env.DECL_SUIT_MARGIN;
  let DECL_FOLLOWS = true;    // Phase 4 SHIPPED: declaring-side FOLLOW-suit decisions rolled out. 0/false disables.
  if(typeof process!=='undefined' && process.env && process.env.DECL_FOLLOWS!==undefined) DECL_FOLLOWS = (process.env.DECL_FOLLOWS==="1"||process.env.DECL_FOLLOWS==="true");
  let DECL_CONS = false;    // Phase 5 (A/B pending): auction-conditioned belief in the declarer rollout sampler. OFF = byte-identical.
  if(typeof process!=='undefined' && process.env && process.env.DECL_CONS!==undefined) DECL_CONS = (process.env.DECL_CONS==="1"||process.env.DECL_CONS==="true");
  let DECL_CONS_LEN = false; // sub-mode: condition only on reliable SUIT-LENGTH cons (drop soft HCP caps).
  if(typeof process!=='undefined' && process.env && process.env.DECL_CONS_LEN!==undefined) DECL_CONS_LEN = (process.env.DECL_CONS_LEN==="1"||process.env.DECL_CONS_LEN==="true");
  // strip a cons array to length-only (suitMin/suitMax); a seat with no length info becomes null (unconstrained).
  function _consLen(cons){ if(!cons) return null; return cons.map(c=>{ if(!c) return null; const o={}; if(c.suitMin) o.suitMin=c.suitMin; if(c.suitMax) o.suitMax=c.suitMax; return (o.suitMin||o.suitMax)?o:null; }); }
  let DECL_FOLLOW_MARGIN = 0.75;  // Phase-4 knee (3-seed A/B: 30 fixes/4 regr @0.75 vs 37/9 @0.5).
  if(typeof process!=='undefined' && process.env && process.env.DECL_FOLLOW_MARGIN!==undefined) DECL_FOLLOW_MARGIN = +process.env.DECL_FOLLOW_MARGIN;
  let DEF_FOLLOWS = true;    // SHIPPED (SD-optimal defense): roll out DEFENSIVE follow decisions. 0/false disables.
  if(typeof process!=='undefined' && process.env && process.env.DEF_FOLLOWS!==undefined) DEF_FOLLOWS = (process.env.DEF_FOLLOWS==="1"||process.env.DEF_FOLLOWS==="true");
  let DEF_FOLLOW_MARGIN = 0.5;
  if(typeof process!=='undefined' && process.env && process.env.DEF_FOLLOW_MARGIN!==undefined) DEF_FOLLOW_MARGIN = +process.env.DEF_FOLLOW_MARGIN;
  let DEF_SIGNAL = true;    // SHIPPED: condition defensive belief on partner attitude signals (encourage => honour).
  if(typeof process!=='undefined' && process.env && process.env.DEF_SIGNAL!==undefined) DEF_SIGNAL = (process.env.DEF_SIGNAL==="1"||process.env.DEF_SIGNAL==="true");
  let DEF_COUNT = false;    // count-parity conditioning — measured neutral-to-harmful (1-bit, whole-suit flip). Off.
  if(typeof process!=='undefined' && process.env && process.env.DEF_COUNT!==undefined) DEF_COUNT = (process.env.DEF_COUNT==="1"||process.env.DEF_COUNT==="true");

  /* Candidate leads for the declarer oracle: per suit, the cheapest card (duck/establish) plus the top
     of a touching-honour sequence (knock-out) when it differs. The follow cascade picks the exact spot;
     these are the strategic "which suit / duck-vs-drive" choices worth rolling out. */
  function declarerCandidates(ctx, legal){
    const b=buckets(legal); const out=[]; const seen=new Set();
    const push=(c)=>{ if(c && !seen.has(c.id)){ seen.add(c.id); out.push(c); } };
    for(const s of SUITS){
      const cs=b[s]||[]; if(!cs.length) continue;
      push(byAsc(cs)[0]);                                   // low: duck-to-establish / quiet
      const seq=topOfSequenceInSuit(byDesc(cs)); push(seq); // top-of-sequence: knock out a stopper
    }
    // suit contracts: the top trump = "start drawing trumps" line (NT has no trump suit -> inert).
    if(ctx.trump!=="NT"){ const tr=b[ctx.trump]||[]; if(tr.length) push(byDesc(tr)[0]); }
    return out;
  }

  function declarerLeadRollout(ctx, legal){
    const K = DECL_ROLLOUT_K;
    if(!K || _inRollout) return null;
    if(ctx.trick && ctx.trick.length) return null;                     // leads only
    if(sideOf(ctx.seat)!==sideOf(ctx.declarer)) return null;           // declaring side only
    const mate = ctx.mateHand || ctx.dummyHand;
    if(!mate) return null;                                             // need the partner declaring hand
    if(ctx.trump!=="NT" && !DECL_SUITS) return null;                   // phase-1 NT; phase-3 opt-in for suits
    const cands=declarerCandidates(ctx, legal);
    if(cands.length<2) return null;                                    // no real strategic choice
    _inRollout=true;
    try{
      const hidden=[0,1,2,3].filter(s=> sideOf(s)!==sideOf(ctx.declarer)); // the two defenders
      const partnerSeat=(ctx.seat===ctx.declarer)?ctx.dummy:ctx.declarer;
      const cfg={ hiddenSeats:hidden, knownCards: ctx.hand.concat(mate), cons: DECL_CONS ? (DECL_CONS_LEN ? _consLen(ctx.cons) : ctx.cons) : null };
      const rng=_mulb(_stateSeed(ctx));
      const worlds=[]; for(let n=0;n<K;n++){ const w=_sampleWorld(ctx,rng,cfg); if(w) worlds.push(w); }
      if(!worlds.length) return null;
      const evalCard=(cand)=>{ let sum=0;
        for(const w of worlds){ const h=[null,null,null,null];
          h[ctx.seat]=ctx.hand.slice(); h[partnerSeat]=mate.slice();
          for(const s of hidden) h[s]=(w[s]||[]).slice();
          sum += _playoutAfterLead(ctx, h, cand); }
        return sum/worlds.length;
      };
      // strict-override gate: compare against what the cascade would play (re-entrant call runs the pure
      // cascade because _inRollout is set — declarerLead skips the rollout while _inRollout is true).
      const cascadePick=declarerLead(ctx, legal).card;
      const cascadeVal=evalCard(cascadePick);
      let best=null,bestVal=-Infinity;
      for(const cand of cands){ const v=evalCard(cand); if(v>bestVal+1e-9){ bestVal=v; best=cand; } }
      const overrideMargin = (ctx.trump==="NT") ? DECL_ROLLOUT_MARGIN : DECL_SUIT_MARGIN;
      if(best && bestVal - cascadeVal >= overrideMargin){
        // inert diagnostic hook: logs the rollout's own estimate only when a harness opts in.
        if(typeof globalThis!=='undefined' && globalThis.__DECL_PLAN_LOG)
          globalThis.__DECL_PLAN_LOG.push({ trick:(ctx.history||[]).length, suit:best.suit, rank:best.rank, est:bestVal, casc:cascadeVal });
        // Phase 2: label the chosen line by candidate type (label-only; the card is already fixed).
        // Reuse vetted codes where intent matches: top trump = DECL_DRAW, low-to-establish = DECL_ESTABLISH;
        // only top-of-sequence force-out (DECL_DEVELOP_KO) is a new code.
        const _sc = buckets(legal)[best.suit] || [];
        const _ko = topOfSequenceInSuit(byDesc(_sc));
        const _lo = byAsc(_sc)[0];
        const _top = byDesc(_sc)[0];
        const _code = (ctx.trump!=="NT" && best.suit===ctx.trump) ? (best.id===_top.id ? "DECL_DRAW" : "DECL_PLAN")
                    : (_ko && _ko.id===best.id) ? "DECL_DEVELOP_KO"
                    : (_lo && _lo.id===best.id) ? "DECL_ESTABLISH"
                    : "DECL_PLAN";
        return W(best,_code,{suit:best.suit,card:best.rank});
      }
      return null;
    } finally { _inRollout=false; }
  }

  // Collapse touching cards (same suit, consecutive ranks all present) to the cheapest representative — they
  // are strategically identical for the rollout, so we only evaluate one per run.
  function dedupeTouching(cards){
    const set=new Set(cards.map(c=>c.suit+RANKVAL[c.rank]));
    return cards.filter(c=> !set.has(c.suit+(RANKVAL[c.rank]-1)));   // keep a card only if the rank below is absent = bottom of run
  }
  // Play out from a mid-trick FOLLOW: finish the current trick (my `followCard`, then heuristic for the rest),
  // then heuristic to the end. Returns declarer-side tricks. Mirrors _playoutAfterLead's tail.
  function _playoutAfterFollow(ctx, h, followCard){
    const { trump, declarer, dummy, seat, seen, history, trick, ledSuit } = ctx;
    const seen2=(seen||[]).map(c=>({rank:c.rank,suit:c.suit}));
    const hist2=(history||[]).map(t=>({ledSuit:t.ledSuit,winner:t.winner,cards:t.cards.map(c=>({rank:c.rank,suit:c.suit,player:c.player}))}));
    let declTricks=hist2.reduce((a,tr)=> a+(sideOf(tr.winner)===sideOf(declarer)?1:0),0);
    const led=ledSuit, leader=trick[0].player;
    const cur=trick.map(c=>({rank:c.rank,suit:c.suit,player:c.player,id:c.id}));
    { const i=h[seat].findIndex(x=>x.id===followCard.id); if(i>=0) h[seat].splice(i,1); }
    cur.push({rank:followCard.rank,suit:followCard.suit,player:seat,id:followCard.id});
    for(let k=cur.length; k<4; k++){ const s=(leader+k)%4; const dg=sideOf(s)===sideOf(declarer);
      const c2={ hand:h[s], trick:cur.slice(), ledSuit:led, trump, seat:s, declarer, dummy,
        seen:seen2.slice(), history:hist2.slice(), dummyHand:h[dummy].slice(),
        mateHand:(dg&&s===declarer)?h[dummy].slice():(dg&&s===dummy)?h[declarer].slice():undefined };
      let card; try{ card=chooseCard(c2); }catch(_){ card=null; }
      const lg=legalPlays(h[s], led); if(!card||!lg.find(x=>x.id===card.id)) card=lg[0];
      const i=h[s].findIndex(x=>x.id===card.id); h[s].splice(i,1);
      cur.push({rank:card.rank,suit:card.suit,player:s,id:card.id});
    }
    let leader2; { const win=resolveTrick(cur, led, trump).winner; if(sideOf(win)===sideOf(declarer))declTricks++;
      for(const tc of cur) seen2.push({rank:tc.rank,suit:tc.suit});
      hist2.push({ledSuit:led,winner:win,cards:cur.map(x=>({rank:x.rank,suit:x.suit,player:x.player}))}); leader2=win; }
    for(let t=hist2.length;t<13;t++){
      const tr=[]; let led3=null;
      for(let k=0;k<4;k++){ const s=(leader2+k)%4; const dg=sideOf(s)===sideOf(declarer);
        const c2={ hand:h[s], trick:tr.slice(), ledSuit:led3, trump, seat:s, declarer, dummy,
          seen:seen2.slice(), history:hist2.slice(), dummyHand:h[dummy].slice(),
          mateHand:(dg&&s===declarer)?h[dummy].slice():(dg&&s===dummy)?h[declarer].slice():undefined };
        let card; try{ card=chooseCard(c2); }catch(_){ card=null; }
        const lg=legalPlays(h[s], tr.length?led3:null); if(!card||!lg.find(x=>x.id===card.id)) card=lg[0];
        const i=h[s].findIndex(x=>x.id===card.id); h[s].splice(i,1);
        if(k===0) led3=card.suit; tr.push({rank:card.rank,suit:card.suit,player:s,id:card.id});
      }
      const win=resolveTrick(tr,led3,trump).winner; if(sideOf(win)===sideOf(declarer))declTricks++;
      for(const tc of tr) seen2.push({rank:tc.rank,suit:tc.suit});
      hist2.push({ledSuit:led3,winner:win,cards:tr.map(x=>({rank:x.rank,suit:x.suit,player:x.player}))}); leader2=win;
    }
    return declTricks;
  }
  // Phase 4: roll out a declaring-side FOLLOW-suit decision (2nd/3rd/4th hand). Same belief framing as the
  // lead oracle (two defenders hidden). Void (ruff/discard) follows stay with the cascade for now.
  function declarerFollowRollout(ctx, legal){
    const K = DECL_ROLLOUT_K;
    if(!K || _inRollout || !DECL_FOLLOWS) return null;
    if(!(ctx.trick && ctx.trick.length)) return null;                 // follows only (trick in progress)
    if(sideOf(ctx.seat)!==sideOf(ctx.declarer)) return null;          // declaring side only
    const mate = ctx.mateHand || ctx.dummyHand;
    if(!mate) return null;
    if(ctx.trump!=="NT" && !DECL_SUITS) return null;                  // reuse the suit opt-in
    const suitCards = legal.filter(c=>c.suit===ctx.ledSuit);
    let cands;
    if(suitCards.length){
      cands=dedupeTouching(suitCards);                               // following suit: finesse/cover/duck spots
    } else {
      // void in the led suit: ruff-or-discard. Candidates = trump levels (ruff high/low) + the low card of
      // each side suit (which suit to pitch). The rollout scores ruff vs pitch and picks the suit.
      cands=[];
      if(ctx.trump!=="NT"){ const trs=legal.filter(c=>c.suit===ctx.trump); if(trs.length) cands.push(...dedupeTouching(trs)); }
      const bs=buckets(legal);
      for(const s of SUITS){ if(s===ctx.trump) continue; const cs=bs[s]; if(cs&&cs.length) cands.push(byAsc(cs)[0]); }
    }
    if(cands.length<2) return null;                                  // no real choice
    _inRollout=true;
    try{
      const hidden=[0,1,2,3].filter(s=> sideOf(s)!==sideOf(ctx.declarer));
      const partnerSeat=(ctx.seat===ctx.declarer)?ctx.dummy:ctx.declarer;
      const trickCards=ctx.trick.map(c=>({rank:c.rank,suit:c.suit,player:c.player}));
      const cfg={ hiddenSeats:hidden, knownCards: ctx.hand.concat(mate), trickCards, cons: DECL_CONS ? (DECL_CONS_LEN ? _consLen(ctx.cons) : ctx.cons) : null };
      const rng=_mulb(_stateSeed(ctx));
      const worlds=[]; for(let n=0;n<K;n++){ const w=_sampleWorld(ctx,rng,cfg); if(w) worlds.push(w); }
      if(!worlds.length) return null;
      const evalCard=(cand)=>{ let sum=0;
        for(const w of worlds){ const h=[null,null,null,null];
          h[ctx.seat]=ctx.hand.slice(); h[partnerSeat]=mate.slice();
          for(const s of hidden) h[s]=(w[s]||[]).slice();
          sum += _playoutAfterFollow(ctx, h, cand); }
        return sum/worlds.length;
      };
      const cascadePick=chooseFollow(ctx, legal).card;                // pure cascade (re-entrant, _inRollout set)
      const cascadeVal=evalCard(cascadePick);
      let best=null,bestVal=-Infinity;
      for(const cand of cands){ const v=evalCard(cand); if(v>bestVal+1e-9){ bestVal=v; best=cand; } }
      if(best && bestVal - cascadeVal >= DECL_FOLLOW_MARGIN){
        // Phase-2-style follow label (label-only; card already fixed). Void => ruff/discard; suit => the
        // chosen card's trick role (cover / win / duck).
        let _fc;
        if(best.suit!==ctx.ledSuit){
          _fc = (ctx.trump!=="NT" && best.suit===ctx.trump) ? "DECL_FOLLOW_RUFF" : "DECL_FOLLOW_DISCARD";
        } else {
          const _cur=currentWinner(ctx.trick, ctx.ledSuit, ctx.trump);
          const _wins = _cur.card.suit===ctx.ledSuit && RANKVAL[best.rank] > RANKVAL[_cur.card.rank];
          _fc = !_wins ? "DECL_FOLLOW_DUCK"
              : (ctx.trick.length===1 && RANKVAL[best.rank]>=11 && RANKVAL[_cur.card.rank]>=11) ? "DECL_FOLLOW_COVER"
              : "DECL_FOLLOW_WIN";
        }
        return W(best,_fc,{suit:best.suit,card:best.rank});
      }
      return null;
    } finally { _inRollout=false; }
  }

  // (experimental) DEFENSIVE follow oracle — same rollout, defender framing (dummy known; partner+declarer
  // hidden) and MINIMISE declarer tricks. NOTE: the belief omits partner's SIGNALS, so this is signalling-
  // blind; kept behind DEF_FOLLOWS for measurement.
  function defensiveFollowRollout(ctx, legal){
    const K = DECL_ROLLOUT_K;
    if(!K || _inRollout || !DEF_FOLLOWS) return null;
    if(!(ctx.trick && ctx.trick.length)) return null;                 // follows only
    if(sideOf(ctx.seat)===sideOf(ctx.declarer)) return null;          // DEFENDING side only
    if(!ctx.dummyHand) return null;                                   // dummy must be visible
    const suitCards = legal.filter(c=>c.suit===ctx.ledSuit);
    let cands;
    if(suitCards.length){ cands=dedupeTouching(suitCards); }
    else { cands=[];
      if(ctx.trump!=="NT"){ const trs=legal.filter(c=>c.suit===ctx.trump); if(trs.length) cands.push(...dedupeTouching(trs)); }
      const bs=buckets(legal);
      for(const s of SUITS){ if(s===ctx.trump) continue; const cs=bs[s]; if(cs&&cs.length) cands.push(byAsc(cs)[0]); }
    }
    if(cands.length<2) return null;
    _inRollout=true;
    try{
      const trickCards=ctx.trick.map(c=>({rank:c.rank,suit:c.suit,player:c.player}));
      let honorConstraints=[], countConstraints=[];
      if(DEF_SIGNAL){ const read=readDefense(ctx); const partnerSeat=partnerOf(ctx.seat);
        for(const s of read.prefer){ if(read.reason[s]==="encourage") honorConstraints.push({seat:partnerSeat, suit:s}); }
        for(const suit of (DEF_COUNT?SUITS:[])){                     // count signal -> partner's remaining-length parity (gated: measured neutral)
          // count is only a signal when partner FOLLOWED to a suit an OPPONENT led and did not win the trick.
          let ledBy=null, won=null;
          for(const tr of ctx.history||[]){ if(tr.ledSuit!==suit) continue;
            const pc=(tr.cards||[]).find(c=>c.player===partnerSeat && c.suit===suit);
            if(pc){ ledBy=(tr.cards[0]||{}).player; won=tr.winner; break; } }
          if(ledBy==null || sideOf(ledBy)!==sideOf(ctx.declarer) || won===partnerSeat) continue;
          const myInSuit=ctx.hand.filter(c=>c.suit===suit).length + playedInSuit(ctx, ctx.seat, suit);
          const dummyInSuit=(ctx.dummyHand||[]).filter(c=>c.suit===suit).length + playedInSuit(ctx, ctx.dummy, suit);
          const outstanding=13-myInSuit-dummyInSuit; if(outstanding<=0) continue;
          const origLen=partnerOrigLen(ctx, suit, outstanding); if(origLen==null) continue;
          const remLen=origLen - playedInSuit(ctx, partnerSeat, suit); if(remLen<0) continue;
          countConstraints.push({seat:partnerSeat, suit, parity: remLen%2});
        }
      }
      const rng=_mulb(_stateSeed(ctx));
      const worlds=[]; for(let n=0;n<K;n++){ const w=_sampleWorld(ctx,rng,{trickCards, honorConstraints, countConstraints}); if(w) worlds.push(w); }
      if(!worlds.length) return null;
      const evalCard=(cand)=>{ let sum=0;
        for(const w of worlds){ const h=[null,null,null,null];
          h[ctx.seat]=ctx.hand.slice(); h[ctx.dummy]=ctx.dummyHand.slice();
          for(const s of Object.keys(w)) h[+s]=w[s].slice();
          sum += _playoutAfterFollow(ctx, h, cand); }
        return sum/worlds.length;
      };
      const cascadePick=chooseFollow(ctx, legal).card;
      const cascadeVal=evalCard(cascadePick);
      let best=null,bestVal=Infinity;                                 // defender minimises declarer tricks
      for(const cand of cands){ const v=evalCard(cand); if(v<bestVal-1e-9){ bestVal=v; best=cand; } }
      if(best && cascadeVal - bestVal >= DEF_FOLLOW_MARGIN){
        let _fc;
        if(best.suit!==ctx.ledSuit){
          _fc = (ctx.trump!=="NT" && best.suit===ctx.trump) ? "DEF_FOLLOW_RUFF" : "DEF_FOLLOW_DISCARD";
        } else {
          const _cur=currentWinner(ctx.trick, ctx.ledSuit, ctx.trump);
          const _wins = _cur.card.suit===ctx.ledSuit && RANKVAL[best.rank] > RANKVAL[_cur.card.rank];
          _fc = _wins ? "DEF_FOLLOW_WIN" : "DEF_FOLLOW_DUCK";
        }
        return W(best,_fc,{suit:best.suit,card:best.rank});
      }
      return null;
    } finally { _inRollout=false; }
  }

  function defenderLead(ctx, legal){
    const { hand, trump } = ctx;
    const b=buckets(hand);
    const read=readDefense(ctx);
    // live rollout picks the switch SUIT when enabled; then fall to the cascade to pick the spot card.
    const rlead=defensiveLeadRollout(ctx, legal);
    if(rlead){ const cand=byDesc(b[rlead.suit]);
      if(trump!=="NT" && cand.length && cand[0].rank==="A") return W(cand[0],"D_ROLLOUT",{suit:rlead.suit});
      if(cand.length>=4) return W(cand[3],"D_ROLLOUT",{suit:rlead.suit});
      if(cand.length) return W(byAsc(cand)[0],"D_ROLLOUT",{suit:rlead.suit});
    }
    // 1) return / continue a suit partner asked for (their own suit, or one they encouraged) —
    //    but NOT into a ruff: in a suit contract, returning a suit dummy is void in just gives
    //    declarer a ruff, so skip it and switch instead (mined from rollout-oracle disagreements).
    const dvoid = s => ctx.trump!=="NT" && ctx.dummyHand && ctx.dummyHand.filter(c=>c.suit===s).length===0;
    const pref=[...read.prefer].filter(s=>s!==trump && (b[s]||[]).length && !dvoid(s));
    if(pref.length){
      pref.sort((a,c)=>(b[c].length-b[a].length));
      const s=pref[0]; const cand=byDesc(b[s]);
      const code = read.reason[s]==="return" ? "D_RETURN" : "D_CONTINUE";
      if(ctx.trump!=="NT" && cand.length && cand[0].rank==="A") return W(cand[0],code,{suit:s}); // don't underlead the ace vs a suit contract
      if(cand.length>=4) return W(cand[3],code,{suit:s});
      if(cand.length===2) return W(cand[0],code,{suit:s});   // high from a doubleton (return)
      return W(byAsc(cand)[0],code,{suit:s});
    }
    // 2) top of a sequence — a safe attacking lead
    const seq=topOfSequence(hand);
    if(seq) return W(seq,"LEAD_SEQ",{suit:seq.suit,top:seq.rank});
    // 3) longest non-trump suit, avoiding one partner discouraged, one that feeds dummy's tenace,
    //    or (mined) one dummy is void in — leading it into a suit contract just gives a ruff.
    const avoid=new Set([...read.discourage, ...leadIntoDummyTenace(ctx)]);
    for(const s of SUITS) if(dvoid(s)) avoid.add(s);
    let best=null,len=-1;
    for(const s of SUITS){ if(s===trump||avoid.has(s)) continue; if((b[s]||[]).length>len){ len=(b[s]||[]).length; best=s; } }
    if(best==null){ for(const s of SUITS){ if(s===trump) continue; if((b[s]||[]).length>len){ len=(b[s]||[]).length; best=s; } } }
    const cand = best!=null ? byDesc(b[best]) : byDesc(legal);
    if(trump!=="NT" && cand.length && cand[0].rank==="A") return W(cand[0],"LEAD_ACE",{suit:cand[0].suit});
    if(cand.length>=4) return W(cand[3],"LEAD_4TH",{suit:cand[3].suit});
    if(cand.length) return W(byAsc(cand)[0],"LEAD_LOW",{suit:cand[0].suit});
    return W(byAsc(legal)[0],"LEAD_LOW",{suit:byAsc(legal)[0].suit});
  }
  
  /* ---------- following ---------- */
  /* Cover an honour with an honour (2nd hand). Cover a led J/Q/K when we hold exactly ONE
     honour above it (the classic Kx-covers-Q that promotes lower cards); if we hold two+
     honours above, we dominate and keep them (play low). Never squander the bare ace on a
     lower honour as 2nd hand. */
  function coverHonour(ctx, suitCards){
    const led = ctx.trick[0];
    if(!led) return null;
    const lv = RANKVAL[led.rank];
    if(lv < 11 || lv >= 14) return null;                 // only cover J/Q/K
    const above = byAsc(suitCards).filter(c=>RANKVAL[c.rank] > lv);
    const honoursAbove = above.filter(c=>RANKVAL[c.rank] >= 11);
    if(honoursAbove.length !== 1) return null;           // 2+ honours above -> dominate, don't cover
    const cov = honoursAbove[0];
    if(cov.rank === "A") return null;                    // keep the ace as 2nd hand
    return cov;                                          // cheapest single honour that covers
  }

  /* Second-hand exception — SPLIT HONOURS. When a low card is led and I (a defender in second
     seat) hold two or more TOUCHING honours but not the ace, play the LOWER honour. This forces
     declarer to spend a top card now and promotes my remaining honour, rather than letting declarer
     steal a cheap trick with a middling card. Never split when I hold the ace (I control the suit). */
  function splitHonors(ctx, suitCards){
    const { trick, seat, declarer } = ctx;
    if(sideOf(seat)===sideOf(declarer)) return null;              // defenders only
    const led = trick[0];
    if(!led || RANKVAL[led.rank] >= 10) return null;              // only when a LOW card is led
    if(suitCards.some(c=>c.rank==="A")) return null;              // holding the ace = control, play low
    const desc = byDesc(suitCards);
    for(let i=0;i<desc.length;i++){
      if(RANKVAL[desc[i].rank] < 10) break;                       // honours only (10,J,Q,K)
      let j=i;
      while(j+1<desc.length && RANKVAL[desc[j].rank]-RANKVAL[desc[j+1].rank]===1 && RANKVAL[desc[j+1].rank]>=10) j++;
      if(j>i) return desc[j];                                     // lower card of the touching honour run
    }
    return null;
  }


  function thirdHandCard(suitCards, curHighVal){
    const canWin = byDesc(suitCards).filter(c=>RANKVAL[c.rank] > curHighVal);
    if(!canWin.length) return null;
    if(RANKVAL[canWin[0].rank] < 11) return canWin[0];   // no honour available -> highest spot
    let i=0;
    while(i+1<canWin.length && RANKVAL[canWin[i].rank]-RANKVAL[canWin[i+1].rank]===1 && RANKVAL[canWin[i+1].rank]>=10) i++;
    return canWin[i];                                    // cheapest of the top touching-honour run
  }

  /* Declarer hold-up in notrump: with a SOLE ace stopper in a short combined holding, duck
     early rounds (Rule of 7: duck 7 - combinedLen times) to sever the defenders' link. */
  function holdUp(ctx, suitCards){
    const { trump, ledSuit, seat, declarer, seen, trick } = ctx;
    if(trump !== "NT") return null;
    if(sideOf(seat) !== sideOf(declarer)) return null;   // declaring side only
    const leaderSeat = (seat - trick.length + 4) % 4;    // hold up only when an OPPONENT is attacking
    if(sideOf(leaderSeat) === sideOf(declarer)) return null;
    if(!suitCards.some(c=>c.rank==="A")) return null;     // must hold the ace
    // (mined) a hold-up only gains with a SINGLE stopper. If the two declaring hands together hold the
    // ace AND king, that's a double stopper — just win; ducking only loses tempo. (Was checking the
    // acting hand alone, which missed an A/K split across declarer and dummy.)
    const mateInSuit = (ctx.mateHand || ctx.dummyHand || []).filter(c=>c.suit===ledSuit);
    const combined = new Set(suitCards.concat(mateInSuit).map(c=>c.rank));
    if(combined.has("A") && combined.has("K")) return null;
    const nonAce = suitCards.filter(c=>c.rank!=="A");
    if(!nonAce.length) return null;                        // only the bare ace -> must win
    const cur = currentWinner(trick, ledSuit, trump);
    if(cur.winner!==-1 && sideOf(cur.winner)===sideOf(seat)) return null; // our side already winning
    const mate = ctx.mateHand || ctx.dummyHand || [];
    const combinedLen = suitCards.length + mate.filter(c=>c.suit===ledSuit).length;
    const ducks = 7 - combinedLen;
    if(ducks <= 0) return null;
    const roundsBefore = Math.floor((seen||[]).filter(c=>c.suit===ledSuit).length / 3);
    if(roundsBefore >= ducks) return null;                 // held up enough -> take it now
    return byAsc(nonAce)[0];                               // duck low, keep the ace
  }

  /* Defensive carding: choose WHICH low card to play so it carries a signal.
     Attitude on partner's lead (high = encourage, low = discourage). Count on an opponent's lead,
     but only when it is USEFUL — when the opponents are establishing this suit and partner must
     read its length (dummy long here, or a later round of the same suit). On a random suit, honest
     count mostly helps declarer (who sees both defenders), so we just play a neutral low card. The
     signal card never wins the trick, so it's trick-neutral. Declarer's side never signals. */
  function signalPlay(ctx, suitCards, plainCode){
    const { seat, declarer, trump, ledSuit, trick, dummyHand, history } = ctx;
    const lowest = byAsc(suitCards)[0];
    if(sideOf(seat) === sideOf(declarer)) return W(lowest, plainCode || "F_2ND_LOW", {suit:ledSuit});
    const pos = trick.length;
    const leaderSeat = (seat - pos + 4) % 4;
    const partnerLed = leaderSeat === partnerOf(seat);
    const spots = suitCards.filter(c => RANKVAL[c.rank] < 10);   // 2..9 — never signal with the 10+
    // (mined) if the holding is ALL honours/tens there is no spot to signal with — don't spend an
    // honour on a signal, just play the lowest card and keep the higher honour as a potential trick.
    if(!spots.length) return W(lowest, plainCode || "F_2ND_LOW", {suit:ledSuit});
    const pool = spots;
    const hi = byDesc(pool)[0], lo = byAsc(pool)[0];
    if(partnerLed){
      const topRank = RANKVAL[byDesc(suitCards)[0].rank];
      const ruffValue = trump !== "NT" && suitCards.length <= 2 && ledSuit !== trump;
      const encourage = topRank >= 12 || ruffValue;             // Q+ in the suit, or a doubleton to ruff
      return encourage ? W(hi, "F_ATT_HI", { card: hi.rank, suit: ledSuit })
                       : W(lo, "F_ATT_LO", { card: lo.rank, suit: ledSuit });
    }
    // opponent led: give count only when the suit is being established and partner needs it
    const dummyLen = (dummyHand||[]).filter(c=>c.suit===ledSuit).length;
    const roundsPlayed = (history||[]).filter(t=>t.ledSuit===ledSuit).length;
    const countUseful = dummyLen>=4 || roundsPlayed>=1;
    if(!countUseful) return W(lowest, plainCode || "F_2ND_LOW", {suit:ledSuit});
    const even = (suitCards.length % 2) === 0;
    return even ? W(hi, "F_CNT_HI", { card: hi.rank, suit: ledSuit })
                : W(lo, "F_CNT_LO", { card: lo.rank, suit: ledSuit });
  }

  /* Count how many cards of `suit` a given player has already shown (history + current trick). */
  function playedInSuit(ctx, player, suit){
    let n=0;
    for(const tr of ctx.history||[]) for(const c of (tr.cards||[])) if(c.player===player && c.suit===suit) n++;
    for(const c of (ctx.trick||[])) if(c.player===player && c.suit===suit) n++;
    return n;
  }
  /* READ partner's count signal: infer partner's ORIGINAL length in `suit` from the first spot they
     played to it (high spot = even, low spot = odd), resolved to the parity-correct length closest to
     an even split of `outstanding` (= declarer + partner cards). Returns null if no clear read. */
  function partnerOrigLen(ctx, suit, outstanding){
    const partner=partnerOf(ctx.seat);
    let first=null;
    for(const tr of ctx.history||[]){ if(tr.ledSuit!==suit) continue; const pc=(tr.cards||[]).find(c=>c.player===partner && c.suit===suit); if(pc){ first=pc; break; } }
    if(!first) for(const c of (ctx.trick||[])) if(c.player===partner && c.suit===suit){ first=c; break; }
    if(!first) return null;
    const rv=RANKVAL[first.rank];
    const even = rv>=7 ? true : (rv<=5 ? false : null);   // a lone 6 is ambiguous
    if(even===null) return null;
    let best=null, bd=99;
    for(let L=1;L<=outstanding;L++){ if((L%2===0)!==even) continue; const d=Math.abs(L-outstanding/2); if(d<bd){ bd=d; best=L; } }
    return best;
  }

  /* Defensive hold-up: as a defender, duck the sole ace stopper to strand a long, running dummy suit.
     Count-aware: read partner's count to learn declarer's length and WIN the ace on the round that
     exhausts declarer (never later than the Rule-of-7-style third-round fallback). Returns {card,code}
     — either a low duck or the ace to win-and-strand — or null when the hold-up doesn't apply. NT only. */
  function defHoldUp(ctx, suitCards){
    const { trump, ledSuit, seat, declarer, dummy, dummyHand, history, trick } = ctx;
    if(trump!=="NT") return null;
    if(sideOf(seat)===sideOf(declarer)) return null;                 // defenders only
    const leaderSeat=(seat - trick.length + 4)%4;
    if(sideOf(leaderSeat)===sideOf(seat)) return null;               // an opponent must have led it
    if(!dummyHand) return null;
    const ace=suitCards.find(c=>c.rank==="A");
    if(!ace || suitCards.length<3) return null;                      // sole ace stopper, Axx+
    const dummySuit=dummyHand.filter(c=>c.suit===ledSuit);
    if(dummySuit.length<4 || RANKVAL[byDesc(dummySuit)[0].rank]<12) return null; // long, honour-headed
    const roundsPlayed=(history||[]).filter(t=>t.ledSuit===ledSuit).length;
    const thisRound=roundsPlayed+1;
    // read count -> declarer's original length in the suit; take the ace once declarer is exhausted
    const myOrig    = suitCards.length + playedInSuit(ctx, seat, ledSuit);
    const dummyOrig = dummySuit.length + playedInSuit(ctx, dummy, ledSuit);
    const outstanding = 13 - myOrig - dummyOrig;                     // declarer + partner, originally
    const pOrig = partnerOrigLen(ctx, ledSuit, outstanding);
    const declOrig = (pOrig!=null) ? Math.max(1, outstanding - pOrig) : null;
    const takeByCount = declOrig!=null && thisRound >= declOrig;     // count says declarer's last card
    const takeByRule  = roundsPlayed >= 2;                           // fallback: no later than 3rd round
    if(takeByCount || takeByRule) return { card: ace, code:"F_HOLDUP_WIN" };
    const spare=byAsc(suitCards.filter(c=>c.rank!=="A"));
    return spare.length ? { card: spare[0], code:"F_DUCK_HOLDUP" } : { card: ace, code:"F_HOLDUP_WIN" };
  }

  function chooseFollow(ctx, legal){
    if(!_inRollout){ const r=declarerFollowRollout(ctx, legal) || defensiveFollowRollout(ctx, legal); if(r) return r; }
    const { trick, ledSuit, trump, seat } = ctx;
    const pos=trick.length;
    const partner=partnerOf(seat);
    const cur=currentWinner(trick, ledSuit, trump);
    const partnerWinning = cur.winner===partner;
    const canFollow = legal.some(c=>c.suit===ledSuit);
  
    if(canFollow){
      const suitCards = legal.filter(c=>c.suit===ledSuit);
      // declarer hold-up (sole ace stopper, NT) — applies at any seat before the win/duck logic
      const hu = holdUp(ctx, suitCards);
      if(hu) return W(hu,"F_HOLDUP",{suit:ledSuit});
      // defensive hold-up: duck (or, once count says declarer is exhausted, win) the ace to strand a long dummy suit
      const dhu = defHoldUp(ctx, suitCards);
      if(dhu) return W(dhu.card, dhu.code, {suit:ledSuit});
      // 2nd hand: cover an honour, split touching honours on a low lead, else low (with count for a defender)
      if(pos===1){
        const cov = coverHonour(ctx, suitCards);
        if(cov) return W(cov,"F_COVER",{card:cov.rank});
        const sp = splitHonors(ctx, suitCards);
        if(sp) return W(sp,"F_SPLIT",{card:sp.rank,suit:ledSuit});
        return signalPlay(ctx, suitCards, "F_2ND_LOW");
      }
      // 3rd hand: third-hand high, unless partner's led honour is already winning
      if(pos===2){
        const ledCard = trick[0];
        // (mined) partner is SECURE if already winning and either led an honour (J+) OR the only hand
        // still to play is the dummy and it cannot beat partner's card — then don't waste a winner.
        const fourthIsDummy = ((seat+1)%4)===ctx.dummy && ctx.dummyHand;
        const dummyCantBeat = fourthIsDummy && !ctx.dummyHand.some(c=>c.suit===ledSuit && RANKVAL[c.rank] > RANKVAL[cur.card.rank]);
        const partnerSecure = partnerWinning && (RANKVAL[ledCard.rank] >= 11 || dummyCantBeat);
        if(!partnerSecure){
          const declaring = sideOf(seat)===sideOf(ctx.declarer);
          const known = (ctx.hand||[]).concat(ctx.mateHand||[]);
          // declarer with a genuine tenace finesses the low honour (Q from AQ); otherwise both
          // declarer and defender secure the trick with proper third-hand-high (the A from A84).
          const isFin = declaring && isFinessableTenace(byDesc(suitCards), ledSuit, known, ctx.seen);
          const th = isFin ? cheapestWinner(ctx, suitCards)
                           : thirdHandCard(suitCards, RANKVAL[cur.card.rank]);
          if(th) return W(th, isFin?"F_FINESSE_WIN":"F_3RD_HIGH", {card:th.rank, suit:ledSuit});
        }
        return signalPlay(ctx, suitCards, "F_DUCK_PARTNER");   // duck -> attitude for a defender
      }
      // 4th hand: win as cheaply as possible; never overtake partner
      if(!partnerWinning){
        const w=cheapestWinner(ctx, suitCards); if(w) return W(w,"F_WIN_CHEAP",{card:w.rank});
      }
      return signalPlay(ctx, suitCards, partnerWinning?"F_DUCK_PARTNER":"F_CANT");
    }
    if(trump!=="NT"){
      const myTr=legal.filter(c=>c.suit===trump);
      if(myTr.length && !partnerWinning){ const w=cheapestWinner(ctx, myTr); if(w) return W(w,"RUFF",{suit:ledSuit}); }
    }
    const d=discard(ctx, legal);
    return W(d,"DISCARD",{suit:d.suit});
  }
  /* Discard from length: shed the lowest card of your longest suit — the card you can most afford,
     keeping guards and honours in the shorter suits. (Deliberate attitude discards were tried and
     removed: for the bot they spend more than they return, the same trap as costly signalling.) */
  function discard(ctx, legal){
    const { trump, seat, declarer, dummyHand } = ctx;
    const pool = legal.filter(c=>c.suit!==trump).length ? legal.filter(c=>c.suit!==trump) : legal;
    const b=buckets(pool);
    const defender = sideOf(seat)!==sideOf(declarer);
    if(defender && dummyHand){
      // Keep length that guards dummy's long suits; pitch from a suit with no guarding duty.
      // Guard duty = dummy has a real long suit (4+) AND is LONGER than me: the danger is the cards
      // dummy holds beyond my length, so if I'm as long as dummy I already outlast it and can pitch
      // freely. (Guarding 4-card suits I already match ties up length for nothing — measured worse.)
      const scored = SUITS.filter(s=>(b[s]||[]).length).map(s=>{
        const myLen=(b[s]||[]).length;
        const dlen=dummyHand.filter(c=>c.suit===s).length;
        return { s, myLen, guardDuty: dlen>=4 && dlen>myLen };
      });
      const free = scored.filter(x=>!x.guardDuty);
      // longest first (economy); (mined) break LENGTH TIES by pitching from the most worthless suit —
      // the one whose highest card is lowest — so equal-length honour/sequence holdings stay intact.
      const topVal = s => (b[s]||[]).reduce((m,c)=>Math.max(m,RANKVAL[c.rank]),0);
      const pickFrom = (free.length ? free : scored).sort((a,c)=> (c.myLen-a.myLen) || (topVal(a.s)-topVal(c.s)));
      if(pickFrom.length) return byAsc(b[pickFrom[0].s])[0];
    }
    // declarer, or no dummy view yet: economy — pitch the lowest card of the longest suit
    let best=null,len=-1;
    for(const s of SUITS){ if((b[s]||[]).length>len){ len=(b[s]||[]).length; best=s; } }
    return byAsc(b[best])[0];
  }
  
  
  
  return { chooseCard, chooseCardWhy, currentWinner, partnerOf, sideOf };
})();



//#region gen (auto — removed when bundled to a single bridge.jsx)
export { PLY };
//#endregion gen
