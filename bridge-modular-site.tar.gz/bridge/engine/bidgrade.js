//#region gen (auto — removed when bundled to a single bridge.jsx)
import { MEAN } from "./meaning.js";
//#endregion gen

/* bidgrade.js — the BIDDING GRADE ("was that call RIGHT?"), by CONVENTION-CONSISTENCY.
 *
 * This is the bidding twin of deftech.js, and it exists because expected score CANNOT grade bidding:
 * a belief-sampled expected-score evaluator was built, measured, and found to have an irreducible
 * POLICY-BIAS FLOOR of 0.72 +/- 0.22 IMP (t=3.3) — it converges on "the best call against THIS BOT",
 * not "the best call in bridge" (reports/BID_EV_NULL.md). More compute makes it more confidently wrong.
 *
 * So bidding is graded the way defence is: against the CONVENTION, not against the double-dummy score.
 * Bidding is a partnership LANGUAGE. A call is right because it honestly describes the hand within SAYC
 * and discharges the obligations partner's calls have placed on it — not because it maximises DD EV.
 *
 *   declarer -> single agent      -> DD is the judge            (twoLensGrade)
 *   defence  -> partnership convention -> DD overstates ~18x    (deftech / siggrade)
 *   bidding  -> partnership language   -> expected score has a policy floor  <- HERE
 *
 * THE CASCADE (mirrors twoLensGrade):
 *   Tier 1  CONVENTION  — the grade. Two FIRM, objective checks, both from meaning.js:
 *             (a) OBLIGATION — did this call ignore a forcing call by partner? (a sin of OMISSION,
 *                 which checkHonesty structurally cannot see: it only grades the call you MADE.)
 *             (b) HONESTY    — does the call MISREPRESENT the hand? (MEAN.checkHonesty)
 *   Tier 2  BLUNDER GATE — an INJECTED expected-score gap (bid_ev), admissible ONLY at eps >= 5 IMP,
 *             where it has 2% false positives and catches 99% of indefensible calls. It may say
 *             "that call is INDEFENSIBLE"; it must NEVER say "that call was second-best" — the policy
 *             floor makes fine rankings meaningless. It can only ever make a grade WORSE, never better.
 *   Tier 3  LENIENT    — no firm promise and no blunder: stay quiet, full marks, LOW confidence.
 *
 * PRECISION OVER RECALL, deliberately. A bidding teacher that FALSELY ACCUSES is worse than one that
 * stays quiet. Every judgment call (a legitimate upgrade, a tactical underbid, a competitive punt) is
 * marked `judgment` by meaning.js and is NEVER darkened here. Recall is sacrificed on purpose.
 *
 * PURE: no DDS, no sampling, no async. Runs synchronously on the main thread, so the trainer can grade a
 * call at PREVIEW time (before it is committed) as well as after. Tier 2, when supplied, comes from the
 * worker/offline — it is passed IN, never computed here.
 *
 * gradeBid(ctx, ev) -> see the return shape at the bottom of this comment.
 *   ctx : { call, calls, dealer, seat, hand }   call = {k:"P"|"D"|"R"|"B", level?, strain?}
 *                                               calls = the auction BEFORE this call
 *   ev  : { gap } | null    Tier-2 cross-fit expected-score gap in IMPs, or null if not computed.
 */

const BIDGRADE = (function(){
  const GLYPH = { S:"\u2660", H:"\u2665", D:"\u2666", C:"\u2663", NT:"NT" };
  const sname = (s)=> s==="NT" ? "notrump" : GLYPH[s];
  const call = (c)=> !c ? "?" : c.k==="P" ? "Pass" : c.k==="D" ? "Double" : c.k==="R" ? "Redouble"
                     : `${c.level}${c.strain==="NT"?"NT":GLYPH[c.strain]}`;
  const cap = (t)=> t ? t.charAt(0).toUpperCase()+t.slice(1) : t;

  /* Tier scores. Identical ladder to deftech.js (T_OK/T_NEAR/T_BAD) so the bidding grade and the card
   * grade read on ONE scale. A violation DEGRADES rather than corrupts. */
  const T_OK = 100, T_NEAR = 70, T_BAD = 25;

  /* The Tier-2 operating point, from BID_EV_NULL §7: at eps >= 5 IMP the blunder gate accuses a sound
   * call 2% of the time and still catches 99% of indefensible ones. BELOW this it is NOT admissible —
   * the 0.72 IMP policy floor means a 2-3 IMP "gap" is as likely to be bot-exploitation as a real error. */
  const BLUNDER_EPS = 5.0;

  /* ---------- Tier 1(a): OBLIGATION — did this call ignore partner's FORCING bid? ----------
   *
   * checkHonesty grades the call you MADE. It is structurally blind to the call you FAILED to make, and
   * the single most common such failure — and the one bid_discrim measured at 2.71 IMP (4.3 sigma) —
   * is PASSING PARTNER'S FORCING BID. meaning.js already computes `forcing` for every call, so this is
   * free and deterministic; it needs no solver and no sampling.
   *
   * CONSERVATISM (precision over recall), three ways:
   *   1. Only PASS can breach an obligation. Any other call keeps the auction alive by definition.
   *   2. Only a call marked `mustAnswer` counts — a call there is NO hand on which passing is legal. This is
   *      deliberately a SEPARATE axis from `forcing`: a takeout double is forcing, but passing it to convert
   *      it to penalties with long trumps is a real expert action, and accusing that would be exactly the
   *      false accusation this whole cascade exists to avoid. (It used to key on `confidence:"standard"`,
   *      which happened to exclude the double only because the double's promise was vague. The moment that
   *      promise was firmed up, the check would have started accusing correct penalty passes. Two unrelated
   *      facts must not share one flag.)
   *   3. Only if NOTHING has happened since: every call after partner's forcing call must be a Pass. If
   *      RHO has bid or doubled, the auction has been kept alive and my pass is a competitive judgment,
   *      which players legitimately make with real values.
   */
  function checkObligation(c, calls, dealer, seat){
    if(!c || c.k!=="P") return null;                       // only a PASS can fail to answer a force
    const partner = (seat+2)%4;
    let idx = -1;
    for(let i=calls.length-1;i>=0;i--){ if(calls[i].by===partner){ idx=i; break; } }
    if(idx<0) return null;                                 // partner has not called
    for(let i=idx+1;i<calls.length;i++) if(calls[i].k!=="P") return null;   // opponents kept it alive
    const pc = calls[idx];
    let m; try{ m = MEAN.callMeaning(pc, calls.slice(0,idx), dealer, partner); }catch(_){ return null; }
    if(!m || !m.mustAnswer) return null;                   // not an unpassable force
    return { breach:true, partnerCall:pc, meaning:m,
      why:`Partner's ${call(pc)} is FORCING — it asks a question and you must answer it. Passing leaves partner`
        + ` describing a hand nobody will hear about; find a bid, however weak.` };
  }

  /* ---------- Tier 1(b): HONESTY severity ----------
   * meaning.js states its own rule (see its opening-bid branch): "Length is inviolable; strength is
   * judgment." So the two breach classes are NOT interchangeable and must not be pooled into one number:
   *   - a SUIT-LENGTH breach is a misrepresentation. Partner will play you for the cards. T_BAD.
   *   - an HCP breach of exactly 1, and nothing else, is a STRETCH, not a lie. T_NEAR.
   *   - anything more (2+ HCP out, or more than one clause broken) is a misrepresentation. T_BAD.
   * The lenient direction is the safe direction: we would rather under-accuse than over-accuse. */
  function breachClass(con, ev){
    let lengthBreach = false, hcpOut = 0, clauses = 0;
    if(con.hcpMin!=null && ev.hcp < con.hcpMin){ hcpOut = Math.max(hcpOut, con.hcpMin - ev.hcp); clauses++; }
    if(con.hcpMax!=null && ev.hcp > con.hcpMax){ hcpOut = Math.max(hcpOut, ev.hcp - con.hcpMax); clauses++; }
    if(con.suitMin) for(const s in con.suitMin) if(ev.len[s] < con.suitMin[s]){ lengthBreach = true; clauses++; }
    if(con.suitMax) for(const s in con.suitMax) if(ev.len[s] > con.suitMax[s]){ lengthBreach = true; clauses++; }
    if(lengthBreach) return "bad";
    if(clauses===1 && hcpOut===1) return "near";
    return "bad";
  }

  /* ================= the grade ================= */
  function gradeBid(ctx, ev){
    ctx = ctx || {};
    const c = ctx.call, calls = ctx.calls || [], dealer = ctx.dealer|0, seat = ctx.seat|0;
    const hand = ctx.hand || [];
    const out = (o)=> Object.assign({
      tier:3, classification:"unjudged", confidence:"low", points:T_OK,
      meaning:null, honesty:null, obligation:null, blunder:null,
      code:"B_QUIET", tag:"no objection", why:null, call:call(c),
    }, o);

    if(!c || !hand.length) return out({ why:null });

    // The teaching payload — what this call PROMISES — is always available, graded or not.
    let hon = null;
    try{ hon = MEAN.checkHonesty(c, calls, dealer, seat, hand); }catch(_){ hon = null; }
    const meaning = hon ? hon.meaning : null;

    // ---- Tier 2 is evaluated FIRST as a fact (not as a verdict): an INDEFENSIBLE call is indefensible
    // whether or not it also lied. It is folded in below, and can only ever make the grade WORSE.
    //
    // ADVISORY BY DEFAULT — and this is a measured decision, not a timid one. `bid_cascade.mjs` ran the
    // evaluator live against real bot auctions and fired on 2 of 39 Tier-1-CLEARED calls: a point estimate
    // of 5.1%, but a 95% Wilson interval of [1.4%, 16.9%]. That sample cannot tell 2% from 10%, and
    // resolving it to +/-1.5pp needs ~500 nodes (~1.2 h of sequential WASM).
    //
    // Meanwhile TIER 1 IS AT ZERO FALSE ACCUSATIONS IN 18,996 CALLS. Letting an unresolved single-to-double
    // digit false-positive rate SET the grade would trade a perfect precision record for recall we can no
    // longer even price — and the recall on offer has shrunk, because the obligation check now catches the
    // single biggest blunder bid_discrim ever measured (pass partner's forcing bid, 2.71 IMP / 4.3 sigma)
    // in Tier 1, for free, deterministically.
    //
    // So by default the gate ANNOTATES and does not grade: the student is told an expected-score check
    // thinks the call is indefensible, and the POINTS are left alone. Pass `ev.authoritative` to let it set
    // the grade — the path is built and tested, and is the right one to switch on IF the false-positive rate
    // is ever pinned below the Tier-1 record it would be diluting.
    const gap = (ev && typeof ev.gap === "number" && isFinite(ev.gap)) ? ev.gap : null;
    const fired = gap !== null && gap >= BLUNDER_EPS;
    const authoritative = !!(ev && ev.authoritative);
    const blunder = (gap !== null)
      ? { fired, gap, eps:BLUNDER_EPS, authoritative,
          why: fired
            ? `Expected-score check: this call looks INDEFENSIBLE — it costs about ${gap.toFixed(1)} IMPs against`
              + ` the best alternative. (This gate only ever speaks up about the indefensible; it says nothing`
              + ` about which call was BEST, and it is advisory — it has not changed your score.)`
            : null }
      : null;
    const gates = fired && authoritative;   // may the gate SET the grade?

    // ---- Tier 1(a): OBLIGATION. Outranks honesty: a pass that abandons partner's force is the error,
    // and describing what the pass "promised" would be beside the point.
    const obl = checkObligation(c, calls, dealer, seat);
    if(obl){
      return out({ tier:1, classification:"obligation", confidence:"high", points:T_BAD,
        meaning, honesty:hon, obligation:obl, blunder,
        code:"B_FORCING_PASS", tag:"answer the force", why:obl.why });
    }

    // ---- Tier 1(b): HONESTY.
    if(hon && hon.lie){
      const cls = breachClass(meaning.constraint, MEAN.evalHand(hand.map(x=>({rank:x.rank,suit:x.suit}))));
      const near = cls === "near";
      return out({ tier:1, classification: near ? "stretch" : "misdescription",
        confidence:"high", points: near ? T_NEAR : T_BAD,
        meaning, honesty:hon, obligation:null, blunder,
        code: near ? "B_STRETCH" : "B_LIE",
        tag: near ? "a stretch" : "misdescribes your hand",
        // NOTE: do NOT restate meaning.text here. Every surface that shows `why` shows the promise directly
        // above it, and splicing it mid-sentence reads as "1S promises Opening bid: 5+ spades...". Name the
        // BREACH and its consequence; the promise is already on the screen.
        why: near
          ? `A slight stretch — ${hon.why}. Within a point, so partner will not be badly misled, but the`
            + ` standard call describes this hand more honestly.`
          : `${cap(hon.why)}. Partner will bid the rest of this auction playing you for cards you do not hold.` });
    }

    // ---- Tier 1 CLEARS. If the promise was FIRM, that is a confident, positive grade.
    if(meaning && meaning.constraint && meaning.confidence==="standard"){
      if(gates){
        return out({ tier:2, classification:"blunder", confidence:"high", points:T_BAD,
          meaning, honesty:hon, obligation:null, blunder,
          code:"B_BLUNDER", tag:"indefensible", why:blunder.why });
      }
      return out({ tier:1, classification:"sound", confidence:"high", points:T_OK,
        meaning, honesty:hon, obligation:null, blunder,
        code:"B_HONEST", tag:"describes your hand", why:null });   // the promise IS the teaching; no gloss needed
    }

    // ---- Tier 2 alone: an honest-or-unpromising call that is nonetheless indefensible.
    if(gates){
      return out({ tier:2, classification:"blunder", confidence:"high", points:T_BAD,
        meaning, honesty:hon, obligation:null, blunder,
        code:"B_BLUNDER", tag:"indefensible", why:blunder.why });
    }

    // ---- Tier 3: a JUDGMENT call. SAYC leaves genuine choice here (an upgrade for shape or controls, a
    // tactical underbid, a competitive punt). We describe it and we STAY QUIET. Full marks, low confidence:
    // "no objection" is an honest verdict, and a far better one than a confident wrong accusation.
    return out({ tier:3, classification:"unjudged", confidence:"low", points:T_OK,
      meaning, honesty:hon, obligation:null, blunder,
      code:"B_QUIET", tag:"judgment call",
      why: meaning ? `${meaning.text} This is a judgment call — SAYC leaves it open, so it is not marked wrong.`
                   : null });
  }

  /* Short display tags for the codes this module emits. */
  const BIDGRADE_TAG = {
    B_HONEST:"describes your hand", B_STRETCH:"a stretch", B_LIE:"misdescribes your hand",
    B_FORCING_PASS:"answer the force", B_BLUNDER:"indefensible", B_QUIET:"judgment call",
  };

  return { gradeBid, checkObligation, breachClass, BIDGRADE_TAG, T_OK, T_NEAR, T_BAD, BLUNDER_EPS };
})();

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { BIDGRADE };
//#endregion gen
