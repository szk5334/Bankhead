//#region gen (auto — removed when bundled to a single bridge.jsx)
import { C } from "../ui/theme.js";
//#endregion gen

/* ==== Standard bridge core logic (verified modules, inlined & namespaced) ==== */
const ENG = (function(){
  /* Standard contract bridge engine — 52 cards, ranks 2..A (A high), 13 tricks. */
  
  const SUITS   = ["S","H","D","C"];                 // display order (spades high)
  const RANKS   = ["2","3","4","5","6","7","8","9","10","J","Q","K","A"];
  const STRAINS = ["C","D","H","S","NT"];            // bidding order (clubs low)
  const STRAIN_IDX = { C:0, D:1, H:2, S:3, NT:4 };
  const SUIT_RANK  = { C:0, D:1, H:2, S:3 };         // for tie-break display only
  const RANKVAL = RANKS.reduce((m,r,i)=>(m[r]=i+2,m),{});   // 2->2 ... A->14
  
  let _uid=1;
  function makeDeck(){
    const d=[];
    for(const s of SUITS) for(const r of RANKS) d.push({ id:_uid++, rank:r, suit:s });
    return d;
  }
  function shuffle(a){
    a=a.slice();
    for(let i=a.length-1;i>0;i--){ const j=(Math.random()*(i+1))|0; [a[i],a[j]]=[a[j],a[i]]; }
    return a;
  }
  
  // bids encode as level*5 + strainIndex for easy comparison
  function bidCode(level, strain){ return level*5 + STRAIN_IDX[strain]; }
  function decodeBid(code){ return { level: Math.floor(code/5), strain: STRAINS[code%5] }; }
  
  /* Standard trick resolution: if any trump was played, the highest trump wins;
     otherwise the highest card of the led suit wins. cards = [{rank,suit,player}]. */
  function resolveTrick(cards, ledSuit, trump){
    let best=cards[0], bestIsTrump=(trump!=="NT" && cards[0].suit===trump);
    for(let i=1;i<cards.length;i++){
      const c=cards[i];
      const cTrump=(trump!=="NT" && c.suit===trump);
      if(cTrump && !bestIsTrump){ best=c; bestIsTrump=true; continue; }
      if(cTrump===bestIsTrump){
        // same category — compare only if this card is in the category that can win
        const relevant = bestIsTrump ? true : (c.suit===ledSuit && best.suit===ledSuit);
        if(bestIsTrump){ if(RANKVAL[c.rank]>RANKVAL[best.rank]) best=c; }
        else {
          // non-trump: only led-suit cards can beat; a non-led non-trump can never win
          if(c.suit===ledSuit){ if(best.suit!==ledSuit || RANKVAL[c.rank]>RANKVAL[best.rank]) best=c; }
        }
      }
    }
    return { winner: best.player };
  }
  
  /* Legal plays: must follow the led suit if you hold any card of it; else anything. */
  function legalPlays(hand, ledSuit){
    if(!ledSuit) return hand.slice();
    const follow=hand.filter(c=>c.suit===ledSuit);
    return follow.length ? follow : hand.slice();
  }
  
  
  
  return { SUITS, RANKS, STRAINS, STRAIN_IDX, SUIT_RANK, RANKVAL,
  makeDeck, shuffle, bidCode, decodeBid, resolveTrick, legalPlays };
})();


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { ENG };
//#endregion gen
