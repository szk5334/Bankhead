//#region gen (auto — removed when bundled to a single bridge.jsx)
// dependency-free — no imports
//#endregion gen

/* signals.js — complete defensive SIGNAL machinery: a matched EMITTER and READER for the three standard
 * carding primitives (attitude, count, suit-preference), plus the priority logic that decides which primitive
 * is in force. These are standard contract-bridge conventions (public technique); the module is configurable
 * so upside-down / odd-even variants can be layered later. Pure and self-contained so it can be unit-tested
 * and shared between the play engine (bot carding) and any grader.
 *
 *   emit(ctx)  -> { card, type, why }         choose the exact spot that carries an intended message
 *   read(ctx)  -> { attitude, count, suitPref, honorLikely, prefer, avoid, notes }
 *                                             infer partner's messages from every card partner has played
 *
 * Conventions (default = "standard", the app's existing convention):
 *   attitude : high = encourage / like (ask continue or shift-to), low = discourage           [partner's lead / discard]
 *   count    : high-low = even, low(-high) = odd                                               [declarer's / dummy's lead]
 *   suit-pref: high = higher-ranking side suit, low = lower-ranking side suit                  [ruff / known suit]
 * Guiding principle (Woolsey/Kantar and standard theory): "signal with the highest card you can afford" —
 * so the READER judges a card RELATIVE to the lower spots partner could have played, not by an absolute cutoff.
 */

const SIG = (function(){
  const RV = { "2":2,"3":3,"4":4,"5":5,"6":6,"7":7,"8":8,"9":9,"10":10,"J":11,"Q":12,"K":13,"A":14 };
  const RANKS = ["2","3","4","5","6","7","8","9","10","J","Q","K","A"];
  const SUITS = ["S","H","D","C"];
  const SORDER = { S:0, H:1, D:2, C:3 };                 // higher-ranking first (S highest)
  const sideOf = (s) => s % 2;
  const partnerOf = (s) => (s + 2) % 4;
  const byAsc  = (a) => a.slice().sort((x,y)=>RV[x.rank]-RV[y.rank]);
  const byDesc = (a) => a.slice().sort((x,y)=>RV[y.rank]-RV[x.rank]);
  const isSpot = (c) => RV[c.rank] < 10;                 // 2..9 — never "signal" with a 10+/honour
  const GLYPH = { S:"\u2660", H:"\u2665", D:"\u2666", C:"\u2663" };
  const lbl = (c) => `${c.rank}${GLYPH[c.suit]}`;

  const DEFAULT_METHODS = { attitude:"standard", count:"standard" };

  // ---------------------------------------------------------------- EMITTER ----------------------------------
  /* Pick the exact card to play so it carries `message` under `context`. suitCards = the cards I can legally
   * contribute (follows to the suit, or the candidate discards). Returns null card only if suitCards empty. */
  function emit(ctx){
    const M = Object.assign({}, DEFAULT_METHODS, ctx.method || {});
    const cards = ctx.suitCards || [];
    if(!cards.length) return { card:null, type:"none", why:"no card" };
    const spots = cards.filter(isSpot);
    const lowest = byAsc(cards)[0];
    const highSpot = spots.length ? byDesc(spots)[0] : null;   // highest AFFORDABLE spot (don't burn an honour)
    const lowSpot  = spots.length ? byAsc(spots)[0]  : lowest;

    const pick = (card, type, why) => ({ card, type, why });

    if(ctx.context === "attitude"){
      const enc = ctx.message === "encourage";
      const wantHigh = (M.attitude === "standard") ? enc : !enc;   // udca flips
      if(wantHigh){
        if(highSpot) return pick(highSpot, "attitude", `${lbl(highSpot)}: ${enc?"encouraging":"discouraging"} (high${M.attitude==="standard"?"":", UDCA"}).`);
        return pick(lowest, "attitude", `${lbl(lowest)}: can't spare a high spot — lowest, message unclear.`);
      } else {
        return pick(lowSpot, "attitude", `${lbl(lowSpot)}: ${enc?"encouraging":"discouraging"} (low${M.attitude==="standard"?"":", UDCA"}).`);
      }
    }

    if(ctx.context === "count"){
      const len = ctx.message|0;                              // MY length in the suit
      const even = (len % 2) === 0;
      const wantHigh = (M.count === "standard") ? even : !even; // first card of the echo
      if(wantHigh){
        if(highSpot) return pick(highSpot, "count", `${lbl(highSpot)}: begins a high-low (${even?"even":"odd"} length).`);
        return pick(lowest, "count", `${lbl(lowest)}: no affordable high spot — count obscured.`);
      }
      return pick(lowSpot, "count", `${lbl(lowSpot)}: low, showing ${even?"even":"odd"} length.`);
    }

    if(ctx.context === "suitpref"){
      // message: { high:suit, low:suit } — the two remaining side suits, ranked. Play high spot for the higher,
      // low spot for the lower. ctx.want = "high" | "low".
      const wantHigh = ctx.want === "high";
      if(wantHigh){
        if(highSpot) return pick(highSpot, "suitpref", `${lbl(highSpot)}: suit-preference for the higher side suit.`);
        return pick(byDesc(cards)[0], "suitpref", `${lbl(byDesc(cards)[0])}: highest available (suit-preference, higher).`);
      }
      return pick(lowSpot, "suitpref", `${lbl(lowSpot)}: suit-preference for the lower side suit.`);
    }

    return pick(lowest, "none", `${lbl(lowest)}: no signal context — lowest.`);
  }

  // ---------------------------------------------------------------- READER ------------------------------------
  /* Infer partner's messages from every card partner has played. Robust attitude: judge partner's card RELATIVE
   * to the lower spots partner could still have held (the "highest you can afford" principle), not by a fixed
   * cutoff. Count: parity from high-vs-low, refined to a length via the outstanding cards. */
  function read(ctx){
    const M = Object.assign({}, DEFAULT_METHODS, ctx.method || {});
    const seat = ctx.seat, partner = partnerOf(seat), declarer = ctx.declarer, dummy = ctx.dummy, trump = ctx.trump;
    const hist = ctx.history || [];
    const cur  = ctx.trick ? [{ cards: (ctx.trick||[]).map(c=>({player:c.player??c.seat, suit:c.suit, rank:c.rank})),
                                ledSuit: (ctx.trick&&ctx.trick[0])?ctx.trick[0].suit:null,
                                leaderSeat: (ctx.trick&&ctx.trick[0])?(ctx.trick[0].player??ctx.trick[0].seat):null, winner:null }] : [];
    const tricks = hist.map(t => ({ cards:t.cards||[], ledSuit:t.ledSuit, winner:t.winner,
                                    leaderSeat: (t.cards&&t.cards[0])?t.cards[0].player:null })).concat(cur);

    // cards visible to me now (my hand + dummy + everything played) -> what's unseen (could be partner's/declarer's)
    const seen = new Set();
    for(const c of (ctx.hand||[]))       seen.add(c.rank+c.suit);
    for(const c of (ctx.dummyHand||[]))  seen.add(c.rank+c.suit);
    for(const t of tricks) for(const c of (t.cards||[])) seen.add(c.rank+c.suit);
    const unseenSpotsBelow = (suit, rank) => {              // lower spots in `suit` I can't see (partner could hold)
      let n=0; for(const r of RANKS){ if(RV[r] >= rank) break; if(RV[r]>=10) continue; if(!seen.has(r+suit)) n++; } return n;
    };
    const outstanding = (suit) => {                         // cards of `suit` not in my hand or dummy (declarer+partner)
      let n=13; for(const c of (ctx.hand||[])) if(c.suit===suit) n--; for(const c of (ctx.dummyHand||[])) if(c.suit===suit) n--; return n;
    };

    const attitude = {S:null,H:null,D:null,C:null};
    const count    = {S:{parity:null,length:null},H:{parity:null,length:null},D:{parity:null,length:null},C:{parity:null,length:null}};
    const suitPref = {};                                    // suit -> preferred side suit
    const partnerLed = new Set();
    const notes = [];
    const attSeen = new Set(), cntSeen = new Set();         // only the FIRST signal in a suit counts

    for(const t of tricks){
      const cards = t.cards||[]; if(!cards.length) continue;
      const led = t.ledSuit || (cards[0] && cards[0].suit);
      const leader = t.leaderSeat;
      const pc = cards.find(c => c.player === partner);
      if(leader === partner){ partnerLed.add(led); }        // partner attacked this suit
      if(!pc) continue;

      // ---- context of partner's card ----
      const partnerFollowed = pc.suit === led;
      if(leader === partner){
        // partner's own lead: not a signal to me here (it's their attack); skip attitude.
        continue;
      }
      if((leader === seat) && partnerFollowed){
        // ATTITUDE: I led, partner followed -> like/dislike of the led suit.
        if(attSeen.has(led)) continue; attSeen.add(led);
        attitude[led] = readAttitude(pc, led, M);
        continue;
      }
      if(sideOf(leader) === sideOf(declarer) && partnerFollowed){
        // COUNT: declaring side led, partner followed -> length parity (first round only).
        if(cntSeen.has(led)) continue; cntSeen.add(led);
        const parity = readCountParity(pc, led, M);
        count[led].parity = parity;
        count[led].length = refineLength(led, parity, outstanding(led));
        continue;
      }
      if(!partnerFollowed && pc.suit !== trump){
        // DISCARD (couldn't follow): first discard in a suit = attitude about that suit (standard).
        if(attSeen.has(pc.suit)) continue; attSeen.add(pc.suit);
        attitude[pc.suit] = readAttitude(pc, pc.suit, M);
        notes.push(`discard ${lbl(pc)} → ${attitude[pc.suit]==="like"?"likes":"dislikes"} ${pc.suit}`);
        continue;
      }
    }

    // attitude judged relative to affordable spots (the key inference)
    function readAttitude(pc, suit, M){
      const rank = RV[pc.rank];
      const couldGoLower = unseenSpotsBelow(suit, rank) > 0;   // a lower spot existed that partner didn't play
      // standard: high (or a spot with lower cards still out) = encourage; the bottom card = discourage.
      let like;
      if(rank >= 9)               like = true;                 // 9+ is a clear high card
      else if(rank <= 4 && !couldGoLower) like = false;        // truly the bottom
      else if(couldGoLower)        like = (rank >= 6);          // mid card with lower ones out: lean by height
      else                         like = false;               // lowest available = discourage
      if(M.attitude === "udca") like = !like;
      return like ? "like" : "dislike";
    }
    function readCountParity(pc, suit, M){
      const rank = RV[pc.rank];
      // high spot = even (standard). 6 is ambiguous; lean odd only if clearly low.
      let even = rank >= 7 ? true : (rank <= 5 ? false : null);
      if(even === null) return null;
      if(M.count === "udca") even = !even;
      return even ? "even" : "odd";
    }
    function refineLength(suit, parity, outstandingN){
      if(!parity) return null;
      const wantEven = parity === "even";
      let best=null, bd=99;
      for(let L=0;L<=outstandingN;L++){ if(((L%2===0)!==wantEven)) continue; const d=Math.abs(L - outstandingN/2); if(d<bd){ bd=d; best=L; } }
      return best;
    }

    // ---- derive a switch belief: which suits to attack, which to avoid ----
    const honorLikely = {};
    const preferScore = {S:0,H:0,D:0,C:0};
    const avoid = new Set();
    for(const s of SUITS){
      if(attitude[s] === "like"){ honorLikely[s] = true;  preferScore[s] += 2; }
      if(attitude[s] === "dislike"){ honorLikely[s] = false; preferScore[s] -= 2; avoid.add(s); }
      if(partnerLed.has(s)) preferScore[s] += 1;           // partner already chose to attack it
    }
    // suit-preference reads (from a clearly high/low card in a suit whose attitude/count is already settled)
    // — conservative: only when partner discouraged the led suit, the size hints which side suit (Lavinthal-like).
    // GATED: this decode is only sound if the EMITTER encoded suit-preference. With a plain-attitude emitter it
    // is reading noise, so `mode:"att"` disables it (attitude-only: continue liked, avoid disliked, guess shift).
    if(ctx.mode !== "att")
    for(const t of tricks){
      const cards=t.cards||[]; if(!cards.length) continue;
      const led=t.ledSuit||(cards[0]&&cards[0].suit); const pc=cards.find(c=>c.player===partner);
      if(!pc || pc.suit!==led || t.leaderSeat!==seat) continue;
      if(attitude[led]==="dislike"){
        const others = SUITS.filter(x=>x!==led).sort((a,b)=>SORDER[a]-SORDER[b]); // higher-ranking first
        const rank=RV[pc.rank];
        const wantHigher = rank >= 7;                       // a high discouraging spot hints the higher side suit
        const target = wantHigher ? others[0] : others[others.length-1];
        if(!avoid.has(target)){ preferScore[target] += 1; suitPref[led]=target; }
      }
    }
    const prefer = SUITS.filter(s=>preferScore[s]>0).sort((a,b)=>preferScore[b]-preferScore[a]);

    return { attitude, count, suitPref, partnerLed:[...partnerLed], honorLikely, prefer, avoid, preferScore, notes };
  }

  return { emit, read, RV, isSpot };
})();

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { SIG };
//#endregion gen
