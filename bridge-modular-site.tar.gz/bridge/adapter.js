//#region gen (auto — removed when bundled to a single bridge.jsx)
import App from "./App.jsx";
import { BID } from "./engine/bidding.js";
import { SEAT_NAME, SUIT_GLYPH, sideOf } from "./state/constants.js";
import { who } from "./state/personas.js";
//#endregion gen

/* =======================================================================
   GAME ADAPTER — the standard contract the multiplayer shell consumes.
   ===================================================================== */
function redactFor(state, seat){
  if(!state || !state.hands) return state;
  const fake=(n)=>{ const a=[]; for(let i=0;i<n;i++) a.push({id:0,rank:"?",suit:"?",back:true}); return a; };
  const dummyVisible = state.contract && state.dummyRevealed ? state.dummy : -1;   // dummy is public once exposed
  const hands={};
  for(let i=0;i<4;i++){
    if(i===seat || i===dummyVisible) hands[i]=state.hands[i];
    else hands[i]=fake((state.hands[i]||[]).length);
  }
  const out={...state, hands};
  if(state.phase!=="scored") out.dealtHands=undefined;                            // never leak concealed hands early
  return out;
}
function publicView(s){
  if(!s || !s.hands) return { status:"", seats:[], pileTop:null, pileCount:0, stockCount:0, log:[] };
  const seats=[];
  for(let i=0;i<4;i++){
    seats.push({
      name: who(s,i),
      handCount: (s.hands[i]||[]).length,
      score: s.total[sideOf(i)],
      turn: i===s.turn && s.phase!=="scored",
      note: i===s.declarer?"declarer":i===s.dummy?"dummy":SEAT_NAME[i],
    });
  }
  const top = s.trick && s.trick.length ? s.trick[s.trick.length-1].card
            : (s.lastTrick? s.lastTrick.trick[s.lastTrick.trick.length-1].card : null);
  const status = s.phase==="auction" ? `${who(s,s.turn)} to bid`
    : s.phase==="play" ? `${who(s,s.turn)} to play`
    : s.phase==="scored" ? (s.result? s.result.head : "hand over") : "";
  return {
    status, seats,
    pileTop: top ? (top.rank+SUIT_GLYPH[top.suit]) : null,
    pileCount: s.trick? s.trick.length : 0,
    stockCount: 0,
    log: s.log||[],
  };
}
if (typeof window !== "undefined") {
  window.GAME = {
    id: "bridge",
    title: "BRIDGE",
    minPlayers: 4,
    maxPlayers: 4,
    App: App,
    redactFor: redactFor,
    publicView: publicView,
    actionTypes: ["BID","PLAY","NEXT_DEAL","NEW_RUBBER"],
    seatOf: (a)=> a.seat!=null ? a.seat : a.player,
  };
}



//#region gen (auto — removed when bundled to a single bridge.jsx)
export { publicView, redactFor };
//#endregion gen
