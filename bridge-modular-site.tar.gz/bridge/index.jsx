/* App entry — dev preview ONLY (mounts <App/>). The shell build (build-bridge.mjs) ignores this file. */
import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App.jsx";
import "./adapter.js"; // side effect: registers window.GAME
const el = document.getElementById("root");
if (el) createRoot(el).render(React.createElement(App));
