//#region gen (auto — removed when bundled to a single bridge.jsx)
import React, { useReducer, useEffect, useRef } from "react";
import { ANA } from "./engine/analysis.js";
import { ENG } from "./engine/core.js";
import { GRADER_WORKER_SRC } from "./grader/workerSrc.js";
import { SIDE_NAME, STRAIN_GLYPH, SUIT_GLYPH, callLabel, controllerOf, nextSeat, partnerOf, sideOf } from "./state/constants.js";
import { who } from "./state/personas.js";
import { SETUP, botAction, previewKey, reducer, sdDecisionPos } from "./state/reducer.js";
import { getGlossary, suggestBidWhy, suggestPlayWhy } from "./state/teachingMode.js";
import { THEME_CSS } from "./ui/css.js";
import { UIErrorBoundary } from "./ui/errorBoundary.jsx";
import { GlossaryScreen, linkifyGlossary, suitColorClass } from "./ui/glossary.jsx";
import { HelpDrawer } from "./ui/helpDrawer.jsx";
import { LearnScreen } from "./ui/learn.jsx";
import { OnlineBar, OnlineScreens, SpectatorView, useBridgeNet } from "./ui/online.js";
import { RulesScreen, Setup } from "./ui/setup.jsx";
import { loadCampaign, loadStats, loadTheme, saveCampaign, saveStats, saveTheme } from "./ui/storage.js";
import { AnalysisView } from "./ui/analysis.jsx";
import { SolitaireTable } from "./ui/solitaireTable.jsx";
import { AuctionView, BiddingBox, HandRow, RevealGate, ScoreSheet, SeatStrip, StatusBar, SwipeHand, TabBar, TrickTable } from "./ui/table.jsx";
import { C, btn } from "./ui/theme.js";
import "./data/teaching.js";
//#endregion gen

export default function App(){
  const [s,dispatch]=useReducer(reducer,SETUP);
  const [theme,setTheme]=React.useState(()=>loadTheme());
  const [campaign,setCampaign]=React.useState(()=>loadCampaign());
  const [showRules,setShowRules]=React.useState(false);
  const [revealSeat,setRevealSeat]=React.useState(0);
  const [hint,setHint]=React.useState(false);
  const [alwaysOn,setAlwaysOn]=React.useState(()=>{ try{ return localStorage.getItem("bridge.suggest.always")==="on"; }catch(_){ return false; } });
  React.useEffect(()=>{ try{ localStorage.setItem("bridge.suggest.always", alwaysOn?"on":"off"); }catch(_){} },[alwaysOn]);
  const showHint = hint || alwaysOn;
  const [teach,setTeach]=React.useState(()=>{ try{ return localStorage.getItem("bridge.teach.v1")!=="off"; }catch(_){ return true; } });
  const [teachVer,setTeachVer]=React.useState(0);
  const [showGloss,setShowGloss]=React.useState(false);
  const [glossTerm,setGlossTerm]=React.useState(null);
  const [drawerOpen,setDrawerOpen]=React.useState(false);
  const [showLearn,setShowLearn]=React.useState(false);
  const [glossPop,setGlossPop]=React.useState(null);
  const [tab,setTab]=React.useState("game");   // "game" (bid/play/result) | "talk" (Table Talk)
  const [sel,setSel]=React.useState(null);      // selected card id for select-then-play
  const [menuOpen,setMenuOpen]=React.useState(false);

  // load teaching text + glossary at startup: use a script-provided global if present,
  // otherwise fetch the JSON next to the page; fall back silently to the built-in defaults.
  useEffect(()=>{
    if(typeof window==="undefined") return;
    if(window.BRIDGE_TEACHING){ setTeachVer(v=>v+1); return; }
    const url = window.BRIDGE_TEACHING_URL || "bridge-teaching.json";
    let alive=true;
    try{
      fetch(url).then(r=>r.ok?r.json():null).then(j=>{ if(alive&&j){ window.BRIDGE_TEACHING=j; setTeachVer(v=>v+1); } }).catch(()=>{});
    }catch(_){}
    return ()=>{ alive=false; };
  },[]);
  const timer=useRef(null);
  const focusRef=useRef(0);
  const recordedRef=useRef(null);
  const netRef=useRef(null);

  // Off-thread declarer-play grader (bridge-dds WASM in a worker; endgame pure-JS fallback inside it).
  // Purely additive: results arrive as PLAY_GRADE and only annotate the Table Talk log.
  const gradeWorkerRef=useRef(null);
  const workerSrcRef=useRef(null);      // assembled worker source, for spawning short-lived SD workers
  const gradeReqRef=useRef(null);
  if(gradeReqRef.current===null) gradeReqRef.current=new Set();
  const pickRef=useRef(null);   // pending bot single-dummy play decision (resolved by the worker)
  const [gradeStatus,setGradeStatus]=React.useState({worker:null,backend:null,ddsError:null,graded:0,skipped:0,errored:0,lastError:null});
  useEffect(()=>{
    if(typeof window==="undefined"||typeof Worker==="undefined") return;
    let w=null, alive=true, url=null;
    // SPLIT DEPLOY: the bridge-dds WASM engine ships as a separate static file (fetched, not inlined in
    // workerSrc.js, to keep the app bundle small). Fetch its text and PREPEND it to the worker source so
    // __DDS_ENGINE is defined in the worker's module scope. Same relative-path convention as the teaching
    // JSON. If the fetch fails, we still start the worker from GRADER_WORKER_SRC alone — it degrades to the
    // pure-JS endgame solver (backend=js) rather than breaking.
    const engineUrl = window.BRIDGE_DDS_ENGINE_URL || "bridge/grader/dds_engine.inline.js";
    const start=(engineText)=>{
      if(!alive) return;
      try{
        const src=(engineText? engineText+"\n" : "")+GRADER_WORKER_SRC;
        // Bank the assembled source. The post-hand SD pass must RECYCLE its worker between chunks (the WASM
        // DDS OOMs past ~800 solves in a process and that pass is 16 per card), and it cannot recycle the
        // LIVE grader — that one is still serving the table. So it spawns its own, from this text.
        workerSrcRef.current = src;
        const _blob=new Blob([src],{type:"text/javascript"});
        url=URL.createObjectURL(_blob);
        w=new Worker(url,{type:"module"});
      }catch(_){ w=null; }
      gradeWorkerRef.current=w;
      setGradeStatus(st=>({...st, worker: !!w}));
      if(w) w.onmessage=(ev)=>{ const d=ev.data||{};
        if(d.ready){ setGradeStatus(st=>({...st, worker:true, backend:d.backend, ddsError:d.ddsError||null})); return; }
        // bot single-dummy play decision: play grade.best_named (with its reason), else fall back to the engine.
        if(typeof d.id==="string" && d.id.indexOf("pick:")===0){
          const ctx=pickRef.current; pickRef.current=null;
          if(ctx && ctx.timer) clearTimeout(ctx.timer);
          if(ctx){
            const g=d.grade; let done=false;
            if(g && !g.skipped && !g.error){
              const key=g.best_named||g.best;
              const card=(ctx.hand||[]).find(c=>`${c.rank}.${c.suit}`===key);
              if(card){ apply({type:"PLAY", player:ctx.seat, cardId:card.id, why:g.best_why}); done=true; }
            }
            if(!done){ try{ apply(botAction(ctx.bs)); }catch(_){} }
          }
          return;
        }
        if(d.id==null) return;
        if(d.error){ setGradeStatus(st=>({...st, errored:st.errored+1, lastError:d.error, backend:d.backend||st.backend})); return; }
        const g=d.grade;
        setGradeStatus(st=>({...st, backend:d.backend||st.backend, graded:st.graded+((g&&!g.skipped)?1:0), skipped:st.skipped+((g&&g.skipped)?1:0)}));
        dispatch({type:"PLAY_GRADE", moveId:d.id, grade:g});
      };
    };
    try{
      fetch(engineUrl).then(r=>r.ok?r.text():null).then(t=>start(t||"")).catch(()=>start(""));
    }catch(_){ start(""); }
    return ()=>{ alive=false; try{ if(w) w.terminate(); }catch(_){} try{ if(url) URL.revokeObjectURL(url); }catch(_){} gradeWorkerRef.current=null; };
  },[]);
  useEffect(()=>{
    const w=gradeWorkerRef.current; if(!w) return;
    for(const pos of (s.gradeQueue||[])){
      if(gradeReqRef.current.has(pos.moveId)) continue;
      gradeReqRef.current.add(pos.moveId);
      try{ w.postMessage({id:pos.moveId, pos}); }catch(_){}
    }
  },[s.gradeQueue]);

  /* ---------------- THE POST-HAND SD PASS (solitaire only) ----------------
   *
   * The live table runs on the DD lens: exact, instant, one solve per POSITION. This pass runs the OTHER
   * lens — "would you have played that if you COULDN'T see their hands?" — which is 16 belief worlds per
   * card and cannot be live. It is what the whole analysis is built on.
   *
   * IT MUST RECYCLE ITS WORKER. The WASM DDS OOMs somewhere past ~800 solves in one process; this pass is
   * ~16 per card over ~40 non-forced decisions. So it runs in CHUNKS, spawning a short-lived worker per
   * chunk and terminating it — which also means it never touches the live grader, which is still serving
   * the table behind the analysis screen.
   *
   * Sequential, never parallel: two WASM solvers racing in one tab is how you OOM twice as fast.
   */
  const [sdProgress,setSdProgress]=React.useState(null);
  const sdRunRef=useRef(null);          // the token driving the current pass (null = not running)
  useEffect(()=>{
    // Leaving the analysis (new deal, replay, exit) cancels any pass still in flight.
    if(!s.solitaire || s.phase!=="scored"){
      if(sdRunRef.current) sdRunRef.current.cancelled=true;
      sdRunRef.current=null; setSdProgress(null); return;
    }
    if(s.sdDone) return;
    if(!workerSrcRef.current) return;                 // worker source not assembled yet
    if(s.sdWork===undefined){ dispatch({type:"SD_START"}); return; }
    if(sdRunRef.current) return;                      // already driving this hand

    /* CANCELLATION IS BY TOKEN, NOT BY EFFECT CLEANUP. Every SD_GRADE mutates s.sdWork, which is a dep of
     * this effect — so React would run the cleanup on EVERY result, and a cleanup that cancelled the chain
     * would kill it after the very first card. The token lives in a ref and is only cancelled when the HAND
     * changes, which is the only time cancelling is actually meant. */
    const token={cancelled:false};
    sdRunRef.current=token;

    const CHUNK=6;
    const work=(s.sdWork||[]).slice();                // snapshot ONCE; the reducer drains the real list
    setSdProgress({done:0,total:work.length});
    if(!work.length){ dispatch({type:"SD_GRADE", moveId:"__none__", grade:null}); return; }

    const runChunk=(i)=>{
      if(token.cancelled || i>=work.length) return;
      let w=null,url=null;
      try{
        const blob=new Blob([workerSrcRef.current],{type:"text/javascript"});
        url=URL.createObjectURL(blob);
        w=new Worker(url,{type:"module"});
      }catch(_){ return; }
      const batch=work.slice(i,i+CHUNK);
      let left=batch.length;
      const finish=()=>{
        try{ w.terminate(); }catch(_){}              // RECYCLE: a fresh WASM heap for the next chunk
        try{ URL.revokeObjectURL(url); }catch(_){}
        if(!token.cancelled) runChunk(i+CHUNK);
      };
      w.onmessage=(ev)=>{
        const d=ev.data||{};
        if(d.ready){ for(const pos of batch){ try{ w.postMessage({id:pos.moveId, pos}); }catch(_){} } return; }
        if(d.id==null) return;
        if(!token.cancelled){
          dispatch({type:"SD_GRADE", moveId:d.id, grade:d.grade||null});
          setSdProgress(pr=>pr?{...pr, done:Math.min(pr.total, pr.done+1)}:pr);
        }
        if(--left<=0) finish();
      };
      // A chunk that dies must not stall the pass: bank nulls (honestly reported as "not analysed") and move on.
      w.onerror=()=>{
        if(!token.cancelled) for(const pos of batch) dispatch({type:"SD_GRADE", moveId:pos.moveId, grade:null});
        finish();
      };
    };
    runChunk(0);
  },[s.solitaire, s.phase, s.sdWork, s.sdDone]);   // eslint-disable-line

  /* The analysis is a PURE function of the two lenses, so it is derived, never stored. */
  const solAnalysis = React.useMemo(()=>{
    if(!s.solitaire || s.phase!=="scored" || !s.sdDone) return null;
    const byPos={};
    for(const p of (s.sdQueue||[])) byPos[p.solPosKey]=p.moveId;
    const positions=[];
    for(const posKey of Object.keys(s.ddPlayed||{})){
      const g=(s.grades||{})[posKey];
      if(!g || g.mode!=="solitaire") continue;
      const sdId=byPos[posKey];
      positions.push({ posKey, seat:g.seat, trick:+String(posKey).split(".")[1],
        dd:g.dd, playedKey:s.ddPlayed[posKey],
        sd: sdId ? ((s.sdResults||{})[sdId] || null) : null });
    }
    try{ return ANA.analyse({ calls:s.calls, positions, contract:s.contract, tricks:s.tricks }); }
    catch(_){ return null; }
  },[s.solitaire, s.phase, s.sdDone, s.sdResults, s.grades, s.ddPlayed, s.calls]);

  useEffect(()=>{ saveTheme(theme); },[theme]);
  useEffect(()=>{ try{ localStorage.setItem("bridge.teach.v1", teach?"on":"off"); }catch(_){} },[teach]);

  const apply=React.useCallback((action)=>{
    if(netRef.current && netRef.current.role==="guest"){ netRef.current.send(action); return; }
    dispatch(action);
  },[]);

  const net = useBridgeNet({
    onAction:(a)=>apply(a),
    onResume:(state)=>{ dispatch({type:"__SYNC__", state}); },
    onGoSolo:()=>dispatch({type:"TO_SETUP"}),
    onSeatChange:(seat,brain,name)=>dispatch({type:"SET_BRAIN_LIVE", seat, brain, name:(name!=null?name:"")}),
  });
  netRef.current=net;
  const online = net.role!=="off";
  const mySeat = net.seat;
  useEffect(()=>{ if(net.role==="host" && s.mode==="play") net.broadcastState(s, net.names, 0); },[s, net.names, net.role]); // eslint-disable-line
  useEffect(()=>{ if(net.role==="guest" && net.snap) dispatch({type:"__SYNC__", state:net.snap}); },[net.snapV]); // eslint-disable-line

  // bot auto-play (auction + play); also covers a disconnected human seat when hosting online
  useEffect(()=>{
    if(netRef.current && netRef.current.role==="guest") return;
    if(s.mode!=="play") return;
    if(s.phase!=="auction" && s.phase!=="play") return;
    const controller = s.phase==="auction" ? s.turn : controllerOf(s, s.turn);
    const nrole = netRef.current && netRef.current.role;
    const down = nrole==="host" && netRef.current.isSeatDown && netRef.current.isSeatDown(controller);
    if(s.brains[controller]==="human" && !down) return;
    const bs = (s.brains[controller]==="human")
      ? {...s, brains:s.brains.map((b,i)=> i===controller ? "sayer" : b)} : s;
    const delay = down ? 2200 : (s.phase==="auction"?520:620);
    timer.current=setTimeout(()=>{
      // On a PLAY turn, let the bots play the SINGLE-DUMMY recommendation (the same grader the teaching
      // uses): ask the worker for this seat's SD-best card and play it, with its reason. Falls back to the
      // engine when the worker is unavailable, grading is off, or the position isn't graded (opening lead).
      const w=gradeWorkerRef.current;
      if(s.phase==="play" && w && s.gradeOn){
        let pos=null; try{ pos=sdDecisionPos(bs, s.turn); }catch(_){ pos=null; }
        if(pos){
          const seat=s.turn;
          const hand=(bs.hands[seat]||[]).map(c=>({id:c.id,rank:c.rank,suit:c.suit}));
          const ctx={ seat, hand, bs };
          ctx.timer=setTimeout(()=>{ if(pickRef.current===ctx){ pickRef.current=null; try{ apply(botAction(bs)); }catch(_){} } }, 4000);
          pickRef.current=ctx;
          try{ w.postMessage({id:"pick:"+pos.moveId, pos}); return; }
          catch(_){ if(ctx.timer) clearTimeout(ctx.timer); pickRef.current=null; }
        }
      }
      apply(botAction(bs));
    }, delay);
    return ()=>clearTimeout(timer.current);
  },[s]); // eslint-disable-line

  useEffect(()=>{ setHint(false); setGlossPop(null); setSel(null); },[s.turn,s.phase,s.mode]);
  useEffect(()=>{
    const ctrl = s.phase==="auction"? s.turn : controllerOf(s, s.turn);
    if((s.phase==="auction"||s.phase==="play") && s.brains[ctrl]==="human") focusRef.current=ctrl;
  },[s.turn,s.phase]); // eslint-disable-line

  // persist an in-progress rubber + light stats, once per scored deal
  useEffect(()=>{
    if(!(s.mode==="play" && s.phase==="scored" && s.roundEndedAt)) return;
    if(recordedRef.current===s.roundEndedAt) return;
    recordedRef.current=s.roundEndedAt;
    const st=loadStats(); st.dealsPlayed=(st.dealsPlayed||0)+1;
    if(s.result && s.result.made) st.contractsMade=(st.contractsMade||0)+1;
    if(s.rubberDone){ st.rubbers=(st.rubbers||0)+1; if(s.rubberWinner===0) st.rubbersWon=(st.rubbersWon||0)+1; }
    saveStats(st);
    if(s.rubberDone){ saveCampaign(null); setCampaign(null); }
    else {
      const snap={brains:[...s.brains], names:[...(s.names||["","","",""])], games:[...s.games], vuln:[...s.vuln],
        gameBelow:[...s.gameBelow], total:[...s.total], dealer:s.dealer, rubberNo:s.rubberNo||1, ts:Date.now()};
      saveCampaign(snap); setCampaign(snap);
    }
  },[s.phase, s.roundEndedAt]); // eslint-disable-line

  const resumeCampaign=()=>{
    const c=campaign; if(!c) return;
    recordedRef.current=null;
    apply({type:"RESUME", brains:c.brains, names:c.names, games:c.games, vuln:c.vuln,
      gameBelow:c.gameBelow, total:c.total, dealer:c.dealer, rubberNo:c.rubberNo});
  };
  const discardCampaign=()=>{ saveCampaign(null); setCampaign(null); };
  const goSetup=()=>{ dispatch({type:"TO_SETUP"}); };

  if(net.role==="spectate"){
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><SpectatorView net={net}/></div>;
  }
  if(net.role==="lobby" || (net.role!=="off" && s.mode!=="play")){
    return <div className="br" data-theme={theme}><style>{THEME_CSS}</style><OnlineScreens net={net} onStart={()=>{}}/></div>;
  }

  /* ---------------- SOLITAIRE ----------------
   * A fixed 588px table that never moves, and — when the hand ends — the analysis it exists to produce.
   * The normal table's whole apparatus (bots, reveal gates, hints, online) is bypassed: there are no bots,
   * nothing is hidden, and there is no opponent. */
  if(s.solitaire){
    const done = s.phase==="scored";
    return (
      <div className="br" data-theme={theme}
        style={{height:"100vh",background:"var(--bg)",display:"flex",flexDirection:"column",overflow:"hidden"}}>
        <style>{THEME_CSS}</style>
        <UIErrorBoundary>
          {done
            ? <AnalysisView s={s} analysis={solAnalysis} progress={sdProgress}
                onReplay={()=>dispatch({type:"START_SOLITAIRE"})}
                onClose={()=>dispatch({type:"NEW_SOLITAIRE_DEAL"})} />
            : <SolitaireTable s={s} dispatch={dispatch} />}
        </UIErrorBoundary>
        {!done ? (
          <div style={{padding:"6px 8px",borderTop:"1px solid rgba(127,127,127,0.25)",display:"flex",gap:6}}>
            <button onClick={goSetup} style={{fontSize:11,padding:"5px 10px",borderRadius:6}}>Exit</button>
            <span style={{flex:1}}/>
            <span style={{fontSize:10,opacity:0.45,alignSelf:"center"}}>
              all four hands face up · double-dummy is the truth here
            </span>
          </div>
        ) : null}
      </div>
    );
  }

  if(s.mode==="setup"){
    return (
      <div className="br" data-theme={theme} style={{minHeight:"100vh",background:"var(--bg)",padding:14}}>
        <style>{THEME_CSS}</style>
        <OnlineBar net={net}/>
        <div className="app">
          <header>
            <div className="wordmark">BRIDGE</div>
            <div className="toggle">
              {[["casino","Casino"],["blue","Blue"],["red","Red"],["black","Black"],["cream","Cream"]].map(([t,lab])=>(
                <button key={t} className={theme===t?"on":""} onClick={()=>setTheme(t)}>{lab}</button>
              ))}
            </div>
          </header>
          <div className="hint">Standard contract bridge — bid for the contract, then take your tricks.</div>
          <button className="lrn-open-btn" onClick={()=>setShowLearn(true)}>Learn — lessons &amp; practice drills ›</button>
          {/* SOLITAIRE. Every hand face up, you play all four seats, and afterwards it tells you how much of
              your good play you'd have found WITHOUT looking. No opponent, no hidden cards, no points. */}
          <button className="lrn-open-btn" onClick={()=>dispatch({type:"START_SOLITAIRE"})}
            style={{marginTop:6}}>
            Solitaire — play all four hands, face up ›
          </button>
          <Setup s={s} dispatch={apply} onShowRules={()=>setShowRules(true)} onShowGloss={()=>{setGlossTerm(null);setShowGloss(true);}}
            campaign={campaign} onResume={resumeCampaign} onDiscard={discardCampaign}/>
        </div>
        {showRules && <RulesScreen onClose={()=>setShowRules(false)}/>}
        {showGloss && <GlossaryScreen gloss={getGlossary()} focusTerm={glossTerm} onClose={()=>{setShowGloss(false);setGlossTerm(null);}}/>}
        {showLearn && <UIErrorBoundary onClose={()=>setShowLearn(false)}><LearnScreen onClose={()=>setShowLearn(false)}/></UIErrorBoundary>}
      </div>
    );
  }

  const activeController = s.phase==="auction" ? s.turn : (s.phase==="play"? controllerOf(s,s.turn) : null);
  const isHumanActing = activeController!=null && s.brains[activeController]==="human";
  const focus = online ? mySeat : (isHumanActing ? activeController : (focusRef.current<4?focusRef.current:0));
  const multiHuman = s.brains.filter(b=>b==="human").length>1;
  const needReveal = online ? false : (multiHuman && isHumanActing && activeController!==revealSeat);

  const dummySeat = s.dummy;
  const showDummy = s.contract && s.dummyRevealed && dummySeat!=null && dummySeat!==focus;
  const playableSeat = (s.phase==="play" && isHumanActing && !needReveal) ? s.turn : null;
  const legalForPlayable = playableSeat!=null ? new Set(ENG.legalPlays(s.hands[playableSeat], s.trick.length?s.ledSuit:null).map(c=>c.id)) : null;

  const sugBidB  = (s.phase==="auction" && isHumanActing && showHint && !needReveal) ? suggestBidWhy(s, s.turn) : null;
  const sugPlayB = (s.phase==="play" && isHumanActing && showHint && !needReveal) ? suggestPlayWhy(s, s.turn) : null;
  const sugBid  = sugBidB ? sugBidB.call : null;
  const sugPlay = sugPlayB ? sugPlayB.card : null;
  const sugPlayId = sugPlay ? sugPlay.id : null;
  const sugText = teach ? ((sugBidB && sugBidB.text) || (sugPlayB && sugPlayB.text) || "") : "";

  const ct=s.contract;
  const declSide = ct? sideOf(ct.declarer):0;
  const contractBanner = ct ? (()=>{
    const dbl = ct.dbl===4?" XX":ct.dbl===2?" X":"";
    const role = focus===ct.declarer ? "you declare" : focus===s.dummy ? "you are dummy" : sideOf(focus)===declSide ? "your side declares" : "you defend";
    return `${ct.level}${STRAIN_GLYPH[ct.strain]}${dbl} by ${who(s,ct.declarer)} — ${role}`;
  })() : "";

  // Select-then-play: first tap on a legal card selects (lifts) it; a second tap on the same card, or the
  // Play button, commits it. Selection is cleared on every turn/phase change (see the effect above).
  const onCardTap=(card)=>{
    if(playableSeat==null) return;
    if(sel===card.id){ setHint(false); setSel(null); apply({type:"PLAY", player:playableSeat, cardId:card.id}); }
    else setSel(card.id);
  };
  const playSelected=()=>{ if(sel==null||playableSeat==null) return; setHint(false); const id=sel; setSel(null); apply({type:"PLAY", player:playableSeat, cardId:id}); };
  const selCard = sel!=null ? ((s.hands[focus]||[]).find(c=>c.id===sel) || (showDummy?(s.hands[dummySeat]||[]).find(c=>c.id===sel):null)) : null;
  const rubberWon = s.rubberDone;

  const turnText = isHumanActing
    ? (s.phase==="auction" ? "Your bid" : s.phase==="play" ? "Your turn" : "")
    : (s.phase==="scored" ? "" : `${who(s, activeController)} ${s.phase==="auction"?"is bidding":"is thinking"}\u2026`);

  // "Why" teaching box — computed once, reused on both the bid and play screens.
  const teachEl = (showHint && teach && sugText) ? (
    <div className="teachbox">
      <div className="tb-tag">Why</div>
      <div className="tb-body">
        <div className="tb-txt">{linkifyGlossary(sugText, getGlossary(), (term)=>setGlossPop({term, def:getGlossary()[term]}))}</div>
        {glossPop && <div className="tb-def"><b>{glossPop.term}</b> — {glossPop.def} <span className="tb-more" onClick={()=>{setGlossTerm(glossPop.term);setShowGloss(true);}}>full glossary →</span></div>}
      </div>
    </div>
  ) : null;

  // Suggest toggle (lives in the status bar) — only when it's the human's turn and auto-hint is off.
  const hintToggle = (isHumanActing && s.phase!=="scored" && !alwaysOn && tab==="game") ? (
    <button className={"gs-sug"+(hint?" on":"")} onClick={()=>setHint(h=>!h)}>{hint?"Hint \u2713":"Suggest"}</button>
  ) : null;

  return (
    <div className="br" data-theme={theme} style={{height:"100dvh",background:"var(--bg)",display:"flex",flexDirection:"column"}}>
      <style>{THEME_CSS}</style>
      <OnlineBar net={net}/>
      <div className="stage">
        <StatusBar s={s} focus={focus} phase={s.phase} contractText={contractBanner} turnText={turnText}
          onMenu={()=>setMenuOpen(true)} hint={hintToggle}/>

        <div className={"gscreen "+(tab==="talk"?"talk":s.phase)}>
          {tab==="talk" ? (
            <HelpDrawer embedded s={s} focus={focus} gradeStatus={gradeStatus}
              onTapTerm={(t)=>{setGlossTerm(t);setShowGloss(true);}}
              sug={{ text:sugText, label: sugBid?("consider "+callLabel(sugBid)) : (sugPlay?("consider "+sugPlay.rank+SUIT_GLYPH[sugPlay.suit]):"") }}/>
          ) : needReveal ? (
            <RevealGate s={s} seat={activeController} onReveal={()=>setRevealSeat(activeController)}/>
          ) : (s.phase==="scored" && s.result) ? (
            <div className="resultscreen">
              <div className="result">
                <div className={"rhead "+(s.result.made?"made":"down")}>{s.result.head}</div>
                <div className="rdetail">
                  {s.result.detail.join(" · ")}
                  {s.result.honours.length>0 && <><br/>{s.result.honours.join(" · ")}</>}
                  {s.result.gameWon && <><br/><b style={{color:"var(--green)"}}>{SIDE_NAME[s.result.declSide]} win a game!</b></>}
                </div>
                {rubberWon && <div className="rbig">{SIDE_NAME[s.rubberWinner]} take the rubber +{s.result.rubberBonus}</div>}
              </div>
              <ScoreSheet s={s}/>
              <div className="bar">
                {!rubberWon
                  ? <button className="btn primary" onClick={()=>apply({type:"NEXT_DEAL"})}>Next deal</button>
                  : <button className="btn primary" onClick={()=>apply({type:"NEW_RUBBER"})}>New rubber</button>}
                <button className="btn ghost" onClick={()=>setMenuOpen(true)}>Menu</button>
              </div>
            </div>
          ) : s.phase==="auction" ? (
            <div className="bidscreen">
              <SeatStrip s={s} focus={focus}/>
              <div className="bid-elastic">
                <AuctionView s={s}/>
                {teachEl}
              </div>
              <div className="youhand">
                <HandRow hand={s.hands[focus]} label="You"/>
              </div>
              {isHumanActing
                ? <BiddingBox s={s} seat={s.turn} dispatch={apply} suggestion={sugBid}/>
                : <div className="waitbar hint">{turnText}</div>}
            </div>
          ) : (
            <div className="playscreen">
              <div className="contractline">{contractBanner ? <b>{contractBanner}</b> : "Play"}</div>
              <div className="trick-zone"><TrickTable s={s} focus={focus}/></div>
              <div className="hand-dock dummy">
                {showDummy
                  ? (playableSeat===dummySeat
                      ? <SwipeHand hand={s.hands[dummySeat]} label={`Dummy · ${who(s,dummySeat)}`}
                          legalIds={legalForPlayable} sugId={sugPlayId} selId={sel} onPlay={onCardTap}/>
                      : <HandRow hand={s.hands[dummySeat]} label={`Dummy · ${who(s,dummySeat)}`}/>)
                  : <div className="dock-wait lbl2">dummy appears after the opening lead</div>}
              </div>
              <div className="hand-dock you">
                {playableSeat===focus
                  ? <SwipeHand hand={s.hands[focus]} label="You"
                      legalIds={legalForPlayable} sugId={sugPlayId} selId={sel} onPlay={onCardTap}/>
                  : <HandRow hand={s.hands[focus]} label="You"/>}
              </div>
              <div className="playfoot">
                {(sel && selCard)
                  ? <button className="playconfirm" onClick={playSelected}>Play&nbsp;{selCard.rank}<span className={suitColorClass(selCard.suit)}>{SUIT_GLYPH[selCard.suit]}</span>&nbsp;▶</button>
                  : playableSeat!=null
                    ? <div className="playhint hint">Tap a card to select, tap again to play{sugPlayId?" · green is suggested":""}</div>
                    : <div className="playhint hint">{turnText}</div>}
              </div>
              {teachEl && <div className="play-why">{teachEl}</div>}
            </div>
          )}
        </div>

        <TabBar tab={tab} onTab={setTab} phase={s.phase} yourTurn={isHumanActing && s.phase!=="scored"}/>
      </div>

      {menuOpen && (
        <div className="overlay" onClick={()=>setMenuOpen(false)}>
          <div className="sheetmodal" onClick={(e)=>e.stopPropagation()}>
            <div className="smhead"><b className="dl-title">MENU</b><button className="dl-x" onClick={()=>setMenuOpen(false)}>×</button></div>
            <div className="smbody menu">
              <div className="menu-row"><span className="lbl2">Theme</span>
                <div className="toggle">
                  {[["casino","C"],["blue","B"],["red","R"],["black","K"],["cream","W"]].map(([t,lab])=>(
                    <button key={t} className={theme===t?"on":""} onClick={()=>setTheme(t)}>{lab}</button>
                  ))}
                </div>
              </div>
              <div className="menu-row"><span className="lbl2">Teaching</span>
                <button className={"btn ghost"+(teach?" on":"")} onClick={()=>setTeach(t=>!t)}>{teach?"On \u2713":"Off"}</button></div>
              <div className="menu-row"><span className="lbl2">Auto-hint</span>
                <button className={"btn ghost"+(alwaysOn?" on":"")} onClick={()=>setAlwaysOn(a=>!a)}>{alwaysOn?"On \u2713":"Off"}</button></div>
              <ScoreSheet s={s}/>
              <div className="menu-acts">
                <button className="btn ghost" onClick={()=>{setMenuOpen(false);setShowRules(true);}}>Rules</button>
                <button className="btn ghost" onClick={()=>{setMenuOpen(false);setGlossTerm(null);setShowGloss(true);}}>Glossary</button>
                <button className="btn ghost" onClick={()=>{setMenuOpen(false);setShowLearn(true);}}>Learn</button>
                <button className="btn ghost" onClick={()=>{setMenuOpen(false);goSetup();}}>Setup</button>
              </div>
            </div>
          </div>
        </div>
      )}
      {showRules && <RulesScreen onClose={()=>setShowRules(false)}/>}
      {showGloss && <GlossaryScreen gloss={getGlossary()} focusTerm={glossTerm} onClose={()=>{setShowGloss(false);setGlossTerm(null);}}/>}
      {showLearn && <UIErrorBoundary onClose={()=>setShowLearn(false)}><LearnScreen onClose={()=>setShowLearn(false)}/></UIErrorBoundary>}
    </div>
  );
}
