//#region gen (auto — removed when bundled to a single bridge.jsx)
import { installDeclPlay } from "./declplay.js";
import { who } from "../state/personas.js";
import { C } from "../ui/theme.js";
//#endregion gen

function makeGenerator({ ENG, AUC, BID, PLY }) {
  const PARTNER = 2, LHO = 1, RHO = 3, SOUTH = 0;

  function deal() {
    const d = ENG.shuffle(ENG.makeDeck());
    return [d.slice(0, 13), d.slice(13, 26), d.slice(26, 39), d.slice(39, 52)];
  }

  // ---- parse the auction-so-far into the facts the reach predicates need ----
  function parse(calls, dealer) {
    const info = AUC.auctionInfo(calls, dealer);
    const firstBid = calls.find((c) => c.k === "B") || null;
    const opener = firstBid ? firstBid.by : -1;
    const bidsBy = (seat) => calls.filter((c) => c.by === seat);
    const lastBidBy = (seat) => {
      const b = bidsBy(seat).filter((c) => c.k === "B");
      return b.length ? b[b.length - 1] : null;
    };
    const southBids = bidsBy(SOUTH);
    const partnerBids = bidsBy(PARTNER).filter((c) => c.k === "B");
    const southRealBids = southBids.filter((c) => c.k === "B");
    const southSuits = new Set(southRealBids.map((b) => b.strain));
    const rank = { C: 0, D: 1, H: 2, S: 3 }; // bidding rank for reverse detection
    // opener reversed = two suit bids, the SECOND a genuinely new suit (not South's,
    // not a rebid) ranking higher than the first, shown at the 2 level.
    const isReverse = (bids) => {
      const s = bids.filter((b) => b.k === "B" && b.strain !== "NT");
      if (s.length < 2) return false;
      const a = s[0], b = s[1];
      return a.strain in rank && b.strain in rank && rank[b.strain] > rank[a.strain] &&
        b.level === a.level + 1 && a.level === 1 &&
        b.strain !== a.strain && !southSuits.has(b.strain); // new suit, not a raise of South
    };
    // count trailing passes right now
    let consec = 0;
    for (let i = calls.length - 1; i >= 0; i--) { if (calls[i].k === "P") consec++; else break; }
    return {
      calls, info, opener, firstBid,
      allPass: calls.length > 0 && calls.every((c) => c.k === "P"),
      southBidCount: southRealBids.length,
      southHasNoBid: southBids.every((c) => c.k !== "B"),
      southFirstBid: southRealBids[0] || null,
      southOpeningIsMajor: !!(southRealBids[0] && southRealBids[0].level === 1 &&
        (southRealBids[0].strain === "H" || southRealBids[0].strain === "S")),
      southPassCount: southBids.filter((c) => c.k === "P").length,
      partnerBidCount: partnerBids.length,
      partnerBids,
      partnerFirstBid: partnerBids[0] || null,
      partnerReversed: isReverse(partnerBids),
      partnerLastBid: lastBidBy(PARTNER),
      rhoLastBid: lastBidBy(RHO),
      lhoLastBid: lastBidBy(LHO),
      partnerLastCall: bidsBy(PARTNER).slice(-1)[0] || null,
      rhoLastCall: bidsBy(RHO).slice(-1)[0] || null,
      lhoLastCall: bidsBy(LHO).slice(-1)[0] || null,
      consecPass: consec,
      lastBid: info.lastBid, lastBidder: info.lastBidder,
    };
  }

  const isMajor = (s) => s === "H" || s === "S";
  const isMinor = (s) => s === "C" || s === "D";
  const isSuit = (s) => s === "C" || s === "D" || s === "H" || s === "S";

  // ---- reach(): is South facing the lesson's decision right now? ----
  // Each entry fixes the dealer (relative to South=0) so the auction shape
  // is predictable, and tests the parsed auction.
  const POS = {
    "open":      { dealer: 0, reach: (p) => p.calls.length === 0 },
    "open-3rd":  { dealer: 2, reach: (p) => p.calls.length === 2 && p.allPass },
    "open-4th":  { dealer: 1, reach: (p) => p.calls.length === 3 && p.allPass },

    "resp-maj":  { dealer: 2, reach: (p) => p.southHasNoBid && p.partnerLastBid &&
                     p.partnerLastBid.level === 1 && isMajor(p.partnerLastBid.strain) &&
                     p.partnerBidCount === 1 && p.opener === PARTNER },
    "resp-min":  { dealer: 2, reach: (p) => p.southHasNoBid && p.partnerLastBid &&
                     p.partnerLastBid.level === 1 && isMinor(p.partnerLastBid.strain) &&
                     p.partnerBidCount === 1 && p.opener === PARTNER },
    "resp-nt":   { dealer: 2, reach: (p) => p.southHasNoBid && p.partnerLastBid &&
                     p.partnerLastBid.strain === "NT" && p.partnerLastBid.level <= 2 &&
                     p.partnerBidCount === 1 && p.opener === PARTNER },
    "resp-2c":   { dealer: 2, reach: (p) => p.southHasNoBid && p.partnerLastBid &&
                     p.partnerLastBid.level === 2 && p.partnerLastBid.strain === "C" &&
                     p.opener === PARTNER },
    "resp-weak": { dealer: 2, reach: (p) => p.southHasNoBid && p.partnerLastBid &&
                     p.opener === PARTNER && isSuit(p.partnerLastBid.strain) &&
                     ((p.partnerLastBid.level === 2 && p.partnerLastBid.strain !== "C") ||
                      p.partnerLastBid.level >= 3) },

    "op-rebid":  { dealer: 0, reach: (p) => p.southBidCount === 1 && p.opener === SOUTH &&
                     p.partnerBidCount >= 1 },
    "rp-rebid":  { dealer: 2, reach: (p) => p.southBidCount === 1 && p.opener === PARTNER &&
                     p.partnerBidCount >= 2 },

    "compete":   { dealer: 3, reach: (p) => p.southHasNoBid && p.opener === RHO &&
                     p.calls.length === 1 && p.rhoLastBid && p.rhoLastBid.level === 1 &&
                     isSuit(p.rhoLastBid.strain) },
    "advance":   { dealer: 1, reach: (p) => p.southHasNoBid && p.opener === LHO &&
                     p.partnerLastCall && (p.partnerLastCall.k === "B" || p.partnerLastCall.k === "D") &&
                     p.calls.length >= 2 },
    // partner opened, RHO overcalled, South acts -> the negative-double seat
    "neg-dbl":   { dealer: 2, reach: (p) => p.southHasNoBid && p.opener === PARTNER &&
                     p.partnerLastBid && p.partnerLastBid.level === 1 && isSuit(p.partnerLastBid.strain) &&
                     p.rhoLastBid && isSuit(p.rhoLastBid.strain) },
    "balance":   { dealer: 1, reach: (p) => p.southHasNoBid && p.info.opened &&
                     p.consecPass === 2 && p.lastBid && p.lastBid.level <= 2 },
    // opponent opened, passed to partner who balanced, now South responds
    "resp-balance": { dealer: 3, reach: (p) => p.southBidCount === 0 && p.southPassCount >= 1 &&
                       p.opener !== PARTNER && p.opener !== SOUTH && p.partnerLastCall &&
                       (p.partnerLastCall.k === "B" || p.partnerLastCall.k === "D") },
    // RHO opens 1NT, South acts directly (Cappelletti)
    "vs-1nt":    { dealer: 3, reach: (p) => p.southHasNoBid && p.opener === RHO && p.calls.length === 1 &&
                     p.rhoLastBid && p.rhoLastBid.level === 1 && p.rhoLastBid.strain === "NT" },
    // partner opens 1-major, RHO makes a takeout double, South acts (Jordan)
    "resp-vs-dbl": { dealer: 2, reach: (p) => p.southHasNoBid && p.opener === PARTNER &&
                     p.partnerLastBid && p.partnerLastBid.level === 1 && isMajor(p.partnerLastBid.strain) &&
                     p.rhoLastCall && p.rhoLastCall.k === "D" },
    // South opens 1-suit, LHO overcalls, partner negative-doubles, South answers
    "op-negdbl": { dealer: 0, reach: (p) => p.southBidCount === 1 && p.opener === SOUTH &&
                     p.partnerLastCall && p.partnerLastCall.k === "D" &&
                     p.lhoLastBid && p.lhoLastBid.strain !== "NT" },
    // South opens, responder uses fourth-suit-forcing, South answers (South's 3rd bid)
    "op-fsf": { dealer: 0, reach: (p) => {
        if(p.opener !== SOUTH || p.southBidCount !== 2) return false;
        const pl = p.partnerLastBid;
        if(!pl || pl.strain === "NT" || pl.level < 2) return false;
        const ours = p.calls.filter(c => c.k === "B" && c.strain !== "NT" && (c.by === SOUTH || c.by === PARTNER));
        const before = new Set(ours.slice(0, -1).map(c => c.strain));
        return before.size === 3 && !before.has(pl.strain);
      } },
    // partner opened 1NT, RHO overcalled a suit, South's first response (systems off).
    "resp-1nt-interf": { dealer: PARTNER, reach: (p) =>
        p.opener === PARTNER && p.partnerFirstBid &&
        p.partnerFirstBid.level === 1 && p.partnerFirstBid.strain === "NT" &&
        p.southBidCount === 0 && p.rhoLastBid && p.rhoLastBid.strain !== "NT" },
    // partner opened one-of-a-suit, South responded a 1-level suit, opener rebid, South's
    // 2nd bid — the spot for a responder reverse (higher second suit, game-forcing).
    "resp-reverse": { dealer: PARTNER, reach: (p) =>
        p.opener === PARTNER && p.partnerFirstBid &&
        p.partnerFirstBid.level === 1 && p.partnerFirstBid.strain !== "NT" &&
        p.southFirstBid && p.southFirstBid.level === 1 && p.southFirstBid.strain !== "NT" &&
        p.southBidCount === 1 && p.partnerBidCount >= 2 },
  };

  // ---- per-lesson refinements so drills are on-concept, not just legal ----
  // clean:  no opponent has bid before South acts (convention is "on")
  // partnerAction: require partner's last call to be a bid ("B") or double ("D")
  // answerOk(answer, ev, p): the drill must show this action to count
  const cue = (a, e, p) => a.k === "B" && p.rhoLastBid && a.level === 2 && a.strain === p.rhoLastBid.strain;
  const CFG = {
    "r-stayman":  { clean: true, answerOk: (a) => a.k === "B" && a.level === 2 && a.strain === "C" },
    "r-transfer": { clean: true, answerOk: (a) => a.k === "B" && a.level === 2 && (a.strain === "D" || a.strain === "H") },
    "r-2sminor":  { clean: true, answerOk: (a) => a.k === "B" && a.level === 2 && a.strain === "S" },
    "r-ntinvite": { clean: true },
    "r-gerber":   { clean: true },
    "r-higher-nt":{ clean: true },
    "rm-min": { clean: true }, "rm-inv": { clean: true }, "rm-gf": { clean: true },
    "rn-min": { clean: true }, "rn-inv": { clean: true }, "rn-gf": { clean: true },
    "rn-slam": { clean: true },
    "r-weak": { clean: true },
    "c-respover":   { partnerAction: "B" },
    "d-resptakeout":{ partnerAction: "D" },
    "d-takeout":    { answerOk: (a) => a.k === "D" },
    "c-michaels":   { answerOk: cue },
    "c-unusual":    { answerOk: (a) => a.k === "B" && a.level === 2 && a.strain === "NT" },
    "c-jumpover":   { answerOk: (a, e, p) => a.k === "B" && isSuit(a.strain) && p.rhoLastBid &&
                        AUC.bidVal(a) >= AUC.bidVal({ level: 2, strain: p.rhoLastBid.strain }) },
    "c-over1":      { answerOk: (a) => a.k === "B" || a.k === "D" },
    "n-what":       { answerOk: (a) => a.k === "D" },
    "ro-dbl":       { answerOk: (a) => a.k === "D" || (a.k === "B") },
    "b-what":       { answerOk: (a) => a.k !== "P" },
    "b-nt":         { answerOk: (a) => a.k === "B" && a.strain === "NT" },
    // ---- B: sharper auction targeting (uses `also`, checked at reach time) ----
    // opener rebids after partner's LIMIT RAISE (jump to 3 of opener's major)
    "or-limit":  { also: (p) => p.southOpeningIsMajor && p.partnerLastBid &&
                     p.partnerLastBid.level === 3 && p.partnerLastBid.strain === p.southFirstBid.strain },
    // responder's rebid after opener REVERSED (over a 1-level response, to avoid
    // the bot's unfinished 2-over-1 handling)
    "rv-respafter": { also: (p) => p.partnerReversed && p.southFirstBid && p.southFirstBid.level === 1 },
    // responder's rebid after a 2-over-1 (first response was a 2-level new suit)
    "ra-2over1": { also: (p) => p.southFirstBid && p.southFirstBid.level === 2 &&
                     ["C","D","H","S"].includes(p.southFirstBid.strain) },
    // new conventions
    "c-capp":    { answerOk: (a) => a.k === "D" || (a.k === "B" && a.level === 2) },
    "d-jordan":  { answerOk: (a) => (a.k === "B" && a.level === 2 && a.strain === "NT") || a.k === "R" },
    "n-resp":    { answerOk: (a) => a.k === "B" },
    "fsf-what":  { clean: true, answerOk: (a, e, p) => {
                     if(a.k !== "B" || a.strain === "NT" || a.level < 2) return false;
                     const ours = new Set(p.calls.filter(c => c.k === "B" && c.strain !== "NT" && (c.by === 0 || c.by === 2)).map(c => c.strain));
                     return ours.size === 3 && !ours.has(a.strain);
                   } },
    "fsf-opener": { clean: true, answerOk: (a) => a.k === "B" },
    // over 1NT interference the teachable answer is the cuebid of the opponents' suit
    "r-ntinterf": { answerOk: (a, ev, p) => a.k === "B" && p.rhoLastBid && a.strain === p.rhoLastBid.strain },
    // responder reverse: partner opened a minor (so majors are unbid); answer is a 2-level
    // bid of a suit ranking higher than South's first response
    "rv-responder": { also: (p) => isMinor(p.partnerFirstBid.strain),
        answerOk: (a, ev, p) => { const RK = { C:0, D:1, H:2, S:3 };
          return a.k === "B" && a.level === 2 && a.strain !== "NT" &&
                 p.southFirstBid && RK[a.strain] > RK[p.southFirstBid.strain]; } } };

  // ---- target(): does South's hand fit THIS lesson (not just this position)? ----
  // Keeps drills on-topic. Answer still comes from chooseBid regardless.
  const has4Major = (ev) => ev.len.H >= 4 || ev.len.S >= 4;
  const has5Major = (ev) => ev.len.H >= 5 || ev.len.S >= 5;
  const longMinor = (ev) => Math.max(ev.len.C, ev.len.D) >= 6;
  const TARGET = {
    // responses to a major
    "rm-min": (e) => e.hcp >= 6 && e.hcp <= 9,
    "rm-inv": (e) => e.hcp >= 10 && e.hcp <= 11,
    "rm-gf":  (e) => e.hcp >= 12,
    "rm-rebid": () => true,
    // responses to a minor
    "rn-min": (e) => e.hcp >= 6 && e.hcp <= 10,
    "rn-inv": (e) => e.hcp >= 10 && e.hcp <= 12,
    "rn-gf":  (e) => e.hcp >= 13,
    // responses to NT
    "r-stayman":  (e) => has4Major(e) && !has5Major(e) && e.hcp >= 8,
    "r-transfer": (e) => has5Major(e),
    "r-2sminor":  (e) => longMinor(e) && e.hcp <= 7,
    "r-ntinvite": (e) => e.hcp >= 8 && e.hcp <= 9,
    "r-gerber":   (e) => e.hcp >= 15,
    "r-higher-nt":() => true,
    // strong / weak responses
    "r-2c":   () => true,
    "r-weak": () => true,
    // opener rebids (South's opening hand strength)
    "or-min": (e) => e.tp >= 12 && e.tp <= 15,
    "or-inv": (e) => e.tp >= 16 && e.tp <= 18,
    "or-gf":  (e) => e.tp >= 19,
    "rv-opener": (e) => e.tp >= 16,
    // responder's later rebids
    "ra-weak": (e) => e.hcp >= 6 && e.hcp <= 11,
    "ra-forcing": (e) => e.hcp >= 12,
    "ra-2over1": (e) => e.hcp >= 10,
    "c-capp": () => true,
    "d-jordan": (e) => e.hcp >= 10,
    "n-resp": () => true,
    "fsf-what": (e) => e.hcp >= 12,
    "fsf-opener": () => true,
    "rn-slam": (e) => e.hcp >= 17,
    "or-2c": (e) => e.hcp >= 22,
    // responding to partner's balance: a genuine "act or discount" decision needs some values
    "b-resp": (e) => e.hcp >= 5 && e.hcp <= 15,
    // 1NT-interference drill: a game-forcing hand with a 4-card major (no 5-card major) cuebids
    "r-ntinterf": (e) => e.hcp >= 10 && (e.len.H === 4 || e.len.S === 4) && e.len.H < 5 && e.len.S < 5,
    // responder reverse: a game-forcing 4-4 majors hand responds up the line, then reverses
    "rv-responder": (e) => e.hcp >= 12 && e.hcp <= 15 && e.len.H >= 4 && e.len.S >= 4,
    // competitive
    "c-over1": (e) => e.hcp >= 8 && e.hcp <= 17,
    "c-over2": (e) => e.hcp >= 10 && e.hcp <= 17,
    "c-jumpover": (e) => e.hcp >= 5 && e.hcp <= 10,
    "c-michaels": () => true,
    "c-unusual": () => true,
    "d-takeout": (e) => e.hcp >= 12,
    "c-respover": () => true,
    "d-resptakeout": () => true,
    "n-what": () => true,
    "ro-dbl": () => true,
    "b-what": () => true,
    // openings (single round) already keyed by their own predicates in the lab,
    // but provide light targets so mixed generation stays on-topic:
    "o-1nt":   (e) => e.balanced && e.hcp >= 13 && e.hcp <= 19,
    "o-highnt":(e) => e.balanced && e.hcp >= 20,
    "o-suit":  (e) => e.tp >= 13 && e.tp <= 21 && !e.balanced,
    "o-whichminor": (e) => e.len.S < 5 && e.len.H < 5 && e.len.D < 5 && e.len.C < 5,
    "o-third":  (e) => e.hcp >= 9 && e.hcp <= 12,
    "o-fourth": (e) => e.hcp + e.len.S >= 13,
    "o-weak2":  (e) => e.hcp >= 5 && e.hcp <= 11,
    "o-preempt":(e) => e.hcp <= 10,
    "o-2c":     (e) => e.hcp >= 20 || e.tp >= 22,
  };

  // ---- distractor choices: always include the truth + Pass + nearby legals ----
  function buildChoices(answer, calls, dealer) {
    const key = (c) => c.k === "B" ? `B${c.level}${c.strain}` : c.k;
    const legal = [];
    const push = (c) => { if (AUC.callLegal(c, calls, dealer)) legal.push(c); };
    push({ k: "P" });
    push({ k: "D" });
    push({ k: "R" });
    for (let lvl = 1; lvl <= 7; lvl++) for (const st of ENG.STRAINS) push({ k: "B", level: lvl, strain: st });

    const answerKey = key(answer);
    // Reference bid-value for proximity scoring. When the answer is a bid, anchor on it.
    // When the answer is Pass/Double/Redouble there is no bid to anchor on, so anchor on
    // the cheapest realistic action (one step above the last bid) — otherwise every bid
    // scores flat and absurd overbids (7D vs a passed-out auction) slip in as distractors.
    const lastV = AUC.bidVal(AUC.auctionInfo(calls, dealer).lastBid || { k: "B", level: 0, strain: "C" });
    const av = answer.k === "B" ? AUC.bidVal(answer) : lastV + 5; // +5 ≈ one level up
    const scored = legal
      .filter((c) => key(c) !== answerKey)
      .map((c) => {
        let s = 0;
        if (c.k === "P") s = 2;
        else if (c.k === "D" || c.k === "R") s = 6;
        else {
          const d = Math.abs(AUC.bidVal(c) - av);
          s = d <= 5 ? 1 : d <= 10 ? 3 : 8; // within a level / two levels of the anchor
          if (answer.k === "B" && c.strain === answer.strain) s -= 1;
          if (answer.k !== "B") s += 1; // slightly favour Pass/Dbl themselves as distractors
        }
        return { c, s: s + Math.random() * 0.5 };
      })
      .sort((a, b) => a.s - b.s)
      .slice(0, 4)
      .map((x) => x.c);

    const all = [answer, ...scored];
    // dedupe + shuffle
    const seen = new Set(), out = [];
    for (const c of ENG.shuffle(all)) { const k = key(c); if (!seen.has(k)) { seen.add(k); out.push(c); } }
    return out.slice(0, 5);
  }

  // ---- D: evaluation drills (no auction; answer computed from the hand) ----
  const quickTricks = (ev) => {
    let qt = 0;
    for (const s of ["S", "H", "D", "C"]) {
      const r = ev.by[s], a = r.includes("A"), k = r.includes("K"), q = r.includes("Q"), l = ev.len[s];
      if (a && k) qt += 2; else if (a && q) qt += 1.5; else if (a) qt += 1;
      else if (k && q) qt += 1; else if (k && l >= 2) qt += 0.5;
    }
    return qt;
  };
  const shapeClass = (ev) => {
    const [a, b, c] = ev.shape; // sorted desc
    if (ev.balanced) return "Balanced";
    if (a >= 6 && b <= 3) return "One-suiter";
    if (a === 4 && b === 4 && c === 4) return "Three-suiter";
    if (a === 5 && b === 4 && c === 4) return "Three-suiter";
    if (a >= 5 && b >= 4) return "Two-suiter";
    return "One-suiter";
  };
  const numericChoices = (ans, spread = 3) => {
    const set = new Set([ans]);
    let d = 1;
    while (set.size < 5) { if (ans - d >= 0) set.add(ans - d); set.add(ans + d); d++; if (d > spread + 4) break; }
    return ENG.shuffle(Array.from(set)).slice(0, 5);   // shuffled — don't sort (that centers the answer)
  };
  function ruleOf20Sum(ev) {
    const L = [ev.len.S, ev.len.H, ev.len.D, ev.len.C].sort((a, b) => b - a);
    return ev.hcp + L[0] + L[1];
  }

  const EVAL = {
    hcp: (ev) => ({
      prompt: "How many high-card points?",
      answerLabel: String(ev.hcp),
      why: `A=4, K=3, Q=2, J=1 \u2014 this hand totals ${ev.hcp} HCP.`,
      choices: numericChoices(ev.hcp).map((n) => ({ label: String(n), correct: n === ev.hcp })),
    }),
    tp: (ev) => ({
      prompt: "How many total points (HCP + long-suit points)?",
      answerLabel: String(ev.tp),
      why: `${ev.hcp} HCP plus ${ev.tp - ev.hcp} for length (one per card past the fourth in a suit) = ${ev.tp} total points.`,
      choices: numericChoices(ev.tp).map((n) => ({ label: String(n), correct: n === ev.tp })),
    }),
    r20: (ev) => {
      const open = ev.tp >= 13 || (ev.tp === 12 && ruleOf20Sum(ev) >= 20);
      return {
        prompt: "First or second seat \u2014 open or pass?",
        answerLabel: open ? "Open" : "Pass",
        why: open
          ? `${ev.tp} total points${ev.tp < 13 ? `, and HCP + your two longest suits = ${ruleOf20Sum(ev)} (\u2265 20)` : ""} \u2014 worth an opening bid.`
          : `Only ${ev.tp} total points and HCP + two longest suits = ${ruleOf20Sum(ev)} (< 20) \u2014 pass.`,
        choices: ENG.shuffle([{ label: "Open", correct: open }, { label: "Pass", correct: !open }]),
      };
    },
    shape: (ev) => {
      const ans = shapeClass(ev);
      return {
        prompt: "Classify this hand's shape.",
        answerLabel: ans,
        why: `Distribution ${ev.shape.join("-")} \u2014 ${ans.toLowerCase()}.`,
        choices: ENG.shuffle(["Balanced", "One-suiter", "Two-suiter", "Three-suiter"]).map((l) => ({ label: l, correct: l === ans })),
      };
    },
    qt: (ev) => {
      const qt = quickTricks(ev);
      const fmt = (n) => (Number.isInteger(n) ? String(n) : n.toFixed(1));
      const opts = new Set([qt]); let d = 0.5;
      while (opts.size < 5) { if (qt - d >= 0) opts.add(qt - d); opts.add(qt + d); d += 0.5; if (d > 3) break; }
      return {
        prompt: "How many quick tricks?",
        answerLabel: fmt(qt),
        why: `Quick tricks: AK=2, AQ=1\u00bd, A=1, KQ=1, Kx=\u00bd \u2014 this hand has ${fmt(qt)}.`,
        choices: ENG.shuffle(Array.from(opts)).slice(0, 5).map((n) => ({ label: fmt(n), correct: n === qt })),
      };
    },
  };
  function generateEval(lesson) {
    const q = EVAL[lesson.drill.q];
    if (!q) return { ok: false, reason: "unknown eval question: " + lesson.drill.q };
    const hand = deal()[0];
    const ev = BID.evalHand(hand);
    return { ok: true, kind: "eval", lesson: lesson.id, southHand: hand, ev, ...q(ev) };
  }

  // ---- D2: declarer-play COUNT drills (deterministic; answer computed, not from a heuristic
  // play engine). PLY plays declarer only mechanically, so a "correct card" can't be read off
  // it — but "top tricks" is a pure function of the two hands. Verified against Bernard Magee's
  // six worked examples + invariants (sum == total, per-suit <= longer holding). ----
  const TT_ORDER = ["A", "K", "Q", "J", "10", "9", "8", "7", "6", "5", "4", "3", "2"];
  // Sure winners in ONE suit given each hand's ranks: the unbroken run of top cards you hold,
  // capped by your longer holding; if that run drops every outstanding card, the whole longer
  // holding runs (the "AJ543 opposite KQ92 = 5" case).
  function topTricksSuit(declRanks, dummyRanks) {
    const held = new Set([...declRanks, ...dummyRanks]);
    const lenD = declRanks.length, lenN = dummyRanks.length;
    const longer = Math.max(lenD, lenN);
    if (longer === 0) return 0;
    const oppCount = 13 - (lenD + lenN);
    let solid = 0;
    for (const r of TT_ORDER) { if (held.has(r)) solid++; else break; }
    if (oppCount <= solid) return longer;   // your run exhausts the defenders -> long cards cash
    return Math.min(solid, longer);
  }
  function topTricks(decl, dummy) {
    const bySuit = (h) => { const b = { S: [], H: [], D: [], C: [] }; for (const c of h) b[c.suit].push(c.rank); return b; };
    const d = bySuit(decl), n = bySuit(dummy);
    let t = 0; const per = {};
    for (const s of ["S", "H", "D", "C"]) { per[s] = topTricksSuit(d[s], n[s]); t += per[s]; }
    return { total: t, per };
  }
  // Deal a realistic declarer+dummy pair (partners, so no overlap) for a counting drill:
  // no freak-long combined suit, a sensible combined count, and a teachable top-trick band.
  function dealDeclDummy() {
    for (let t = 0; t < 5000; t++) {
      const h = deal();
      const decl = h[0], dummy = h[2];
      const cl = { S: 0, H: 0, D: 0, C: 0 };
      for (const c of [...decl, ...dummy]) cl[c.suit]++;
      if (["S", "H", "D", "C"].some((s) => cl[s] > 7)) continue;   // no absurd combined length
      const tt = topTricks(decl, dummy);
      if (tt.total < 3 || tt.total > 12) continue;                 // keep it in a teachable band
      const hcp = BID.evalHand(decl).hcp + BID.evalHand(dummy).hcp;
      if (hcp < 20) continue;                                      // looks like a real contract
      return { decl, dummy, tt, hcp };
    }
    return null;
  }
  function generateDeclCount(lesson) {
    const D = dealDeclDummy();
    if (!D) return { ok: false, reason: "no suitable declarer/dummy deal" };
    const { decl, dummy, tt } = D;
    const breakdown = ["S", "H", "D", "C"].filter((s) => tt.per[s])
      .map((s) => `${tt.per[s]} in ${suitWord(s)}`).join(", ") || "none";
    if (lesson.drill.q === "needtricks") {
      const need = Math.max(0, 9 - tt.total);
      return {
        ok: true, kind: "declcount", lesson: lesson.id, declHand: decl, dummyHand: dummy, contractLabel: "3NT",
        prompt: "You are declarer in 3NT. How many more tricks must you develop?",
        answerLabel: String(need),
        why: `3NT needs nine tricks and you have ${tt.total} on top (${breakdown}), so establishment must find ${need} more${need ? " \u2014 through high cards, length, or a finesse" : ", meaning the contract is already there"}.`,
        choices: numericChoices(need, 2).map((n) => ({ label: String(n), correct: n === need })),
      };
    }
    // default: raw top-trick count
    const ans = tt.total;
    return {
      ok: true, kind: "declcount", lesson: lesson.id, declHand: decl, dummyHand: dummy,
      prompt: "How many top tricks (sure winners) do the two hands hold?",
      answerLabel: String(ans),
      why: `Counting sure winners suit by suit \u2014 ${breakdown} \u2014 gives ${ans} top trick${ans === 1 ? "" : "s"} you can cash without losing the lead.`,
      choices: numericChoices(ans).map((n) => ({ label: String(n), correct: n === ans })),
    };
  }

  // ---- E: concept / judgment drills (rule-keyed multiple choice) ----
  // These lessons have no single "bot bid" as an answer, so instead of forcing an auction
  // drill the answer key is an explicit, inspectable rule. Some are LIVE (built on a real
  // bot auction, e.g. takeout-vs-penalty); others draw from a small curated bank of standard
  // doctrine (paraphrased, original wording). Choices carry {label, correct}, exactly like
  // the eval kind, so the UI renders them the same way.
  const GLY = { S: "\u2660", H: "\u2665", D: "\u2666", C: "\u2663", NT: "NT" };
  const shuffleChoices = (opts, correctLabel) =>
    ENG.shuffle(opts.map((label) => ({ label, correct: label === correctLabel })));

  // Per SAYC: a double of a partscore is takeout; a double of game-or-higher (or their
  // freely-bid 3NT) is penalty. This is the crisp rule the d-penalty lesson teaches.
  function doubleIsTakeout(lastBid) {
    if (!lastBid || lastBid.k !== "B") return null;
    if (lastBid.strain === "NT") return lastBid.level < 3;   // 3NT+ = penalty
    const gameLevel = isMajor(lastBid.strain) ? 4 : (isMinor(lastBid.strain) ? 5 : 4);
    return lastBid.level < gameLevel;                         // below game = takeout
  }

  const CONCEPT = {
    // d-penalty — CONSTRUCTED, balanced 50/50: the opponents settle in a partscore (double
    // = takeout) or reach game / 3NT (double = penalty). The answer is keyed by the same
    // doubleIsTakeout rule so there is a single source of truth. South is always on turn
    // facing the opponents' final bid.
    "penalty": () => {
      const wantPenalty = Math.random() < 0.5;
      const openSuit = ENG.shuffle(["S", "H", "D", "C"])[0];
      let lastBid;
      if (wantPenalty) {
        const useNT = Math.random() < 0.35;
        lastBid = useNT ? { k: "B", level: 3, strain: "NT" }
                        : { k: "B", level: isMajor(openSuit) ? 4 : 5, strain: openSuit };
      } else {
        lastBid = { k: "B", level: (Math.random() < 0.4 ? 3 : 2), strain: openSuit }; // partscore raise
      }
      const calls = [{ k: "B", level: 1, strain: openSuit, by: LHO }, { k: "P", by: PARTNER }, { ...lastBid, by: RHO }];
      const takeout = doubleIsTakeout(lastBid);
      const ans = takeout ? "Takeout" : "Penalty";
      const ct = lastBid.level + GLY[lastBid.strain];
      return {
        calls, dealer: LHO,
        prompt: `The opponents have reached ${ct}. If you double now, is it takeout or penalty?`,
        answerLabel: ans,
        why: takeout
          ? `${ct} is a partscore, so a double here is takeout \u2014 it asks partner to pick a suit, showing values and support for the unbid suits.`
          : `${ct} is ${lastBid.strain === "NT" ? "their 3NT" : "game"}, so a double here is penalty \u2014 partner can't read it as takeout, so it says you expect to defeat the contract.`,
        choices: shuffleChoices(["Takeout", "Penalty"], ans),
      };
    },

    // c-balancetwo — CONSTRUCTED: is a 2NT bid Unusual (direct) or natural (balancing)?
    "balance2nt": () => {
      const unusual = Math.random() < 0.5;
      const openSuit = ENG.shuffle(["H", "S", "D", "C"])[0];
      const ans = unusual ? "Unusual (two-suiter)" : "Natural (19\u201321 balanced)";
      const calls = unusual
        ? [{ k: "B", level: 1, strain: openSuit, by: RHO }, { k: "B", level: 2, strain: "NT", by: SOUTH }]
        : [{ k: "B", level: 1, strain: openSuit, by: LHO }, { k: "P", by: PARTNER }, { k: "P", by: RHO }, { k: "B", level: 2, strain: "NT", by: SOUTH }];
      return {
        calls, dealer: unusual ? RHO : LHO,
        prompt: "Your 2NT here \u2014 Unusual or natural?",
        answerLabel: ans,
        why: unusual
          ? "A jump to 2NT directly over their opening is Unusual: five or more in the two lowest unbid suits (here, the minors), not a strong balanced hand."
          : "In the passout seat the opening was passed to you, so 2NT is not Unusual \u2014 by common agreement it is natural: a strong balanced hand, about 19\u201321. Confirm the meaning with your partner.",
        choices: shuffleChoices(["Unusual (two-suiter)", "Natural (19\u201321 balanced)"], ans),
      };
    },

    // s-choose — curated: match the slam tool to the doubt.
    "slamtool": () => {
      const BANK = [
        { s: "You and partner have found a big spade fit and slam is in the air. Your only worry is whether you're off two aces.", a: "Blackwood 4NT", why: "A suit fit is set and the doubt is ace count, so Blackwood asks partner directly how many aces they hold \u2014 keeping you out of a slam missing two." },
        { s: "You hold a balanced 18 opposite partner's balanced notrump opening. There's no suit fit; the only question is whether the combined count is enough.", a: "Quantitative 4NT", why: "For a notrump slam decided by points with no suit fit, a raise to 4NT is quantitative \u2014 it invites 6NT, and partner passes minimum or accepts with a maximum." },
        { s: "You have a heart fit and slam values, but a small doubleton in clubs worries you \u2014 not the ace count.", a: "Control bids (cuebidding)", why: "When a specific unguarded side suit is the worry rather than the number of aces, cuebid your controls up the line so partner can tell you whether the danger suit is covered." },
        { s: "You've agreed diamonds with slam interest and you're happy about side-suit controls, but you must check you aren't off two aces.", a: "Blackwood 4NT", why: "The trump fit is set and the only doubt is aces, so Blackwood is the right tool." },
        { s: "You have a spade fit and worry specifically that both minors might be wide open \u2014 the ace count isn't the issue.", a: "Control bids (cuebidding)", why: "The worry is unguarded suits, not ace count, so cuebid controls to locate where your side is protected before committing to slam." },
        { s: "Partner opened 1NT and you have a flat 16. You want slam only if partner is at the very top of the range.", a: "Quantitative 4NT", why: "A direct 4NT over a natural notrump is quantitative: it decides a notrump slam by points, inviting 6NT." },
      ];
      const item = ENG.shuffle(BANK.slice())[0];
      return {
        scenario: item.s, prompt: "Which slam tool fits the doubt?",
        answerLabel: item.a, why: item.why,
        choices: shuffleChoices(["Blackwood 4NT", "Quantitative 4NT", "Control bids (cuebidding)"], item.a),
      };
    },

    // d-strategy — curated: pick the defensive plan before the lead.
    "defplan": () => {
      const BANK = [
        { s: "Dummy came down with a long, strong side suit (K\u2011Q\u2011J\u2011x\u2011x) and an outside entry. Declarer can soon pitch losers on it.", a: "Active", why: "When dummy has a ready source of discards, defend actively \u2014 cash or set up your winners fast, before declarer throws losers away on the long suit." },
        { s: "It's a flat notrump contract, no long suit in sight, and every lead from your hand risks handing declarer a trick.", a: "Passive", why: "With no source of tricks for declarer and nothing safe to attack, defend passively \u2014 give nothing away and make declarer do the work." },
        { s: "You hold four trumps to the jack plus a long side suit, and declarer is in a suit game.", a: "Forcing", why: "Lead your long suit to make declarer ruff; shortening declarer's trumps below yours wins trump control \u2014 the forcing defence." },
        { s: "Dummy will come down short in a side suit with small trumps, poised to ruff declarer's losers.", a: "Attack trumps", why: "When dummy's value is ruffing, lead trumps to strip them before declarer can use them, killing the ruffs." },
        { s: "Declarer is in four of a major; dummy has a singleton in your long suit and three small trumps.", a: "Attack trumps", why: "Dummy will ruff your suit, so lead trumps to draw dummy's trumps and stop the ruffs." },
        { s: "You're defending 3NT with a balanced hand and no long suit to run; any new suit you broach could cost a tempo or a trick.", a: "Passive", why: "Nothing to establish and every switch is risky \u2014 stay passive and let declarer break the suits open." },
      ];
      const item = ENG.shuffle(BANK.slice())[0];
      return {
        scenario: item.s, prompt: "Which defensive plan?",
        answerLabel: item.a, why: item.why,
        choices: shuffleChoices(["Active", "Passive", "Forcing", "Attack trumps"], item.a),
      };
    },

    // s-control — curated: the up-the-line cuebidding mechanic (cheapest first-round control).
    "controlseq": () => {
      const BANK = [
        { s: "Spades are agreed and slam is live. You hold the \u2663A and the \u2665A, nothing in diamonds. Which control do you show first?",
          a: "4\u2663", opts: ["4\u2663", "4\u2666", "4\u2665", "4NT"],
          why: "Cuebid your cheapest first-round control up the line. Holding the club and heart aces, clubs is cheaper, so 4\u2663 comes first \u2014 the heart ace can wait for the next round." },
        { s: "Spades are agreed with slam interest. You hold the \u2666A but no first-round club control. What's your cuebid?",
          a: "4\u2666", opts: ["4\u2663", "4\u2666", "4\u2665", "4NT"],
          why: "You cue only controls you actually hold. Bypassing 4\u2663 to bid 4\u2666 shows the diamond control and denies a first-round club control \u2014 the skip itself carries information." },
        { s: "Spades are agreed and slam beckons. Your only first-round side control is the \u2665A \u2014 no control in clubs or diamonds. What do you cue?",
          a: "4\u2665", opts: ["4\u2663", "4\u2666", "4\u2665", "4NT"],
          why: "Cue the cheapest control you hold. With nothing in clubs or diamonds, you skip straight to 4\u2665 \u2014 partner reads the bypass as denying first-round club and diamond controls." },
        { s: "Spades are agreed, slam values. You are void in clubs and hold the \u2665A. Cheapest first-round control?",
          a: "4\u2663", opts: ["4\u2663", "4\u2665", "4NT", "4\u2660"],
          why: "A void is a first-round control, exactly like an ace. Clubs is cheapest, so 4\u2663 shows the club void up the line before you reveal the heart ace." },
        { s: "Hearts are agreed with slam interest. You hold the \u2666A but no first-round club control. Your cuebid?",
          a: "4\u2666", opts: ["4\u2663", "4\u2666", "4\u2660", "4NT"],
          why: "Up the line below game in hearts, clubs is cheapest \u2014 but with no club control you bid 4\u2666, showing the diamond control and denying the club one. (4\u2660 would be past game and isn't a cue.)" },
        { s: "Spades are agreed, slam values. Your clubs are headed by the \u2663K (second-round control) and you hold the \u2665A (first-round). What do you cue first?",
          a: "4\u2665", opts: ["4\u2663", "4\u2665", "4NT", "4\u2660"],
          why: "First-round controls \u2014 aces and voids \u2014 come first; the club king is only a second-round control, so don't cue 4\u2663. Bid 4\u2665 to show the heart ace; the club king can come on a later round." },
      ];
      const item = ENG.shuffle(BANK.slice())[0];
      return {
        scenario: item.s, prompt: "Which control do you bid first?",
        answerLabel: item.a, why: item.why,
        choices: shuffleChoices(item.opts, item.a),
      };
    },

    // dp-method — curated: name the establishment method for a single suit (declarer play).
    "establishmethod": () => {
      const BANK = [
        { s: "You hold \u2665K Q J 10 opposite \u2665 8 7 6.", a: "High cards",
          why: "You hold a solid sequence but not the ace. Lead the suit to knock out the defenders' ace, promoting your K-Q-J into winners \u2014 establishment by high cards." },
        { s: "You hold \u2663Q J 10 9 opposite \u2663 4 3 2.", a: "High cards",
          why: "Force out the ace and king; once those are gone your Q-J-10 are winners. Driving out the defenders' high cards is establishment by high cards." },
        { s: "You hold \u2660A K 7 6 5 opposite \u2660 9 4 3 2 \u2014 nothing missing at the top.", a: "Length",
          why: "You already hold the top cards; the extra trick comes from the fifth card once the defenders' spades are gone. If the suit splits 3-2 your last card wins \u2014 establishment by length." },
        { s: "You hold \u2666A K Q 6 5 opposite \u2666 7 3.", a: "Length",
          why: "The top honours are already tricks; the chance for MORE comes from the long 6 and 5 after the outstanding diamonds fall. A 3-3 break sets up an extra winner \u2014 establishment by length." },
        { s: "You hold \u2666A Q opposite \u2666 4 3.", a: "Finesse",
          why: "Lead low toward the A-Q and, if the king lies with your left-hand opponent, play the queen to win a trick you don't own outright \u2014 a finesse." },
        { s: "You hold \u2660A Q J 10 opposite \u2660 3 2.", a: "Finesse",
          why: "With a tenace missing the king, lead toward the A-Q-J-10 and finesse; each successful finesse wins a trick around the defender's king \u2014 establishment by finessing." },
        { s: "Hearts are trumps. You hold \u2666A 4 opposite a diamond void in dummy, and dummy has small trumps.", a: "Ruffing",
          why: "Cash the ace, then ruff your low diamond in the short (dummy) hand. Trumping losers in the hand with fewer trumps turns them into tricks \u2014 establishment by ruffing." },
        { s: "Spades are trumps. You hold \u2663 6 5 4 3 opposite a singleton \u2663 2 in dummy.", a: "Ruffing",
          why: "Give up a club or two, then ruff your remaining low clubs in dummy. The short trump hand ruffing your losers is establishment by ruffing." },
      ];
      const item = ENG.shuffle(BANK.slice())[0];
      return {
        scenario: item.s, prompt: "How do you develop extra tricks in this suit?",
        answerLabel: item.a, why: item.why,
        choices: shuffleChoices(["High cards", "Length", "Finesse", "Ruffing"], item.a),
      };
    },
  };
  // ---- declarer-play technique drills: single-suit double-dummy oracle ----
  const DECLPLAY = installDeclPlay({ ENG });
  CONCEPT.finesseplay = DECLPLAY.CONCEPT_EXTRA.finesseplay;
  CONCEPT.forceplay   = DECLPLAY.CONCEPT_EXTRA.forceplay;
  function generateConcept(lesson) {
    const q = CONCEPT[lesson.drill.concept];
    if (!q) return { ok: false, reason: "unknown concept: " + lesson.drill.concept };
    const built = q();
    if (!built) return { ok: false, reason: "concept did not converge" };
    return { ok: true, kind: "concept", lesson: lesson.id, ...built };
  }

  // ---- C: opening-lead drills (answer from the game's own PLY oracle) ----
  const cardKey = (c) => c.rank + c.suit;
  const RVL = ENG.RANKVAL;
  const LEAD_WHY = {
    LEAD_SEQ: (p) => `Top of a sequence in ${suitWord(p.suit)}: the ${p.top} is a safe lead that can't cost a trick and promotes your lower cards into winners.`,
    LEAD_4TH: (p) => `Fourth-best from your longest suit (${suitWord(p.suit)}): the classic attacking lead to develop length \u2014 and it lets partner use the Rule of 11 to place the missing cards.`,
    LEAD_ACE: (p) => `Against a suit contract you don't underlead an ace \u2014 you might never score it \u2014 so lead the ace of ${suitWord(p.suit)} itself.`,
    LEAD_LOW: (p) => `Lead a low ${suitWord(p.suit)} \u2014 a quiet, constructive choice when you have no sequence or clear suit to attack.`,
    ONLY: () => `Only one card to lead.`,
  };
  const suitWord = (s) => ({ S: "spades", H: "hearts", D: "diamonds", C: "clubs" }[s] || s);

  // natural lead candidate from a single suit's cards (desc)
  function suitLeadCandidate(cards, isNT) {
    if (!cards.length) return null;
    const d = cards.slice().sort((a, b) => RVL[b.rank] - RVL[a.rank]);
    // top of a 2+ sequence of honors
    for (let i = 0; i + 1 < d.length; i++)
      if (RVL[d[i].rank] - RVL[d[i + 1].rank] === 1 && RVL[d[i].rank] >= 11) return d[i];
    if (!isNT && d[0].rank === "A") return d[0];       // ace from length vs suit
    if (d.length >= 4) return d[3];                     // fourth best
    return d[d.length - 1];                             // low
  }
  function leadChoices(hand, answer, isNT) {
    const bySuit = { S: [], H: [], D: [], C: [] };
    for (const c of hand) bySuit[c.suit].push(c);
    const cands = [];
    for (const s of ["S", "H", "D", "C"]) {
      const c = suitLeadCandidate(bySuit[s], isNT);
      if (c) cands.push(c);
    }
    // ensure the answer is present, then fill with other-suit candidates
    const out = [answer], seen = new Set([cardKey(answer)]);
    for (const c of ENG.shuffle(cands)) { if (!seen.has(cardKey(c))) { seen.add(cardKey(c)); out.push(c); } }
    return ENG.shuffle(out).slice(0, Math.min(5, Math.max(4, out.length)));
  }
  // ---- constructed slam-ask RESPONSE drills (guaranteed 100% convergence) ----
  // The only faithfulness requirement is that South's ANSWER come from BID.chooseBid.
  // The bot returns the ace-showing response for ANY legal auction ending in partner's
  // 4NT (Blackwood) / 4C (Gerber), so instead of waiting for the rare event of partner
  // organically reaching the ask (which no finite retry budget can guarantee), we build a
  // clean, textbook fit-then-ask prefix and read South's reply off chooseBid. This yields a
  // tidier auction than a random ramble AND converges every time. Verified 100% correct
  // across all ace counts 0-4. (Gerber needs South to have bid notrump for the bot to read
  // partner's 4C as Gerber, so the skeleton has South respond 1NT.)
  const slamSuitLen = (hand) => { const l = { S: 0, H: 0, D: 0, C: 0 }; for (const c of hand) l[c.suit]++; return l; };
  function slamTrump(hand) {
    const l = slamSuitLen(hand);
    const majors = ["H", "S"].filter((s) => l[s] >= 4).sort((a, b) => l[b] - l[a]);
    if (majors.length) return majors[0];                       // prefer a real major fit
    return ["S", "H", "D", "C"].sort((a, b) => l[b] - l[a])[0]; // else South's longest (always >= 4)
  }
  // ---- constructed lead-directing double drill (guaranteed convergence) ----
  // A lead-directing double shows a good 5+ suit but only modest overall values — the bot makes
  // it only when it would otherwise pass (a strong hand overcalls instead). So we deal a strong
  // suit AND keep dealing until BID.chooseBid actually returns the double, guaranteeing both
  // convergence and bot-faithfulness. The auction: LHO 1NT, partner passes, RHO bids the
  // conventional 2-level call in that suit; South doubles to demand the lead.
  function generateLeadDirect(lesson) {
    const dealer = LHO;
    for (let t = 0; t < 8000; t++) {
      const h = deal()[0];
      const e = BID.evalHand(h);
      const cand = ["C", "D", "H"].filter((s) => e.len[s] >= 5 && e.top3(s) >= 2);
      if (!cand.length) continue;
      const suit = cand[(Math.random() * cand.length) | 0];
      const calls = [{ k: "B", level: 1, strain: "NT", by: LHO }, { k: "P", by: PARTNER },
                     { k: "B", level: 2, strain: suit, by: RHO }];
      const answer = BID.chooseBid(h, calls, dealer, SOUTH);
      if (answer.k !== "D") continue;   // strong hands overcall instead — keep looking
      return {
        ok: true, lesson: lesson.id, dealer,
        southHand: h, calls, answer, ev: e, choices: buildChoices(answer, calls, dealer),
      };
    }
    return { ok: false, reason: "no lead-directing-double hand found" };
  }

  function generateSlamResponse(lesson, kind) {
    const south = deal()[0];
    const dealer = PARTNER;                                    // partner (North) opens and asks
    let calls, okFn;
    if (kind === "BW") {
      const t = slamTrump(south);
      calls = [{ k: "B", level: 1, strain: t, by: PARTNER }, { k: "P", by: RHO },
               { k: "B", level: 3, strain: t, by: SOUTH },   { k: "P", by: LHO },
               { k: "B", level: 4, strain: "NT", by: PARTNER }, { k: "P", by: RHO }];
      okFn = (a) => a.k === "B" && a.level === 5;              // 5-level ace-show
    } else { // GB (Gerber): South must have bid NT for the bot to read 4C as Gerber
      calls = [{ k: "B", level: 1, strain: "D", by: PARTNER }, { k: "P", by: RHO },
               { k: "B", level: 1, strain: "NT", by: SOUTH },  { k: "P", by: LHO },
               { k: "B", level: 4, strain: "C", by: PARTNER }, { k: "P", by: RHO }];
      okFn = (a) => a.k === "B" && a.level === 4 && ["D", "H", "S", "NT"].includes(a.strain);
    }
    const answer = BID.chooseBid(south, calls, dealer, SOUTH);
    if (!okFn(answer)) return { ok: false, reason: "slam-ask answer was not an ace-show (unexpected)" };
    // Distractors ARE the sibling ace-showing responses, so every wrong answer is a
    // plausible "miscounted your aces" — the exact skill the drill tests. (0 and 4 aces
    // share a response, so there are four distinct rungs for five ace counts.)
    const ladder = (kind === "BW")
      ? [{ k: "B", level: 5, strain: "C" }, { k: "B", level: 5, strain: "D" }, { k: "B", level: 5, strain: "H" }, { k: "B", level: 5, strain: "S" }]
      : [{ k: "B", level: 4, strain: "D" }, { k: "B", level: 4, strain: "H" }, { k: "B", level: 4, strain: "S" }, { k: "B", level: 4, strain: "NT" }];
    return {
      ok: true, lesson: lesson.id, dealer,
      southHand: south, calls: calls.slice(),
      answer, ev: BID.evalHand(south), choices: ENG.shuffle(ladder),
    };
  }

  function generateLead(lesson, tries = 12000) {
    if (!PLY) return { ok: false, reason: "no play oracle (PLY) injected" };
    const wantNT = lesson.drill.strain === "NT";
    for (let t = 0; t < tries; t++) {
      const hands = deal();
      const dealer = (Math.random() * 4) | 0;
      const calls = [];
      let guard = 0;
      while (guard++ < 40) {
        const info = AUC.auctionInfo(calls, dealer);
        if (info.ended) break;
        const seat = AUC.turnSeat(calls, dealer);
        const c = BID.chooseBid(hands[seat], calls, dealer, seat);
        calls.push({ ...c, by: seat });
      }
      const info = AUC.auctionInfo(calls, dealer);
      if (!info.ended || info.passedOut || !info.contract) continue;
      const ct = info.contract;
      if (ct.declarer !== 3) continue;               // South (0) must be the opening leader
      const isNT = ct.strain === "NT";
      if (wantNT !== isNT) continue;
      const w = PLY.chooseCardWhy({
        hand: hands[0], trick: [], ledSuit: null, trump: ct.strain,
        seat: 0, declarer: 3, dummy: 1, seen: [],
      });
      const why = (LEAD_WHY[w.why.code] || (() => "Standard lead."))(w.why);
      return {
        ok: true, kind: "lead", lesson: lesson.id, dealer, calls, contract: ct,
        southHand: hands[0], answer: w.card, code: w.why.code, why,
        answerLabel: w.card.rank + w.card.suit,
        choices: leadChoices(hands[0], w.card, isNT),
      };
    }
    return { ok: false, reason: "did not converge (South rarely on lead vs this contract type)" };
  }

  // ---- the generator ----
  function generate(lesson, tries = 8000) {
    if (lesson.drill && lesson.drill.kind === "eval") return generateEval(lesson);
    if (lesson.drill && lesson.drill.kind === "declcount") return generateDeclCount(lesson);
    if (lesson.drill && lesson.drill.kind === "concept") return generateConcept(lesson);
    if (lesson.drill && lesson.drill.pos === "lead") return generateLead(lesson);
    if (lesson.drill && lesson.drill.pos === "slam-bwresp") return generateSlamResponse(lesson, "BW");
    if (lesson.drill && lesson.drill.pos === "slam-gbresp") return generateSlamResponse(lesson, "GB");
    if (lesson.drill && lesson.drill.pos === "resp-lead-dbl") return generateLeadDirect(lesson);
    const spec = lesson.drill && POS[lesson.drill.pos];
    if (!spec) return { ok: false, reason: "no drillable position for this lesson" };
    const target = TARGET[lesson.id] || (() => true);
    const cfg = CFG[lesson.id] || {};
    const dealer = spec.dealer;

    for (let t = 0; t < tries; t++) {
      const hands = deal();
      const calls = [];
      let guard = 0;
      while (guard++ < 40) {
        const info = AUC.auctionInfo(calls, dealer);
        if (info.ended) break;
        const seat = AUC.turnSeat(calls, dealer);
        if (seat === SOUTH) {
          const p = parse(calls, dealer);
          if (spec.reach(p)) {
            // refinements: clean auction / partner's action / hand target / extra reach
            if (cfg.clean && (p.rhoLastBid || p.lhoLastBid)) break;
            if (cfg.partnerAction && (!p.partnerLastCall || p.partnerLastCall.k !== cfg.partnerAction)) break;
            if (cfg.also && !cfg.also(p)) break;
            const ev = BID.evalHand(hands[SOUTH]);
            if (!target(ev)) break;
            const answer = BID.chooseBid(hands[SOUTH], calls, dealer, SOUTH);
            if (cfg.answerOk && !cfg.answerOk(answer, ev, p)) break; // must show the concept
            return {
              ok: true, lesson: lesson.id, dealer,
              southHand: hands[SOUTH], calls: calls.slice(),
              answer, ev, choices: buildChoices(answer, calls, dealer),
            };
          }
        }
        const c = BID.chooseBid(hands[seat], calls, dealer, seat);
        calls.push({ ...c, by: seat });
      }
    }
    return { ok: false, reason: "did not converge within budget" };
  }

  // ---- audit(): which drillable lessons can the CURRENT bot actually produce? ----
  // Runs each lesson a few times; a lesson that never converges is either a
  // convention the bot doesn't play yet or one needing another oracle (leads).
  // The app calls this once at load to decide which drills to offer — so a
  // lesson activates automatically the moment the bot learns its convention.
  function audit(lessons, samples = 24, budget = 4000) {
    const out = {};
    for (const l of lessons) {
      if (!l.drill) { out[l.id] = { generatable: false, reason: "teach-only", rate: 0 }; continue; }
      if (l.drill.kind === "eval") { out[l.id] = { generatable: true, reason: "eval", rate: 1 }; continue; }
      if (l.drill.kind === "declcount") { out[l.id] = { generatable: true, reason: "declcount", rate: 1 }; continue; }
      if (l.drill.pos === "lead" && !PLY) { out[l.id] = { generatable: false, reason: "needs play oracle", rate: 0 }; continue; }
      let hit = 0;
      for (let i = 0; i < samples; i++) if (generate(l, budget).ok) hit++;
      out[l.id] = {
        generatable: hit > 0,
        rate: hit / samples,
        reason: hit > 0 ? "ok" : "bot does not play this convention yet",
      };
    }
    return out;
  }

  return { generate, audit, parse, POS, TARGET, CFG, topTricks, SUIT_SOLVER: DECLPLAY.SUIT_SOLVER };
}



//#region gen (auto — removed when bundled to a single bridge.jsx)
export { makeGenerator };
//#endregion gen
