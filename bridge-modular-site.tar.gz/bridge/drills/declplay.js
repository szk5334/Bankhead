//#region gen (auto — removed when bundled to a single bridge.jsx)
import { makeGenerator } from "./generator.js";
import { DeclarerDummy } from "../ui/learn.jsx";
import { C } from "../ui/theme.js";
//#endregion gen

/* ===== inlined generator.js ===== */
/* ============================================================================
   MULTI-ROUND AUCTION DRILL GENERATOR
   ----------------------------------------------------------------------------
   Turns a lesson's `pos` hint into a real, self-consistent practice deal:

     1. Deal four hands.
     2. Simulate the auction from the dealer using the game's own BID.chooseBid
        for every seat EXCEPT at South's target decision point.
     3. The instant it is South's turn AND the auction matches the lesson's
        position (reach) AND South's hand fits the lesson (target) — stop.
     4. The correct answer is BID.chooseBid(South) at that point, so the drill
        can never contradict how the bots actually bid. Others' bids in the
        prefix are also chooseBid's, so the whole auction is bot-consistent.

   Engine-agnostic: inject the game's real modules. In the standalone lab,
   inject the same extracted ENG/AUC/BID.

     const gen = makeGenerator({ ENG, AUC, BID });
     const drill = gen.generate(lesson);   // lesson from curriculum.js
        -> { ok, southHand, dealer, calls, answer, choices, ev } | { ok:false }

   South (the learner) is always seat 0. Partner = 2, LHO = 1, RHO = 3.
   ========================================================================== */

/* ============================================================================
   DECLARER-PLAY TECHNIQUE DRILLS  (single-suit double-dummy answer oracle)
   ----------------------------------------------------------------------------
   Inline-ready block for makeGenerator({ENG,AUC,BID,PLY}). Provides:
     - SUIT_SOLVER: an exact single-suit double-dummy solver (the ANSWER ORACLE
       for technique drills, exactly as topTricks() is the oracle for counting).
     - Two curated, solver-VERIFIED banks (finesse, force) whose correct answer
       is what SUIT_SOLVER computes; the Node harness re-derives & asserts them.
     - Two CONCEPT builders (finesseplay, forceplay) that render through the
       existing concept + DeclarerDummy UI path with ZERO UI changes.
   Model (standard suit-combination convention, matches the Official Encyclopedia):
   one suit in isolation; declarer has entries to both hands, chooses the leader
   every trick and always regains the lead; both sides double-dummy; NT-style
   (highest card wins). South = the hand that holds the tenace/sequence; North =
   dummy. This is the same idealisation textbooks use to state suit-combo results.
   ========================================================================== */
function installDeclPlay({ ENG }) {
  const RV = ENG.RANKVAL;                                   // ten is "10", NOT "T"
  const ALLR = ["A","K","Q","J","10","9","8","7","6","5","4","3","2"];
  const vv = (r) => RV[r];
  const desc = (a) => a.slice().sort((x,y) => vv(y)-vv(x));
  const asc  = (a) => a.slice().sort((x,y) => vv(x)-vv(y));
  const lo   = (a) => asc(a)[0];

  // ---------- exact double-dummy for one FIXED layout (memoized) ----------
  const _memo = new Map();
  const key = (S,N,W,E) => S.join("")+"|"+N.join("")+"|"+W.join("")+"|"+E.join("");
  function ddLayout(S,N,W,E){
    if(!S.length && !N.length) return 0;
    const k = key(S,N,W,E); const h=_memo.get(k); if(h!==undefined) return h;
    let best=-1;
    const leaders=[]; if(S.length) leaders.push("S"); if(N.length) leaders.push("N");
    for(const L of leaders){ const hand=(L==="S"?S:N);
      for(const c of hand){ const v=playFixed(L,c,S,N,W,E); if(v>best) best=v; } }
    _memo.set(k,best); return best;
  }
  // one trick from a fixed layout with a chosen (leader,card); defenders minimax, declarer max.
  function playFixed(L,card,S,N,W,E){
    const order = L==="N" ? ["N","E","S","W"] : ["S","W","N","E"];
    const H={S,N,W,E}; const def2=order[1], d3=order[2], def4=order[3];
    const opts2 = H[def2].length? H[def2] : [null];
    let b2=Infinity;
    for(const c2 of opts2){
      const opts3 = H[d3].length? H[d3] : [null];
      let b3=-Infinity;
      for(const c3 of opts3){
        const opts4 = H[def4].length? H[def4] : [null];
        let b4=Infinity;
        for(const c4 of opts4){
          const played={[L]:card,[def2]:c2,[d3]:c3,[def4]:c4};
          let w=null,bv=-1; for(const s of order){ const c=played[s]; if(c==null) continue; if(vv(c)>bv){bv=vv(c);w=s;} }
          const won=(w==="S"||w==="N")?1:0;
          const nS=S.slice(),nN=N.slice(),nW=W.slice(),nE=E.slice(),R={S:nS,N:nN,W:nW,E:nE};
          const drop=(s,c)=>{ if(c!=null){ const i=R[s].indexOf(c); if(i>=0) R[s].splice(i,1); } };
          drop(L,card); drop(def2,c2); drop(d3,c3); drop(def4,c4);
          const val=won+ddLayout(nS,nN,nW,nE);
          if(val<b4) b4=val;
        }
        if(b4>b3) b3=b4;
      }
      if(b3<b2) b2=b3;
    }
    return b2;
  }
  // ---------- a-priori split weights over the missing cards ----------
  function comb(n,k){ if(k<0||k>n) return 0; k=Math.min(k,n-k); let r=1; for(let i=0;i<k;i++) r=r*(n-i)/(i+1); return Math.round(r); }
  function partitions(missing){
    const m=missing.length, out=[];
    for(let mask=0; mask<(1<<m); mask++){
      const W=[],Ee=[]; for(let i=0;i<m;i++){ (mask&(1<<i))? W.push(missing[i]) : Ee.push(missing[i]); }
      out.push({ W:desc(W), E:desc(Ee), w:comb(26-m, 13-W.length) });   // a-priori vacant-space weight
    }
    return out;
  }
  // ---------- non-clairvoyant first action, exact continuation ----------
  // third-hand rule captures real technique on round 1: "cheapest-win" = partner plays the
  // lowest card that beats the current high (the finesse / rise-with-honour), else lowest.
  function thirdCard(rule, hand, curHigh){
    if(!hand.length) return null; const a=asc(hand);
    if(rule==="low") return a[0];
    const wins=a.filter(c=>vv(c)>curHigh); return wins.length? wins[0] : a[0];
  }
  function actionEV(S,N,action){
    S=desc(S); N=desc(N);
    const held=new Set([...S,...N]); const missing=ALLR.filter(r=>!held.has(r));
    const parts=partitions(missing); let num=0, den=0;
    for(const p of parts){ num += p.w*firstThenDD(S,N,p.W.slice(),p.E.slice(),action); den += p.w; }
    return { ev:num/den };
  }
  function firstThenDD(S,N,W,E,action){
    const L=action.from, card=action.card;
    const order = L==="N" ? ["N","E","S","W"] : ["S","W","N","E"];
    const H={S:S.slice(),N:N.slice(),W:W.slice(),E:E.slice()};
    const def2=order[1], d3=order[2], def4=order[3];
    const opts2 = H[def2].length? H[def2] : [null];
    let b2=Infinity;
    for(const c2 of opts2){
      const curHigh=Math.max(vv(card), c2==null?-1:vv(c2));
      const c3=thirdCard(action.third, H[d3], curHigh);
      const opts4 = H[def4].length? H[def4] : [null];
      let b4=Infinity;
      for(const c4 of opts4){
        const played={[L]:card,[def2]:c2,[d3]:c3,[def4]:c4};
        let w=null,bv=-1; for(const s of order){ const c=played[s]; if(c==null) continue; if(vv(c)>bv){bv=vv(c);w=s;} }
        const won=(w==="S"||w==="N")?1:0;
        const nS=S.slice(),nN=N.slice(),nW=W.slice(),nE=E.slice(),R={S:nS,N:nN,W:nW,E:nE};
        const drop=(s,c)=>{ if(c!=null){ const i=R[s].indexOf(c); if(i>=0) R[s].splice(i,1);} };
        drop(L,card); drop(def2,c2); drop(d3,c3); drop(def4,c4);
        const val=won+ddLayout(nS,nN,nW,nE);
        if(val<b4) b4=val;
      }
      if(b4<b2) b2=b4;
    }
    return b2;
  }
  // Rank the standard first-actions for a South-tenace / North-dummy layout.
  function rankActions(S,N){
    S=desc(S); N=desc(N); const acts=[];
    if(N.length) acts.push({ id:"finN", from:"N", card:lo(N), third:"cheapest-win" }); // lead low from dummy (the finesse)
    if(S.length) acts.push({ id:"finS", from:"S", card:lo(S), third:"cheapest-win" });
    if(S.length) acts.push({ id:"cashS",from:"S", card:desc(S)[0], third:"low" });      // cash top from hand
    if(N.length) acts.push({ id:"cashN",from:"N", card:desc(N)[0], third:"low" });
    return acts.map(a=>({ ...a, ev:actionEV(S,N,a).ev })).sort((x,y)=>y.ev-x.ev);
  }
  const SUIT_SOLVER = { ddLayout, actionEV, rankActions, partitions };

  // ---------- solver-VERIFIED curated banks (ranks; South holds the honours) ----------
  // Every finesse entry: SUIT_SOLVER's best action is "lead low from dummy" (finN) and it
  // beats the best cash line by >= FIN_MARGIN. Every force entry: a solid sequence whose only
  // line is to drive out the missing top honour(s). The harness asserts all of this.
  const FIN_MARGIN = 0.30;
  const FINESSE_BANK = [
    { S:["A","Q"],            N:["6","4","3"] },
    { S:["A","Q"],            N:["8","6","4","3"] },
    { S:["K","J"],            N:["7","4","2"] },
    { S:["A","J","10"],       N:["5","4","3"] },
    { S:["A","J","10"],       N:["6","2"] },
    { S:["A","J","10","9"],   N:["6","4","2"] },
    { S:["A","Q","J"],        N:["6","5","4"] },
  ];
  const FORCE_BANK = [
    { S:["K","Q","J"],        N:["4","3","2"] },
    { S:["K","Q","J","10"],   N:["4","3","2"] },
    { S:["Q","J","10"],       N:["5","4","3"] },
    { S:["Q","J","10","9"],   N:["4","3","2"] },
    { S:["Q","J","10","9"],   N:["6","5"] },
  ];

  // ---------- render helpers ----------
  const GLY = { S:"\u2660", H:"\u2665", D:"\u2666", C:"\u2663" };
  const shuffle = (a) => ENG.shuffle(a);
  // build real card objects for ONE suit from a fresh deck (valid unique ids, ten = "10")
  function suitCards(ranks, suit){
    const deck = ENG.makeDeck();
    return ranks.map(r => deck.find(c => c.suit===suit && c.rank===r));
  }
  const honourList = (ranks) => ranks.filter(r => vv(r) >= 11);          // J,Q,K,A
  const joinHonours = (rs) => rs.join("\u2011");                        // non-breaking hyphen: A-Q
  const andList = (rs, g) => rs.length===1 ? rs[0]+g : rs.slice(0,-1).map(r=>r+g).join(", ")+" and "+rs[rs.length-1]+g;

  const SUITWORD = { S:"spades", H:"hearts", D:"diamonds", C:"clubs" };
  const seqName = (ranks) => desc(ranks).join("\u2011");   // full holding, e.g. A-Q-J, Q-J-10
  function pickSuit(){ return shuffle(["S","H","D","C"])[0]; }

  function buildFinesse(entry){
    const suit = pickSuit(), g = GLY[suit];
    const declHand = suitCards(entry.S, suit);
    const dummyHand = suitCards(entry.N, suit);
    const ten = honourList(entry.S);
    const held = new Set([...entry.S, ...entry.N]);
    const missHon = ALLR.filter(r => vv(r)>=11 && vv(r)>vv(ten[ten.length-1]) && !held.has(r)); // honours above the tenace, out
    const lowDummy = lo(entry.N);
    const top = desc(entry.S)[0];
    const correct = `Lead low from dummy (${lowDummy}${g}) toward your hand and finesse`;
    const dCash   = `Cash your ${top}${g} from hand`;
    const dWrong  = `Lead low from your hand toward dummy`;
    const sit = missHon.length>1 ? "sit" : "sits";
    const why =
      `You hold the ${seqName(entry.S)} tenace in ${SUITWORD[suit]} opposite low cards. `+
      `Lead low from dummy toward your hand: the defender on your right must commit before your honour, so if the missing `+
      `${missHon.length?andList(missHon,g):"honour"} ${sit} in front of the tenace you score a trick you could never take by force \u2014 a finesse. `+
      `Cashing a top honour, or leading from the strong hand, throws that extra trick away.`;
    return {
      declHand, dummyHand, contractLabel: null,
      scenario: `One suit in isolation (you have free entries to both hands). Focus only on ${GLY[suit]}.`,
      prompt: "What is your best play to maximise tricks in this suit?",
      answerLabel: correct,
      why,
      choices: shuffle([
        { label: correct, correct: true },
        { label: dCash,   correct: false },
        { label: dWrong,  correct: false },
      ]),
    };
  }

  function buildForce(entry){
    const suit = pickSuit(), g = GLY[suit];
    const declHand = suitCards(entry.S, suit);
    const dummyHand = suitCards(entry.N, suit);
    const top = desc(entry.S)[0];
    const held = new Set([...entry.S, ...entry.N]);
    const missTop = ALLR.filter(r => vv(r) > vv(top) && !held.has(r));   // top honours to drive out
    const count = ddLayout(desc(entry.S), desc(entry.N),
                           desc(ALLR.filter(r=>!held.has(r))), []);       // established count (all out cards onside is irrelevant for a pure sequence)
    const dropVb  = missTop.length>1 ? "drop" : "drops";
    const correct = `Lead the ${top}${g} to force out the ${andList(missTop,g)}`;
    const dFin    = `Lead low toward the ${top}${g} and finesse`;
    const dHope   = `Cash from the top and hope the ${andList(missTop,g)} ${dropVb}`;
    const why =
      `Your ${seqName(entry.S)} is a solid sequence in ${SUITWORD[suit]} missing only the ${andList(missTop,g)}. `+
      `There is no tenace to finesse and the ${missTop.length>1?"honours":"honour"} won't fall to cashing, so lead the sequence and knock ${missTop.length>1?"them":"it"} out. `+
      `Once ${missTop.length>1?"they are":"it is"} gone your remaining cards are all high \u2014 ${count} trick${count===1?"":"s"}.`;
    return {
      declHand, dummyHand, contractLabel: null,
      scenario: `One suit in isolation (you have free entries to both hands). Focus only on ${g}.`,
      prompt: "How do you develop the tricks you need in this suit?",
      answerLabel: correct,
      why,
      choices: shuffle([
        { label: correct, correct: true },
        { label: dFin,    correct: false },
        { label: dHope,   correct: false },
      ]),
    };
  }

  // CONCEPT builders keyed by concept name (spread into generateConcept's return)
  const CONCEPT_EXTRA = {
    finesseplay: () => buildFinesse(shuffle(FINESSE_BANK.slice())[0]),
    forceplay:   () => buildForce(shuffle(FORCE_BANK.slice())[0]),
  };

  return { SUIT_SOLVER, FINESSE_BANK, FORCE_BANK, buildFinesse, buildForce, CONCEPT_EXTRA, FIN_MARGIN };
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { installDeclPlay };
//#endregion gen
