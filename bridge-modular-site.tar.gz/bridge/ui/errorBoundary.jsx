//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { btn } from "./theme.js";
//#endregion gen

class UIErrorBoundary extends React.Component{
  constructor(p){ super(p); this.state={err:null}; }
  static getDerivedStateFromError(err){ return {err}; }
  render(){
    if(this.state.err) return (
      <div className="lrn-overlay">
        <div className="lrn-top"><span className="lrn-title">LEARN</span><button className="dl-x" onClick={this.props.onClose}>×</button></div>
        <div className="lrn-scroll"><div className="lrn-fail">Something went wrong opening this screen.</div>
          <div className="lrn-why" style={{marginTop:10}}>{String((this.state.err&&this.state.err.message)||this.state.err)}</div>
          <button className="lrn-btn" onClick={this.props.onClose}>Close</button></div>
      </div>
    );
    return this.props.children;
  }
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { UIErrorBoundary };
//#endregion gen
