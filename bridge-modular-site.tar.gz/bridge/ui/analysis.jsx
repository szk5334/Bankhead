//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { ANA } from "../engine/analysis.js";
import { SEAT_ABBR, STRAIN_GLYPH, SUIT_GLYPH } from "../state/constants.js";
import { suitColorClass } from "./glossary.jsx";
import { BidVerdict } from "./table.jsx";
//#endregion gen

/* analysis.jsx — THE POST-HAND ANALYSIS. The payload the whole mode is built to deliver.
 *
 * It leads with the number nobody else can give you: THE CLAIRVOYANCE RATE.
 *
 * With every hand face up, chasing the double-dummy card is easy — and it teaches you nothing about bridge,
 * because a real player at a real table cannot see West's hand. So the analysis crosses the two lenses and
 * asks, of every play that LOOKS right: *would you have found it blind?*
 *
 *     sound        you found it, and you'd have found it without looking
 *     CLAIRVOYANT  the double-dummy best card — but not a play any blind player finds. You LOOKED.
 *     unlucky      the percentage play; this layout beat it. NOT a mistake, and we say so.
 *     mistake      wrong on both lenses
 *
 * Measured on a genuinely double-dummy-perfect line: 19 decisions, 0 tricks lost, 0 mistakes — and 3 plays
 * (16%) the player would never have found unaided. A scoreboard would have said "perfect". This says what
 * actually happened.
 *
 * NO POINTS in V1, deliberately, and the tone must not smuggle them back in: praise inflation is how a
 * teaching tool turns into a slot machine.
 */

const TONE = {
  good:    "#3aa657",
  neutral: "#7f8fa6",
  warn:    "#c79a2e",   // clairvoyant — not an error, but not YOUR play either
  bad:     "#c0503f",
};
const CELL_TONE = { sound:"good", unlucky:"neutral", clairvoyant:"warn", mistake:"bad", unknown:"neutral" };

const gl = (k) => { if(!k) return "?"; const i = k.lastIndexOf("."); const s = k.slice(i+1);
  return <>{k.slice(0,i)}<span className={suitColorClass(s)}>{SUIT_GLYPH[s]||s}</span></>; };

/* ---------------- the headline ---------------- */
function Headline({ a }) {
  const p = a.play;
  const pct = Math.round(100 * p.clairvoyanceRate);
  const looksRight = p.sound + p.clairvoyant;
  return (
    <div style={{ padding: "10px 12px", borderBottom: "1px solid rgba(127,127,127,0.25)" }}>
      <div style={{ fontSize: 12.5, lineHeight: 1.5, marginBottom: 8 }}>{ANA.headline(a)}</div>

      {/* HINTED DECISIONS ARE NOT YOURS. Say so first, before any number, because every number below is
          computed over the UNAIDED ones and the reader is owed that up front. */}
      {p.aided ? (
        <div style={{ padding: "6px 9px", borderRadius: 8, marginBottom: 8, fontSize: 11, lineHeight: 1.45,
          background: "rgba(199,154,46,0.10)", borderLeft: "3px solid " + TONE.warn }}>
          <b>{p.aided} of your {p.decisions} decision{p.decisions === 1 ? "" : "s"} {p.aided === 1 ? "was" : "were"} hinted.</b>{" "}
          {p.unaided
            ? <>Those are left out of everything below — you were told the answer, so it is not a measure of you. The numbers here are your <b>{p.unaided}</b> unaided decision{p.unaided === 1 ? "" : "s"}.</>
            : <>That is all of them, so there is nothing here to measure.</>}
        </div>
      ) : null}

      {/* THE number. Front and centre, because it is the only one the normal game cannot produce. */}
      {looksRight > 0 ? (
        <div style={{ padding: "8px 10px", borderRadius: 8, background: "rgba(199,154,46,0.10)",
          borderLeft: "3px solid " + TONE.warn }}>
          <div style={{ fontSize: 20, fontWeight: 700, lineHeight: 1 }}>{pct}%</div>
          <div style={{ fontSize: 11, opacity: 0.85, marginTop: 3, lineHeight: 1.45 }}>
            of your correct-looking plays, you would <b>not</b> have found without seeing the other hands
            <span style={{ opacity: 0.65 }}> ({p.clairvoyant} of {looksRight}).</span>
          </div>
          {p.clairvoyant === 0 ? (
            <div style={{ fontSize: 11, marginTop: 4, color: TONE.good }}>
              Every good play here was a play you could have found at a real table.
            </div>
          ) : null}
        </div>
      ) : null}

      <div style={{ display: "flex", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
        <Pill n={p.sound}       label="sound"       tone="good" />
        <Pill n={p.clairvoyant} label="clairvoyant" tone="warn" />
        <Pill n={p.unlucky}     label="unlucky"     tone="neutral" />
        <Pill n={p.mistake}     label="mistake"     tone="bad" />
        <span style={{ flex: 1 }} />
        <span style={{ fontSize: 10, opacity: 0.5, alignSelf: "center" }}>
          {p.forced} forced · {p.free} indifferent · not graded
        </span>
      </div>
    </div>
  );
}
const Pill = ({ n, label, tone }) => (
  <span style={{ fontSize: 10, padding: "3px 8px", borderRadius: 10,
    background: n ? TONE[tone] : "rgba(127,127,127,0.18)",
    color: n ? "#fff" : "inherit", opacity: n ? 1 : 0.55 }}>
    {n} {label}{n === 1 ? "" : "s"}
  </span>
);

/* ---------------- one card's verdict ---------------- */
function CardRow({ c, s }) {
  const tone = TONE[CELL_TONE[c.cell] || "neutral"];
  const declSide = s.contract && (c.seat === s.contract.declarer || c.seat === (s.contract.declarer + 2) % 4);
  return (
    <div style={{ padding: "6px 9px", marginBottom: 5, borderRadius: 8, fontSize: 11.5, lineHeight: 1.45,
      background: "rgba(127,127,127,0.08)", borderLeft: "3px solid " + tone }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
        <span style={{ fontSize: 9.5, opacity: 0.5, width: 44 }}>trick {c.trick + 1}</span>
        <b style={{ fontSize: 12 }}>{SEAT_ABBR[c.seat]} {gl(c.playedKey)}</b>
        <span style={{ fontSize: 9, opacity: 0.5 }}>{declSide ? "declarer" : "defence"}</span>
        <span style={{ flex: 1 }} />
        {c.hinted ? (
          <em style={{ fontSize: 9, padding: "1px 6px", borderRadius: 9, color: "#fff", background: TONE.warn }}>
            hinted
          </em>
        ) : null}
        <em style={{ fontSize: 9, padding: "1px 6px", borderRadius: 9, color: "#fff", background: tone }}>
          {c.cellLabel}
        </em>
      </div>
      <div style={{ opacity: 0.85 }}>{c.blurb}</div>

      {/* The two lenses, stated separately. They are different questions and must never be collapsed. */}
      <div style={{ display: "flex", gap: 12, marginTop: 4, fontSize: 10.5, opacity: 0.8 }}>
        <span>
          <b style={{ color: c.ddOptimal ? TONE.good : TONE.bad }}>DD</b>{" "}
          {c.ddOptimal ? `best (${c.ddBest} tricks)` : `${c.ddVal} vs ${c.ddBest} — ${c.ddLost} away`}
        </span>
        {c.sd ? (
          <span>
            <b style={{ color: c.sd.played_in_equiv ? TONE.good : TONE.bad }}>SD</b>{" "}
            {c.sd.played_in_equiv ? "the percentage play" : <>blind, you'd play {gl(c.sdBest)}</>}
          </span>
        ) : <span style={{ opacity: 0.5 }}>SD not analysed</span>}
      </div>

      {!c.ddOptimal && c.ddEquiv && c.ddEquiv.length ? (
        <div style={{ marginTop: 3, opacity: 0.7, fontSize: 10.5 }}>
          Best here: {c.ddEquiv.slice(0, 4).map((k, i) => <span key={i} style={{ marginRight: 6 }}>{gl(k)}</span>)}
        </div>
      ) : null}
    </div>
  );
}

/* ---------------- the screen ---------------- */
function AnalysisView({ s, analysis, progress, onReplay, onClose }) {
  const [tab, setTab] = React.useState("mistakes");
  if (!analysis) {
    const pct = progress ? Math.round(100 * progress.done / Math.max(1, progress.total)) : 0;
    return (
      <div style={{ padding: 20, textAlign: "center", fontSize: 12 }}>
        <div style={{ marginBottom: 8 }}>Working out what you would have played <i>blind</i>…</div>
        <div style={{ height: 4, borderRadius: 2, background: "rgba(127,127,127,0.25)", overflow: "hidden" }}>
          <div style={{ height: "100%", width: pct + "%", background: TONE.warn, transition: "width 200ms" }} />
        </div>
        <div style={{ marginTop: 6, opacity: 0.55, fontSize: 10.5 }}>
          {progress ? `${progress.done} / ${progress.total} decisions` : ""} — sampling sixteen worlds per card
        </div>
      </div>
    );
  }

  const p = analysis.play;
  const list = tab === "mistakes"
    ? p.worst.filter(c => c.cell === "mistake" || c.cell === "clairvoyant")
    : p.worst;

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
      <Headline a={analysis} />

      <div style={{ display: "flex", gap: 4, padding: "6px 10px 0" }}>
        {[["mistakes", "What to fix"], ["all", "Every decision"], ["bidding", "The auction"]].map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)}
            style={{ fontSize: 11, padding: "4px 9px", borderRadius: 6,
              background: tab === k ? "rgba(127,127,127,0.22)" : "transparent" }}>{l}</button>
        ))}
        <span style={{ flex: 1 }} />
        {onReplay ? <button onClick={onReplay} style={{ fontSize: 11, padding: "4px 9px", borderRadius: 6 }}>Replay</button> : null}
      </div>

      <div style={{ flex: 1, overflowY: "auto", padding: "8px 10px" }}>
        {tab === "bidding" ? (
          analysis.bidding.calls.length
            ? analysis.bidding.calls.map((c, i) => (
                <div key={i} style={{ marginBottom: 5 }}>
                  <div style={{ fontSize: 9.5, opacity: 0.5, marginBottom: 1 }}>{SEAT_ABBR[c.by]}</div>
                  <BidVerdict g={c.grade} />
                </div>
              ))
            : <Empty>No calls to review.</Empty>
        ) : list.length ? (
          list.map(c => <CardRow key={c.posKey} c={c} s={s} />)
        ) : tab === "mistakes" ? (
          <Empty>
            Nothing to fix. Every real decision was both the best card <i>and</i> the card you would have
            found without seeing the other hands.
          </Empty>
        ) : <Empty>No decisions in this hand.</Empty>}
      </div>

      {onClose ? (
        <div style={{ padding: 8, borderTop: "1px solid rgba(127,127,127,0.25)" }}>
          <button onClick={onClose} style={{ width: "100%", padding: 8, borderRadius: 8, fontSize: 12 }}>
            Next deal
          </button>
        </div>
      ) : null}
    </div>
  );
}
const Empty = ({ children }) => (
  <div style={{ padding: "16px 8px", opacity: 0.6, fontSize: 11.5, lineHeight: 1.5, textAlign: "center" }}>{children}</div>
);

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { AnalysisView, Headline, CardRow };
//#endregion gen
