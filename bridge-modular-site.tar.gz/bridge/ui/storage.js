/* ---------------- persistence (wrapped so a sandbox never throws) ---------------- */
const THEME_KEY="bridge.theme.v1", CAMP_KEY="bridge.campaign.v1", STATS_KEY="bridge.stats.v1";
function loadTheme(){ try{ return localStorage.getItem(THEME_KEY)||"casino"; }catch(_){ return "casino"; } }
function saveTheme(t){ try{ localStorage.setItem(THEME_KEY,t); }catch(_){} }
function loadCampaign(){ try{ return JSON.parse(localStorage.getItem(CAMP_KEY))||null; }catch(_){ return null; } }
function saveCampaign(c){ try{ if(c) localStorage.setItem(CAMP_KEY, JSON.stringify(c)); else localStorage.removeItem(CAMP_KEY); }catch(_){} }
function loadStats(){ try{ return JSON.parse(localStorage.getItem(STATS_KEY))||{rubbers:0,rubbersWon:0,dealsPlayed:0,contractsMade:0}; }catch(_){ return {rubbers:0,rubbersWon:0,dealsPlayed:0,contractsMade:0}; } }
function saveStats(v){ try{ localStorage.setItem(STATS_KEY, JSON.stringify(v)); }catch(_){} }


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { CAMP_KEY, STATS_KEY, THEME_KEY, loadCampaign, loadStats, loadTheme, saveCampaign, saveStats, saveTheme };
//#endregion gen
