//#region gen (auto — removed when bundled to a single bridge.jsx)
import { who } from "../state/personas.js";
import { btn } from "./theme.js";
//#endregion gen

const THEME_CSS=`
.br{
  --mono:ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  --k:1.15;
  --bg:#0f3b2b; --ink:#f2e8ce; --dim:#9a8f63; --line:rgba(212,175,55,.42); --line2:rgba(212,175,55,.20);
  --card:#f6efd9; --cardline:#cdc09a; --fill:#f2e8ce; --fillink:#0f3b2b;
  --purple:#e2c068; --pink:#ed7464; --cyan:#67cdbb; --green:#4fc47a;
  --yellow:#f0d27a; --orange:#e0a45a; --red:#ed7464; --comment:#9a8f63; --rule:#e2c068;
  --sp:#1c6fd4; --he:#b3232a; --di:#d6a51b; --cl:#1c7a3f;
  --selbg:#efe2bd; --playink:#0d3322;
  background:var(--bg); color:var(--ink);
}
.br[data-theme="blue"]{ --bg:#112c4f; --fillink:#112c4f; --playink:#0a1830; }
.br[data-theme="red"]{ --bg:#3c1418; --fillink:#3c1418; --playink:#220a0c; }
.br[data-theme="black"]{ --bg:#0d0d10; --fillink:#0d0d10; --playink:#060608; }
.br[data-theme="cream"]{
  --bg:#f3ead4; --ink:#2b2517; --dim:#857852; --line:rgba(150,116,30,.55); --line2:rgba(150,116,30,.26);
  --card:#fdf9f1; --cardline:#d8c8a0; --fill:#fdf9f1; --fillink:#2b2517;
  --purple:#a87e22; --pink:#bb3b2a; --cyan:#157a70; --green:#2e8b50;
  --yellow:#9c7d18; --orange:#b5611f; --red:#c0392b; --comment:#857852; --rule:#a87e22;
  --sp:#1c6fd4; --he:#b3232a; --di:#b8890f; --cl:#1c7a3f;
  --selbg:#f2e7c6; --playink:#f6efda;
}
.br *{font-family:var(--mono)!important;border-radius:0!important;box-shadow:none!important;text-shadow:none!important;-webkit-tap-highlight-color:transparent;box-sizing:border-box;}
.brcard{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;background:var(--card);border:1px solid var(--cardline);cursor:default;user-select:none;transition:transform .08s;}
.brcard.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}
.brcard.clk{cursor:pointer;} .brcard.dis{opacity:.32;}
.brcard.s-sp{color:var(--sp);} .brcard.s-he{color:var(--he);} .brcard.s-di{color:var(--di);} .brcard.s-cl{color:var(--cl);}
.brcard .idx,.brcard .ir,.brcard .is,.brcard .mid,.brcard .ctr,.brcard .pip{color:inherit;background:transparent;font-variant-emoji:text;-webkit-text-fill-color:currentColor;-webkit-backface-visibility:hidden;backface-visibility:hidden;}
.brcard .is,.brcard .pip{font-family:"DejaVu Sans","Noto Sans Symbols2","Noto Sans Symbols","Segoe UI Symbol","Apple Symbols","Arial Unicode MS",sans-serif!important;}
.brcard.sel{background:var(--selbg);border-color:var(--purple);transform:translateY(calc(-8px*var(--k)));}
.brcard.sug{border-color:var(--green);box-shadow:0 0 0 2px var(--green),0 0 12px color-mix(in srgb,var(--green) 55%,transparent);transform:translateY(calc(-9px*var(--k)));}
.brcard .idx{position:absolute;display:flex;flex-direction:column;align-items:center;line-height:.9;font-weight:700;}
.brcard .idx.tl{top:calc(3px*var(--k));left:calc(4px*var(--k));} .brcard .idx.br{bottom:calc(3px*var(--k));right:calc(4px*var(--k));transform:rotate(180deg);}
.brcard .ir{font-size:calc(11px*var(--k));} .brcard .is{font-size:calc(8px*var(--k));margin-top:calc(1px*var(--k));}
.brcard.sm .ir{font-size:calc(8px*var(--k));} .brcard.sm .is{font-size:calc(6px*var(--k));}
.brcard .ctr{position:absolute;inset:0;}
.brcard .pip{position:absolute;font-size:calc(9.5px*var(--k));line-height:1;transform:translate(-50%,-50%);}
.brcard .pip.flip{transform:translate(-50%,-50%) rotate(180deg);}
.brcard .pip.ace{font-size:calc(27px*var(--k));}
.brcard.sm .pip.ace{font-size:calc(18px*var(--k));}
.brcard.sm .pip{font-size:calc(7px*var(--k));}
.brcard .mid{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-weight:800;}
.brcard .mid.fc{font-size:calc(25px*var(--k));} .brcard.sm .mid.fc{font-size:calc(17px*var(--k));}
.brback{position:relative;width:calc(42px*var(--k));height:calc(58px*var(--k));flex:0 0 auto;border:1px solid var(--line);background:repeating-linear-gradient(135deg,var(--bg) 0 4px,var(--line2) 4px 5px);}
.brback.sm{width:calc(30px*var(--k));height:calc(42px*var(--k));}
.br select{background:var(--bg);color:var(--ink);border:1px solid var(--line);font-size:11px;padding:4px 6px;}
.br option{background:var(--card);color:var(--sp);}
.br .app{width:100%;max-width:412px;margin:0 auto;display:flex;flex-direction:column;gap:9px;}
.br .num{font-variant-numeric:tabular-nums;}
.br .lbl2{font-size:9px;letter-spacing:.18em;text-transform:uppercase;color:var(--dim);font-weight:700;}
.br header{display:flex;align-items:baseline;justify-content:space-between;flex-wrap:wrap;gap:6px;border-bottom:1px solid var(--rule);padding-bottom:6px;}
.br .wordmark{font-size:18px;font-weight:700;letter-spacing:.34em;padding-left:.34em;background:linear-gradient(92deg,var(--pink),var(--purple) 50%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}
.br .wordmark.sm{font-size:14px;}
.br .target{font-size:10px;letter-spacing:.10em;color:var(--dim);}
.br .toggle{display:flex;border:1px solid var(--line);}
.br .toggle button{font:inherit;font-size:8.5px;letter-spacing:.06em;text-transform:uppercase;background:transparent;color:var(--dim);border:0;padding:4px 6px;cursor:pointer;}
.br .toggle button.on{background:var(--purple);color:var(--fillink);}
.br .toggle button+button{border-left:1px solid var(--line);}
.br .seats{display:grid;grid-template-columns:1fr 1fr;gap:6px;}
.br .seat{border:1px solid var(--line2);padding:6px 8px;min-width:0;--accent:var(--purple);}
.br .seat.act{background:var(--line2);border-color:var(--line);}
.br .seat .top{display:flex;align-items:center;gap:5px;}
.br .seat .gl{font-size:13px;color:var(--accent);}
.br .seat .nm{font-size:9.5px;letter-spacing:.06em;text-transform:uppercase;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .seat .sub{display:flex;gap:7px;margin-top:3px;align-items:center;flex-wrap:wrap;}
.br .seat .pos{font-size:8.5px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .seat .vtag{color:var(--red);}
.br .seat .role{font-size:8px;letter-spacing:.08em;text-transform:uppercase;padding:1px 4px;border:1px solid var(--accent);color:var(--accent);}
.br .seat .role.decl{color:var(--green);border-color:var(--green);}
.br .seat .role.dummy{color:var(--cyan);border-color:var(--cyan);}
.br .seat .cnt{font-size:9px;color:var(--dim);}
.br .auction{border:1px solid var(--line);}
.br .ahead,.br .arow{display:grid;grid-template-columns:repeat(4,1fr);}
.br .ahead{border-bottom:1px solid var(--line2);}
.br .ac{padding:3px 0;text-align:center;font-size:9px;color:var(--dim);letter-spacing:.14em;}
.br .acell{padding:4px 0;text-align:center;border-left:1px solid var(--line2);min-height:22px;}
.br .acell:first-child{border-left:0;}
.br .aempty{padding:8px;text-align:center;color:var(--dim);font-size:10px;letter-spacing:.1em;}
.br .chip{font-size:11px;font-weight:700;letter-spacing:.02em;}
.br .chip.pass{color:var(--dim);} .br .chip.dbl{color:var(--pink);}
.br .chip.bid{color:var(--ink);} .br .chip.bid.red{color:var(--red);} .br .chip.bid b{font-weight:800;}
.br .chip.big{font-size:15px;}
.br .bidbox2{border:1px solid var(--line);padding:7px;display:flex;flex-direction:column;gap:5px;}
.br .bb-levels{display:grid;grid-template-columns:repeat(7,1fr);gap:4px;}
.br .bb-lv{font:inherit;font-size:14px;font-weight:800;padding:8px 0;background:transparent;color:var(--ink);border:1px solid var(--line);cursor:pointer;transition:background .08s;}
.br .bb-lv.on{background:var(--ink);color:var(--bg);border-color:var(--ink);}
.br .bb-lv.sug{border-color:var(--green);box-shadow:inset 0 0 0 1px var(--green);}
.br .bb-lv:disabled{opacity:.2;cursor:default;}
.br .bb-strains{display:grid;grid-template-columns:repeat(5,1fr);gap:4px;}
.br .bb-st{font:inherit;font-size:21px;font-weight:700;line-height:1;padding:9px 0;background:transparent;color:var(--ink);border:1px solid var(--line);cursor:pointer;}
.br .bb-st.gsp{color:var(--sp);} .br .bb-st.ghe{color:var(--he);} .br .bb-st.gdi{color:var(--di);} .br .bb-st.gcl{color:var(--cl);}
.br .bb-st:disabled{opacity:.2;cursor:default;}
.br .bb-st.sug{border-color:var(--green);box-shadow:0 0 0 2px var(--green);}
.br .bb-acts{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;margin-top:1px;}
.br .bb-act{font:inherit;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;padding:8px 0;background:transparent;color:var(--ink);border:1px solid var(--line);cursor:pointer;}
.br .bb-act:disabled{opacity:.24;cursor:default;}
.br .bb-act.sug{border-color:var(--green);box-shadow:inset 0 0 0 1px var(--green);}
.br .tricktable{position:relative;height:200px;border:1px solid var(--line);display:grid;
  grid-template-columns:1fr 1fr 1fr;grid-template-rows:1fr 1fr 1fr;
  grid-template-areas:". top ." "left center right" ". bottom .";align-items:center;justify-items:center;}
.br .tslot{display:flex;flex-direction:column;align-items:center;gap:2px;}
.br .tslot.top{grid-area:top;} .br .tslot.left{grid-area:left;} .br .tslot.right{grid-area:right;} .br .tslot.bottom{grid-area:bottom;}
.br .tslot.turn .tempty{border-color:var(--green);color:var(--green);}
.br .tslot.win .tname{color:var(--green);}
.br .tempty{width:calc(30px*var(--k));height:calc(42px*var(--k));border:1px dashed var(--line2);display:flex;align-items:center;justify-content:center;color:var(--dim);font-size:10px;}
.br .tname{font-size:8.5px;color:var(--dim);letter-spacing:.08em;}
.br .tcenter{grid-area:center;text-align:center;}
.br .tinfo .big{font-size:20px;font-weight:800;color:var(--yellow);}
.br .tinfo .big .slash{font-size:12px;color:var(--dim);font-weight:600;}
.br .tinfo .lbl2{margin-top:1px;}
.br .tinfo .trk2{font-size:9px;color:var(--dim);margin-top:4px;letter-spacing:.06em;}
.br .handblock{border:1px solid var(--line2);padding:5px 4px 6px;}
.br .hlabel{margin:0 0 4px 2px;}
.br .hand{display:flex;flex-wrap:nowrap;justify-content:center;align-items:flex-start;min-height:44px;padding-top:calc(11px*var(--k));}
.br .hand .brcard{margin-left:calc(-27px*var(--k));transition:transform .1s;}
.br .hand .brcard.sm{margin-left:calc(-18px*var(--k));}
.br .hand .brcard:first-child{margin-left:0;}
.br .hand .brcard.clk:hover{transform:translateY(calc(-11px*var(--k)));z-index:20;}
.br .hand .brcard.sel,.br .hand .brcard.sug{z-index:18;}
.br .youhand .hand{min-height:74px;}
.br .sheet{border:1px solid var(--line);}
.br .shead,.br .srow{display:grid;grid-template-columns:1.3fr 1fr 1fr;}
.br .shead{border-bottom:1px solid var(--line2);}
.br .scol{padding:4px 6px;text-align:center;font-size:9px;letter-spacing:.12em;color:var(--dim);text-transform:uppercase;border-left:1px solid var(--line2);}
.br .srow{border-top:1px solid var(--line2);}
.br .slbl{padding:4px 8px;font-size:9.5px;letter-spacing:.08em;text-transform:uppercase;color:var(--dim);}
.br .sval{padding:4px 6px;text-align:center;border-left:1px solid var(--line2);font-size:12px;color:var(--ink);}
.br .sval.big{font-size:16px;font-weight:700;color:var(--yellow);}
.br .sval.vul{font-size:9px;letter-spacing:.1em;color:var(--dim);}
.br .sval.vul.on{color:var(--red);font-weight:700;}
.br .bar{display:flex;gap:7px;align-items:center;justify-content:center;flex-wrap:wrap;min-height:34px;}
.br .btn{font:inherit;font-size:11px;letter-spacing:.08em;text-transform:uppercase;font-weight:700;background:transparent;color:var(--ink);border:1px solid var(--ink);padding:6px 12px;cursor:pointer;}
.br .btn.primary{background:var(--green);color:var(--playink);border-color:var(--green);min-width:120px;text-align:center;}
.br .btn.ghost{border-color:var(--line);color:var(--dim);}
.br .btn.gold{background:var(--purple);color:var(--fillink);border-color:var(--purple);}
.br .btn:disabled{opacity:.3;cursor:default;color:var(--dim);border-color:var(--line);}
.br .hint{font-size:11px;color:var(--dim);text-align:center;line-height:1.4;min-height:16px;}
.br .hint b{color:var(--ink);}
.br .gsp{color:var(--sp);} .br .ghe{color:var(--he);} .br .gdi{color:var(--di);} .br .gcl{color:var(--cl);}
.br .lrn-l-mod{font-size:9px;letter-spacing:.14em;text-transform:uppercase;color:var(--dim);margin-bottom:3px;}
.br .lrn-l-body{margin:8px 0 4px;}
.br .lrn-l-para{font-size:12px;line-height:1.62;color:var(--ink);margin:0 0 10px;}
.br .lrn-xref{color:var(--rule);border-bottom:1px dotted var(--rule);cursor:pointer;font-style:italic;}
.br .lrn-nav{display:flex;gap:8px;margin-top:16px;border-top:1px solid var(--line2);padding-top:10px;}
.br .lrn-nav-b{flex:1;font:inherit;font-size:10px;font-weight:700;letter-spacing:.04em;color:var(--ink);background:transparent;border:1px solid var(--line);padding:8px 10px;cursor:pointer;text-align:left;line-height:1.3;}
.br .lrn-nav-b.right{text-align:right;}
.br .lrn-nav-b:disabled{opacity:0;cursor:default;}
.br .lrn-hist{display:flex;gap:2px;margin-right:8px;}
.br .lrn-hb{font:inherit;font-size:16px;line-height:1;font-weight:700;width:26px;height:24px;padding:0;color:var(--ink);background:transparent;border:1px solid var(--line);cursor:pointer;}
.br .lrn-hb:disabled{opacity:.3;cursor:default;}
.br .teachbox{border:1px solid var(--purple);background:var(--line2);padding:9px 11px;display:flex;gap:9px;align-items:flex-start;}
.br .teachbox .tb-tag{font-size:8.5px;letter-spacing:.16em;text-transform:uppercase;color:var(--purple);font-weight:700;padding-top:2px;flex:0 0 auto;}
.br .teachbox .tb-txt{font-size:11px;line-height:1.55;color:var(--ink);}
.br .teachbox .tb-body{flex:1;min-width:0;}
.br .gloss-term{color:var(--purple);border-bottom:1px dotted var(--purple);cursor:pointer;}
.br .tb-def{margin-top:7px;padding-top:7px;border-top:1px solid var(--line2);font-size:10.5px;line-height:1.5;color:var(--dim);}
.br .tb-def b{color:var(--purple);text-transform:capitalize;}
.br .tb-more{color:var(--purple);cursor:pointer;white-space:nowrap;}
.br .gterm{padding:8px 0;border-top:1px solid var(--line2);}
.br .gterm:first-child{border-top:0;}
.br .gterm.hot{background:var(--line2);margin:0 -6px;padding:8px 6px;}
.br .gt-name{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:capitalize;color:var(--purple);margin-bottom:2px;}
.br .gt-def{font-size:11px;line-height:1.5;color:var(--ink);}
.br .btn.ghost.on{border-color:var(--purple);color:var(--purple);}
.br .log{font-size:10px;color:var(--dim);line-height:1.5;text-align:center;}
.br .log b{color:var(--ink);}
.br .setwrap{display:flex;flex-direction:column;gap:9px;}
.br .setcard{border:1px solid var(--line2);padding:9px 10px;}
.br .partners{display:flex;align-items:center;justify-content:space-between;gap:8px;}
.br .pteam{display:flex;flex-direction:column;gap:2px;}
.br .pteam b{font-size:11px;letter-spacing:.1em;color:var(--purple);}
.br .pteam span{font-size:10px;color:var(--ink);}
.br .pvs{font-size:9px;color:var(--dim);letter-spacing:.1em;}
.br .setseat{display:grid;grid-template-columns:76px 116px 1fr;gap:8px;align-items:center;padding:5px 0;border-top:1px solid var(--line2);}
.br .setseat:first-of-type{border-top:0;}
.br .ss-pos{display:flex;flex-direction:column;gap:1px;}
.br .ss-abbr{font-size:13px;font-weight:700;color:var(--purple);}
.br .ss-blurb{line-height:1.3;letter-spacing:.04em;text-transform:none;font-size:9px;}
.br .setcard.resume{border-color:var(--purple);}
.br .rz-line{font-size:11px;color:var(--ink);margin:4px 0 7px;}
.br .rz-btns{display:flex;gap:7px;}
.br .setbtns{display:flex;flex-direction:column;gap:8px;align-items:center;margin-top:2px;}
.br .setlinks{display:flex;gap:8px;}
.br .startbtn{font:inherit;font-size:12px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;background:var(--green);color:var(--playink);border:1px solid var(--green);padding:10px 22px;cursor:pointer;width:100%;}
.br .revealgate{border:1px solid var(--line);padding:26px 16px;display:flex;flex-direction:column;align-items:center;gap:9px;text-align:center;}
.br .rg-glyph{font-size:34px;}
.br .rg-who{font-size:13px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;}
.br .overlay{position:fixed;inset:0;background:rgba(0,0,0,.66);display:flex;align-items:center;justify-content:center;padding:16px;z-index:40;}
.br .sheetmodal{background:var(--bg);border:1px solid var(--line);max-width:400px;width:100%;max-height:84vh;overflow:auto;}
.br .smhead{display:flex;align-items:center;justify-content:space-between;padding:10px 12px;border-bottom:1px solid var(--rule);position:sticky;top:0;background:var(--bg);}
.br .smbody{padding:12px;}
.br .rsec{margin-bottom:12px;}
.br .rsh{font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--purple);margin-bottom:5px;}
.br .rsl{font-size:11px;color:var(--ink);line-height:1.5;margin-bottom:3px;}
.br .result{border:1px solid var(--line);padding:14px;text-align:center;}
.br .result .rhead{font-size:15px;font-weight:700;letter-spacing:.04em;}
.br .result .rhead.made{color:var(--green);} .br .result .rhead.down{color:var(--red);}
.br .result .rdetail{font-size:10.5px;color:var(--dim);line-height:1.6;margin-top:7px;}
.br .result .rbig{font-size:22px;font-weight:800;color:var(--yellow);letter-spacing:.06em;margin-top:8px;}

/* ---- help drawer (table talk) ---- */
.br .dl-tab{position:fixed;top:50%;right:0;transform:translateY(-50%);z-index:40;display:flex;align-items:center;gap:5px;
  writing-mode:vertical-rl;font:inherit;font-size:9px;font-weight:800;letter-spacing:.18em;text-transform:uppercase;
  background:linear-gradient(180deg,var(--pink),var(--purple));color:#1a1205;border:0;border-radius:8px 0 0 8px;
  padding:12px 5px;cursor:pointer;box-shadow:-2px 0 10px rgba(0,0,0,.35);}
.br .dl-tab.open{right:min(360px,86vw);}
.br .dl-tab .dl-tab-l{writing-mode:vertical-rl;}
.br .help-drawer{position:fixed;top:0;right:0;height:100vh;width:min(360px,86vw);z-index:39;display:flex;flex-direction:column;
  background:color-mix(in srgb,var(--bg) 82%,#000);border-left:1px solid var(--line);box-shadow:-8px 0 26px rgba(0,0,0,.45);
  transform:translateX(101%);transition:transform .28s cubic-bezier(.4,.0,.2,1);}
.br .help-drawer.open{transform:translateX(0);}
.br .dl-top{display:flex;align-items:center;justify-content:space-between;padding:12px 13px;border-bottom:1px solid var(--line);flex:0 0 auto;}
.br .dl-title{font-size:11px;font-weight:800;letter-spacing:.24em;background:linear-gradient(92deg,var(--pink),var(--purple) 55%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}
.br .dl-x{font:inherit;font-size:20px;line-height:1;background:transparent;border:0;color:var(--dim);cursor:pointer;padding:0 4px;}
.br .dl-scroll{flex:1 1 auto;overflow-y:auto;padding:10px 12px 26px;-webkit-overflow-scrolling:touch;}
.br .dl-head{font-size:9px;font-weight:800;letter-spacing:.2em;text-transform:uppercase;color:var(--dim);margin:12px 0 7px;padding-bottom:4px;border-bottom:1px solid var(--line2);}
.br .dl-head:first-child{margin-top:0;}
/* a bidding line: seat badge (side-coloured), the call (suit-coloured), the meaning */
.br .dl-call{display:grid;grid-template-columns:22px 34px 1fr;gap:7px;align-items:baseline;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.045);line-height:1.4;}
.br .dl-seat{font-size:9px;font-weight:800;letter-spacing:.05em;text-align:center;border-radius:4px;padding:2px 0;}
.br .dl-call.us .dl-seat{color:var(--cyan);background:color-mix(in srgb,var(--cyan) 15%,transparent);}
.br .dl-call.them .dl-seat{color:var(--pink);background:color-mix(in srgb,var(--pink) 15%,transparent);}
.br .dl-bid{font-size:13px;font-weight:800;color:var(--ink);white-space:nowrap;}
.br .dl-bid.red{color:var(--pink);}
.br .dl-txt{font-size:11.5px;color:var(--ink);opacity:.92;}
.br .tagpill{display:inline-block;font-size:8px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:1px 5px;border-radius:9px;margin-left:5px;vertical-align:1px;}
.br .tagpill.conv{color:var(--purple);border:1px solid color-mix(in srgb,var(--purple) 55%,transparent);}
.br .tagpill.force{color:var(--cyan);border:1px solid color-mix(in srgb,var(--cyan) 45%,transparent);}
.br .tagpill.infer{color:var(--dim);border:1px solid var(--line2);}
.br .dl-call.inf .dl-txt{font-style:italic;opacity:.7;}
.br .dl-call.inf .dl-bid{opacity:.6;}
/* partner snapshot */
.br .dl-snap{margin:11px 0 4px;padding:10px 11px;border:1px solid var(--line2);border-radius:10px;background:color-mix(in srgb,var(--cyan) 7%,transparent);}
.br .dl-snap-h{font-size:9px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--cyan);margin-bottom:6px;}
.br .dl-snap-row{display:flex;justify-content:space-between;align-items:baseline;padding:2px 0;font-size:12px;}
.br .dl-snap-row span{font-size:9px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .dl-snap-row b{color:var(--ink);letter-spacing:.04em;}
/* play log */
.br .dl-trick{display:grid;grid-template-columns:auto 1fr;gap:10px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,.05);align-items:start;}
.br .dl-trick.live{grid-template-columns:1fr;}
.br .dl-trick-body{min-width:0;}
.br .dl-play{font-size:11px;color:var(--ink);opacity:.9;padding:1.5px 0;display:flex;gap:6px;align-items:baseline;}
.br .dl-play .dl-seat.sm{width:18px;font-size:8.5px;padding:1px 0;flex:0 0 auto;}
.br .dl-play.us{}
.br .dl-play.win{color:var(--green);font-weight:600;opacity:1;}
.br .dl-trick-sum{font-size:10.5px;color:var(--purple);font-weight:700;margin-top:4px;letter-spacing:.02em;}
.br .dl-live-h,.br .dl-hint-h{font-size:9px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--dim);margin-bottom:4px;}
/* mini trick diagram — diamond layout, small white cards */
.br .minitrick{display:grid;grid-template-columns:repeat(3,20px);grid-template-rows:repeat(3,26px);gap:1px;
  grid-template-areas:". top ." "left num right" ". bottom .";align-items:center;justify-items:center;}
.br .mt-slot{display:flex;flex-direction:column;align-items:center;gap:1px;}
.br .mt-slot.top{grid-area:top;} .br .mt-slot.left{grid-area:left;} .br .mt-slot.right{grid-area:right;} .br .mt-slot.bottom{grid-area:bottom;}
.br .mt-num{grid-area:num;font-size:8px;color:var(--dim);font-weight:700;}
.br .mcard{width:19px;height:23px;border-radius:3px;background:#f7f4ea;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1;box-shadow:0 1px 2px rgba(0,0,0,.4);}
.br .mcard.empty{background:transparent;box-shadow:none;border:1px dashed var(--line2);}
.br .mcard.win{outline:2px solid var(--green);outline-offset:1px;}
.br .mcard .mr{font-size:9px;font-weight:800;color:inherit;}
.br .mcard .ms{font-size:8px;color:inherit;margin-top:.5px;}
.br .mcard{color:#1a1a1a;}
.br .mcard.gsp{color:#1c6fd4;} .br .mcard.ghe{color:#b3232a;} .br .mcard.gdi{color:#b8860b;} .br .mcard.gcl{color:#1c7a3f;}
.br .mt-seat{font-size:7.5px;letter-spacing:.04em;color:var(--dim);font-weight:700;}
.br .mt-seat.win{color:var(--green);}
/* your-turn hint */
.br .dl-hint{margin:12px 0 4px;padding:10px 11px;border:1px solid color-mix(in srgb,var(--green) 40%,transparent);border-radius:10px;background:color-mix(in srgb,var(--green) 8%,transparent);}
.br .dl-hint-h{color:var(--green);}
.br .dl-hint-b{font-size:11.5px;color:var(--ink);line-height:1.45;}
.br .dl-empty{font-size:11.5px;color:var(--dim);line-height:1.5;padding:20px 4px;}
.br .dl-scroll .gloss-term{color:var(--yellow);border-bottom:1px dotted color-mix(in srgb,var(--yellow) 60%,transparent);cursor:pointer;}

/* ---- learn: lesson browser + drills ---- */
.br .lrn-open-btn{display:block;width:100%;margin-top:12px;font:inherit;font-size:12px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;
  padding:13px;border-radius:11px;border:0;cursor:pointer;color:#1a1205;background:linear-gradient(92deg,var(--pink),var(--purple) 55%,var(--cyan));}
.br .lrn-mini{font:inherit;font-size:8.5px;font-weight:800;letter-spacing:.1em;background:transparent;border:1px solid var(--line);color:var(--purple);border-radius:6px;padding:4px 7px;cursor:pointer;}
.br .lrn-overlay{position:fixed;inset:0;z-index:60;display:flex;flex-direction:column;background:var(--bg);}
.br .lrn-top{display:flex;align-items:center;justify-content:space-between;padding:14px 15px;border-bottom:1px solid var(--line);flex:0 0 auto;}
.br .lrn-title{font-size:13px;font-weight:800;letter-spacing:.22em;background:linear-gradient(92deg,var(--pink),var(--purple) 55%,var(--cyan));-webkit-background-clip:text;background-clip:text;color:transparent;}
.br .lrn-scroll{flex:1 1 auto;overflow-y:auto;padding:14px 15px 40px;max-width:640px;width:100%;margin:0 auto;-webkit-overflow-scrolling:touch;}
.br .lrn-intro{font-size:12px;color:var(--dim);line-height:1.55;margin-bottom:16px;}
.br .lrn-module{margin-bottom:16px;}
.br .lrn-mod-h{font-size:10px;font-weight:800;letter-spacing:.16em;text-transform:uppercase;color:var(--purple);margin-bottom:6px;padding-bottom:5px;border-bottom:1px solid var(--line2);}
.br .lrn-lrow{display:flex;width:100%;align-items:center;justify-content:space-between;gap:10px;font:inherit;text-align:left;
  background:transparent;border:0;border-bottom:1px solid rgba(255,255,255,.05);padding:9px 2px;cursor:pointer;color:var(--ink);}
.br .lrn-lrow-t{font-size:13px;}
.br .lrn-badge{font-size:8px;font-weight:800;letter-spacing:.1em;text-transform:uppercase;padding:2px 7px;border-radius:9px;flex:0 0 auto;}
.br .lrn-badge.drill{color:var(--cyan);border:1px solid color-mix(in srgb,var(--cyan) 45%,transparent);}
.br .lrn-badge.read{color:var(--dim);border:1px solid var(--line2);}
.br .lrn-back{font:inherit;font-size:11px;font-weight:700;letter-spacing:.05em;background:transparent;border:0;color:var(--purple);cursor:pointer;padding:0 0 10px;}
.br .lrn-l-title{font-size:19px;font-weight:800;color:var(--ink);margin:2px 0 4px;letter-spacing:.01em;}
.br .lrn-l-ref{font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);margin-bottom:12px;}
.br .lrn-l-teach{font-size:14px;line-height:1.62;color:var(--ink);opacity:.95;}
.br .lrn-l-teach .gloss-term{color:var(--yellow);border-bottom:1px dotted color-mix(in srgb,var(--yellow) 60%,transparent);cursor:pointer;}
.br .lrn-teachonly{margin-top:16px;font-size:12px;color:var(--dim);font-style:italic;line-height:1.5;}
.br .lrn-btn{font:inherit;font-size:12px;font-weight:800;letter-spacing:.08em;text-transform:uppercase;padding:11px 16px;border-radius:10px;border:0;cursor:pointer;color:#1a1205;background:linear-gradient(92deg,var(--purple),var(--cyan));margin-top:14px;}
.br .lrn-btn.big{display:block;width:100%;margin-top:22px;padding:14px;}
.br .lrn-btn.ghost{background:transparent;color:var(--dim);border:1px solid var(--line);margin-left:8px;}
/* drill */
.br .lrn-drill-top{display:flex;align-items:center;justify-content:space-between;}
.br .lrn-score{font-size:12px;color:var(--dim);letter-spacing:.05em;}
.br .lrn-contract{font-size:12.5px;color:var(--ink);margin:8px 0 4px;padding:9px 11px;border:1px solid var(--line2);border-radius:9px;background:color-mix(in srgb,var(--purple) 7%,transparent);}
.br .lrn-auction{display:flex;flex-wrap:wrap;gap:5px;margin:10px 0;}
.br .lrn-acall{display:inline-flex;gap:4px;align-items:baseline;font-size:11px;border:1px solid var(--line2);border-radius:6px;padding:3px 7px;}
.br .lrn-acall .s{font-size:8px;font-weight:800;letter-spacing:.05em;color:var(--dim);}
.br .lrn-acall.us .s{color:var(--cyan);} .br .lrn-acall.them .s{color:var(--pink);}
.br .lrn-acall .b{font-weight:800;color:var(--ink);} .br .lrn-acall .b.red{color:var(--pink);}
.br .lrn-yourhand-l,.br .lrn-prompt{font-size:9px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--dim);margin:14px 0 6px;}
.br .lrn-prompt{color:var(--ink);font-size:14px;letter-spacing:0;text-transform:none;font-weight:700;margin:16px 0 10px;}
.br .lrn-scenario{color:var(--ink);font-size:13px;line-height:1.5;background:var(--panel,rgba(255,255,255,.04));border-left:2px solid var(--line);padding:10px 12px;border-radius:6px;margin:12px 0 4px;}
.br .lrn-hand{padding:8px 6px;border:1px solid var(--line2);border-radius:10px;background:rgba(0,0,0,.14);}
.br .lrn-decldummy{display:flex;flex-direction:column;gap:2px;}
.br .lrn-decldummy .lrn-yourhand-l:first-of-type{margin-top:4px;}
.br .lrn-suit{display:flex;gap:3px;flex-wrap:wrap;}
.br .lrn-choices{display:flex;flex-wrap:wrap;gap:8px;}
.br .lrn-choice{font:inherit;font-size:15px;font-weight:800;min-width:52px;padding:11px 12px;border-radius:9px;border:1px solid var(--line);background:transparent;color:var(--ink);cursor:pointer;}
.br .lrn-choice.red{color:var(--pink);}
.br .lrn-choice:disabled{cursor:default;}
.br .lrn-choice.correct{border-color:var(--green);background:color-mix(in srgb,var(--green) 18%,transparent);color:var(--green);}
.br .lrn-choice.wrong{border-color:var(--pink);background:color-mix(in srgb,var(--pink) 16%,transparent);}
.br .lrn-reveal{margin-top:16px;padding:13px;border-radius:11px;border:1px solid var(--line2);}
.br .lrn-reveal.ok{border-color:color-mix(in srgb,var(--green) 45%,transparent);background:color-mix(in srgb,var(--green) 8%,transparent);}
.br .lrn-reveal.no{border-color:color-mix(in srgb,var(--pink) 40%,transparent);background:color-mix(in srgb,var(--pink) 7%,transparent);}
.br .lrn-verdict{font-size:13px;font-weight:800;color:var(--ink);margin-bottom:6px;}
.br .lrn-reveal.ok .lrn-verdict{color:var(--green);} .br .lrn-reveal.no .lrn-verdict{color:var(--pink);}
.br .lrn-why{font-size:13px;line-height:1.55;color:var(--ink);opacity:.94;}
.br .lrn-why .gloss-term{color:var(--yellow);border-bottom:1px dotted color-mix(in srgb,var(--yellow) 60%,transparent);cursor:pointer;}
.br .lrn-fail{font-size:13px;color:var(--dim);margin-bottom:10px;}

/* ============================================================
   FIXED APP SHELL — status bar / screen / tab bar. Nothing at
   the top level scrolls; each game screen is sized to fit a
   phone, and only the Table Talk tab (a log) scrolls inside.
   ============================================================ */
.br .stage{flex:1 1 auto;min-height:0;width:100%;max-width:640px;margin:0 auto;display:flex;flex-direction:column;overflow:hidden;}
/* --- top status bar (constant height) --- */
.br .gstatus{flex:0 0 auto;display:flex;align-items:center;gap:8px;padding:7px 10px;border-bottom:1px solid var(--rule);}
.br .gs-menu{font:inherit;font-size:19px;line-height:1;background:transparent;border:1px solid var(--line);color:var(--ink);padding:3px 9px;cursor:pointer;flex:0 0 auto;}
.br .gs-mid{flex:1 1 auto;min-width:0;text-align:center;}
.br .gs-title{font-size:12px;font-weight:800;letter-spacing:.04em;color:var(--ink);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-title b{color:var(--ink);}
.br .gs-turn{font-size:9.5px;letter-spacing:.06em;color:var(--dim);margin-top:1px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.br .gs-hint{flex:0 0 auto;}
.br .gs-sug{font:inherit;font-size:9px;font-weight:800;letter-spacing:.09em;text-transform:uppercase;background:transparent;border:1px solid var(--purple);color:var(--purple);padding:5px 8px;cursor:pointer;}
.br .gs-sug.on{background:var(--purple);color:var(--fillink);}
.br .gs-score{flex:0 0 auto;display:flex;flex-direction:column;align-items:flex-end;gap:1px;font-size:9px;letter-spacing:.06em;color:var(--dim);line-height:1.25;}
.br .gs-score .gs-games{font-size:12px;font-weight:700;color:var(--yellow);}
.br .gs-vul{font-size:8px;letter-spacing:.1em;text-transform:uppercase;color:var(--dim);}
.br .gs-vul.on{color:var(--red);font-weight:700;}
/* --- screen container --- */
.br .gscreen{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;overflow:hidden;}
/* --- bottom tab bar --- */
.br .gtabs{flex:0 0 auto;display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--rule);padding-bottom:env(safe-area-inset-bottom,0);}
.br .gtab{position:relative;font:inherit;font-size:11px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;
  background:transparent;border:0;color:var(--dim);padding:15px 0;cursor:pointer;}
.br .gtab+.gtab{border-left:1px solid var(--line2);}
.br .gtab.on{color:var(--ink);background:var(--line2);box-shadow:inset 0 2px 0 var(--purple)!important;}
.br .gt-dot{position:absolute;top:11px;margin-left:5px;width:7px;height:7px;border-radius:50%!important;background:var(--green);display:inline-block;}

/* --- BID screen --- */
.br .bidscreen{display:flex;flex-direction:column;height:100%;min-height:0;gap:6px;padding:8px;}
.br .seatstrip{flex:0 0 auto;display:grid;grid-template-columns:repeat(4,1fr);gap:4px;}
.br .ss-cell{border:1px solid var(--line2);padding:4px 5px;min-width:0;--accent:var(--purple);}
.br .ss-cell.act{background:var(--line2);border-color:var(--line);}
.br .ss-cell.me{border-color:var(--accent);}
.br .ss-nm{font-size:9px;font-weight:700;letter-spacing:.02em;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:3px;}
.br .ss-gl{color:var(--accent);font-size:11px;}
.br .ss-meta{display:flex;gap:5px;margin-top:2px;align-items:baseline;}
.br .ss-seat{font-size:8px;letter-spacing:.08em;text-transform:uppercase;color:var(--dim);}
.br .ss-deal{font-size:7.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--purple);}
.br .ss-vul{font-size:7.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--red);font-weight:700;}
.br .bid-elastic{flex:1 1 auto;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:8px;-webkit-overflow-scrolling:touch;}
.br .bidscreen .youhand{flex:0 0 auto;}
.br .bidscreen .bidbox2{flex:0 0 auto;}
.br .waitbar{flex:0 0 auto;padding:10px;}

/* --- PLAY screen --- */
.br .playscreen{display:flex;flex-direction:column;height:100%;min-height:0;gap:6px;padding:8px;}
.br .contractline{flex:0 0 auto;text-align:center;font-size:11px;color:var(--dim);letter-spacing:.02em;}
.br .contractline b{color:var(--ink);}
.br .play-elastic{flex:1 1 auto;min-height:0;overflow-y:auto;display:flex;flex-direction:column;gap:8px;-webkit-overflow-scrolling:touch;}
.br .play-elastic .tricktable{height:auto;flex:1 1 auto;min-height:168px;}
.br .playscreen .handblock{flex:0 0 auto;}
.br .playfoot{flex:0 0 auto;min-height:44px;display:flex;align-items:center;justify-content:center;}
.br .playconfirm{font:inherit;font-size:15px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;
  width:100%;padding:12px;background:var(--green);color:var(--playink);border:1px solid var(--green);cursor:pointer;display:flex;align-items:center;justify-content:center;gap:2px;}
.br .playhint{font-size:10px;}

/* --- RESULT screen --- */
.br .resultscreen{height:100%;min-height:0;overflow-y:auto;display:flex;flex-direction:column;justify-content:center;gap:12px;padding:14px;}

/* --- TABLE TALK (full-width tab) --- */
.br .talkwrap{height:100%;min-height:0;display:flex;flex-direction:column;}
.br .dl-full{flex:1 1 auto;min-height:0;overflow-y:auto;width:100%;padding:12px 14px 34px;-webkit-overflow-scrolling:touch;}
.br .dl-full .dl-trick{grid-template-columns:auto 1fr;gap:14px;}

/* --- MENU overlay --- */
.br .smbody.menu{display:flex;flex-direction:column;gap:13px;}
.br .menu-row{display:flex;align-items:center;justify-content:space-between;gap:10px;}
.br .menu-acts{display:grid;grid-template-columns:1fr 1fr;gap:8px;}
`;



//#region gen (auto — removed when bundled to a single bridge.jsx)
export { THEME_CSS };
//#endregion gen
