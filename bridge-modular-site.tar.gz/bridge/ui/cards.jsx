//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { SUIT_GLYPH } from "../state/constants.js";
//#endregion gen

const IDXSUIT=new Set(["J","Q","K","A"]);
const PIPS={
  "2":[[50,27],[50,73]],
  "3":[[50,27],[50,50],[50,73]],
  "4":[[34,27],[66,27],[34,73],[66,73]],
  "5":[[34,27],[66,27],[50,50],[34,73],[66,73]],
  "6":[[34,27],[66,27],[34,50],[66,50],[34,73],[66,73]],
  "7":[[34,27],[66,27],[50,38.5],[34,50],[66,50],[34,73],[66,73]],
  "8":[[34,27],[66,27],[50,38.5],[34,50],[66,50],[50,61.5],[34,73],[66,73]],
  "9":[[34,26],[66,26],[34,42],[66,42],[50,50],[34,58],[66,58],[34,74],[66,74]],
  "10":[[34,26],[66,26],[50,34],[34,42],[66,42],[34,58],[66,58],[50,66],[34,74],[66,74]],
};
const suitClass=su=>su==="S"?"s-sp":su==="H"?"s-he":su==="D"?"s-di":"s-cl";
const Corner=({rank,glyph,pos})=>(
  <div className={"idx "+pos}><span className="ir">{rank}</span>{glyph!=null&&<span className="is">{glyph}</span>}</div>
);
function Card({c,faceDown,onClick,disabled,selected,suggested,small}){
  if(faceDown) return <div onClick={onClick} className={"brback"+(small?" sm":"")} style={{cursor:onClick?"pointer":"default"}}/>;
  const g=SUIT_GLYPH[c.suit];
  const cls=["brcard",suitClass(c.suit),small?"sm":"",selected?"sel":"",suggested?"sug":"",
    (onClick&&!disabled)?"clk":"",disabled?"dis":""].filter(Boolean).join(" ");
  const idxGlyph=IDXSUIT.has(c.rank)?g:null;
  let center;
  if(c.rank==="A") center=<div className="ctr"><span className="pip ace" style={{left:"50%",top:"50%"}}>{g}</span></div>;
  else if(c.rank==="J"||c.rank==="Q"||c.rank==="K") center=<div className="mid fc">{c.rank}</div>;
  else center=<div className="ctr">{(PIPS[c.rank]||[]).map(([x,y],i)=>(
    <span key={i} className={"pip"+(y>50?" flip":"")} style={{left:x+"%",top:y+"%"}}>{g}</span>))}</div>;
  return <div onClick={disabled?undefined:onClick} className={cls}>
    <Corner rank={c.rank} glyph={idxGlyph} pos="tl"/>
    <Corner rank={c.rank} glyph={idxGlyph} pos="br"/>
    {center}
  </div>;
}
const Empty=({small})=><div className={"brcard"+(small?" sm":"")} style={{background:"transparent",border:"1px dashed var(--line)"}}/>;


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { Card, Corner, Empty, IDXSUIT, PIPS, suitClass };
//#endregion gen
