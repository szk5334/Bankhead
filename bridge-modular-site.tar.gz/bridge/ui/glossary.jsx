//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { C, btn } from "./theme.js";
//#endregion gen

/* wrap known glossary terms in a string as tappable spans (first occurrence of each) */
/* Colorize bare suit glyphs in running text to match the four-colour deck: spades blue,
   hearts red, diamonds gold, clubs green. Returns an array of strings and colored spans. */
function suitColorClass(suit){ return suit==="S"?"gsp":suit==="H"?"ghe":suit==="D"?"gdi":suit==="C"?"gcl":""; }
function colorizeSuits(str, kp){
  if(!str || typeof str!=="string") return [str];
  if(!/[\u2660\u2665\u2666\u2663]/.test(str)) return [str];
  const out=[]; let last=0, m; const re=/[\u2660\u2665\u2666\u2663]\uFE0E?/g;
  const clsOf={"\u2660":"gsp","\u2665":"ghe","\u2666":"gdi","\u2663":"gcl"};
  while((m=re.exec(str))){
    if(m.index>last) out.push(str.slice(last,m.index));
    out.push(<span key={(kp||"s")+m.index} className={clsOf[m[0][0]]}>{m[0]}</span>);
    last=m.index+m[0].length;
  }
  if(last<str.length) out.push(str.slice(last));
  return out;
}
function linkifyGlossary(text, gloss, onTap){
  const keys=Object.keys(gloss||{}); if(!keys.length || !text) return colorizeSuits(text,"c");
  const esc=s=>s.replace(/[.*+?^${}()|[\]\\]/g,"\\$&");
  const ordered=keys.slice().sort((a,b)=>b.length-a.length);
  let re; try{ re=new RegExp("\\b("+ordered.map(esc).join("|")+")(es|s)?\\b","gi"); }catch(_){ return colorizeSuits(text,"c"); }
  const out=[]; let last=0,m; const seen=new Set();
  while((m=re.exec(text))){
    const whole=m[0], start=m.index, base=m[1].toLowerCase();
    const key=ordered.find(k=>k.toLowerCase()===base);
    if(!key || seen.has(key)) continue;
    seen.add(key);
    if(start>last) out.push(...colorizeSuits(text.slice(last,start),"a"+start));
    out.push(<span key={start} className="gloss-term" onClick={(e)=>{e.stopPropagation();onTap(key);}}>{colorizeSuits(whole,"g"+start)}</span>);
    last=start+whole.length;
  }
  if(last<text.length) out.push(...colorizeSuits(text.slice(last),"z"+last));
  return out;
}

function GlossaryScreen({onClose, gloss, focusTerm}){
  const terms=Object.keys(gloss).sort();
  const ref=React.useRef(null);
  React.useEffect(()=>{ if(focusTerm && ref.current){ try{ ref.current.scrollIntoView({block:"center"}); }catch(_){} } },[focusTerm]);
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheetmodal" onClick={e=>e.stopPropagation()}>
        <div className="smhead"><div className="wordmark sm">GLOSSARY</div><button style={btn("ghost",true)} onClick={onClose}>Close</button></div>
        <div className="smbody">
          {terms.map(t=>(
            <div key={t} className={"gterm"+(t===focusTerm?" hot":"")} ref={t===focusTerm?ref:null}>
              <div className="gt-name">{t}</div>
              <div className="gt-def">{gloss[t]}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { GlossaryScreen, colorizeSuits, linkifyGlossary, suitColorClass };
//#endregion gen
