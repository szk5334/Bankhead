//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { AUC } from "../engine/auction.js";
import { ENG } from "../engine/core.js";
import { SOL } from "../engine/solitaire.js";
import { SEAT_ABBR, SEAT_NAME, STRAIN_GLYPH, SUIT_GLYPH } from "../state/constants.js";
import { previewKey } from "../state/reducer.js";
import { FanHand } from "./fanHand.jsx";
import { suitColorClass } from "./glossary.jsx";
import { BidVerdict, BiddingBox, CallChip } from "./table.jsx";
//#endregion gen

/* solitaireTable.jsx — FOUR HANDS, ALWAYS, AND A SCREEN THAT NEVER MOVES.
 *
 * THE HARD CONSTRAINT: no scrolling, no reflow, no layout shift. Ever. Not when the turn passes, not when a
 * grade lands, not when a card is played. A table that jumps under your thumb is worse than one that shows
 * less, because you stop trusting where things are.
 *
 * Everything below follows from that:
 *   - FOUR STACKED ROWS, not a compass. On a phone, West and East as vertical fans are cramped and force a
 *     DIFFERENT drag axis per seat. Rows give one uniform horizontal scrub for every hand, the tightest
 *     vertical budget, and — the point — a geometry that is IDENTICAL whoever is to play. Only the
 *     highlight moves.
 *   - EVERY ROW RESERVES THE LIFT SPACE, even when it is not the active seat. Otherwise the row would grow
 *     the moment you touched it and shove the other three hands down the screen.
 *   - THE TEACHING PANEL IS A FIXED BOX. Content scrolls INSIDE it. It never grows to fit its contents,
 *     because growing is how a panel pushes the table off the bottom of the screen.
 *
 * THE LIVE GRADE IS FREE. One double-dummy solve per POSITION returns the value of every legal card at once
 * (reducer.maybeEnqueuePreview). So as your thumb travels the fan, the cost of every card you touch is
 * already known — you find out what a card is worth BEFORE you commit to it. That is the entire difference
 * between a teacher and a scorekeeper, and it is why the panel tracks the scrub rather than the play.
 *
 * The SD lens ("would you have found it if you COULDN'T see their hands?") is deliberately NOT here. It is
 * 668 ms/card and it is a nudge; showing it live would answer the very question the mode exists to ask.
 * It lands in the post-hand analysis.
 */

const SEAT_ORDER = [2, 3, 0, 1];        // N, E, S, W — around the table, in play order
const ROW_H = 84;                        // fixed. lift room is reserved in EVERY row, active or not.

/* ---------------- status ---------------- */
function SolStatus({ s, onUndo, canUndo }) {
  const ct = s.contract;
  const turn = s.phase === "auction" ? AUC.turnSeat(s.calls, s.dealer) : s.turn;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8, height: 34, padding: "0 8px",
      fontSize: 12, borderBottom: "1px solid rgba(127,127,127,0.25)" }}>
      <b style={{ fontSize: 13 }}>
        {ct ? <>{ct.level}<span className={suitColorClass(ct.strain)}>{STRAIN_GLYPH[ct.strain]}</span>{ct.dbl === 2 ? "X" : ct.dbl === 4 ? "XX" : ""} by {SEAT_ABBR[ct.declarer]}</>
            : "Auction"}
      </b>
      {ct ? <span style={{ opacity: 0.7 }}>NS {s.tricks[0]} · EW {s.tricks[1]}</span> : null}
      <span style={{ flex: 1 }} />
      <span style={{ opacity: 0.75 }}>{SEAT_NAME[turn]} to {s.phase === "auction" ? "bid" : "play"}</span>
      <button onClick={onUndo} disabled={!canUndo}
        style={{ fontSize: 11, padding: "3px 8px", borderRadius: 6, opacity: canUndo ? 1 : 0.35 }}>Undo</button>
    </div>
  );
}

/* ---------------- one seat's row ---------------- */
function SeatRow({ s, seat, active, focusCard, onFocus, onPlay }) {
  const hand = s.hands[seat] || [];
  const legalIds = React.useMemo(() => {
    if (!active || s.phase !== "play") return new Set();
    return new Set(ENG.legalPlays(hand, s.trick.length ? s.ledSuit : null).map(c => c.id));
  }, [active, hand, s.trick.length, s.ledSuit, s.phase]);

  const declSide = s.contract && (seat === s.contract.declarer || seat === (s.contract.declarer + 2) % 4);
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 6, height: ROW_H, padding: "0 6px",
      // Only the HIGHLIGHT moves. The geometry is identical for every seat, every turn.
      background: active ? "rgba(90,160,255,0.10)" : "transparent",
      borderLeft: "3px solid " + (active ? "#5aa0ff" : "transparent"),
    }}>
      <div style={{ width: 22, flexShrink: 0, textAlign: "center" }}>
        <div style={{ fontSize: 12, fontWeight: 700, opacity: active ? 1 : 0.55 }}>{SEAT_ABBR[seat]}</div>
        {s.contract ? <div style={{ fontSize: 8, opacity: 0.45 }}>{declSide ? "decl" : "def"}</div> : null}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <FanHand cards={hand} legalIds={legalIds} active={active && s.phase === "play"}
          onFocus={onFocus} onPlay={onPlay} height={ROW_H - 6} cardW={38} />
      </div>
      <button
        onClick={() => focusCard && onPlay(focusCard)}
        disabled={!active || s.phase !== "play" || !focusCard}
        style={{ width: 46, flexShrink: 0, fontSize: 11, padding: "5px 0", borderRadius: 6,
          opacity: (active && focusCard) ? 1 : 0.25 }}>
        Play
      </button>
    </div>
  );
}

/* ---------------- the trick ---------------- */
function TrickStrip({ s }) {
  const played = new Map((s.trick || []).map(t => [t.seat, t.card]));
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, height: 40, padding: "0 10px",
      borderTop: "1px solid rgba(127,127,127,0.25)", borderBottom: "1px solid rgba(127,127,127,0.25)",
      fontSize: 12 }}>
      <span style={{ opacity: 0.5, fontSize: 10 }}>TRICK {Math.min(13, (s.tricksPlayed || 0) + 1)}</span>
      {SEAT_ORDER.map(seat => {
        const c = played.get(seat);
        return (
          <span key={seat} style={{ display: "flex", alignItems: "center", gap: 3, opacity: c ? 1 : 0.3 }}>
            <span style={{ fontSize: 9, opacity: 0.6 }}>{SEAT_ABBR[seat]}</span>
            {c ? <b>{c.rank}<span className={suitColorClass(c.suit)}>{SUIT_GLYPH[c.suit]}</span></b>
               : <span style={{ opacity: 0.4 }}>·</span>}
          </span>
        );
      })}
    </div>
  );
}

/* ---------------- the teaching panel (fixed box, scrolls inside) ---------------- */
const PANEL_H = 178;

function CardVerdict({ dd, cardKey, seat, s }) {
  if (!dd) return <div style={{ opacity: 0.45, fontSize: 11 }}>Solving this position…</div>;
  const g = SOL.gradeCard(dd, cardKey);
  if (g.kind === "none") return null;
  const gl = (k) => { const i = k.lastIndexOf("."); return k.slice(0, i) + (SUIT_GLYPH[k.slice(i + 1)] || ""); };
  const declSide = s.contract && (seat === s.contract.declarer || seat === (s.contract.declarer + 2) % 4);
  const side = declSide ? "declarer" : "the defence";

  // FORCED and FREE are NOT decisions, and saying so is a teaching act. If a singleton or a set of
  // double-dummy-identical cards paid the same praise as a real choice, "playing well" would mean "being
  // dealt easy cards". Grade the decisions; stay quiet about everything else.
  if (g.kind === "forced")
    return <Note color="#8a8a8a" tag="forced" title={gl(cardKey)}
      body={`Only one legal card. Not a decision — nothing to get right or wrong.`} />;
  if (g.kind === "free")
    return <Note color="#8a8a8a" tag="all equal" title={gl(cardKey)}
      body={`Every legal card here takes exactly ${g.best} trick${g.best === 1 ? "" : "s"} for ${side}. Genuinely nothing to choose — this one is free.`} />;

  const perfect = g.optimal;
  return (
    <Note color={perfect ? "#3aa657" : "#c0503f"}
      tag={perfect ? "double-dummy best" : `costs ${g.lost} trick${g.lost === 1 ? "" : "s"}`}
      title={gl(cardKey)}
      body={perfect
        ? `Optimal. With every hand face up, no card does better for ${side} — ${g.best} tricks.`
        : `This takes ${g.val} for ${side}; the best card takes ${g.best}. You are throwing away ${g.lost} trick${g.lost === 1 ? "" : "s"}.`}
      extra={!perfect && g.equiv.length
        ? <>Best here: {g.equiv.slice(0, 4).map(gl).join("  ")}</>
        : null} />
  );
}

function Note({ color, tag, title, body, extra }) {
  return (
    <div style={{ padding: "6px 9px", borderRadius: 8, fontSize: 11.5, lineHeight: 1.45,
      background: "rgba(127,127,127,0.10)", borderLeft: "3px solid " + color }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 2 }}>
        <b>{title}</b>
        <em style={{ fontSize: 9, padding: "1px 6px", borderRadius: 9, color: "#fff", background: color }}>{tag}</em>
      </div>
      <div style={{ opacity: 0.85 }}>{body}</div>
      {extra ? <div style={{ marginTop: 3, opacity: 0.7 }}>{extra}</div> : null}
    </div>
  );
}

/* ---------------- the table ---------------- */
function SolitaireTable({ s, dispatch }) {
  const [focus, setFocus] = React.useState(null);     // the card under your thumb, per seat
  const turn = s.phase === "auction" ? AUC.turnSeat(s.calls, s.dealer) : s.turn;

  // The live, perfect-information answer for THIS position. One solve, every card valued.
  const dd = React.useMemo(() => {
    if (s.phase !== "play") return null;
    const g = (s.grades || {})[previewKey(s)];
    return (g && g.mode === "solitaire") ? g.dd : null;
  }, [s.grades, s.tricksPlayed, s.trick && s.trick.length, s.phase]);

  React.useEffect(() => { setFocus(null); }, [turn, s.tricksPlayed, s.phase]);

  const play = (card) => { if (card) { setFocus(null); dispatch({ type: "PLAY", player: turn, cardId: card.id }); } };
  const canUndo = !!(s.undo && s.undo.length);

  const lastCall = React.useMemo(() => {
    for (let i = (s.calls || []).length - 1; i >= 0; i--) if (s.calls[i].grade) return s.calls[i];
    return null;
  }, [s.calls]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
      <SolStatus s={s} onUndo={() => dispatch({ type: "UNDO" })} canUndo={canUndo} />

      {/* four hands, always, in a geometry that never changes */}
      <div style={{ flexShrink: 0 }}>
        {SEAT_ORDER.map(seat => (
          <SeatRow key={seat} s={s} seat={seat} active={seat === turn}
            focusCard={seat === turn ? focus : null}
            onFocus={setFocus} onPlay={play} />
        ))}
      </div>

      <TrickStrip s={s} />

      {/* the auction ladder, compact, in place */}
      {s.phase === "auction" ? (
        <div style={{ display: "flex", flexWrap: "wrap", gap: 4, padding: "5px 8px", minHeight: 26 }}>
          {(s.calls || []).map((c, i) => (
            <span key={i} style={{ display: "flex", alignItems: "center", gap: 2 }}>
              <span style={{ fontSize: 8, opacity: 0.5 }}>{SEAT_ABBR[c.by]}</span>
              <CallChip c={c} grade={c.grade} />
            </span>
          ))}
        </div>
      ) : null}

      {/* FIXED-HEIGHT teaching panel. It scrolls inside; it never grows. */}
      <div style={{ height: PANEL_H, flexShrink: 0, overflowY: "auto", padding: "6px 8px",
        borderTop: "1px solid rgba(127,127,127,0.25)" }}>
        {s.phase === "auction"
          ? <BiddingBox s={s} seat={turn} dispatch={dispatch} suggestion={null} />
          : focus
            ? <CardVerdict dd={dd} cardKey={`${focus.rank}.${focus.suit}`} seat={turn} s={s} />
            : <div style={{ opacity: 0.5, fontSize: 11, lineHeight: 1.5 }}>
                Slide along {SEAT_NAME[turn]}'s hand to weigh a card. Flick it up — or press Play — to play it.
                <div style={{ marginTop: 4, opacity: 0.8 }}>
                  Every hand is face up, so the double-dummy answer here is not an estimate. It is the truth.
                </div>
              </div>}
      </div>
    </div>
  );
}

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { SolitaireTable, SeatRow, TrickStrip, CardVerdict, SEAT_ORDER, ROW_H, PANEL_H };
//#endregion gen
