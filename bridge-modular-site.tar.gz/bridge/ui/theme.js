/* =======================================================================
   UI THEME (felt-and-brass card table)
   ===================================================================== */
const C={ gold:"var(--purple)", brass:"var(--line)", cream:"var(--ink)", dim:"var(--dim)",
  card:"var(--card)", ink:"var(--fillink)", red:"var(--red)" };
const btn=(kind="gold",small)=>{
  const base={borderRadius:0,fontWeight:700,padding:small?"5px 11px":"7px 13px",cursor:"pointer",
    fontSize:small?10.5:11,fontFamily:"var(--mono)",letterSpacing:".09em",textTransform:"uppercase",
    border:"1px solid var(--line)",background:"transparent",color:"var(--ink)"};
  if(kind==="gold") return {...base,background:"var(--green)",color:"var(--playink)",border:"1px solid var(--green)"};
  if(kind==="red")  return {...base,color:"var(--red)",border:"1px solid var(--red)"};
  return {...base,color:"var(--dim)"};
};
const lbl={fontSize:9,letterSpacing:".18em",textTransform:"uppercase",color:"var(--dim)",fontWeight:700,fontFamily:"var(--mono)"};


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { C, btn, lbl };
//#endregion gen
