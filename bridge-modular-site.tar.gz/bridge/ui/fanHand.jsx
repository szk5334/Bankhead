//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { sortHandDisplay } from "../state/constants.js";
import { Card } from "./cards.jsx";
//#endregion gen

/* fanHand.jsx — THE HAND, AS A FAN YOU SCRUB THROUGH.
 *
 * The old model made you hunt for a card among overlapping slivers and tap a target the width of a match.
 * This one: slide a finger along the hand, the card under your thumb LIFTS and the rest SPREAD AWAY from it
 *
 *        /// /// ///   ▲K♠   ///// ///// /////
 *
 * so the card you are considering is fully readable without the hand ever changing size or position.
 *
 * THREE INVARIANTS, and every one of them is load-bearing:
 *
 * 1. THE HAND'S FOOTPRINT NEVER CHANGES. The container is a fixed box. Cards are displaced INSIDE it, and
 *    the displacement decays to zero at both ends, so the outermost cards never move and nothing is ever
 *    pushed off-screen. A hand that grows when you touch it would shove the rest of the table around, which
 *    is the whole thing we are trying to avoid.
 *
 * 2. EVERY CARD STAYS ON SCREEN, ALWAYS. Illegal cards are not removed and not collapsed — they are rendered
 *    in place, darkened, and they still take part in the spread. You can always see your whole hand. They
 *    simply cannot take focus: the scrub snaps only to LEGAL cards.
 *
 * 3. HIT-TESTING USES BASE POSITIONS, NEVER DISPLACED ONES. This is the subtle one. If you hit-test against
 *    the cards where they are currently DRAWN, then moving the focus moves the cards, which moves the thing
 *    you are hit-testing against, which moves the focus — the fan oscillates and judders under your finger.
 *    The base layout is a fixed ruler; the spread is a pure render effect on top of it.
 *
 * Pure geometry lives in `fanLayout` so it can be unit-tested with no DOM and no React.
 */

/* ---------------- pure geometry ----------------
 * n         : number of cards
 * width     : container width, px (fixed)
 * cardW     : card width, px
 * focus     : focused index, or null
 * gap       : how far the neighbours of the focused card are pushed away, px
 * lift      : how far the focused card rises, px
 *
 * returns [{ i, x, y, z, focused }] — x is the LEFT edge, in px, inside the container.
 */
function fanLayout(n, width, cardW, focus, gap = 26, lift = 20) {
  if (n <= 0) return [];
  if (n === 1) return [{ i: 0, x: (width - cardW) / 2, y: focus === 0 ? -lift : 0, z: 1, focused: focus === 0 }];

  // Base ruler: evenly overlapped, first card flush left, last card flush right. Independent of focus.
  const pitch = (width - cardW) / (n - 1);
  const out = [];
  for (let i = 0; i < n; i++) {
    let d = 0;
    if (focus != null && focus >= 0 && focus < n && i !== focus) {
      // Displace AWAY from the focus, ramping to zero at the ends so the ends stay pinned. Cards adjacent to
      // the focus move the most; the outermost cards do not move at all.
      if (i < focus)      d = -gap * (i / focus);                       // i=0 -> 0 (pinned)
      else                d = +gap * ((n - 1 - i) / (n - 1 - focus));   // i=n-1 -> 0 (pinned)
    }
    const focused = focus === i;
    out.push({ i, x: i * pitch + d, y: focused ? -lift : 0, z: focused ? 100 : i, focused });
  }
  return out;
}

/* Which LEGAL index is nearest a touch at `px` (container-relative)? Measured against the BASE ruler — see
 * invariant 3. Illegal cards are invisible to this, so a scrub glides straight over them. */
function nearestLegal(px, n, width, cardW, legalIdx) {
  if (!legalIdx.length) return null;
  const pitch = n > 1 ? (width - cardW) / (n - 1) : 0;
  let best = legalIdx[0], bestD = Infinity;
  for (const i of legalIdx) {
    const c = i * pitch + cardW / 2;         // BASE centre, not the drawn centre
    const d = Math.abs(px - c);
    if (d < bestD) { bestD = d; best = i; }
  }
  return best;
}

/* ---------------- the card face ----------------
 * THE REAL CARD. Not a bespoke stub — the same `Card` the rest of the app draws, with its pip patterns and
 * its corner indices. A card that looks different in one mode is a card the player has to re-learn, and the
 * whole point of this pass is that a card is a card is a card.
 *
 * Its size lives in CSS (`.brcard` = 42x58 px scaled by --k; `.sm` = 30x42), so the geometry READS that
 * scale rather than hard-coding a number. Hard-coding it would silently desynchronise the fan from the cards
 * the moment anyone touched the theme.
 */
const CARD_W = { normal: 42, small: 30 };
const CARD_H = { normal: 58, small: 42 };

/* ---------------- the fan ----------------
 * cards     : [{id,rank,suit}] in display order
 * legalIds  : Set of playable card ids ("" => none playable, e.g. not this seat's turn)
 * onFocus   : (card|null) -> void   — fires as you scrub, so the teaching panel can track your thumb
 * onPlay    : (card) -> void        — flick up, or the Play button
 * active    : is this the seat to act?
 */
function FanHand({ hand, legalIds, onFocus, onPlay, active, small = true, height }) {
  const ref = React.useRef(null);
  const [w, setW] = React.useState(320);
  const [k, setK] = React.useState(1);
  const [focus, setFocus] = React.useState(null);
  const drag = React.useRef(null);

  /* SORTED, ALWAYS, AND BY THE APP'S OWN RULE. sortHandDisplay groups by suit and runs LOW -> HIGH within
   * each one. The solitaire table used to hand its raw dealt hands straight to the fan, so they came out in
   * shuffle order — four hands on screen, none of them readable. A hand you cannot read is not a hand. */
  const cards = React.useMemo(() => sortHandDisplay(hand || []), [hand]);

  const size = small ? "small" : "normal";
  const cardW = CARD_W[size] * k;
  const cardH = CARD_H[size] * k;
  const H = height || (cardH + 22);          // lift room, reserved whether or not this seat is active

  React.useEffect(() => {
    const el = ref.current; if (!el) return;
    const measure = () => {
      setW(el.clientWidth || 320);
      // Read the card scale from CSS rather than assuming it. --k is what the theme actually uses.
      try {
        const kv = parseFloat(getComputedStyle(el).getPropertyValue("--k"));
        if (kv && isFinite(kv) && kv > 0) setK(kv);
      } catch (_) { /* keep 1 */ }
    };
    measure();
    if (typeof ResizeObserver !== "undefined") {
      const ro = new ResizeObserver(measure); ro.observe(el); return () => ro.disconnect();
    }
  }, []);

  const legalIdx = React.useMemo(
    () => cards.map((c, i) => (legalIds && legalIds.has(c.id)) ? i : -1).filter(i => i >= 0),
    [cards, legalIds]);

  // If the legal set changes under us (a trick completes, the turn moves), any stale focus must go.
  React.useEffect(() => {
    if (focus != null && !legalIdx.includes(focus)) { setFocus(null); onFocus && onFocus(null); }
  }, [legalIdx]);   // eslint-disable-line

  const setF = (i) => {
    if (i === focus) return;
    setFocus(i);
    onFocus && onFocus(i == null ? null : cards[i]);
  };

  const xOf = (e) => {
    const el = ref.current; if (!el) return 0;
    const t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    return t.clientX - el.getBoundingClientRect().left;
  };
  const yOf = (e) => {
    const t = (e.touches && e.touches[0]) || (e.changedTouches && e.changedTouches[0]) || e;
    return t.clientY;
  };

  const start = (e) => {
    if (!active || !legalIdx.length) return;
    drag.current = { y0: yOf(e), moved: false };
    setF(nearestLegal(xOf(e), cards.length, w, cardW, legalIdx));
  };
  const move = (e) => {
    if (!drag.current || !active) return;
    drag.current.moved = true;
    setF(nearestLegal(xOf(e), cards.length, w, cardW, legalIdx));
  };
  const end = (e) => {
    if (!drag.current || !active) { drag.current = null; return; }
    const dy = yOf(e) - drag.current.y0;
    drag.current = null;
    // FLICK UP to play. A deliberate upward gesture on the lifted card — you cannot do this by accident while
    // scrubbing sideways, and it reads as "throw the card onto the table".
    if (dy < -FLICK_PX && focus != null) { const c = cards[focus]; setF(null); onPlay && onPlay(c); }
  };

  const lay = fanLayout(cards.length, w, cardW, active ? focus : null, 0.62 * cardW, 0.34 * cardH);

  return (
    <div ref={ref}
      style={{ position: "relative", height: H, width: "100%", touchAction: "pan-y" }}
      onTouchStart={start} onTouchMove={move} onTouchEnd={end}
      onMouseDown={start} onMouseMove={(e) => drag.current && move(e)} onMouseUp={end}
      onMouseLeave={() => { drag.current = null; }}>
      {lay.map(({ i, x, y, z, focused }) => {
        const c = cards[i];
        const legal = !!(legalIds && legalIds.has(c.id));
        return (
          <div key={c.id} style={{
            position: "absolute", left: 0, bottom: 0,
            // translate3d keeps this on the compositor — the spread animates without a layout pass, which is
            // what lets it track a thumb at 60fps without the rest of the table reflowing.
            transform: `translate3d(${x}px, ${y}px, 0)`,
            transition: "transform 110ms cubic-bezier(.2,.8,.3,1)",
            zIndex: z, pointerEvents: "none",
            // Illegal cards are DARKENED, never hidden and never removed. You can always see your whole hand.
            opacity: (active && legalIds && legalIds.size) ? (legal ? 1 : 0.34) : 1,
            filter: (active && legalIds && legalIds.size && !legal) ? "grayscale(0.85)" : "none",
            boxShadow: focused ? "0 6px 16px rgba(0,0,0,0.42)" : "none",
          }}>
            <Card c={c} small={small} selected={focused} />
          </div>
        );
      })}
    </div>
  );
}

const FLICK_PX = 26;   // upward travel that counts as "play it"

//#region gen (auto — removed when bundled to a single bridge.jsx)
export { FanHand, fanLayout, nearestLegal, FLICK_PX, CARD_W, CARD_H };
//#endregion gen
