//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { SEAT_ABBR, SEAT_NAME, SIDE_NAME } from "../state/constants.js";
import { ALL_BRAINS, PROFILES, seatPersona, who } from "../state/personas.js";
import { btn } from "./theme.js";
//#endregion gen

/* ---------------- setup ---------------- */
function Setup({s, dispatch, onShowRules, onShowGloss, campaign, onResume, onDiscard}){
  const setBrain=(seat,key)=>dispatch({type:"SET_BRAIN", seat, key});
  const seatRow=(seat)=>{
    const isHuman=s.brains[seat]==="human";
    const p=seatPersona(s,seat);
    return (
      <div className="setseat" key={seat}>
        <div className="ss-pos">
          <span className="ss-abbr">{SEAT_ABBR[seat]}</span>
          <span className="lbl2">{SEAT_NAME[seat]}{seat===0?" · you":""}</span>
        </div>
        <select value={s.brains[seat]} onChange={e=>setBrain(seat,e.target.value)}>
          <option value="human">Human</option>
          {ALL_BRAINS.map(b=><option key={b} value={b}>{PROFILES[b].name}</option>)}
        </select>
        <div className="ss-blurb lbl2" style={{color:p.color}}>{isHuman?"Plays from this device.":p.blurb}</div>
      </div>
    );
  };
  const humans=s.brains.filter(b=>b==="human").length;
  return (
    <div className="setup">
      <div className="setwrap">
        <div className="setcard">
          <div className="lbl2" style={{marginBottom:6}}>Partnerships</div>
          <div className="partners">
            <div className="pteam"><b>{SIDE_NAME[0]}</b><span>{who(s,0)} &amp; {who(s,2)}</span></div>
            <div className="pvs">vs</div>
            <div className="pteam"><b>{SIDE_NAME[1]}</b><span>{who(s,1)} &amp; {who(s,3)}</span></div>
          </div>
        </div>
        <div className="setcard">
          <div className="lbl2" style={{marginBottom:6}}>Seats</div>
          {[0,1,2,3].map(seatRow)}
          <div className="lbl2" style={{marginTop:6,color:"var(--dim)"}}>
            {humans>1?`${humans} humans — pass the device between turns.`:"Solo vs three bots. You sit South."}
          </div>
        </div>
        {campaign && (
          <div className="setcard resume">
            <div className="lbl2">Rubber in progress</div>
            <div className="rz-line">Games {campaign.games[0]}–{campaign.games[1]} · totals {campaign.total[0]} / {campaign.total[1]}</div>
            <div className="rz-btns">
              <button style={btn("gold",true)} onClick={onResume}>Resume</button>
              <button style={btn("ghost",true)} onClick={onDiscard}>Discard</button>
            </div>
          </div>
        )}
        <div className="setbtns">
          <button className="startbtn" onClick={()=>dispatch({type:"START"})}>Deal the first hand</button>
          <div className="setlinks">
            <button style={btn("ghost")} onClick={onShowRules}>How to play</button>
            <button style={btn("ghost")} onClick={onShowGloss}>Glossary</button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- rules (standard contract bridge) ---------------- */
const RULES_SECTIONS = [
  ["The deal", [
    "Four players in two partnerships: North–South against East–West, partners sitting opposite.",
    "A standard 52-card deck is dealt out, 13 cards each. Ranks run A (high) down to 2.",
  ]],
  ["The auction", [
    "Starting with the dealer and moving clockwise, players bid for the contract.",
    "A bid names a level (1–7 = tricks over six) and a strain (♣ < ♦ < ♥ < ♠ < No-Trump). Each bid must be higher than the last.",
    "You may Pass, Double an opponent's bid, or Redouble. Three passes after a bid end the auction; four passes to start redeal the hand.",
    "The final bid is the contract. The side that won it supplies the declarer — the player who first named that strain.",
  ]],
  ["Declarer & dummy", [
    "The player to declarer's left makes the opening lead. Then declarer's partner lays their hand face-up as the dummy.",
    "Declarer plays both their own hand and the dummy; the defenders play their own cards.",
  ]],
  ["Playing the tricks", [
    "Each trick is four cards, one per player, clockwise. You must follow the suit led if you can; otherwise play anything.",
    "Highest card of the led suit wins — unless someone plays a trump, in which case the highest trump wins.",
    "The winner of a trick leads to the next. Thirteen tricks are played in all.",
  ]],
  ["Making the contract", [
    "'Book' is the first six tricks. The contract asks for book + the bid level, so 4♠ needs 6 + 4 = 10 tricks.",
    "Extra tricks are overtricks; falling short means the contract goes down by that many undertricks.",
  ]],
  ["Scoring the rubber", [
    "Made contracts score below the line toward game: minors 20 per level, majors 30, No-Trump 40 then 30.",
    "First side to 100 below the line wins a game and becomes vulnerable; the line resets. Win two games to take the rubber (+700, or +500 if the opponents won a game).",
    "Overtricks, slam bonuses (small 500/750, grand 1000/1500), honours, doubling insults and undertrick penalties all score above the line.",
  ]],
];
function RulesScreen({onClose}){
  return (
    <div className="overlay" onClick={onClose}>
      <div className="sheetmodal" onClick={e=>e.stopPropagation()}>
        <div className="smhead"><div className="wordmark sm">BRIDGE</div><button style={btn("ghost",true)} onClick={onClose}>Close</button></div>
        <div className="smbody">
          {RULES_SECTIONS.map(([h,items],i)=>(
            <div key={i} className="rsec">
              <div className="rsh">{h}</div>
              {items.map((t,j)=><div key={j} className="rsl">{t}</div>)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { RULES_SECTIONS, RulesScreen, Setup };
//#endregion gen
