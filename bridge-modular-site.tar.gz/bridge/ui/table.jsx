//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { AUC } from "../engine/auction.js";
import { BID } from "../engine/bidding.js";
import { BIDGRADE } from "../engine/bidgrade.js";
import { MEAN } from "../engine/meaning.js";
import { SEAT_ABBR, SEAT_NAME, SIDE_NAME, STRAIN_GLYPH, STRAIN_ORDER, nextSeat, partnerOf, sideOf, sortHandDisplay } from "../state/constants.js";
import { seatPersona, who } from "../state/personas.js";
import { Card } from "./cards.jsx";
import { suitColorClass } from "./glossary.jsx";
import { btn } from "./theme.js";
//#endregion gen

/* ---------------- the bidding grade, as seen ----------------
   ONE vocabulary, shared by the auction ladder, the trainer panel and the post-hand review, so a verdict
   always looks the same wherever it appears. Colours match the CARD grade's (GradeNote in helpDrawer):
   green = sound, amber = a stretch, red = a broken promise. Grey = we are deliberately SAYING NOTHING —
   a judgment call SAYC leaves open. That grey is a feature: the grade stays quiet on two-thirds of calls,
   and it must LOOK quiet, not look like a gap. */
const BID_CLASS = {
  sound:          { label:"describes your hand", color:"#3aa657", dot:true  },
  stretch:        { label:"a stretch",           color:"#c79a2e", dot:true  },
  misdescription: { label:"misleads partner",    color:"#c0503f", dot:true  },
  obligation:     { label:"answer the force",    color:"#c0503f", dot:true  },
  blunder:        { label:"indefensible",        color:"#c0503f", dot:true  },
  unjudged:       { label:"judgment call",       color:"#8a8a8a", dot:false },
};
const bidMeta = (g)=> (g && BID_CLASS[g.classification]) || null;

const CallChip=({c,big,grade})=>{
  // A graded call carries a hairline underline in its verdict colour. Judgment calls get NO mark at all —
  // silence has to read as silence.
  const m = grade ? bidMeta(grade) : null;
  const mark = (m && m.dot) ? { boxShadow:`inset 0 -2px 0 0 ${m.color}` } : undefined;
  if(c.k==="P") return <span className="chip pass" style={mark}>Pass</span>;
  if(c.k==="D") return <span className="chip dbl" style={mark}>X</span>;
  if(c.k==="R") return <span className="chip dbl" style={mark}>XX</span>;
  return <span className={"chip bid"+(big?" big":"")} style={mark}>{c.level}<b className={suitColorClass(c.strain)}>{STRAIN_GLYPH[c.strain]}</b></span>;
};

/* The verdict card. Used for a PREVIEW (before you commit — "this is what it would say") and for the
   COMMITTED grade. Identical either way, deliberately: the student should learn to read the same thing
   before bidding that they'll be judged by after. */
function BidVerdict({g, preview}){
  if(!g) return null;
  const m = bidMeta(g), M = g.meaning;
  const accent = m ? m.color : "#8a8a8a";
  const bad = g.points < 100;
  return (
    <div style={{marginTop:6,padding:"6px 9px",borderRadius:8,fontSize:11.5,lineHeight:1.45,
      background:"rgba(127,127,127,0.10)", borderLeft:"3px solid "+accent}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:2}}>
        <b>{g.call}</b>
        <span style={{display:"flex",gap:4,alignItems:"center"}}>
          {M && M.artificial ? <em style={{fontSize:9,padding:"1px 5px",borderRadius:9,background:"rgba(122,92,199,0.22)"}}>artificial</em> : null}
          {M && M.mustAnswer ? <em style={{fontSize:9,padding:"1px 5px",borderRadius:9,background:"rgba(58,134,199,0.22)"}}>forcing</em> : null}
          {m ? <em style={{fontSize:9,padding:"1px 6px",borderRadius:9,color:"#fff",background:accent}}>{m.label}</em> : null}
        </span>
      </div>
      {M ? <div style={{opacity:0.85}}>{M.text}</div> : null}
      {bad && g.why ? <div style={{marginTop:3,color:accent}}>{g.why}</div> : null}
      {/* Tier 2 is ADVISORY: it may say a call is indefensible, but it does NOT move the score.
          Say so out loud rather than quietly showing a number the points don't reflect. */}
      {g.blunder && g.blunder.fired ? (
        <div style={{marginTop:3,color:"#c0503f"}}>{g.blunder.why}</div>
      ) : null}
      {preview ? <div style={{marginTop:4,opacity:0.55,fontSize:10}}>Tap again to bid it.</div> : null}
    </div>
  );
}

/* ---------------- seat badges ---------------- */
function SeatBadge({s, seat, focus, active}){
  const p=seatPersona(s,seat);
  const isDummy = s.contract && seat===s.dummy;
  const isDecl  = s.contract && seat===s.declarer;
  const cnt=(s.hands[seat]||[]).length;
  const vul = s.vuln[sideOf(seat)];
  return (
    <div className={"seat"+(active?" act":"")+(seat===focus?" me":"")} style={{"--accent":p.color}}>
      <div className="top">
        <span className="gl">{p.glyph}</span>
        <span className="nm">{who(s,seat)}</span>
      </div>
      <div className="sub">
        <span className="pos">{SEAT_NAME[seat]}{vul?" ·":""}{vul?<span className="vtag"> vul</span>:""}</span>
        {isDecl && <span className="role decl">Declarer</span>}
        {isDummy && <span className="role dummy">Dummy</span>}
        {!isDecl && !isDummy && <span className="cnt num">{cnt} cards</span>}
      </div>
    </div>
  );
}

/* ---------------- auction ladder ---------------- */
function AuctionView({s}){
  const order=[0,1,2,3].map(i=>(s.dealer+i)%4);
  const rows=[]; let row=new Array(4).fill(undefined); let col=0;
  for(const c of s.calls){ row[col]=c; col++; if(col===4){ rows.push(row); row=new Array(4).fill(undefined); col=0; } }
  if(col>0) rows.push(row);
  return (
    <div className="auction">
      <div className="ahead">{order.map((seat,i)=><div key={i} className="ac num">{SEAT_ABBR[seat]}</div>)}</div>
      <div className="agrid">
        {rows.length===0 && <div className="aempty">Auction begins…</div>}
        {rows.map((r,ri)=>(
          <div key={ri} className="arow">
            {[0,1,2,3].map(ci=>{
              const c=r[ci];
              // Only the STUDENT'S calls are marked. The bot is graded too (a live regression tripwire — it
              // sits at 0 accusations in 19,123 calls), but showing its verdicts would just be noise.
              const mine = c && s.brains && s.brains[c.by]==="human";
              return <div key={ci} className="acell">{c!==undefined && c!==null ? <CallChip c={c} grade={mine?c.grade:null}/> : ""}</div>;
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- bidding TRAINER panel (meaning.js) ----------------
   Three teaching surfaces, all driven by MEAN:
     1. HAND METRICS — what you're holding, in the terms bidding decisions are made in.
     2. PER-BUTTON MEANING — tap/hover a bid to read exactly what it would PROMISE partner.
     3. LIE-DARKENING — a bid that would MISREPRESENT the hand is dimmed and marked.
   The darkening only fires on FIRM promises (suit lengths, firm conventional promises). Range/judgment calls are
   described but never dimmed — punishing a legitimate upgrade or tactical underbid would teach rigidity. */
function HandMetrics({hand}){
  if(!hand || !hand.length) return null;
  let m; try{ m = MEAN.handMetrics(hand); }catch(_){ return null; }
  const chip=(label,val,strong)=>(
    <span key={label} style={{display:"inline-flex",gap:4,alignItems:"baseline",padding:"2px 7px",borderRadius:8,
      background:"rgba(127,127,127,0.13)",fontSize:11}}>
      <span style={{opacity:0.65}}>{label}</span><b style={{fontWeight:strong?700:600}}>{val}</b></span>
  );
  return (
    <div style={{display:"flex",flexWrap:"wrap",gap:5,margin:"0 0 6px"}}>
      {chip("HCP", m.hcp, true)}
      {m.lengthPoints>0 ? chip("+length", m.lengthPoints) : null}
      {chip("total", m.total, true)}
      {chip("shape", m.shape)}
      {m.balanced ? chip("", "balanced") : null}
      {m.ruleOf20 ? chip("", "Rule of 20 \u2713") : null}
      <span style={{display:"inline-flex",gap:6,alignItems:"center",padding:"2px 7px",borderRadius:8,
        background:"rgba(127,127,127,0.13)",fontSize:11}}>
        {STRAIN_ORDER.filter(x=>x!=="NT").map(x=>(
          <span key={x} className={suitColorClass(x)||""}>{STRAIN_GLYPH[x]}{m.lengths[x]}</span>
        ))}
      </span>
    </div>
  );
}

/* ---------------- bidding box ---------------- */
function BiddingBox({s, seat, dispatch, suggestion}){
  const sug = suggestion;
  const sugKey = sug ? (sug.k==="B"?`${sug.level}${sug.strain}`:sug.k) : null;
  const sugLevel = sug && sug.k==="B" ? sug.level : null;
  const bidLegal=(L,st)=>AUC.callLegal({k:"B",level:L,strain:st}, s.calls, s.dealer);
  const legalLevels=[1,2,3,4,5,6,7].filter(L=>STRAIN_ORDER.some(st=>bidLegal(L,st)));
  const [lvl,setLvl]=React.useState(null);
  const [note,setNote]=React.useState(null);           // the meaning of the last-touched button
  const curLvl = (lvl!=null && legalLevels.includes(lvl)) ? lvl
    : (sugLevel && legalLevels.includes(sugLevel)) ? sugLevel : legalLevels[0];
  const canDbl = AUC.callLegal({k:"D"}, s.calls, s.dealer);
  const canRdbl= AUC.callLegal({k:"R"}, s.calls, s.dealer);

  // TRAINER: on (teaching mode). Describe + honesty-check any call from THIS seat's hand.
  const teach = (s.gradeOn !== false);
  const hand = (s.hands && s.hands[seat]) || [];
  /* The preview now runs the FULL GRADE, not just the honesty check. That is not cosmetic: checkHonesty can
     only judge the call you MAKE, and is structurally blind to the call you FAIL to make — so the old preview
     could not warn you that passing partner's forcing bid abandons it. gradeBid can, and now does, BEFORE you
     commit. Same function, same verdict, before and after. */
  const describe = React.useCallback((call)=>{
    if(!teach || !hand.length) return null;
    try{ return BIDGRADE.gradeBid({ call, calls:s.calls, dealer:s.dealer, seat, hand }, null); }catch(_){ return null; }
  }, [teach, hand, s.calls, s.dealer, seat]);
  // the verdict on the last call THIS seat made — shown once committed, so the lesson lands after the bid too
  const lastMine = React.useMemo(()=>{
    for(let i=(s.calls||[]).length-1;i>=0;i--) if(s.calls[i].by===seat) return s.calls[i];
    return null;
  }, [s.calls, seat]);

  // Show the meaning of a call (tap or hover) without committing to it.
  /* Compare on the CALL OBJECT, never on the rendered label. constants.js STRAIN_GLYPH appends a \uFE0E
     variation selector and bidgrade.js's GLYPH does not, so "3♠" !== "3♠︎" and tap-to-confirm would silently
     never fire. Two glyph tables, one invisible codepoint apart. */
  const sameCall=(a,b)=> a&&b&&a.k===b.k && a.level===b.level && a.strain===b.strain;
  const noteIsFor=(call)=> !!note && sameCall(note.call, call);
  const peek = (call)=>{ const r=describe(call); if(r) setNote({ call, g:r }); };
  const commitNow = (call)=>{ setNote(null); dispatch({type:"BID", seat, call}); };
  /* TAP-TO-PREVIEW, TAP-AGAIN-TO-CONFIRM (teaching mode only).
     There is no hover on a phone, so a single tap that both explains and commits would mean the student can
     never read what a bid PROMISES before making it — which defeats the purpose. In teaching mode the first tap
     shows the meaning (and any misrepresentation warning); a second tap on the SAME button confirms. With
     teaching off, one tap bids as before. */
  const press = (call)=>{
    if(!teach) return commitNow(call);
    if(note && noteIsFor(call)) return commitNow(call);
    peek(call);
  };

  const meaningOf = (call)=> describe(call);
  // A bid is DIMMED only when the grade would actually mark it down. Judgment calls are never dimmed —
  // punishing a legitimate upgrade or a tactical underbid teaches rigidity.
  const lieOf = (call)=>{ const r=describe(call); return (r && r.points < 100) ? r : null; };

  return (
    <div className="bidbox2">
      {teach ? <HandMetrics hand={hand}/> : null}
      <div className="bb-levels">
        {[1,2,3,4,5,6,7].map(L=>(
          <button key={L} disabled={!legalLevels.includes(L)}
            className={"bb-lv"+(L===curLvl?" on":"")+(sugLevel===L?" sug":"")}
            onClick={()=>setLvl(L)}>{L}</button>
        ))}
      </div>
      <div className="bb-strains">
        {STRAIN_ORDER.map(st=>{
          const ok=curLvl!=null && bidLegal(curLvl,st);
          const call={k:"B",level:curLvl,strain:st};
          const lie = ok ? lieOf(call) : null;
          return <button key={st} disabled={!ok}
            title={ok && teach ? ((meaningOf(call)||{}).meaning||{}).text : undefined}
            style={lie ? {opacity:0.42, filter:"grayscale(0.6)"} : undefined}
            className={"bb-st "+(suitColorClass(st)||"nt")+(sugKey===`${curLvl}${st}`?" sug":"")}
            onMouseEnter={()=>ok&&peek(call)}
            onClick={()=>{ if(ok) press(call); }}>
            {STRAIN_GLYPH[st]}{lie ? <span style={{fontSize:9,opacity:0.9,marginLeft:2}}>!</span> : null}
          </button>;
        })}
      </div>
      <div className="bb-acts">
        <button className={"bb-act"+(sugKey==="P"?" sug":"")}
          onMouseEnter={()=>peek({k:"P"})}
          onClick={()=>press({k:"P"})}>Pass</button>
        <button className={"bb-act"+(sugKey==="D"?" sug":"")} disabled={!canDbl}
          onMouseEnter={()=>canDbl&&peek({k:"D"})}
          onClick={()=>press({k:"D"})}>Double</button>
        <button className={"bb-act"+(sugKey==="R"?" sug":"")} disabled={!canRdbl}
          onMouseEnter={()=>canRdbl&&peek({k:"R"})}
          onClick={()=>press({k:"R"})}>Redbl</button>
      </div>
      {teach && note ? <BidVerdict g={note.g} preview/> : null}
      {/* Once committed, the verdict stays up until you bid again. The card grade already teaches after the
          fact; bidding had no such surface at all until now — the meaning vanished the instant you tapped. */}
      {teach && !note && lastMine && lastMine.grade ? (
        <div style={{marginTop:6}}>
          <div style={{fontSize:9.5,opacity:0.5,marginBottom:2,letterSpacing:0.4}}>YOUR LAST CALL</div>
          <BidVerdict g={lastMine.grade}/>
        </div>
      ) : null}
    </div>
  );
}

/* ---------------- the played trick (center of the table) ---------------- */
function TrickTable({s, focus}){
  const bottom=focus, top=partnerOf(focus), left=nextSeat(focus), right=(focus+3)%4;
  const cardBy=(seat)=>{ const t=s.trick.find(tc=>tc.seat===seat); return t?t.card:null; };
  const lastBy=(seat)=>{ if(!s.lastTrick) return null; const t=s.lastTrick.trick.find(tc=>tc.seat===seat); return t?t.card:null; };
  const showLast = s.trick.length===0 && s.lastTrick;
  const declSide = s.contract? sideOf(s.declarer):0;
  const slot=(seat,pos)=>{
    const c=cardBy(seat) || (showLast?lastBy(seat):null);
    const isWinner = showLast && s.lastTrick.winner===seat;
    const isTurn = s.turn===seat && s.phase==="play";
    return (
      <div className={"tslot "+pos+(isTurn?" turn":"")+(isWinner?" win":"")}>
        {c ? <Card c={c} small/> : <div className="tempty">{SEAT_ABBR[seat]}</div>}
        <div className="tname num">{SEAT_ABBR[seat]}{seat===s.declarer?"*":seat===s.dummy?"°":""}</div>
      </div>
    );
  };
  return (
    <div className="tricktable">
      {slot(top,"top")}
      {slot(left,"left")}
      <div className="tcenter">
        <div className="tinfo">
          <div className="big num">{s.tricks[declSide]}<span className="slash">/{s.contract?6+s.contract.level:""}</span></div>
          <div className="lbl2">declarer tricks</div>
          <div className="trk2 num">{SIDE_NAME[0]} {s.tricks[0]} · {s.tricks[1]} {SIDE_NAME[1]}</div>
        </div>
      </div>
      {slot(right,"right")}
      {slot(bottom,"bottom")}
    </div>
  );
}

/* ---------------- a hand row ---------------- */
/* select-then-play: on a touch device an exact tap is hard, so a first tap lifts a card (selId) and a
 * second tap (or the Play button in the play screen) commits it. onPlay(card) is the tap handler; the
 * caller decides whether that tap selects or plays. */
function HandRow({hand, onPlay, legalIds, selectable, label, faceDown, count, sugId, selId}){
  const cards=sortHandDisplay(hand||[]);
  return (
    <div className="handblock">
      {label && <div className="hlabel lbl2">{label}{count!=null?` · ${count}`:""}</div>}
      <div className="hand">
        {faceDown
          ? Array.from({length:count||cards.length}).map((_,i)=><Card key={i} faceDown small/>)
          : cards.map(c=>{
              const ok=!legalIds || legalIds.has(c.id);
              return <Card key={c.id} c={c} small={label!=="You"} suggested={sugId===c.id} selected={selId===c.id}
                onClick={selectable&&ok?()=>onPlay(c):undefined} disabled={selectable&&!ok}/>;
            })}
      </div>
    </div>
  );
}

/* ---------------- compact seat strip (bid screen) ---------------- */
/* One horizontal row of four seats, focus-relative, with dealer + vulnerability markers and an active
 * highlight. Roles (declarer/dummy) don't exist during the auction, so this stays lean. */
function SeatStrip({s, focus}){
  const order=[focus, nextSeat(focus), partnerOf(focus), (focus+3)%4];
  return (
    <div className="seatstrip">
      {order.map(seat=>{
        const p=seatPersona(s,seat);
        const vul=s.vuln[sideOf(seat)];
        const active=s.turn===seat && s.phase!=="scored";
        return (
          <div key={seat} className={"ss-cell"+(active?" act":"")+(seat===focus?" me":"")} style={{"--accent":p.color}}>
            <div className="ss-nm"><span className="ss-gl">{p.glyph}</span>{seat===focus?"You":who(s,seat)}</div>
            <div className="ss-meta"><span className="ss-seat">{SEAT_NAME[seat]}</span>{seat===s.dealer?<span className="ss-deal">deal</span>:null}{vul?<span className="ss-vul">vul</span>:null}</div>
          </div>
        );
      })}
    </div>
  );
}

/* ---------------- top status bar (always present, constant height) ---------------- */
function StatusBar({s, focus, phase, contractText, turnText, onMenu, hint}){
  const vulTag=(()=>{ const a=s.vuln[0], b=s.vuln[1]; if(!a&&!b) return "none"; if(a&&b) return "all"; return a?"NS":"EW"; })();
  const title = phase==="auction" ? "Auction" : phase==="scored" ? "Result" : (contractText||"Play");
  return (
    <div className="gstatus">
      <button className="gs-menu" onClick={onMenu} aria-label="Menu">≡</button>
      <div className="gs-mid">
        <div className="gs-title">{title}</div>
        {turnText ? <div className="gs-turn">{turnText}</div> : null}
      </div>
      {hint ? <div className="gs-hint">{hint}</div> : null}
      <div className="gs-score num">
        <span>R{s.rubberNo||1}</span>
        <span className="gs-games">{s.games[0]}–{s.games[1]}</span>
        <span className={"gs-vul"+(vulTag!=="none"?" on":"")}>vul {vulTag}</span>
      </div>
    </div>
  );
}

/* ---------------- bottom tab bar ---------------- */
function TabBar({tab, onTab, phase, yourTurn}){
  const gameLabel = phase==="auction" ? "Bid" : phase==="scored" ? "Result" : "Play";
  return (
    <div className="gtabs">
      <button className={"gtab"+(tab==="game"?" on":"")} onClick={()=>onTab("game")}>
        {gameLabel}{yourTurn && tab!=="game" ? <span className="gt-dot"/> : null}
      </button>
      <button className={"gtab"+(tab==="talk"?" on":"")} onClick={()=>onTab("talk")}>Table&nbsp;Talk</button>
    </div>
  );
}

/* ---------------- swipeable playable-card carousel ----------------
 * On your turn the fanned overlap is hard to tap on a phone, so the ACTIVE hand becomes a horizontal,
 * snap-scrolling carousel of ONLY the playable cards — swipe to bring any card to centre, tap to select
 * (it lifts), tap again or press Play to commit. It renders at a FIXED height inside a fixed-height dock
 * so switching between the fan and the carousel never changes the layout (the trick diamond above stays
 * put). Used for both your hand and dummy (whichever seat you're playing from) — identical behaviour. */
function SwipeHand({hand, legalIds, onPlay, selId, sugId, label}){
  const cards=sortHandDisplay(hand||[]);
  const legal = cards.filter(c=>!legalIds || legalIds.has(c.id));
  return (
    <div className="handblock swipeblock">
      {label && <div className="hlabel lbl2">{label}<span className="swipe-hint">swipe · tap to play</span></div>}
      <div className="swipehand" role="listbox" aria-label="Playable cards">
        {legal.map(c=>(
          <div key={c.id} className={"swipe-slot"+(selId===c.id?" sel":"")} role="option" aria-selected={selId===c.id}>
            <Card c={c} suggested={sugId===c.id} selected={selId===c.id} onClick={()=>onPlay(c)}/>
          </div>
        ))}
        {legal.length===0 && <div className="swipe-empty lbl2">No legal card</div>}
      </div>
    </div>
  );
}

/* ---------------- rubber score sheet ---------------- */
function ScoreSheet({s}){
  const vtag=(side)=> s.vuln[side]?"VUL":"—";
  return (
    <div className="sheet">
      <div className="shead"><div className="scorner"></div><div className="scol">{SIDE_NAME[0]}</div><div className="scol">{SIDE_NAME[1]}</div></div>
      <div className="srow"><div className="slbl">Total</div><div className="sval num big">{s.total[0]}</div><div className="sval num big">{s.total[1]}</div></div>
      <div className="srow"><div className="slbl">Games</div><div className="sval num">{s.games[0]}</div><div className="sval num">{s.games[1]}</div></div>
      <div className="srow"><div className="slbl">Toward game</div><div className="sval num">{s.gameBelow[0]}</div><div className="sval num">{s.gameBelow[1]}</div></div>
      <div className="srow"><div className="slbl">Vulnerable</div><div className={"sval vul"+(s.vuln[0]?" on":"")}>{vtag(0)}</div><div className={"sval vul"+(s.vuln[1]?" on":"")}>{vtag(1)}</div></div>
    </div>
  );
}

/* ---------------- pass-and-play reveal gate ---------------- */
function RevealGate({s, seat, onReveal}){
  const p=seatPersona(s,seat);
  return (
    <div className="revealgate">
      <div className="rg-glyph" style={{color:p.color}}>{p.glyph}</div>
      <div className="rg-who">{who(s,seat)} — {SEAT_NAME[seat]}</div>
      <div className="rg-sub lbl2">Pass the device. Hide the previous player's cards.</div>
      <button style={btn("gold")} onClick={onReveal}>Reveal my hand</button>
    </div>
  );
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { AuctionView, BidVerdict, BiddingBox, CallChip, HandRow, RevealGate, ScoreSheet, SeatBadge, SeatStrip, StatusBar, SwipeHand, TabBar, TrickTable };
//#endregion gen
