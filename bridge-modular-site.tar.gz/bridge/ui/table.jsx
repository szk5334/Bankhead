//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { AUC } from "../engine/auction.js";
import { BID } from "../engine/bidding.js";
import { SEAT_ABBR, SEAT_NAME, SIDE_NAME, STRAIN_GLYPH, STRAIN_ORDER, nextSeat, partnerOf, sideOf, sortHandDisplay } from "../state/constants.js";
import { seatPersona, who } from "../state/personas.js";
import { Card } from "./cards.jsx";
import { suitColorClass } from "./glossary.jsx";
import { btn } from "./theme.js";
//#endregion gen

const CallChip=({c,big})=>{
  if(c.k==="P") return <span className="chip pass">Pass</span>;
  if(c.k==="D") return <span className="chip dbl">X</span>;
  if(c.k==="R") return <span className="chip dbl">XX</span>;
  return <span className={"chip bid"+(big?" big":"")}>{c.level}<b className={suitColorClass(c.strain)}>{STRAIN_GLYPH[c.strain]}</b></span>;
};

/* ---------------- seat badges ---------------- */
function SeatBadge({s, seat, focus, active}){
  const p=seatPersona(s,seat);
  const isDummy = s.contract && seat===s.dummy;
  const isDecl  = s.contract && seat===s.declarer;
  const cnt=(s.hands[seat]||[]).length;
  const vul = s.vuln[sideOf(seat)];
  return (
    <div className={"seat"+(active?" act":"")+(seat===focus?" me":"")} style={{"--accent":p.color}}>
      <div className="top">
        <span className="gl">{p.glyph}</span>
        <span className="nm">{who(s,seat)}</span>
      </div>
      <div className="sub">
        <span className="pos">{SEAT_NAME[seat]}{vul?" ·":""}{vul?<span className="vtag"> vul</span>:""}</span>
        {isDecl && <span className="role decl">Declarer</span>}
        {isDummy && <span className="role dummy">Dummy</span>}
        {!isDecl && !isDummy && <span className="cnt num">{cnt} cards</span>}
      </div>
    </div>
  );
}

/* ---------------- auction ladder ---------------- */
function AuctionView({s}){
  const order=[0,1,2,3].map(i=>(s.dealer+i)%4);
  const rows=[]; let row=new Array(4).fill(undefined); let col=0;
  for(const c of s.calls){ row[col]=c; col++; if(col===4){ rows.push(row); row=new Array(4).fill(undefined); col=0; } }
  if(col>0) rows.push(row);
  return (
    <div className="auction">
      <div className="ahead">{order.map((seat,i)=><div key={i} className="ac num">{SEAT_ABBR[seat]}</div>)}</div>
      <div className="agrid">
        {rows.length===0 && <div className="aempty">Auction begins…</div>}
        {rows.map((r,ri)=>(
          <div key={ri} className="arow">
            {[0,1,2,3].map(ci=>(<div key={ci} className="acell">{r[ci]!==undefined && r[ci]!==null ? <CallChip c={r[ci]}/> : ""}</div>))}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ---------------- bidding box ---------------- */
function BiddingBox({s, seat, dispatch, suggestion}){
  const sug = suggestion;
  const sugKey = sug ? (sug.k==="B"?`${sug.level}${sug.strain}`:sug.k) : null;
  const sugLevel = sug && sug.k==="B" ? sug.level : null;
  const bidLegal=(L,st)=>AUC.callLegal({k:"B",level:L,strain:st}, s.calls, s.dealer);
  const legalLevels=[1,2,3,4,5,6,7].filter(L=>STRAIN_ORDER.some(st=>bidLegal(L,st)));
  const [lvl,setLvl]=React.useState(null);
  const curLvl = (lvl!=null && legalLevels.includes(lvl)) ? lvl
    : (sugLevel && legalLevels.includes(sugLevel)) ? sugLevel : legalLevels[0];
  const canDbl = AUC.callLegal({k:"D"}, s.calls, s.dealer);
  const canRdbl= AUC.callLegal({k:"R"}, s.calls, s.dealer);
  return (
    <div className="bidbox2">
      <div className="bb-levels">
        {[1,2,3,4,5,6,7].map(L=>(
          <button key={L} disabled={!legalLevels.includes(L)}
            className={"bb-lv"+(L===curLvl?" on":"")+(sugLevel===L?" sug":"")}
            onClick={()=>setLvl(L)}>{L}</button>
        ))}
      </div>
      <div className="bb-strains">
        {STRAIN_ORDER.map(st=>{
          const ok=curLvl!=null && bidLegal(curLvl,st);
          return <button key={st} disabled={!ok}
            className={"bb-st "+(suitColorClass(st)||"nt")+(sugKey===`${curLvl}${st}`?" sug":"")}
            onClick={()=>dispatch({type:"BID", seat, call:{k:"B",level:curLvl,strain:st}})}>{STRAIN_GLYPH[st]}</button>;
        })}
      </div>
      <div className="bb-acts">
        <button className={"bb-act"+(sugKey==="P"?" sug":"")} onClick={()=>dispatch({type:"BID", seat, call:{k:"P"}})}>Pass</button>
        <button className={"bb-act"+(sugKey==="D"?" sug":"")} disabled={!canDbl} onClick={()=>dispatch({type:"BID", seat, call:{k:"D"}})}>Double</button>
        <button className={"bb-act"+(sugKey==="R"?" sug":"")} disabled={!canRdbl} onClick={()=>dispatch({type:"BID", seat, call:{k:"R"}})}>Redbl</button>
      </div>
    </div>
  );
}

/* ---------------- the played trick (center of the table) ---------------- */
function TrickTable({s, focus}){
  const bottom=focus, top=partnerOf(focus), left=nextSeat(focus), right=(focus+3)%4;
  const cardBy=(seat)=>{ const t=s.trick.find(tc=>tc.seat===seat); return t?t.card:null; };
  const lastBy=(seat)=>{ if(!s.lastTrick) return null; const t=s.lastTrick.trick.find(tc=>tc.seat===seat); return t?t.card:null; };
  const showLast = s.trick.length===0 && s.lastTrick;
  const declSide = s.contract? sideOf(s.declarer):0;
  const slot=(seat,pos)=>{
    const c=cardBy(seat) || (showLast?lastBy(seat):null);
    const isWinner = showLast && s.lastTrick.winner===seat;
    const isTurn = s.turn===seat && s.phase==="play";
    return (
      <div className={"tslot "+pos+(isTurn?" turn":"")+(isWinner?" win":"")}>
        {c ? <Card c={c} small/> : <div className="tempty">{SEAT_ABBR[seat]}</div>}
        <div className="tname num">{SEAT_ABBR[seat]}{seat===s.declarer?"*":seat===s.dummy?"°":""}</div>
      </div>
    );
  };
  return (
    <div className="tricktable">
      {slot(top,"top")}
      {slot(left,"left")}
      <div className="tcenter">
        <div className="tinfo">
          <div className="big num">{s.tricks[declSide]}<span className="slash">/{s.contract?6+s.contract.level:""}</span></div>
          <div className="lbl2">declarer tricks</div>
          <div className="trk2 num">{SIDE_NAME[0]} {s.tricks[0]} · {s.tricks[1]} {SIDE_NAME[1]}</div>
        </div>
      </div>
      {slot(right,"right")}
      {slot(bottom,"bottom")}
    </div>
  );
}

/* ---------------- a hand row ---------------- */
function HandRow({hand, onPlay, legalIds, selectable, label, faceDown, count, sugId}){
  const cards=sortHandDisplay(hand||[]);
  return (
    <div className="handblock">
      {label && <div className="hlabel lbl2">{label}{count!=null?` · ${count}`:""}</div>}
      <div className="hand">
        {faceDown
          ? Array.from({length:count||cards.length}).map((_,i)=><Card key={i} faceDown small/>)
          : cards.map(c=>{
              const ok=!legalIds || legalIds.has(c.id);
              return <Card key={c.id} c={c} small={label!=="You"} suggested={sugId===c.id}
                onClick={selectable&&ok?()=>onPlay(c):undefined} disabled={selectable&&!ok}/>;
            })}
      </div>
    </div>
  );
}

/* ---------------- rubber score sheet ---------------- */
function ScoreSheet({s}){
  const vtag=(side)=> s.vuln[side]?"VUL":"—";
  return (
    <div className="sheet">
      <div className="shead"><div className="scorner"></div><div className="scol">{SIDE_NAME[0]}</div><div className="scol">{SIDE_NAME[1]}</div></div>
      <div className="srow"><div className="slbl">Total</div><div className="sval num big">{s.total[0]}</div><div className="sval num big">{s.total[1]}</div></div>
      <div className="srow"><div className="slbl">Games</div><div className="sval num">{s.games[0]}</div><div className="sval num">{s.games[1]}</div></div>
      <div className="srow"><div className="slbl">Toward game</div><div className="sval num">{s.gameBelow[0]}</div><div className="sval num">{s.gameBelow[1]}</div></div>
      <div className="srow"><div className="slbl">Vulnerable</div><div className={"sval vul"+(s.vuln[0]?" on":"")}>{vtag(0)}</div><div className={"sval vul"+(s.vuln[1]?" on":"")}>{vtag(1)}</div></div>
    </div>
  );
}

/* ---------------- pass-and-play reveal gate ---------------- */
function RevealGate({s, seat, onReveal}){
  const p=seatPersona(s,seat);
  return (
    <div className="revealgate">
      <div className="rg-glyph" style={{color:p.color}}>{p.glyph}</div>
      <div className="rg-who">{who(s,seat)} — {SEAT_NAME[seat]}</div>
      <div className="rg-sub lbl2">Pass the device. Hide the previous player's cards.</div>
      <button style={btn("gold")} onClick={onReveal}>Reveal my hand</button>
    </div>
  );
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { AuctionView, BiddingBox, CallChip, HandRow, RevealGate, ScoreSheet, SeatBadge, TrickTable };
//#endregion gen
