//#region gen (auto — removed when bundled to a single bridge.jsx)
import React from "react";
import { CURRICULUM } from "../data/curriculum.js";
import { makeGenerator } from "../drills/generator.js";
import { AUC } from "../engine/auction.js";
import { BID } from "../engine/bidding.js";
import { ENG } from "../engine/core.js";
import { PLY } from "../engine/play.js";
import { SEAT_ABBR, SEAT_NAME, STRAIN_GLYPH, SUIT_GLYPH, callLabel, sortHandDisplay } from "../state/constants.js";
import { getGlossary, whyText } from "../state/teachingMode.js";
import { Card } from "./cards.jsx";
import { GlossaryScreen, linkifyGlossary } from "./glossary.jsx";
import { describeCall } from "./helpDrawer.jsx";
import { btn } from "./theme.js";
//#endregion gen

/* ======================================================================
   LEARN — a browseable curriculum of lessons with live practice drills.
   Reads the shared CURRICULUM; runs drills through the same generator the
   engine was verified against. Every teach text and explanation is linkified.
   ====================================================================== */
function dwCallKey(c){ return c.k==="B" ? "B"+c.level+c.strain : c.k; }
function LearnHand({hand}){
  const cards=sortHandDisplay(hand||[]);
  return <div className="lrn-hand"><div className="hand">{cards.map(c=><Card key={c.id} c={c} small/>)}</div></div>;
}
function AuctionStrip({calls, dealer}){
  if(!calls || !calls.length) return null;
  return (
    <div className="lrn-auction">
      {calls.map((c,i)=>(
        <span key={i} className={"lrn-acall "+(c.by%2===0?"us":"them")}>
          <span className="s">{SEAT_ABBR[c.by]}</span><span className={"b"+((c.k==="B"&&(c.strain==="H"||c.strain==="D"))?" red":"")}>{callLabel(c)}</span>
        </span>
      ))}
    </div>
  );
}
function DeclarerDummy({declHand, dummyHand, contractLabel}){
  return (
    <div className="lrn-decldummy">
      {contractLabel && <div className="lrn-contract">Contract: <b>{contractLabel}</b> — you are declarer (South)</div>}
      <div className="lrn-yourhand-l">Dummy (North)</div>
      <LearnHand hand={dummyHand}/>
      <div className="lrn-yourhand-l">Your hand (South, declarer)</div>
      <LearnHand hand={declHand}/>
    </div>
  );
}
function DrillRunner({lesson, onBack, onTapTerm}){
  const gen=React.useMemo(()=>makeGenerator({ENG,AUC,BID,PLY}),[]);
  const [drill,setDrill]=React.useState(()=>gen.generate(lesson));
  const [pick,setPick]=React.useState(null);
  const [score,setScore]=React.useState({c:0,n:0});
  const gloss=getGlossary();
  const link=(t)=>linkifyGlossary(t, gloss, onTapTerm);
  const next=()=>{ setPick(null); setDrill(gen.generate(lesson)); };
  if(!drill || !drill.ok){
    return <div className="lrn-drill"><div className="lrn-fail">This drill couldn't be generated just now.</div><button className="lrn-btn" onClick={next}>Try again</button><button className="lrn-btn ghost" onClick={onBack}>Back</button></div>;
  }
  const isEval=drill.kind==="eval", isLead=drill.kind==="lead", isConcept=drill.kind==="concept", isDecl=drill.kind==="declcount";
  const isMC=isEval||isConcept||isDecl;   // multiple-choice kinds share {label,correct} choices
  // correctness + reveal data per kind
  let choices, isCorrect, correctLabel, whyText, prompt;
  if(isMC){
    choices=drill.choices; prompt=drill.prompt; correctLabel=drill.answerLabel; whyText=drill.why;
    isCorrect=(ch)=>!!ch.correct;
  } else if(isLead){
    choices=drill.choices; prompt="What do you lead?"; correctLabel=drill.answerLabel; whyText=drill.why;
    isCorrect=(ch)=>ch.rank===drill.answer.rank && ch.suit===drill.answer.suit;
  } else {
    choices=drill.choices; prompt="What's your call?"; correctLabel=callLabel(drill.answer);
    whyText=describeCall(drill.calls, drill.dealer, 0, drill.answer).meaning;
    isCorrect=(ch)=>dwCallKey(ch)===dwCallKey(drill.answer);
  }
  const choose=(ch)=>{ if(pick) return; setPick(ch); setScore(s=>({c:s.c+(isCorrect(ch)?1:0),n:s.n+1})); };
  const chLabel=(ch)=> isMC?ch.label : isLead?(ch.rank+SUIT_GLYPH[ch.suit]) : callLabel(ch);
  const chKey=(ch,i)=> isMC?("e"+i) : isLead?(ch.rank+ch.suit) : dwCallKey(ch);
  const picked = pick!=null;
  const gotIt = picked && isCorrect(pick);
  return (
    <div className="lrn-drill">
      <div className="lrn-drill-top">
        <button className="lrn-back" onClick={onBack}>‹ lesson</button>
        <span className="lrn-score num">{score.c}/{score.n}</span>
      </div>
      {isLead && drill.contract && <div className="lrn-contract">Contract: <b>{drill.contract.level}{STRAIN_GLYPH[drill.contract.strain]}</b> by {SEAT_NAME[drill.contract.declarer]} — you're on lead</div>}
      {drill.calls && <AuctionStrip calls={drill.calls} dealer={drill.dealer}/>}
      {drill.southHand && <><div className="lrn-yourhand-l">Your hand (South)</div><LearnHand hand={drill.southHand}/></>}
      {drill.declHand && <DeclarerDummy declHand={drill.declHand} dummyHand={drill.dummyHand} contractLabel={drill.contractLabel}/>}
      {drill.scenario && <div className="lrn-scenario">{link(drill.scenario)}</div>}
      <div className="lrn-prompt">{link(prompt)}</div>
      <div className={"lrn-choices"+(isLead?" cards":"")}>
        {choices.map((ch,i)=>{
          const mine=picked && chKey(pick)===chKey(ch,i);
          const correct=picked && isCorrect(ch);
          const cls="lrn-choice"+(correct?" correct":"")+(mine&&!correct?" wrong":"")+((ch.k==="B"&&(ch.strain==="H"||ch.strain==="D"))||(isLead&&(ch.suit==="H"||ch.suit==="D"))?" red":"");
          return <button key={chKey(ch,i)} className={cls} disabled={picked} onClick={()=>choose(ch)}>{chLabel(ch)}</button>;
        })}
      </div>
      {picked && (
        <div className={"lrn-reveal "+(gotIt?"ok":"no")}>
          <div className="lrn-verdict">{gotIt?"Correct":"Not quite"} — answer: <b>{correctLabel}</b></div>
          <div className="lrn-why">{link(whyText)}</div>
          <button className="lrn-btn" onClick={next}>Next hand ›</button>
        </div>
      )}
    </div>
  );
}
/* Long-form lesson text ("the textbook") is fetched at runtime from bridge-teaching.json
   under the "lessons" key, keyed by lesson id. Until it loads (or in the artifact preview, where
   there is no JSON to fetch), LessonPage falls back to the short `teach` note. Keeping the prose
   out of this file keeps the app lean; the JSON is the source of truth for lesson content. */
function getLessonText(id){
  return (typeof window!=="undefined" && window.BRIDGE_TEACHING && window.BRIDGE_TEACHING.lessons
    && window.BRIDGE_TEACHING.lessons[id]) || null;
}

/* Flat, ordered index across all modules — for prev/next navigation and cross-refs. */
const LESSON_FLAT = CURRICULUM.flatMap(m => m.lessons.map(l => ({ ...l, module: m.module })));
const LESSON_BY_ID = Object.fromEntries(LESSON_FLAT.map(l => [l.id, l]));

/* Render lesson body: paragraphs, [[id]] cross-reference links, glossary + suit colour. */
function renderLessonBody(text, gloss, onTapTerm, onNavId){
  return String(text).split(/\n\n+/).map((para, pi) => {
    const parts=[]; let last=0, m, i=0; const re=/\[\[([a-z0-9-]+)\]\]/gi;
    while((m=re.exec(para))){
      if(m.index>last) parts.push(...linkifyGlossary(para.slice(last,m.index), gloss, onTapTerm));
      const id=m[1], les=LESSON_BY_ID[id];
      parts.push(<span key={"x"+pi+"-"+(i++)} className="lrn-xref" onClick={(e)=>{e.stopPropagation(); onNavId && onNavId(id);}}>{les?les.title:id}</span>);
      last=m.index+m[0].length;
    }
    if(last<para.length) parts.push(...linkifyGlossary(para.slice(last), gloss, onTapTerm));
    return <p key={pi} className="lrn-l-para">{parts}</p>;
  });
}

function LessonPage({lesson, onBack, onTapTerm, onNav, onNavId}){
  const [drilling,setDrilling]=React.useState(false);
  const gloss=getGlossary();
  const bookRef = lesson.ch ? ("Standard Bidding with SAYC — ch. "+lesson.ch) : null;
  const idx = LESSON_FLAT.findIndex(l=>l.id===lesson.id);
  const prev = idx>0 ? LESSON_FLAT[idx-1] : null;
  const next = idx>=0 && idx<LESSON_FLAT.length-1 ? LESSON_FLAT[idx+1] : null;
  const body = getLessonText(lesson.id);
  if(drilling) return <DrillRunner lesson={lesson} onBack={()=>setDrilling(false)} onTapTerm={onTapTerm}/>;
  return (
    <div className="lrn-lesson">
      <button className="lrn-back" onClick={onBack}>‹ all lessons</button>
      <div className="lrn-l-mod">{lesson.module} &nbsp;·&nbsp; {idx+1} / {LESSON_FLAT.length}</div>
      <h3 className="lrn-l-title">{lesson.title}</h3>
      {bookRef && <div className="lrn-l-ref">{bookRef}</div>}
      {body
        ? <div className="lrn-l-body">{renderLessonBody(body, gloss, onTapTerm, onNavId)}</div>
        : <p className="lrn-l-teach">{linkifyGlossary(lesson.teach, gloss, onTapTerm)}</p>}
      {lesson.drill
        ? <button className="lrn-btn big" onClick={()=>setDrilling(true)}>Practice this ›</button>
        : <div className="lrn-teachonly">A concept lesson — read and absorb; there's no single-answer drill for it.</div>}
      <div className="lrn-nav">
        <button className="lrn-nav-b" disabled={!prev} onClick={()=>prev&&onNav(-1)}>{prev? "‹ "+prev.title : ""}</button>
        <button className="lrn-nav-b right" disabled={!next} onClick={()=>next&&onNav(1)}>{next? next.title+" ›" : ""}</button>
      </div>
    </div>
  );
}
function LearnScreen({onClose}){
  const [nav,setNav]=React.useState({stack:[], pos:-1});   // browser-style visit history
  const [glossTerm,setGlossTerm]=React.useState(null);
  const [showGloss,setShowGloss]=React.useState(false);
  const onTapTerm=(t)=>{ setGlossTerm(t); setShowGloss(true); };
  const sel = nav.pos>=0 ? LESSON_BY_ID[nav.stack[nav.pos]] : null;
  const canBack = nav.pos>0, canFwd = nav.pos < nav.stack.length-1;
  const go   = (id)=>{ if(!LESSON_BY_ID[id]) return; setNav(n=>{ const stack=n.stack.slice(0,n.pos+1); stack.push(id); return {stack, pos:stack.length-1}; }); };
  const back = ()=> setNav(n=> n.pos>0 ? {...n, pos:n.pos-1} : n);
  const fwd  = ()=> setNav(n=> n.pos<n.stack.length-1 ? {...n, pos:n.pos+1} : n);
  const toList = ()=> setNav({stack:[], pos:-1});
  const drillableCount=CURRICULUM.reduce((n,m)=>n+m.lessons.filter(l=>l.drill).length,0);
  const total=CURRICULUM.reduce((n,m)=>n+m.lessons.length,0);
  return (
    <div className="lrn-overlay">
      <div className="lrn-top">
        {sel && <div className="lrn-hist">
          <button className="lrn-hb" disabled={!canBack} onClick={back} title="Back">‹</button>
          <button className="lrn-hb" disabled={!canFwd} onClick={fwd} title="Forward">›</button>
        </div>}
        <span className="lrn-title">LEARN&nbsp;·&nbsp;SAYC</span>
        <button className="dl-x" onClick={onClose}>×</button>
      </div>
      <div className="lrn-scroll">
        {sel ? (
          <LessonPage lesson={sel} onBack={toList} onTapTerm={onTapTerm}
            onNav={(d)=>{ const i=LESSON_FLAT.findIndex(l=>l.id===sel.id); const j=i+d; if(j>=0&&j<LESSON_FLAT.length) go(LESSON_FLAT[j].id); }}
            onNavId={(id)=>go(id)}/>
        ) : (
          <>
            <div className="lrn-intro">{total} lessons across {CURRICULUM.length} modules · {drillableCount} with live practice drills. Tap a lesson to read it; drillable lessons let you practice against the bidding engine.</div>
            {CURRICULUM.map((m,mi)=>(
              <div key={mi} className="lrn-module">
                <div className="lrn-mod-h">{m.module}</div>
                {m.lessons.map(l=>(
                  <button key={l.id} className="lrn-lrow" onClick={()=>go(l.id)}>
                    <span className="lrn-lrow-t">{l.title}</span>
                    {l.drill ? <span className="lrn-badge drill">drill</span> : <span className="lrn-badge read">read</span>}
                  </button>
                ))}
              </div>
            ))}
          </>
        )}
      </div>
      {showGloss && <GlossaryScreen gloss={getGlossary()} focusTerm={glossTerm} onClose={()=>{setShowGloss(false);setGlossTerm(null);}}/>}
    </div>
  );
}



//#region gen (auto — removed when bundled to a single bridge.jsx)
export { AuctionStrip, DeclarerDummy, DrillRunner, LESSON_BY_ID, LESSON_FLAT, LearnHand, LearnScreen, LessonPage, dwCallKey, getLessonText, renderLessonBody };
//#endregion gen
