/* ---- online multiplayer bindings (inert unless the shell provides them) ---- */
const __BR_INERT_NET = { role:"off", seat:0, status:"", room:null, snap:null, snapV:0, roster:[],
  names:["","","",""], namesV:0, target:0, full:false, myInitials:"", playerCount:0, downSeats:[],
  isSeatDown:()=>false, prefillCode:"", savedSession:null, lobbyChat:[], roomChat:[], games:[], highScores:[], pub:null, pubV:0,
  requests:[], pendingRoom:null, started:false, availableSeats:()=>[],
  setInitials(){}, hostGame(){}, joinGame(){}, rejoin(){}, goSolo(){}, backToLobby(){}, closeRoom(){}, spectate(){},
  approveRequest(){}, denyRequest(){}, kickSeat(){}, cancelRequest(){},
  sendLobbyChat(){}, sendRoomChat(){}, send(){}, broadcastState(){} };
const useBridgeNet  = (typeof window!=="undefined" && (window.useGameNet || window.useBridgeNet)) || (()=>__BR_INERT_NET);
const OnlineBar     = (typeof window!=="undefined" && (window.GameBar || window.OnlineBar)) || (()=>null);
const OnlineScreens = (typeof window!=="undefined" && (window.LobbyScreens || window.OnlineScreens)) || (()=>null);
const SpectatorView = (typeof window!=="undefined" && window.SpectatorView) || (()=>null);


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { OnlineBar, OnlineScreens, SpectatorView, __BR_INERT_NET, useBridgeNet };
//#endregion gen
