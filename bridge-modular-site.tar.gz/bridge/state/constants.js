//#region gen (auto — removed when bundled to a single bridge.jsx)
import { AUC } from "../engine/auction.js";
import { ENG } from "../engine/core.js";
import { C } from "../ui/theme.js";
//#endregion gen

/* =======================================================================
   DISPLAY CONSTANTS + SEAT / SIDE HELPERS
   ===================================================================== */
const SUIT_GLYPH   = { S:"\u2660\uFE0E", H:"\u2665\uFE0E", D:"\u2666\uFE0E", C:"\u2663\uFE0E" };
const STRAIN_GLYPH = { C:"\u2663\uFE0E", D:"\u2666\uFE0E", H:"\u2665\uFE0E", S:"\u2660\uFE0E", NT:"NT" };
const STRAIN_ORDER = ["C","D","H","S","NT"];
const SEAT_NAME = ["South","West","North","East"];
const SEAT_ABBR = ["S","W","N","E"];
const SIDE_NAME = ["N–S","E–W"];
const sideOf    = (seat)=> seat%2;                 // NS = {0,2}, EW = {1,3}
const partnerOf = (seat)=> (seat+2)%4;
const nextSeat  = (seat)=> (seat+1)%4;
const RVAL = ENG.RANKVAL;
const SUIT_DISPLAY = ["S","H","D","C"];
// group a hand by suit (♠♥♦♣), rank high→low within suit
function sortHandDisplay(hand){
  return [...hand].sort((a,b)=>{
    const sa=SUIT_DISPLAY.indexOf(a.suit), sb=SUIT_DISPLAY.indexOf(b.suit);
    if(sa!==sb) return sa-sb;
    return RVAL[a.rank]-RVAL[b.rank];   // ascending within a suit (low → high, left → right)
  });
}
// the declarer plays the dummy's cards
function controllerOf(s, seat){ return (s.contract && seat===s.dummy) ? s.declarer : seat; }
const callLabel = AUC.callLabel;


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { RVAL, SEAT_ABBR, SEAT_NAME, SIDE_NAME, STRAIN_GLYPH, STRAIN_ORDER, SUIT_DISPLAY, SUIT_GLYPH, callLabel, controllerOf, nextSeat, partnerOf, sideOf, sortHandDisplay };
//#endregion gen
