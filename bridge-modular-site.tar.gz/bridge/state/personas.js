//#region gen (auto — removed when bundled to a single bridge.jsx)
import { SEAT_ABBR } from "./constants.js";
//#endregion gen

/* =======================================================================
   BOT PERSONAS — all bid SAYC and play standard bridge; `skill` only softens
   the weakest persona's non-critical follows (never the human's suggestion).
   ===================================================================== */
const PROFILES = {
  sayer:   {name:"Sayer",   glyph:"♠", color:"var(--sp)",   blurb:"Textbook SAYC. Bids what the points say and plays the percentages.", skill:5},
  rubber:  {name:"Rubber",  glyph:"♥", color:"var(--he)",   blurb:"Old-school rubber player — values tricks, dreads undertricks.",       skill:4},
  gambit:  {name:"Gambit",  glyph:"♦", color:"var(--di)",   blurb:"Aggressive. Stretches for games and competes hard in the auction.",  skill:4},
  finesse: {name:"Finesse", glyph:"♣", color:"var(--cl)",   blurb:"Careful defender. Leads fourth-best and reads the count.",            skill:5},
  novice:  {name:"Novice",  glyph:"☻", color:"var(--cyan)", blurb:"Still learning. A gentle, forgiving opponent to practice against.",   skill:2},
};
const ALL_BRAINS = ["sayer","rubber","gambit","finesse","novice"];
const HUMAN_DISPLAY = { glyph:"☻", color:"var(--cyan)" };
function seatPersona(s,pi){
  return s.brains[pi]==="human"
    ? { name:(pi===0?"You":`Seat ${SEAT_ABBR[pi]}`), glyph:HUMAN_DISPLAY.glyph, color:HUMAN_DISPLAY.color, human:true, skill:5 }
    : PROFILES[s.brains[pi]] || PROFILES.sayer;
}
function who(s,pi){
  const nm=s.names&&s.names[pi];
  if(nm) return nm;
  return s.brains[pi]==="human" ? (pi===0?"You":`Seat ${SEAT_ABBR[pi]}`) : (PROFILES[s.brains[pi]]||PROFILES.sayer).name;
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { ALL_BRAINS, HUMAN_DISPLAY, PROFILES, seatPersona, who };
//#endregion gen
