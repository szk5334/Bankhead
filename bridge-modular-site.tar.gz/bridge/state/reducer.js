//#region gen (auto — removed when bundled to a single bridge.jsx)
import { AUC } from "../engine/auction.js";
import { BID } from "../engine/bidding.js";
import { ENG } from "../engine/core.js";
import { PLY } from "../engine/play.js";
import { SCO } from "../engine/scoring.js";
import { SIDE_NAME, STRAIN_GLYPH, callLabel, controllerOf, nextSeat, partnerOf, sideOf } from "./constants.js";
import { seatPersona, who } from "./personas.js";
//#endregion gen

/* =======================================================================
   STATE — a rubber (best of three games) played one deal at a time.
   ===================================================================== */
function freshDeal(prev, dealer){
  const deck = ENG.shuffle(ENG.makeDeck());
  const hands = {0:[],1:[],2:[],3:[]};
  for(let i=0;i<52;i++) hands[i%4].push(deck[i]);
  const dealtHands = {0:[...hands[0]],1:[...hands[1]],2:[...hands[2]],3:[...hands[3]]};
  return {
    ...prev,
    phase:"auction",
    hands, dealtHands, dealer,
    calls:[], turn:dealer,
    contract:null, trump:null, declarer:null, dummy:null,
    trick:[], ledSuit:null, tricksPlayed:0, trickHistory:[],
    tricks:[0,0], seen:[], lastTrick:null, dummyRevealed:false,
    result:null,
    roundStartedAt:Date.now(), roundEndedAt:null,
    log:[`Deal ${prev.dealNo||1}. ${who(prev,dealer)} deals.`],
    dealNo:(prev.dealNo||1),
    gradeQueue:[], grades:{}, gradeOn:(prev.gradeOn!==false),
  };
}
function freshRubber(brains, names, dealer){
  const base = {
    mode:"play", n:4, brains:[...brains], names:(names||["","","",""]).slice(0,4),
    rubberNo:1, dealNo:1,
    games:[0,0], vuln:[false,false], gameBelow:[0,0], total:[0,0],
    rubberDone:false, rubberWinner:null, sheet:[],
    gradeOn:true,
  };
  return freshDeal(base, dealer!=null?dealer:0);
}
const SETUP = { mode:"setup", n:4, brains:["human","sayer","gambit","finesse"], names:["","","",""] };

const cloneState=(s)=>{
  const c={...s};
  if(s.hands) c.hands={0:[...s.hands[0]],1:[...s.hands[1]],2:[...s.hands[2]],3:[...s.hands[3]]};
  if(s.dealtHands) c.dealtHands={0:[...s.dealtHands[0]],1:[...s.dealtHands[1]],2:[...s.dealtHands[2]],3:[...s.dealtHands[3]]};
  c.calls=[...(s.calls||[])]; c.trick=[...(s.trick||[])]; c.seen=[...(s.seen||[])];
  c.games=[...s.games]; c.vuln=[...s.vuln]; c.gameBelow=[...s.gameBelow]; c.total=[...s.total];
  c.tricks=[...(s.tricks||[0,0])]; c.brains=[...s.brains];
  c.names=[...(s.names||["","","",""])]; c.sheet=[...(s.sheet||[])]; c.log=[...(s.log||[])];
  c.gradeQueue=[...(s.gradeQueue||[])]; c.grades={...(s.grades||{})};
  return c;
};
const pushLog=(s,l)=>{ s.log=[l,...(s.log||[])].slice(0,40); };

/* ---- auction step ---- */
function applyBid(s, seat, call){
  const c={...call, by:seat};
  s.calls=[...s.calls, c];
  pushLog(s, `${who(s,seat)}: ${callLabel(c)}`);
  const info = AUC.auctionInfo(s.calls, s.dealer);
  if(info.ended){
    if(info.passedOut || !info.contract){
      pushLog(s, "Passed out — redeal.");
      return freshDeal({...s, dealNo:(s.dealNo||1)+1}, nextSeat(s.dealer));
    }
    const ct=info.contract;
    s.contract=ct; s.trump=ct.strain;
    s.declarer=ct.declarer; s.dummy=partnerOf(ct.declarer);
    s.phase="play"; s.turn=nextSeat(ct.declarer);           // opening lead by declarer's LHO
    s.trick=[]; s.ledSuit=null; s.tricksPlayed=0; s.tricks=[0,0]; s.seen=[]; s.dummyRevealed=false;
    const dblTxt = ct.dbl===4?" redoubled":ct.dbl===2?" doubled":"";
    pushLog(s, `Contract: ${ct.level}${STRAIN_GLYPH[ct.strain]}${dblTxt} by ${who(s,ct.declarer)}. ${who(s,s.turn)} leads.`);
    return s;
  }
  s.turn=nextSeat(seat);
  return s;
}

/* ---- live declarer-play grading (additive; a snapshot is queued, graded off-thread by the worker,
   and the result is attached as a Table Talk log line — it NEVER touches game state) ---- */
function gradeVoidsPlayed(s, includeCurrent){
  const voids=[new Set(),new Set(),new Set(),new Set()];
  const played=[[],[],[],[]];
  for(const t of (s.trickHistory||[])){
    for(const tc of t.trick){
      played[tc.seat].push({rank:tc.card.rank, suit:tc.card.suit});
      if(tc.card.suit!==t.ledSuit) voids[tc.seat].add(tc.card.suit);   // show-out void
    }
  }
  // fold in the CURRENT partial trick so a mid-trick grade uses this trick's shows/plays too
  if(includeCurrent && s.trick && s.trick.length){
    for(const tc of s.trick){
      played[tc.seat].push({rank:tc.card.rank, suit:tc.card.suit});
      if(tc.card.suit!==s.ledSuit) voids[tc.seat].add(tc.card.suit);
    }
  }
  return {voids, played};
}
function gradeHash(str){ let h=2166136261>>>0; for(let i=0;i<str.length;i++){ h^=str.charCodeAt(i); h=Math.imul(h,16777619);} return h>>>0; }
// Build the grade/decision snapshot for `seat` about to play `card`. `card` only sets played_key (the seed
// is keyed on the POSITION, not the card, so a bot's decision request and the grade of the card it then
// plays sample identically). Returns null when the position shouldn't be graded/recommended (grading off,
// no contract, or the 3-hidden opening lead). SHARED by the live grader AND the bot's SD play chooser, so
// bots play exactly what the grader teaches.
function buildGradePos(s, seat, card){
  if(!s.gradeOn || !s.contract) return null;
  const declSide=sideOf(s.contract.declarer);
  const isDeclActor = sideOf(seat)===declSide;
  // The opening lead happens BEFORE dummy is exposed (3 hidden hands — outside the 2-hidden sampler), so
  // skip just that one. Everything else is graded: declarer/dummy plays and post-dummy defender plays, at
  // ANY position in the trick (lead OR 2nd/3rd/4th hand — mid-trick grading via solveFollow).
  if(!isDeclActor && !s.dummyRevealed) return null;
  const defs=[0,1,2,3].filter(x=>sideOf(x)!==declSide);
  const {voids, played}=gradeVoidsPlayed(s, true);      // include the current partial trick's shows/plays
  const strip=(h)=>h.map(c=>({rank:c.rank, suit:c.suit}));
  const played_key=`${card.rank}.${card.suit}`;
  const posInTrick=s.trick.length;                      // 0 = lead, 1..3 = 2nd/3rd/4th hand
  const moveId=`${s.rubberNo||1}.${s.dealNo||1}.${s.tricksPlayed}.${posInTrick}`;   // unique per card played
  // cards already on the CURRENT trick (in play order); ledSuitIdx is derived worker-side from trick[0].
  const trick=s.trick.map(tc=>({seat:tc.seat, suit:tc.card.suit, rank:tc.card.rank}));
  return {
    hands:[strip(s.hands[0]),strip(s.hands[1]),strip(s.hands[2]),strip(s.hands[3])],
    voids:voids.map(v=>[...v]), played,
    trump:s.trump, declarer:s.contract.declarer, leader:seat, defs,
    won_decl:s.tricks[declSide], completed:s.tricksPlayed,
    need:6+s.contract.level, level:s.contract.level,
    played_key, seed:gradeHash(moveId), N:16,                 // seed on POSITION so decision == grade
    payoff:"imp", vul:!!s.vuln[declSide], moveId, tricksPlayed:s.tricksPlayed, leaderSeat:seat,
    posInTrick, trick: trick.length ? trick : undefined,
  };
}
function maybeEnqueueGrade(s, seat, card){
  const pos=buildGradePos(s, seat, card);
  if(pos) s.gradeQueue=[...(s.gradeQueue||[]), pos];
}
// Snapshot for asking the grader what the single-dummy-best card is for `seat`'s CURRENT turn (played_key is
// a placeholder — best_named/best don't depend on it). Returns null => let the engine decide (grading off,
// no contract, or the opening lead). App's bot loop posts this to the worker and plays grade.best_named, so
// the bots play (and explain) the single-dummy recommendation the teaching layer would give.
function sdDecisionPos(s, seat){
  const legal=ENG.legalPlays(s.hands[seat], s.trick.length?s.ledSuit:null);
  if(!legal || !legal.length) return null;
  const pos=buildGradePos(s, seat, legal[0]);
  if(pos) pos.decide=true;                                    // App reads best_named; not logged as a grade
  return pos;
}

/* ---- play step ---- */
function applyPlay(s, seat, cardId, whyOverride){
  const hand=s.hands[seat];
  const card=hand.find(c=>c.id===cardId) || ENG.legalPlays(hand, s.trick.length?s.ledSuit:null)[0];
  try{ maybeEnqueueGrade(s, seat, card); }catch(_){}   // snapshot BEFORE the card leaves the hand
  // Reasoning for the Table Talk play-by-play. A bot playing the single-dummy recommendation passes the
  // grader's own reason (whyOverride); otherwise fall back to the engine's read, which applies when the
  // played card is the one the engine would choose (always true for the bots; true for a human "by the book").
  let why = (whyOverride!=null) ? whyOverride : null;
  if(why==null){ try{ const rec=PLY.chooseCardWhy(playCtx(s, seat)); if(rec && rec.card && rec.card.id===card.id) why=rec.why; }catch(_){ why=null; } }
  s.hands={...s.hands, [seat]: hand.filter(c=>c.id!==card.id)};
  const firstCardOfDeal = (s.tricksPlayed===0 && s.trick.length===0);
  if(s.trick.length===0) s.ledSuit=card.suit;
  s.trick=[...s.trick, {seat, card, why}];
  if(firstCardOfDeal) s.dummyRevealed=true;               // dummy exposed after the opening lead
  if(s.trick.length===4){
    const cards=s.trick.map(tc=>({rank:tc.card.rank,suit:tc.card.suit,player:tc.seat}));
    const { winner } = ENG.resolveTrick(cards, s.ledSuit, s.trump);
    s.tricks=[...s.tricks]; s.tricks[sideOf(winner)] += 1;
    s.seen=[...s.seen, ...s.trick.map(tc=>tc.card)];
    s.lastTrick={ trick:s.trick, winner, ledSuit:s.ledSuit };
    s.trickHistory=[...(s.trickHistory||[]), { num:s.tricksPlayed+1, trick:s.trick, winner, ledSuit:s.ledSuit, trump:s.trump }];
    pushLog(s, `Trick ${s.tricksPlayed+1}: ${who(s,winner)} wins. ${SIDE_NAME[0]} ${s.tricks[0]} – ${s.tricks[1]} ${SIDE_NAME[1]}.`);
    s.trick=[]; s.ledSuit=null; s.tricksPlayed=s.tricksPlayed+1; s.turn=winner;
    if(s.tricksPlayed===13) return scoreDeal(s);
    return s;
  }
  s.turn=nextSeat(seat);
  return s;
}

/* ---- deal scoring + rubber bookkeeping ---- */
function scoreDeal(s){
  const ct=s.contract;
  const declSide=sideOf(ct.declarer), defSide=1-declSide;
  const target=6+ct.level;
  const declTricks=s.tricks[declSide];
  const vulnerable=s.vuln[declSide];
  const r = SCO.scoreHand(ct, declTricks, vulnerable);
  // honours (held in one hand) — optional standard bonus
  let honDetail=[]; const honSide=[0,0];
  for(let seat=0;seat<4;seat++){
    const h=SCO.honoursForHand(s.dealtHands[seat], ct.strain);
    if(h>0){ honSide[sideOf(seat)]+=h; honDetail.push(`${who(s,seat)} +${h} honours`); }
  }
  s.total=[...s.total]; s.gameBelow=[...s.gameBelow]; s.games=[...s.games]; s.vuln=[...s.vuln];
  if(r.made){ s.gameBelow[declSide]+=r.below; s.total[declSide]+=r.below+r.above; }
  else { s.total[defSide]+=r.above; }
  s.total[0]+=honSide[0]; s.total[1]+=honSide[1];
  let gameWon=false, rubberDone=false, rubberWinner=null, rubberBonus=0;
  if(r.made && s.gameBelow[declSide]>=100){
    s.games[declSide]+=1; gameWon=true;
    s.gameBelow=[0,0];
    s.vuln[declSide]=true;
    if(s.games[declSide]===2){
      rubberDone=true; rubberWinner=declSide;
      rubberBonus = (s.games[defSide]===0)?700:500;
      s.total[declSide]+=rubberBonus;
    }
  }
  s.phase="scored"; s.roundEndedAt=Date.now();
  s.rubberDone=rubberDone; s.rubberWinner=rubberWinner;
  const dblTxt = ct.dbl===4?" XX":ct.dbl===2?" X":"";
  const head = `${ct.level}${STRAIN_GLYPH[ct.strain]}${dblTxt} by ${who(s,ct.declarer)} — ${r.made?"MADE":"DOWN "+r.under} (${declTricks} tricks, needed ${target})`;
  pushLog(s, head);
  s.result={ made:r.made, declSide, defSide, target, declTricks,
    below:r.below, above:r.above, over:r.over, under:r.under,
    detail:r.detail, honours:honDetail, honSide,
    gameWon, rubberDone, rubberWinner, rubberBonus, contract:ct, head };
  s.sheet=[...(s.sheet||[]), { head, made:r.made, declSide, below:r.below, above:r.above, honDetail }];
  return s;
}

/* ---- reducer ---- */
function reducer(state, a){
  if(a.type==="__SYNC__") return a.state;
  switch(a.type){
    case "SET_BRAIN":{ const brains=[...state.brains]; brains[a.seat]=a.key; return {...state, brains}; }
    case "SET_NAME":{ const names=[...(state.names||["","","",""])]; names[a.seat]=a.name||""; return {...state, names}; }
    case "START": return freshRubber(state.brains, state.names, 0);
    case "RESUME":
      return { ...freshRubber(a.brains, a.names, a.dealer!=null?a.dealer:0),
        games:a.games||[0,0], vuln:a.vuln||[false,false], gameBelow:a.gameBelow||[0,0],
        total:a.total||[0,0], rubberNo:a.rubberNo||1 };
    case "SET_BRAIN_LIVE":{
      const brains=state.brains.map((b,i)=> i===a.seat ? a.brain : b);
      const names=(state.names||["","","",""]).slice(); if(a.seat<names.length) names[a.seat]=a.name!=null?a.name:"";
      return {...state, brains, names};
    }
    case "BID":{
      const s=cloneState(state);
      let call=a.call;
      if(!AUC.callLegal(call, s.calls, s.dealer)) call={k:"P"};
      return applyBid(s, a.seat!=null?a.seat:s.turn, call);
    }
    case "PLAY":{ const s=cloneState(state); return applyPlay(s, a.player!=null?a.player:s.turn, a.cardId, a.why); }
    case "PLAY_GRADE":{
      const g=a.grade;
      const s=cloneState(state);
      s.gradeQueue=(s.gradeQueue||[]).filter(p=>p.moveId!==a.moveId);
      if(g && !g.skipped){
        s.grades={...(s.grades||{}), [a.moveId]: g};
        const glyph=(k)=>{ const i=k.lastIndexOf("."); return k.slice(0,i)+(STRAIN_GLYPH[k.slice(i+1)]||k.slice(i+1)); };
        const bestKey = g.best_named || g.best;   // A5: pedagogically-named representative
        const role = g.role==="defender" ? "Defence" : "Declarer play";
        const tag = g.played_in_equiv ? "\u2713 sound" : `best ${glyph(bestKey)}`;
        pushLog(s, `${role}: ${g.points}/100 \u2014 ${tag}${g.needs_clairvoyance?" (DD-only)":""}`);
      }
      return s;
    }
    case "TOGGLE_GRADE": return {...state, gradeOn: !state.gradeOn};
    case "NEXT_DEAL":{
      if(state.rubberDone) return state;
      const s=cloneState(state);
      return freshDeal({...s, dealNo:(s.dealNo||1)+1}, nextSeat(s.dealer));
    }
    case "NEW_RUBBER": return freshRubber(state.brains, state.names, 0);
    case "TO_SETUP": return {...SETUP, n:4, brains:[...state.brains], names:[...(state.names||["","","",""])]};
    default: return state;
  }
}

/* ---- build the play context for a seat (dummy is public once exposed;
   only the declarer legitimately sees both of the declaring hands) ---- */
function playCtx(s, seat){
  const declaring = s.contract && sideOf(seat)===sideOf(s.declarer);
  const dummyExposed = s.dummyRevealed && s.dummy!=null;
  return {
    hand:s.hands[seat], trick:s.trick.map(tc=>({rank:tc.card.rank,suit:tc.card.suit,player:tc.seat})),
    ledSuit:s.ledSuit, trump:s.trump, seat, declarer:s.declarer, dummy:s.dummy, seen:s.seen.slice(),
    history: (s.trickHistory||[]).map(t=>({ ledSuit:t.ledSuit, winner:t.winner,
      cards:t.trick.map(tc=>({ rank:tc.card.rank, suit:tc.card.suit, player:tc.seat })) })),
    dummyHand: dummyExposed ? s.hands[s.dummy].slice() : undefined,
    mateHand:  (declaring && seat===s.declarer) ? s.hands[s.dummy].slice()
             : (declaring && seat===s.dummy)    ? s.hands[s.declarer].slice() : undefined,
  };
}

/* ---- one bot action for the seat on turn ---- */
function botAction(s){
  const seat=s.turn;
  if(s.phase==="auction"){
    let call;
    try{ call=BID.chooseBid(s.hands[seat], s.calls, s.dealer, seat); }catch(_){ call={k:"P"}; }
    if(!call || !AUC.callLegal(call, s.calls, s.dealer)) call={k:"P"};
    return {type:"BID", seat, call};
  }
  const ctrl=controllerOf(s, seat);
  const persona=seatPersona(s, ctrl);
  const legal=ENG.legalPlays(s.hands[seat], s.trick.length?s.ledSuit:null);
  let card;
  try{ card=PLY.chooseCard(playCtx(s, seat)); }catch(_){ card=legal[0]; }
  if(!card || !legal.find(c=>c.id===card.id)) card=legal[0];
  if(persona.skill<=2 && legal.length>1 && Math.random()<0.25){
    const alt=legal[(Math.random()*legal.length)|0]; if(alt) card=alt;
  }
  return {type:"PLAY", player:seat, cardId:card.id};
}

/* suggestions for the human — full-strength, never softened */
function suggestBid(s, seat){ try{ return BID.chooseBid(s.hands[seat], s.calls, s.dealer, seat); }catch(_){ return {k:"P"}; } }
function suggestPlay(s, seat){
  try{ const c=PLY.chooseCard(playCtx(s, seat)); return c || ENG.legalPlays(s.hands[seat], s.trick.length?s.ledSuit:null)[0]; }
  catch(_){ return ENG.legalPlays(s.hands[seat], s.trick.length?s.ledSuit:null)[0]; }
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { SETUP, applyBid, applyPlay, botAction, buildGradePos, cloneState, freshDeal, freshRubber, gradeHash, gradeVoidsPlayed, maybeEnqueueGrade, playCtx, pushLog, reducer, scoreDeal, sdDecisionPos, suggestBid, suggestPlay };
//#endregion gen
