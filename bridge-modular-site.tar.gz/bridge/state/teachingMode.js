//#region gen (auto — removed when bundled to a single bridge.jsx)
import { BID } from "../engine/bidding.js";
import { ENG } from "../engine/core.js";
import { PLY } from "../engine/play.js";
import { callLabel } from "./constants.js";
import { who } from "./personas.js";
import { playCtx, suggestBid } from "./reducer.js";
import { C } from "../ui/theme.js";
//#endregion gen

/* =======================================================================
   TEACHING MODE — the "why" of each suggestion.
   The suggestion functions emit a reason CODE + a few params; a template
   table (overridable via window.BRIDGE_TEACHING) turns that into a sentence.
   ===================================================================== */
const SUIT_WORD = { S:"spades", H:"hearts", D:"diamonds", C:"clubs", NT:"no-trump" };

// classify a chosen bid into {code, ...params} using the same facts the bidder used
function explainBid(hand, calls, dealer, seat, call){
  let ev, ctx;
  try{ ev=BID.evalHand(hand); ctx=BID.context(calls, dealer, seat); }
  catch(_){ return { code:"B_GENERIC", hcp:0, call:callLabel(call) }; }
  const hcp=ev.hcp, len=ev.len, S=call.strain;
  const nobodyBidYet = ctx.openerSeat===-1;
  const partnerOpen = ctx.partnerBids && ctx.partnerBids[0];

  if(call.k==="P"){
    if(ctx.iOpened) return { code:"B_PASS_SETTLE", hcp };
    if(nobodyBidYet) return { code: hcp<=11?"B_PASS_OPEN":"B_PASS_NEUTRAL", hcp };
    if(ctx.openerSeat===ctx.partner) return { code: hcp<=7?"B_PASS_RESP":"B_PASS_NEUTRAL", hcp };
    if(ctx.partnerOpened) return { code: hcp<=8?"B_PASS_ADVANCE":"B_PASS_NEUTRAL", hcp };
    return { code: hcp<=12?"B_PASS_COMPETE":"B_PASS_NEUTRAL", hcp };
  }
  if(call.k==="D"){
    const lb=ctx.info.lastBid;
    if(!ctx.partnerOpened && lb && lb.level<=2 && lb.strain!=="NT") return { code:"B_DOUBLE_TO", suit:lb.strain };
    return { code:"B_DOUBLE_PEN" };
  }
  if(call.k==="R") return { code:"B_REDBL" };

  if(nobodyBidYet){
    if(S==="NT") return { code: call.level===1?"B_1NT":call.level===2?"B_2NT":"B_3NT", hcp };
    if(call.level===2 && S==="C") return { code:"B_2C", hcp };
    if(call.level===2) return { code:"B_WEAK2", hcp, suit:S };
    if(call.level===3) return { code:"B_PRE3", hcp, suit:S };
    if(S==="S"||S==="H") return { code:"B_1MAJ", hcp, suit:S, len:len[S] };
    return { code:"B_1MIN", hcp, suit:S };
  }
  if(ctx.partnerOpened && !ctx.iOpened){
    if(S==="NT" && call.level===4) return { code:"B_BLACKWOOD" };
    if(partnerOpen && partnerOpen.strain==="NT" && partnerOpen.level===1){
      if(S==="C" && call.level===2) return { code:"B_STAYMAN" };
      if((S==="D"||S==="H") && call.level===2) return { code:"B_TRANSFER", suit:(S==="D"?"H":"S") };
      if(S==="NT") return { code: call.level===2?"B_2NT_RESP":"B_3NT_RESP", hcp };
    }
    if(partnerOpen && partnerOpen.strain===S && S!=="NT")
      return { code:"B_RAISE", suit:S, level:call.level, sup:len[S], pts:ev.hcp+ev.lp };
    if(S==="NT") return { code: call.level===1?"B_1NT_RESP":call.level===2?"B_2NT_RESP":"B_3NT_RESP", hcp };
    return { code:"B_NEWSUIT", suit:S, len:len[S], hcp };
  }
  if(ctx.iOpened){
    if(S==="NT") return { code:"B_REBID_NT", hcp };
    if(partnerOpen && partnerOpen.strain===S) return { code:"B_RAISE", suit:S, level:call.level, sup:len[S], pts:ev.hcp+ev.lp };
    return { code:"B_REBID_SUIT", suit:S, len:len[S] };
  }
  if(ctx.oppsBid){
    if(S==="NT") return { code:"B_1NT_OVERCALL", hcp };
    return { code:"B_OVERCALL", suit:S, len:len[S], hcp };
  }
  return { code:"B_GENERIC", hcp, call:callLabel(call) };
}

// embedded default templates (overridable by window.BRIDGE_TEACHING)
const TEACH_DEFAULT = {
  bid: {
    B_PASS_OPEN:"With only {hcp} HCP you're below opening strength (about 12+). Pass.",
    B_PASS_RESP:"Partner opened, but {hcp} HCP opposite an opening bid isn't enough to look for game — so pass.",
    B_PASS_ADVANCE:"Partner has competed into the opponents' auction; with {hcp} HCP you've no fit to raise or suit to show, so pass.",
    B_PASS_COMPETE:"The opponents own this auction. With {hcp} HCP and no long suit worth an overcall (nor the shape for a takeout double), it's safer to pass than to act on nothing.",
    B_PASS_SETTLE:"You've already described this hand, and there's no fit or extra strength to chase. Pass and let the contract rest where partner can place it.",
    B_PASS_NEUTRAL:"This is a natural place to stop for your hand — pass rather than push the bidding any higher.",
    B_1NT:"{hcp} HCP and a balanced hand: 1NT pins your strength to a 15–17 range in one bid.",
    B_2NT:"{hcp} HCP, balanced — open 2NT (20–21).",
    B_3NT:"{hcp} HCP, balanced — open 3NT (25–27).",
    B_1MAJ:"{hcp} HCP with a {len}-card {suit} suit — open one of your five-card major so partner can find the fit.",
    B_1MIN:"{hcp} HCP but no five-card major, so open your better minor ({suit}) and await partner's response.",
    B_2C:"About {hcp} HCP — too strong for a one-bid, so open the artificial, game-forcing 2\u2663.",
    B_WEAK2:"A six-card {suit} suit but only {hcp} HCP — a weak two robs the opponents of bidding room.",
    B_PRE3:"A seven-card {suit} suit and only {hcp} HCP — preempt at the three level to crowd the auction.",
    B_RAISE:"{sup}-card support and about {pts} points — raise partner to {level} of {suit} to show the fit and your strength.",
    B_1NT_RESP:"{hcp} HCP with no fit and nothing to show at the one level — respond 1NT.",
    B_2NT_RESP:"{hcp} HCP, balanced — invite game with 2NT.",
    B_3NT_RESP:"{hcp} HCP, balanced with stoppers — bid the game, 3NT.",
    B_NEWSUIT:"Show your {len}-card {suit} suit: {hcp}+ HCP, and a new suit forces partner to bid again.",
    B_STAYMAN:"2\u2663 is Stayman, asking partner whether they hold a four-card major.",
    B_TRANSFER:"A Jacoby transfer: it tells partner to bid {suit}, keeping the strong hand hidden as declarer.",
    B_BLACKWOOD:"Slam is in range — 4NT is Blackwood, asking partner how many aces they hold.",
    B_DOUBLE_TO:"A takeout double: opening values, shortness in {suit}, and support for the other suits — asking partner to choose.",
    B_DOUBLE_PEN:"Double for penalty — you expect to beat this contract.",
    B_REDBL:"Redouble — you're confident this contract is yours.",
    B_REBID_NT:"{hcp} HCP, balanced — rebid no-trump to pin down shape and range.",
    B_REBID_SUIT:"Rebid your {len}-card {suit} to show the extra length and let partner place the contract.",
    B_OVERCALL:"Overcall {suit}: a sound {len}-card suit and about {hcp} HCP — competing, and suggesting a lead.",
    B_1NT_OVERCALL:"{hcp} HCP, balanced, their suit stopped — overcall 1NT.",
    B_GENERIC:"{call} is the standard call with about {hcp} HCP and this shape.",
  },
  play: {
    ONLY:"Only one legal card — you must follow suit.",
    LEAD_SEQ:"Top of a sequence in {suit}: the {top} is a safe lead that promotes your lower cards into winners.",
    LEAD_4TH:"Fourth-best from your longest suit ({suit}): the classic lead to develop length — and it lets partner use the Rule of 11 to place the missing cards.",
    LEAD_ACE:"Against a suit contract you don't underlead an ace, so lead the ace of {suit} itself.",
    LEAD_LOW:"Lead a low {suit} — a quiet, constructive choice when you have no sequence or clear suit to attack.",
    D_CONTINUE:"Partner encouraged {suit} with an earlier signal — lead it again to develop the suit they like.",
    D_RETURN:"Return partner's suit: they opened {suit}, so leading it back helps set up their long cards and honours.",
    D_ROLLOUT:"Switch to {suit}: testing each suit against the hands partner and declarer could hold, leading {suit} gives declarer the fewest tricks on average.",
    DECL_DRAW:"You're declarer with the top trump: play the {card} to draw the defenders' trumps so they can't ruff your winners.",
    DECL_CASH:"The {card} is the highest {suit} still out — cash your sure winner.",
    DECL_FINESSE:"Lead low toward your {honor} of {suit}: if the missing higher honour sits before it, the {honor} scores. That's a finesse — a free shot at an extra trick.",
    DECL_RUFF:"Lead your losing {suit} so the other hand can ruff it — turning a loser into a trick with a trump.",
    DECL_RUFF_FIRST:"Ruff before drawing trumps: lead your losing {suit} now so the short hand can trump it while it still holds trumps.",
    DECL_CROSS:"Cross to the other hand in {suit} so you can lead toward your tenace and take the finesse from the correct side.",
    DECL_ESTABLISH:"Lead low in your long {suit} to knock out the defenders' stoppers and set up later winners.",
    DECL_DEVELOP_KO:"Lead the {card} of {suit} \u2014 top of your sequence \u2014 to drive out the defenders' high honour and promote your remaining {suit} into winners.",
    DECL_PLAN:"Rolling each lead out against the defenders' likely holdings, the {card} of {suit} wins the most tricks on average from here.",
    DECL_FOLLOW_PLAN:"Testing each card against the defenders' likely holdings, playing the {card} of {suit} here wins the most tricks on average.",
    DECL_FOLLOW_RUFF:"Ruff with the {card}: rolling the options out, trumping this trick wins more tricks than discarding.",
    DECL_FOLLOW_DISCARD:"Let go of the {card}: rolling it out, discarding {suit} here costs the fewest tricks.",
    DECL_FOLLOW_COVER:"Cover with the {card}: testing the layouts, playing your honour now promotes a trick more often than ducking.",
    DECL_FOLLOW_WIN:"Win it with the {card}: rolling each line out, taking the trick here beats ducking on average.",
    DECL_FOLLOW_DUCK:"Play low, the {card}: rolling it out, ducking this trick keeps more tricks than rising.",
    DEF_FOLLOW_RUFF:"Ruff with the {card}: rolling the layouts out, trumping declarer's trick beats it more often than discarding.",
    DEF_FOLLOW_DISCARD:"Let go of the {card}: rolling it out, discarding {suit} holds declarer to the fewest tricks.",
    DEF_FOLLOW_WIN:"Take it with the {card}: rolling each line out, winning this trick holds declarer to the fewest tricks.",
    DEF_FOLLOW_DUCK:"Play low, the {card}: rolling it out, ducking holds declarer to fewer tricks than rising.",
    F_2ND_LOW:"Second hand low in {suit}: no need to spend an honour before seeing what partner and declarer do.",
    F_SPLIT:"Split your honours: with touching honours in {suit} and a low card led, play the lower one to force out a top card and promote the other.",
    DECL_UNBLOCK:"Unblock: cash the high {suit} from the short hand first so it does not trap the long suit behind it.",
    F_3RD_HIGH:"Third hand high — the {card} is the cheapest card that can win, forcing out the defenders' higher cards.",
    F_FINESSE_WIN:"Finish the finesse: play the {card}, not the ace. If the missing honour is trapped, the {card} wins and you score an extra {suit} trick.",
    F_WIN_CHEAP:"Win the trick as cheaply as you can with the {card}, saving your higher cards.",
    F_DUCK_PARTNER:"Partner is already winning the trick — play low in {suit} and keep your strength for later.",
    F_CANT:"You can't beat what's on the table in {suit}, so play low and hold your honours.",
    F_COVER:"Cover an honour with an honour: play the {card} so your side's lower cards are promoted into winners.",
    F_HOLDUP:"Hold up: duck this round of {suit} and keep your ace, cutting the defenders' link to their long suit.",
    F_DUCK_HOLDUP:"Defensive hold-up: duck your ace of {suit} to cut declarer off from dummy's long suit — win it once declarer is out.",
    F_HOLDUP_WIN:"Take the ace of {suit} now: partner's count shows declarer has run out, so winning here strands dummy's long suit.",
    F_ATT_HI:"Attitude signal: the high {card} of {suit} encourages partner to keep leading the suit.",
    F_ATT_LO:"Attitude signal: the low {card} of {suit} discourages the suit — partner should look elsewhere.",
    F_CNT_HI:"Count signal: the high {card} starts a high-low to show an even number of {suit}.",
    F_CNT_LO:"Count signal: the low {card} shows an odd number of {suit} (low-high).",
    RUFF:"You're out of {suit} — ruff with a low trump to win the trick and save your higher trumps.",
    DISCARD:"Can't follow and don't want to ruff — throw a low {suit}, your safest discard.",
  },
  glossary: {
    "hcp":"High-card points: Ace 4, King 3, Queen 2, Jack 1 — the main measure of strength. The deck holds 40, so an average hand has 10.",
    "balanced":"A hand with no void or singleton and at most one doubleton (4-3-3-3, 4-4-3-2, 5-3-3-2). Ideal for no-trump bids.",
    "major":"The spade and heart suits. Game needs only 10 tricks and scores well, so major fits are prized.",
    "minor":"The club and diamond suits. Game needs 11 tricks, so players often steer to no-trump instead.",
    "no-trump":"A contract with no trump suit; the highest card of the suit led simply wins each trick.",
    "trump":"The suit named by the contract. Any trump beats any card of the other three suits.",
    "fit":"A suit in which the partnership holds eight or more cards together — enough to choose it as trumps.",
    "support":"How many cards you hold in the suit partner bid; three or four is enough to raise.",
    "raise":"Bidding more of the suit partner already named, showing a fit and your strength.",
    "sequence":"Two or more touching honours (e.g. K-Q-J). Leading the top of one is safe and builds tricks.",
    "fourth-best":"Leading the fourth-highest card of your longest suit — a standard opening lead that develops length.",
    "opening lead":"The first card of the play, made by the defender to declarer's left before dummy is exposed.",
    "finesse":"Trying to win a trick with a card that isn't top by playing after an opponent, hoping a missing honour lies favourably.",
    "ruff":"Playing a trump on a suit you cannot follow, to win the trick.",
    "draw trumps":"Leading trumps repeatedly to strip them from the defenders so they can't ruff your winners.",
    "declarer":"The player who plays both their own hand and dummy, trying to make the contract.",
    "dummy":"Declarer's partner, whose hand is laid face-up and played by declarer.",
    "defender":"Either opponent of declarer; the defenders try to defeat the contract.",
    "overcall":"A bid made after an opponent opens — competing for the contract and suggesting a lead.",
    "takeout double":"A double asking partner to choose a suit, showing opening values and support for the unbid suits.",
    "penalty double":"A double made expecting to defeat the opponents' contract for extra points.",
    "redouble":"A call after an opponent's double that raises the stakes when you expect to make the contract.",
    "stayman":"A 2♣ response to 1NT asking opener whether they hold a four-card major.",
    "transfer":"A bid telling partner to bid the next suit up, so the stronger hand becomes hidden declarer (a Jacoby transfer).",
    "blackwood":"A 4NT bid asking partner how many aces they hold, used when exploring a slam.",
    "weak two":"An opening 2♦/2♥/2♠ showing a six-card suit and only 5–10 HCP, made to steal bidding space.",
    "preempt":"A high opening on a long, weak hand, made to crowd the opponents out of the auction.",
    "stopper":"A holding that halts a suit at no-trump (an Ace, or a guarded King, etc.).",
    "vulnerable":"Having already won a game this rubber; bonuses and penalties are larger when vulnerable.",
    "game":"A contract worth 100+ trick points (3NT, 4♥/4♠, 5♣/5♦). Two games win the rubber.",
    "part-score":"A contract below game; several can add up to a game across successive deals.",
    "slam":"A contract for 12 tricks (small slam) or all 13 (grand slam), earning a large bonus.",
    "rubber":"A match won by the first side to complete two games, worth a 500 or 700 bonus.",
    "book":"The first six tricks. A contract's level is how many tricks beyond book you must take.",
    "honour":"An Ace, King, Queen, Jack or Ten; a run of trump honours in one hand can earn a bonus.",
    "second hand low":"A defensive rule of thumb: playing second to a trick, usually play low and wait.",
    "third hand high":"A defensive rule of thumb: playing third to a trick, play high to help win it.",
    "discard":"Playing a card of another suit when you can't follow and choose not to ruff.",
    "attitude signal":"A defender's spot card that shows liking for the suit partner led: a high card encourages continuing, a low card discourages it.",
    "suit-preference":"A discard or spot card whose height points partner toward a suit: a high card likes the suit discarded (or asks for the higher side suit), a low card discourages it.",
    "lead up to weakness":"Leading a suit toward the weak hand rather than into a tenace — avoid feeding declarer a free finesse by leading into dummy's A-Q.",
    "count signal":"A defender's spot card that shows the parity of their length: high-then-low shows an even number, low-then-high shows odd. Given mainly on declarer's leads.",
    "hold-up":"Declarer refusing to win an early round of a suit at no-trump, keeping a stopper to cut the defenders' link to their long suit.",
    "defensive hold-up":"A defender ducking their sole stopper (the ace) for a round or two so that when declarer runs out of the suit, dummy's long cards are stranded without an entry.",
    "cover an honour":"Playing a higher honour on an honour led by an opponent, to promote your side's lower cards into winners.",
    "tenace":"Two non-touching honours such as A-Q or K-J, worth an extra trick if led toward so the missing honour is trapped.",
    "entry":"A card that wins a trick in a particular hand, letting declarer reach that hand to lead from it — often needed to take a finesse from the right side.",
    "contract":"The final bid: how many tricks the declaring side must win, and in which strain.",
    "auction":"The bidding, in which the four players compete to name the contract.",
    "level":"The number in a bid; add six to get the tricks required (4♠ = 6 + 4 = 10 tricks).",
    "opening bid":"The first bid that names a suit or no-trump. It shows about 12 or more points (or a good long suit) and begins describing the hand to partner.",
    "negative double":"A double by responder after partner opens and the next opponent overcalls. It is for takeout — showing the unbid major(s) with enough values to compete — not for penalty.",
    "Jacoby transfer":"A response to 1NT that names the suit just below your real major (2♦ shows hearts, 2♥ shows spades). Opener bids your suit, so the strong hand becomes declarer and stays hidden.",
    "reverse":"Opener's rebid of a new, higher-ranking suit at the two level (e.g. 1♦ then 2♥). It forces partner to the three level to give preference, so it promises extra strength — about 17+ points.",
    "limit raise":"A jump raise of partner's suit (e.g. 1♥–3♥) showing roughly 10–11 points with a fit. It is invitational to game, not forcing.",
    "single raise":"Raising partner's suit by one level (e.g. 1♥–2♥), showing a fit and about 6–10 points.",
    "Michaels":"A cuebid of the opponent's opening suit that shows a two-suiter — both majors over a minor, or the other major plus a minor over a major (at least 5-5).",
    "unusual notrump":"A jump to 2NT over an opponent's opening showing at least 5-5 in the two lowest unbid suits — usually the two minors.",
    "Cappelletti":"A set of overcalls for competing against an opponent's 1NT opening: double shows a strong balanced hand, and the two-level bids show one- or two-suited hands.",
    "Jordan":"A 2NT response over an opponent's takeout double of partner's major, showing a limit raise or better (10+ points with support). It lets a direct raise be merely competitive.",
    "fourth suit forcing":"When three suits have been bid, bidding the fourth is artificial and forcing. It doesn't promise that suit — it asks partner for more, often a stopper for no-trump.",
    "forcing":"A bid partner is not allowed to pass. The partnership must keep bidding until the message is complete.",
    "game-forcing":"A bid that commits the partnership to reach at least game — the auction cannot stop in a part-score.",
    "Gerber":"A 4♣ bid that asks partner how many aces they hold, used mainly after a no-trump bid to explore slam.",
    "cuebid":"A bid of a suit an opponent has bid. It is artificial and forcing — used to show a big hand, a two-suiter (see Michaels), or a fit plus a control.",
    "Jacoby 2NT":"A 2NT response to partner's 1-of-a-major opening showing a game-forcing raise with four-card support, asking opener to describe shape.",
    "control bid":"Bidding a suit where you hold first- or second-round control (an ace or void, a king or singleton) on the way to slam, to show partner where your strength lies.",
    "trick":"One card played by each of the four players in turn. Thirteen tricks are contested each deal; the highest trump — or the highest card of the led suit — wins.",
    "follow suit":"Playing a card of the suit that was led. You must follow suit if you can; only when void may you discard or ruff.",
    "led suit":"The suit of the first card played to a trick. Everyone must follow it if able.",
    "artificial":"A bid whose meaning is conventional rather than natural — it doesn't promise the suit named (e.g. Stayman, a transfer, or fourth suit forcing).",
    "invitational":"A bid inviting partner to bid game with a little extra, but allowing them to pass with a minimum. Not forcing.",
    "shortage":"A short holding — a void (none), singleton (one) or doubleton (two) — which adds ruffing value when partner has a fit.",
    "tenace":"Two high cards with a gap, such as A-Q or K-J. Led toward, a tenace can trap a missing honour and win an extra trick by finesse.",
    "top trick":"A sure winner you can cash at once without giving up the lead. Counting these is the first step of the plan.",
    "establish":"To develop extra winners in a suit — by knocking out the defenders' higher cards or exhausting the suit — until your remaining cards are good.",
    "establishment":"Developing a suit until your lower cards become winners, by forcing out higher cards or running the suit once it breaks.",
    "ruffing":"Trumping a loser to win a trick; the extra tricks come from ruffing in the hand with fewer trumps, usually dummy.",
    "hold-up":"Refusing to win an early trick — typically declining to take an ace — to cut the defenders' link in that suit.",
    "unblock":"Playing or overtaking the high cards from the short hand first so a long suit does not get stuck with its winners out of reach.",
    "promote":"To turn a lower card into a winner by driving out the higher cards that beat it.",
    "promotion":"Turning a lower card into a winner by forcing out the cards that outrank it.",
    "length":"Extra tricks from a long suit: once the other players are void in it, your remaining low cards win by default.",
    "long card":"A low card that becomes a winner once every other player is out of the suit.",
    "entry":"A card that wins a trick in a particular hand, giving you access to that hand's winners.",
    "entries":"Cards that let you reach a particular hand to cash its winners; managing entries is central to any plan.",
    "loser":"A card that will lose a trick because the defenders still hold higher ones.",
    "winner":"A card that will win its trick — either a top card or one you have established.",
    "cover":"Playing a higher honour on an opponent's honour, to promote your side's lower cards — \"cover an honour with an honour.\"",
    "duck":"Deliberately playing low and letting the opponents win a trick you could take, for timing or to preserve communication.",
    "overtake":"Playing a higher card on your side's own winner to gain the lead in the hand you need next, often to unblock or reach length.",
    "drop":"Felling a missing honour by cashing top cards so it falls under them — the alternative to taking a finesse.",
  },
};
function teachTable(kind){
  const ext = (typeof window!=="undefined" && window.BRIDGE_TEACHING && window.BRIDGE_TEACHING[kind]) || null;
  return { ext, def:TEACH_DEFAULT[kind] };
}
function fillTpl(tpl, p){ return tpl.replace(/\{(\w+)\}/g, (m,k)=> (p[k]!=null?String(p[k]):m)); }
function whyText(kind, why){
  if(!why || !why.code) return "";
  const { ext, def } = teachTable(kind);
  const tpl = (ext && ext[why.code]) || def[why.code];
  if(!tpl) return "";
  const p = { ...why };
  if(p.suit && SUIT_WORD[p.suit]) p.suit = SUIT_WORD[p.suit];
  return fillTpl(tpl, p);
}
function getGlossary(){
  const ext = (typeof window!=="undefined" && window.BRIDGE_TEACHING && window.BRIDGE_TEACHING.glossary) || null;
  return ext || TEACH_DEFAULT.glossary;
}
// suggestion + explanation bundles for the UI
function suggestBidWhy(s, seat){
  const call = suggestBid(s, seat);
  return { call, text: whyText("bid", explainBid(s.hands[seat], s.calls, s.dealer, seat, call)) };
}
function suggestPlayWhy(s, seat){
  let r;
  try{ r = PLY.chooseCardWhy(playCtx(s, seat)); }catch(_){ r=null; }
  const legal = ENG.legalPlays(s.hands[seat], s.trick.length?s.ledSuit:null);
  const card = (r && r.card) || legal[0];
  return { card, text: r ? whyText("play", r.why) : "" };
}


//#region gen (auto — removed when bundled to a single bridge.jsx)
export { SUIT_WORD, TEACH_DEFAULT, explainBid, fillTpl, getGlossary, suggestBidWhy, suggestPlayWhy, teachTable, whyText };
//#endregion gen
